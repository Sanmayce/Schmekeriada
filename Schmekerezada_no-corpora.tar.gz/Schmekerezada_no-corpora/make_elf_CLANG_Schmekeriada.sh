clang -msse4.2 -S -O3 -m64 -fomit-frame-pointer Schmekeriada.c -o Schmekerezada_CLANG_16.0.1_SSE4.2_TetraThread.elf.asm -D_N_HIGH_PRIORITY_GCC -Drev5bypass -fopenmp -DCommence_OpenMP -D_POSIX_ENVIRONMENT_
clang -msse4.2 -O3 -m64 -fomit-frame-pointer Schmekeriada.c -o Schmekerezada_CLANG_16.0.1_SSE4.2_TetraThread.elf -D_N_HIGH_PRIORITY_GCC -Drev5bypass -fopenmp -DCommence_OpenMP -D_POSIX_ENVIRONMENT_

