#include <stdint.h> // uint8_t needed
//typedef unsigned char uint8_t;
//typedef unsigned short uint16_t;
//typedef unsigned int uint32_t;

#define KAZE_toupper(c) ( (((c) >= 'a') && ((c) <= 'z')) ? ((c) - 'a' + 'A') : (c) )
#define KAZE_tolower(c) ( (((c) >= 'A') && ((c) <= 'Z')) ? ((c) - 'A' + 'a') : (c) )

#define _rotl_KAZE(x, n) (((x) << (n)) | ((x) >> (32-(n))))
#define HashSizeInBits 27 //512MB
#define ReportAtEvery (1<<HashSizeInBits)-1 //1000000

int PrintTheFirstKTvariants=0;

// Compile line:
// icl /Ox /TcHASH_linearspeed_FURY.c /FaHASH_linearspeed_FURY_Intel_IA-32_12 /FAcs
// 
// Fragment from the .COD file, Intel(R) C++ Compiler XE for applications running on IA-32, Version 12.1.1.258 Build 20111011:
// 
// .B4.4:                          ; Preds .B4.3 .B4.4
// 
// ;;; 		hash32 = (hash32 ^ (_rotl_KAZE(*(uint32_t *)(p+0),5) ^ *(uint32_t *)(p+0+Second_Line_Offset))) * PRIME;        
// 
//   0300c 8b 2b            mov ebp, DWORD PTR [ebx]               
//   0300e c1 c5 05         rol ebp, 5                             
//   03011 33 2c 33         xor ebp, DWORD PTR [ebx+esi]           
//   03014 33 fd            xor edi, ebp                           
// 
// ;;; 		hash32B = (hash32B ^ (_rotl_KAZE(*(uint32_t *)(p+4+Second_Line_Offset),5) ^ *(uint32_t *)(p+4))) * PRIME;        
// 
//   03016 8b 6c 33 04      mov ebp, DWORD PTR [4+ebx+esi]         
//   0301a c1 c5 05         rol ebp, 5                             
//   0301d 33 6b 04         xor ebp, DWORD PTR [4+ebx]             
//   03020 33 cd            xor ecx, ebp                           
// 
// ;;; 		hash32C = (hash32C ^ (_rotl_KAZE(*(uint32_t *)(p+8),5) ^ *(uint32_t *)(p+8+Second_Line_Offset))) * PRIME;        
// 
//   03022 8b 6b 08         mov ebp, DWORD PTR [8+ebx]             
//   03025 c1 c5 05         rol ebp, 5                             
//   03028 33 6c 33 08      xor ebp, DWORD PTR [8+ebx+esi]         
//   0302c 83 c3 0c         add ebx, 12                            
//   0302f 33 c5            xor eax, ebp                           
//   03031 69 ff e7 d3 0a 
//         00               imul edi, edi, 709607                  
//   03037 69 c9 e7 d3 0a 
//         00               imul ecx, ecx, 709607                  
//   0303d 69 c0 e7 d3 0a 
//         00               imul eax, eax, 709607                  
//   03043 4a               dec edx                                
//   03044 75 c6            jne .B4.4 ; Prob 82%                   
// 
// The main loop is 03044-0300c+2 = 58 bytes.



// farolito: [Spanish, paper lantern, diminutive of farol, lantern, from faro, lighthouse, lantern, from Latin pharus, from Pharus Pharos.]
// Stride 32 = 4x(4+4), HalfStride = (4*sizeof(uint32_t))
// Stride 8 = 4x2, HalfStride = (2*sizeof(uint16_t))
uint32_t FNV1A_farolito(const char *str, uint32_t wrdlen)
{
	const uint32_t PRIME = 591798841;
	uint32_t hash32 = 2166136261;
	uint32_t hash32B = 2166136261;
	uint32_t hash32C = 2166136261;
	uint32_t hash32D = 2166136261;
	const char *p = str;
	uint32_t Loop_Counter;
	uint32_t Second_Line_Offset;
if (wrdlen >= 2*(4*sizeof(uint32_t))) {
	Loop_Counter = (wrdlen>>5);
	Loop_Counter++;
	Second_Line_Offset = wrdlen-(Loop_Counter)*((4*sizeof(uint32_t)));
	for(; Loop_Counter; Loop_Counter--, p += (4*sizeof(uint32_t))) {
		hash32 = (hash32 ^ (_rotl_KAZE(*(uint32_t *)(p+0),27) ^ *(uint32_t *)(p+0+Second_Line_Offset))) * PRIME;        
		hash32B = (hash32B ^ (_rotl_KAZE(*(uint32_t *)(p+4+Second_Line_Offset),27) ^ *(uint32_t *)(p+4))) * PRIME;        
		hash32C = (hash32C ^ (_rotl_KAZE(*(uint32_t *)(p+8),27) ^ *(uint32_t *)(p+8+Second_Line_Offset))) * PRIME;        
		hash32D = (hash32D ^ (_rotl_KAZE(*(uint32_t *)(p+12+Second_Line_Offset),27) ^ *(uint32_t *)(p+12))) * PRIME;        
	}
	hash32 = _rotl_KAZE((hash32 ^ _rotl_KAZE(hash32B,16)) * PRIME,24);
	hash32 = _rotl_KAZE((hash32 ^ _rotl_KAZE(hash32C,16)) * PRIME,16);
	hash32 = _rotl_KAZE((hash32 ^ _rotl_KAZE(hash32D,16)) * PRIME,8);
} else if (wrdlen >= 2*(2*sizeof(uint16_t))) {
	Loop_Counter = (wrdlen>>2);
	Loop_Counter++;
	Second_Line_Offset = wrdlen-(Loop_Counter)*((2*sizeof(uint16_t)));
	for(; Loop_Counter; Loop_Counter--, p += (2*sizeof(uint16_t))) {
		hash32 = (hash32 ^ *(uint16_t*)(p+0)) * PRIME;
		hash32B = (hash32B ^ *(uint16_t*)(p+0+Second_Line_Offset)) * PRIME;
		hash32C= (hash32C ^ *(uint16_t*)(p+0+2)) * PRIME;
		hash32D = (hash32D ^ *(uint16_t*)(p+0+Second_Line_Offset+2)) * PRIME;
	}
	hash32 = _rotl_KAZE((hash32 ^ _rotl_KAZE(hash32B,16)) * PRIME,24);
	hash32 = _rotl_KAZE((hash32 ^ _rotl_KAZE(hash32C,16)) * PRIME,16);
	hash32 = _rotl_KAZE((hash32 ^ _rotl_KAZE(hash32D,16)) * PRIME,8);
} else {
	// Cases: 0,1,2,3,4,5,6,7:
	if (wrdlen & 2*sizeof(uint16_t)) {
		hash32 = (hash32 ^ *(p+0)) * PRIME;
		hash32 = (hash32 ^ *(p+1)) * PRIME;
		hash32 = (hash32 ^ *(p+2)) * PRIME;
		hash32 = (hash32 ^ *(p+3)) * PRIME;
		p += 2*sizeof(uint16_t);
	}
	if (wrdlen & sizeof(uint16_t)) {
		hash32 = (hash32 ^ *(p+0)) * PRIME;
		hash32 = (hash32 ^ *(p+1)) * PRIME;
		p += sizeof(uint16_t);
	}
	if (wrdlen & 1) {
		hash32 = (hash32 ^ *(p+0)) * PRIME;
	}
}
	return hash32 ^ (hash32 >> 16);
}
// FNV1A_farolito's 32[+] main loop, 045ac-04560+2 = 78bytes:
/*
  04553 8d b6 00 00 00 
        00 8d bc 27 00 
        00 00 00         ALIGN     16
.B9.4:
;;; 	for(; Loop_Counter; Loop_Counter--, p += (4*sizeof(uint32_t))) {
;;; 		hash32 = (hash32 ^ (_rotl_KAZE(*(uint32_t *)(p+0),27) ^ *(uint32_t *)(p+0+Second_Line_Offset))) * PRIME;        

  04560 8b 08            mov ecx, DWORD PTR [eax]               
  04562 c1 c1 1b         rol ecx, 27                            
  04565 33 0c 10         xor ecx, DWORD PTR [eax+edx]           
  04568 33 e9            xor ebp, ecx                           

;;; 		hash32B = (hash32B ^ (_rotl_KAZE(*(uint32_t *)(p+4+Second_Line_Offset),27) ^ *(uint32_t *)(p+4))) * PRIME;        

  0456a 8b 4c 10 04      mov ecx, DWORD PTR [4+eax+edx]         
  0456e c1 c1 1b         rol ecx, 27                            
  04571 33 48 04         xor ecx, DWORD PTR [4+eax]             
  04574 33 d9            xor ebx, ecx                           

;;; 		hash32C = (hash32C ^ (_rotl_KAZE(*(uint32_t *)(p+8),27) ^ *(uint32_t *)(p+8+Second_Line_Offset))) * PRIME;        

  04576 8b 48 08         mov ecx, DWORD PTR [8+eax]             
  04579 c1 c1 1b         rol ecx, 27                            
  0457c 33 4c 10 08      xor ecx, DWORD PTR [8+eax+edx]         
  04580 33 f1            xor esi, ecx                           

;;; 		hash32D = (hash32D ^ (_rotl_KAZE(*(uint32_t *)(p+12+Second_Line_Offset),27) ^ *(uint32_t *)(p+12))) * PRIME;        

  04582 8b 4c 10 0c      mov ecx, DWORD PTR [12+eax+edx]        
  04586 c1 c1 1b         rol ecx, 27                            
  04589 33 48 0c         xor ecx, DWORD PTR [12+eax]            
  0458c 83 c0 10         add eax, 16                            
  0458f 33 f9            xor edi, ecx                           
  04591 69 ed 39 22 46 
        23               imul ebp, ebp, 591798841               
  04597 69 db 39 22 46 
        23               imul ebx, ebx, 591798841               
  0459d 69 f6 39 22 46 
        23               imul esi, esi, 591798841               
  045a3 69 ff 39 22 46 
        23               imul edi, edi, 591798841               
  045a9 ff 0c 24         dec DWORD PTR [esp]                    
  045ac 75 b2            jne .B9.4
*/
// FNV1A_farolito's 8[+] main loop, 0194b-01918+2 = 53bytes:
/*
.B4.2:
;;; 	for(; Loop_Counter; Loop_Counter--, p += (2*sizeof(uint16_t))) {
;;; 		hash32 = (hash32 ^ *(uint16_t*)(p+0)) * PRIME;

  01918 0f b7 2a         movzx ebp, WORD PTR [edx]              
  0191b 33 cd            xor ecx, ebp                           

;;; 		hash32B = (hash32B ^ *(uint16_t*)(p+0+Second_Line_Offset)) * PRIME;

  0191d 0f b7 6a fc      movzx ebp, WORD PTR [-4+edx]           
  01921 33 fd            xor edi, ebp                           

;;; 		hash32C= (hash32C ^ *(uint16_t*)(p+0+2)) * PRIME;

  01923 0f b7 6a 02      movzx ebp, WORD PTR [2+edx]            
  01927 33 f5            xor esi, ebp                           

;;; 		hash32D = (hash32D ^ *(uint16_t*)(p+0+Second_Line_Offset+2)) * PRIME;

  01929 0f b7 6a fe      movzx ebp, WORD PTR [-2+edx]           
  0192d 33 dd            xor ebx, ebp                           
  0192f 69 c9 39 22 46 
        23               imul ecx, ecx, 591798841               
  01935 83 c2 04         add edx, 4                             
  01938 69 ff 39 22 46 
        23               imul edi, edi, 591798841               
  0193e 69 f6 39 22 46 
        23               imul esi, esi, 591798841               
  01944 69 db 39 22 46 
        23               imul ebx, ebx, 591798841               
  0194a 48               dec eax                                
  0194b 75 cb            jne .B4.2
.B4.3:
;;; 	}
*/



// FNV1A_marline aka FNV1A_YoshimitsuTRIADii revision 2, copyleft 2013-Jul-09, Kaze.
// marline: A light rope made of two loosely twisted strands.
// [Middle English, from Middle Dutch marlijn, alteration (influenced by lijn, line), of marling from marren, to tie.]
#define ROLInBits 27 // 5 in r.1; Caramba: it should be ROR by 5 not ROL, from the very beginning the idea was to mix two bytes by shifting/masking the first 5 'noisy' bits (ASCII 0-31 symbols).
uint32_t FNV1A_marline(const char *str, uint32_t wrdlen)
{
    // r2:
    const uint32_t PRIME = 591798841;

    // 709607:
    // D:\_KAZE\YoYo_r2>YoYo_r2.exe 4andabove_Gamera17LBL.2.txt.sorted 25
    // FNV1A_YoshimitsuTRIADii    : Keys = 00,000,000,000,037,030,186; 000,000,006 x MAXcollisionsAtSomeSlots = 0,000,000,010; HASHfreeSLOTS = 0,011,133,920;
    // CRC32 0x8F6E37A0           : Keys = 00,000,000,000,037,030,186; 000,000,001 x MAXcollisionsAtSomeSlots = 0,000,000,011; HASHfreeSLOTS = 0,011,127,363;
    // D:\_KAZE\YoYo_r2>YoYo_r2.exe 4andabove_Gamera17LBL.2.txt.sorted 26
    // FNV1A_YoshimitsuTRIADii    : Keys = 00,000,000,000,037,030,186; 000,000,002 x MAXcollisionsAtSomeSlots = 0,000,000,009; HASHfreeSLOTS = 0,038,654,435;
    // CRC32 0x8F6E37A0           : Keys = 00,000,000,000,037,030,186; 000,000,001 x MAXcollisionsAtSomeSlots = 0,000,000,009; HASHfreeSLOTS = 0,038,648,206;

    // 591798841:
    // D:\_KAZE\YoYo_r2>YoYo_r2.exe 4andabove_Gamera17LBL.2.txt.sorted 25
    // FNV1A_YoshimitsuTRIADii    : Keys = 00,000,000,000,037,030,186; 000,000,003 x MAXcollisionsAtSomeSlots = 0,000,000,011; HASHfreeSLOTS = 0,011,124,498;
    // CRC32 0x8F6E37A0           : Keys = 00,000,000,000,037,030,186; 000,000,001 x MAXcollisionsAtSomeSlots = 0,000,000,011; HASHfreeSLOTS = 0,011,127,363;
    // D:\_KAZE\YoYo_r2>YoYo_r2.exe 4andabove_Gamera17LBL.2.txt.sorted 26
    // FNV1A_YoshimitsuTRIADii    : Keys = 00,000,000,000,037,030,186; 000,000,003 x MAXcollisionsAtSomeSlots = 0,000,000,009; HASHfreeSLOTS = 0,038,646,657;
    // CRC32 0x8F6E37A0           : Keys = 00,000,000,000,037,030,186; 000,000,001 x MAXcollisionsAtSomeSlots = 0,000,000,009; HASHfreeSLOTS = 0,038,648,206;

    uint32_t hash32 = 2166136261;
    uint32_t hash32B = 2166136261;
    uint32_t hash32C = 2166136261;
    const char *p = str;
    uint32_t Loop_Counter;
    uint32_t Second_Line_Offset;

if (wrdlen >= 24) {
    Loop_Counter = (wrdlen/24);
    Loop_Counter++;
    //if (wrdlen >= 128 && Loop_Counter%4) Loop_Counter += 4-(Loop_Counter%4); // x01+3, x10+2, x11+1
    if (wrdlen >= 128 && (Loop_Counter&3)) Loop_Counter += 4-(Loop_Counter&3); // x01+3, x10+2, x11+1
    Second_Line_Offset = wrdlen-(Loop_Counter)*(3*4); // GRMBL: when (p%16==0 && wrdlen%16==0) && (Loop_Counter%4!=0) Second_Line_Offset could be misaligned since 12 lacks 16/48/96/192 divisibility, could be aligned by prefixing 3[-] 3*4 pairs i.e. adding 36|24|12 bytes.
    // When wrdlen is 128:
    // Loop_Counter: 5+1+2=8
    // Second_Line_Offset: 128-(5+1+2)*(3*4)=32
    for(; Loop_Counter; Loop_Counter--, p += 3*sizeof(uint32_t)) {
		hash32 = (hash32 ^ (_rotl_KAZE(*(uint32_t *)(p+0),ROLInBits) ^ *(uint32_t *)(p+0+Second_Line_Offset))) * PRIME;        
		hash32B = (hash32B ^ (_rotl_KAZE(*(uint32_t *)(p+4+Second_Line_Offset),ROLInBits) ^ *(uint32_t *)(p+4))) * PRIME;        
		hash32C = (hash32C ^ (_rotl_KAZE(*(uint32_t *)(p+8),ROLInBits) ^ *(uint32_t *)(p+8+Second_Line_Offset))) * PRIME;        
    }
		hash32 = (hash32 ^ _rotl_KAZE(hash32C,ROLInBits) ) * PRIME;
} else {
    // 1111=15; 10111=23
    if (wrdlen & 4*sizeof(uint32_t)) {	
		//hash32 = (hash32 ^ (_rotl_KAZE(*(uint32_t *)(p+0),ROLInBits) ^ *(uint32_t *)(p+4))) * PRIME;        
		//hash32B = (hash32B ^ (_rotl_KAZE(*(uint32_t *)(p+8),ROLInBits) ^ *(uint32_t *)(p+12))) * PRIME;        
		// r2:
		hash32 = (hash32 ^ (*(uint32_t *)(p+0))) * PRIME;        
		hash32B = (hash32B ^ (*(uint32_t *)(p+8))) * PRIME;        
		hash32 = (hash32 ^ (*(uint32_t *)(p+4))) * PRIME;        
		hash32B = (hash32B ^ (*(uint32_t *)(p+12))) * PRIME;        
		p += 8*sizeof(uint16_t);
    }
    // Cases: 0,1,2,3,4,5,6,7,...,15
    if (wrdlen & 2*sizeof(uint32_t)) {
		hash32 = (hash32 ^ *(uint32_t*)(p+0)) * PRIME;
		hash32B = (hash32B ^ *(uint32_t*)(p+4)) * PRIME;
		p += 4*sizeof(uint16_t);
    }
    // Cases: 0,1,2,3,4,5,6,7
    if (wrdlen & sizeof(uint32_t)) {
		hash32 = (hash32 ^ *(uint16_t*)(p+0)) * PRIME;
		hash32B = (hash32B ^ *(uint16_t*)(p+2)) * PRIME;
		p += 2*sizeof(uint16_t);
    }
    if (wrdlen & sizeof(uint16_t)) {
        hash32 = (hash32 ^ *(uint16_t*)p) * PRIME;
        p += sizeof(uint16_t);
    }
    if (wrdlen & 1) 
        hash32 = (hash32 ^ *p) * PRIME;
}
    hash32 = (hash32 ^ _rotl_KAZE(hash32B,ROLInBits) ) * PRIME;
    return hash32 ^ (hash32 >> 16);
}
/*
FNV1A_marline          : KT_DumpCounter = 0,000,134,217,729; 000,000,001 x MAXcollisionsAtSomeSlots = 000,011; HASHfreeSLOTS = 0,049,566,954
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,000,134,217,729; 000,000,004 x MAXcollisionsAtSomeSlots = 000,011; HASHfreeSLOTS = 0,049,561,215
FNV1A_marline          : KT_DumpCounter = 0,000,268,435,457; 000,000,002 x MAXcollisionsAtSomeSlots = 000,014; HASHfreeSLOTS = 0,018,311,367
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,000,268,435,457; 000,000,004 x MAXcollisionsAtSomeSlots = 000,014; HASHfreeSLOTS = 0,018,307,048
FNV1A_marline          : KT_DumpCounter = 0,000,402,653,185; 000,000,002 x MAXcollisionsAtSomeSlots = 000,018; HASHfreeSLOTS = 0,006,762,977
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,000,402,653,185; 000,000,008 x MAXcollisionsAtSomeSlots = 000,017; HASHfreeSLOTS = 0,006,762,415
FNV1A_marline          : KT_DumpCounter = 0,000,536,870,913; 000,000,003 x MAXcollisionsAtSomeSlots = 000,021; HASHfreeSLOTS = 0,002,497,447
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,000,536,870,913; 000,000,002 x MAXcollisionsAtSomeSlots = 000,020; HASHfreeSLOTS = 0,002,496,170
FNV1A_marline          : KT_DumpCounter = 0,000,671,088,641; 000,000,001 x MAXcollisionsAtSomeSlots = 000,023; HASHfreeSLOTS = 0,000,922,927
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,000,671,088,641; 000,000,002 x MAXcollisionsAtSomeSlots = 000,023; HASHfreeSLOTS = 0,000,922,884
FNV1A_marline          : KT_DumpCounter = 0,000,805,306,369; 000,000,004 x MAXcollisionsAtSomeSlots = 000,024; HASHfreeSLOTS = 0,000,340,605
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,000,805,306,369; 000,000,002 x MAXcollisionsAtSomeSlots = 000,026; HASHfreeSLOTS = 0,000,339,990
FNV1A_marline          : KT_DumpCounter = 0,000,939,524,097; 000,000,001 x MAXcollisionsAtSomeSlots = 000,029; HASHfreeSLOTS = 0,000,125,512
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,000,939,524,097; 000,000,002 x MAXcollisionsAtSomeSlots = 000,028; HASHfreeSLOTS = 0,000,126,260
FNV1A_marline          : KT_DumpCounter = 0,001,073,741,825; 000,000,002 x MAXcollisionsAtSomeSlots = 000,030; HASHfreeSLOTS = 0,000,046,305
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,001,073,741,825; 000,000,002 x MAXcollisionsAtSomeSlots = 000,030; HASHfreeSLOTS = 0,000,046,780
FNV1A_marline          : KT_DumpCounter = 0,001,207,959,553; 000,000,002 x MAXcollisionsAtSomeSlots = 000,031; HASHfreeSLOTS = 0,000,017,153
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,001,207,959,553; 000,000,002 x MAXcollisionsAtSomeSlots = 000,030; HASHfreeSLOTS = 0,000,017,200
FNV1A_marline          : KT_DumpCounter = 0,001,342,177,281; 000,000,002 x MAXcollisionsAtSomeSlots = 000,034; HASHfreeSLOTS = 0,000,006,383
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,001,342,177,281; 000,000,002 x MAXcollisionsAtSomeSlots = 000,033; HASHfreeSLOTS = 0,000,006,284
FNV1A_marline          : KT_DumpCounter = 0,001,476,395,009; 000,000,001 x MAXcollisionsAtSomeSlots = 000,036; HASHfreeSLOTS = 0,000,002,371
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,001,476,395,009; 000,000,002 x MAXcollisionsAtSomeSlots = 000,034; HASHfreeSLOTS = 0,000,002,338
FNV1A_marline          : KT_DumpCounter = 0,001,610,612,737; 000,000,001 x MAXcollisionsAtSomeSlots = 000,040; HASHfreeSLOTS = 0,000,000,895
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,001,610,612,737; 000,000,006 x MAXcollisionsAtSomeSlots = 000,035; HASHfreeSLOTS = 0,000,000,834
FNV1A_marline          : KT_DumpCounter = 0,001,744,830,465; 000,000,001 x MAXcollisionsAtSomeSlots = 000,041; HASHfreeSLOTS = 0,000,000,343
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,001,744,830,465; 000,000,002 x MAXcollisionsAtSomeSlots = 000,038; HASHfreeSLOTS = 0,000,000,304
FNV1A_marline          : KT_DumpCounter = 0,001,879,048,193; 000,000,001 x MAXcollisionsAtSomeSlots = 000,042; HASHfreeSLOTS = 0,000,000,120
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,001,879,048,193; 000,000,004 x MAXcollisionsAtSomeSlots = 000,040; HASHfreeSLOTS = 0,000,000,124
FNV1A_marline          : KT_DumpCounter = 0,002,013,265,921; 000,000,001 x MAXcollisionsAtSomeSlots = 000,043; HASHfreeSLOTS = 0,000,000,039
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,002,013,265,921; 000,000,006 x MAXcollisionsAtSomeSlots = 000,041; HASHfreeSLOTS = 0,000,000,046
FNV1A_marline          : KT_DumpCounter = 0,002,147,483,649; 000,000,001 x MAXcollisionsAtSomeSlots = 000,044; HASHfreeSLOTS = 0,000,000,013
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,002,147,483,649; 000,000,004 x MAXcollisionsAtSomeSlots = 000,043; HASHfreeSLOTS = 0,000,000,008
FNV1A_marline          : KT_DumpCounter = 0,002,281,701,377; 000,000,004 x MAXcollisionsAtSomeSlots = 000,044; HASHfreeSLOTS = 0,000,000,005
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,002,281,701,377; 000,000,002 x MAXcollisionsAtSomeSlots = 000,045; HASHfreeSLOTS = 0,000,000,002
FNV1A_marline          : KT_DumpCounter = 0,002,415,919,105; 000,000,004 x MAXcollisionsAtSomeSlots = 000,046; HASHfreeSLOTS = 0,000,000,003
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,002,415,919,105; 000,000,002 x MAXcollisionsAtSomeSlots = 000,047; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,002,550,136,833; 000,000,001 x MAXcollisionsAtSomeSlots = 000,049; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,002,550,136,833; 000,000,002 x MAXcollisionsAtSomeSlots = 000,048; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,002,684,354,561; 000,000,004 x MAXcollisionsAtSomeSlots = 000,049; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,002,684,354,561; 000,000,002 x MAXcollisionsAtSomeSlots = 000,050; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,002,818,572,289; 000,000,001 x MAXcollisionsAtSomeSlots = 000,053; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,002,818,572,289; 000,000,002 x MAXcollisionsAtSomeSlots = 000,052; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,002,952,790,017; 000,000,001 x MAXcollisionsAtSomeSlots = 000,054; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,002,952,790,017; 000,000,002 x MAXcollisionsAtSomeSlots = 000,054; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,003,087,007,745; 000,000,001 x MAXcollisionsAtSomeSlots = 000,056; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,003,087,007,745; 000,000,002 x MAXcollisionsAtSomeSlots = 000,054; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,003,221,225,473; 000,000,001 x MAXcollisionsAtSomeSlots = 000,057; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,003,221,225,473; 000,000,006 x MAXcollisionsAtSomeSlots = 000,055; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,003,355,443,201; 000,000,001 x MAXcollisionsAtSomeSlots = 000,059; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,003,355,443,201; 000,000,004 x MAXcollisionsAtSomeSlots = 000,057; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,003,489,660,929; 000,000,001 x MAXcollisionsAtSomeSlots = 000,060; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,003,489,660,929; 000,000,002 x MAXcollisionsAtSomeSlots = 000,058; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,003,623,878,657; 000,000,002 x MAXcollisionsAtSomeSlots = 000,061; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,003,623,878,657; 000,000,008 x MAXcollisionsAtSomeSlots = 000,059; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,003,758,096,385; 000,000,001 x MAXcollisionsAtSomeSlots = 000,063; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,003,758,096,385; 000,000,002 x MAXcollisionsAtSomeSlots = 000,061; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,003,892,314,113; 000,000,001 x MAXcollisionsAtSomeSlots = 000,065; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,003,892,314,113; 000,000,004 x MAXcollisionsAtSomeSlots = 000,062; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,004,026,531,841; 000,000,001 x MAXcollisionsAtSomeSlots = 000,066; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,004,026,531,841; 000,000,004 x MAXcollisionsAtSomeSlots = 000,064; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,004,160,749,569; 000,000,001 x MAXcollisionsAtSomeSlots = 000,070; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,004,160,749,569; 000,000,006 x MAXcollisionsAtSomeSlots = 000,066; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,004,294,967,297; 000,000,001 x MAXcollisionsAtSomeSlots = 000,070; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,004,294,967,297; 000,000,006 x MAXcollisionsAtSomeSlots = 000,067; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,004,429,185,025; 000,000,001 x MAXcollisionsAtSomeSlots = 000,072; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,004,429,185,025; 000,000,004 x MAXcollisionsAtSomeSlots = 000,069; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,004,563,402,753; 000,000,001 x MAXcollisionsAtSomeSlots = 000,073; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,004,563,402,753; 000,000,004 x MAXcollisionsAtSomeSlots = 000,070; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,004,697,620,481; 000,000,001 x MAXcollisionsAtSomeSlots = 000,074; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,004,697,620,481; 000,000,002 x MAXcollisionsAtSomeSlots = 000,072; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,004,831,838,209; 000,000,001 x MAXcollisionsAtSomeSlots = 000,076; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,004,831,838,209; 000,000,002 x MAXcollisionsAtSomeSlots = 000,076; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,004,966,055,937; 000,000,001 x MAXcollisionsAtSomeSlots = 000,076; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,004,966,055,937; 000,000,002 x MAXcollisionsAtSomeSlots = 000,080; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,005,100,273,665; 000,000,001 x MAXcollisionsAtSomeSlots = 000,077; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,005,100,273,665; 000,000,002 x MAXcollisionsAtSomeSlots = 000,080; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,005,234,491,393; 000,000,001 x MAXcollisionsAtSomeSlots = 000,078; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,005,234,491,393; 000,000,002 x MAXcollisionsAtSomeSlots = 000,081; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,005,368,709,121; 000,000,001 x MAXcollisionsAtSomeSlots = 000,080; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,005,368,709,121; 000,000,002 x MAXcollisionsAtSomeSlots = 000,082; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,005,502,926,849; 000,000,003 x MAXcollisionsAtSomeSlots = 000,081; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,005,502,926,849; 000,000,002 x MAXcollisionsAtSomeSlots = 000,084; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,005,637,144,577; 000,000,002 x MAXcollisionsAtSomeSlots = 000,082; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,005,637,144,577; 000,000,002 x MAXcollisionsAtSomeSlots = 000,085; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,005,771,362,305; 000,000,003 x MAXcollisionsAtSomeSlots = 000,084; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,005,771,362,305; 000,000,002 x MAXcollisionsAtSomeSlots = 000,087; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,005,905,580,033; 000,000,002 x MAXcollisionsAtSomeSlots = 000,085; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,005,905,580,033; 000,000,002 x MAXcollisionsAtSomeSlots = 000,087; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,006,039,797,761; 000,000,002 x MAXcollisionsAtSomeSlots = 000,087; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,006,039,797,761; 000,000,002 x MAXcollisionsAtSomeSlots = 000,090; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,006,174,015,489; 000,000,002 x MAXcollisionsAtSomeSlots = 000,089; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,006,174,015,489; 000,000,002 x MAXcollisionsAtSomeSlots = 000,092; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,006,308,233,217; 000,000,001 x MAXcollisionsAtSomeSlots = 000,090; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,006,308,233,217; 000,000,002 x MAXcollisionsAtSomeSlots = 000,092; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,006,442,450,945; 000,000,002 x MAXcollisionsAtSomeSlots = 000,091; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,006,442,450,945; 000,000,004 x MAXcollisionsAtSomeSlots = 000,092; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,006,576,668,673; 000,000,001 x MAXcollisionsAtSomeSlots = 000,092; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,006,576,668,673; 000,000,002 x MAXcollisionsAtSomeSlots = 000,095; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,006,710,886,401; 000,000,001 x MAXcollisionsAtSomeSlots = 000,094; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,006,710,886,401; 000,000,002 x MAXcollisionsAtSomeSlots = 000,095; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,006,845,104,129; 000,000,001 x MAXcollisionsAtSomeSlots = 000,095; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,006,845,104,129; 000,000,002 x MAXcollisionsAtSomeSlots = 000,097; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,006,979,321,857; 000,000,001 x MAXcollisionsAtSomeSlots = 000,100; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,006,979,321,857; 000,000,002 x MAXcollisionsAtSomeSlots = 000,098; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,007,113,539,585; 000,000,001 x MAXcollisionsAtSomeSlots = 000,101; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,007,113,539,585; 000,000,002 x MAXcollisionsAtSomeSlots = 000,100; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,007,247,757,313; 000,000,001 x MAXcollisionsAtSomeSlots = 000,102; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,007,247,757,313; 000,000,002 x MAXcollisionsAtSomeSlots = 000,101; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,007,381,975,041; 000,000,002 x MAXcollisionsAtSomeSlots = 000,102; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,007,381,975,041; 000,000,002 x MAXcollisionsAtSomeSlots = 000,101; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,007,516,192,769; 000,000,004 x MAXcollisionsAtSomeSlots = 000,103; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,007,516,192,769; 000,000,002 x MAXcollisionsAtSomeSlots = 000,103; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,007,650,410,497; 000,000,001 x MAXcollisionsAtSomeSlots = 000,105; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,007,650,410,497; 000,000,002 x MAXcollisionsAtSomeSlots = 000,104; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,007,784,628,225; 000,000,002 x MAXcollisionsAtSomeSlots = 000,105; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,007,784,628,225; 000,000,006 x MAXcollisionsAtSomeSlots = 000,104; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,007,918,845,953; 000,000,003 x MAXcollisionsAtSomeSlots = 000,106; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,007,918,845,953; 000,000,002 x MAXcollisionsAtSomeSlots = 000,107; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,008,053,063,681; 000,000,001 x MAXcollisionsAtSomeSlots = 000,109; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,008,053,063,681; 000,000,002 x MAXcollisionsAtSomeSlots = 000,108; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,008,187,281,409; 000,000,002 x MAXcollisionsAtSomeSlots = 000,110; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,008,187,281,409; 000,000,002 x MAXcollisionsAtSomeSlots = 000,109; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,008,321,499,137; 000,000,001 x MAXcollisionsAtSomeSlots = 000,112; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,008,321,499,137; 000,000,006 x MAXcollisionsAtSomeSlots = 000,110; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,008,455,716,865; 000,000,001 x MAXcollisionsAtSomeSlots = 000,114; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,008,455,716,865; 000,000,002 x MAXcollisionsAtSomeSlots = 000,111; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,008,589,934,593; 000,000,001 x MAXcollisionsAtSomeSlots = 000,115; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,008,589,934,593; 000,000,002 x MAXcollisionsAtSomeSlots = 000,113; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,008,724,152,321; 000,000,001 x MAXcollisionsAtSomeSlots = 000,115; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,008,724,152,321; 000,000,006 x MAXcollisionsAtSomeSlots = 000,113; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,008,858,370,049; 000,000,001 x MAXcollisionsAtSomeSlots = 000,116; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,008,858,370,049; 000,000,004 x MAXcollisionsAtSomeSlots = 000,114; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,008,992,587,777; 000,000,001 x MAXcollisionsAtSomeSlots = 000,117; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,008,992,587,777; 000,000,002 x MAXcollisionsAtSomeSlots = 000,115; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,009,126,805,505; 000,000,001 x MAXcollisionsAtSomeSlots = 000,118; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,009,126,805,505; 000,000,002 x MAXcollisionsAtSomeSlots = 000,117; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,009,261,023,233; 000,000,001 x MAXcollisionsAtSomeSlots = 000,119; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,009,261,023,233; 000,000,002 x MAXcollisionsAtSomeSlots = 000,120; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,009,395,240,961; 000,000,001 x MAXcollisionsAtSomeSlots = 000,122; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,009,395,240,961; 000,000,002 x MAXcollisionsAtSomeSlots = 000,121; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,009,529,458,689; 000,000,001 x MAXcollisionsAtSomeSlots = 000,123; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,009,529,458,689; 000,000,002 x MAXcollisionsAtSomeSlots = 000,121; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,009,663,676,417; 000,000,001 x MAXcollisionsAtSomeSlots = 000,124; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,009,663,676,417; 000,000,002 x MAXcollisionsAtSomeSlots = 000,122; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,009,797,894,145; 000,000,001 x MAXcollisionsAtSomeSlots = 000,127; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,009,797,894,145; 000,000,002 x MAXcollisionsAtSomeSlots = 000,124; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,009,932,111,873; 000,000,002 x MAXcollisionsAtSomeSlots = 000,127; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,009,932,111,873; 000,000,002 x MAXcollisionsAtSomeSlots = 000,125; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,010,066,329,601; 000,000,002 x MAXcollisionsAtSomeSlots = 000,127; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,010,066,329,601; 000,000,002 x MAXcollisionsAtSomeSlots = 000,127; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,010,200,547,329; 000,000,001 x MAXcollisionsAtSomeSlots = 000,129; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,010,200,547,329; 000,000,002 x MAXcollisionsAtSomeSlots = 000,129; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,010,334,765,057; 000,000,001 x MAXcollisionsAtSomeSlots = 000,132; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,010,334,765,057; 000,000,002 x MAXcollisionsAtSomeSlots = 000,130; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,010,468,982,785; 000,000,001 x MAXcollisionsAtSomeSlots = 000,133; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,010,468,982,785; 000,000,002 x MAXcollisionsAtSomeSlots = 000,132; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,010,603,200,513; 000,000,002 x MAXcollisionsAtSomeSlots = 000,134; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,010,603,200,513; 000,000,002 x MAXcollisionsAtSomeSlots = 000,132; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,010,737,418,241; 000,000,001 x MAXcollisionsAtSomeSlots = 000,137; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,010,737,418,241; 000,000,002 x MAXcollisionsAtSomeSlots = 000,132; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,010,871,635,969; 000,000,001 x MAXcollisionsAtSomeSlots = 000,137; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,010,871,635,969; 000,000,010 x MAXcollisionsAtSomeSlots = 000,132; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,011,005,853,697; 000,000,003 x MAXcollisionsAtSomeSlots = 000,137; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,011,005,853,697; 000,000,002 x MAXcollisionsAtSomeSlots = 000,137; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,011,140,071,425; 000,000,001 x MAXcollisionsAtSomeSlots = 000,140; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,011,140,071,425; 000,000,002 x MAXcollisionsAtSomeSlots = 000,138; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,011,274,289,153; 000,000,002 x MAXcollisionsAtSomeSlots = 000,140; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,011,274,289,153; 000,000,002 x MAXcollisionsAtSomeSlots = 000,140; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,011,408,506,881; 000,000,001 x MAXcollisionsAtSomeSlots = 000,143; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,011,408,506,881; 000,000,002 x MAXcollisionsAtSomeSlots = 000,142; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,011,542,724,609; 000,000,001 x MAXcollisionsAtSomeSlots = 000,143; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,011,542,724,609; 000,000,002 x MAXcollisionsAtSomeSlots = 000,143; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,011,676,942,337; 000,000,001 x MAXcollisionsAtSomeSlots = 000,145; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,011,676,942,337; 000,000,002 x MAXcollisionsAtSomeSlots = 000,146; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,011,811,160,065; 000,000,002 x MAXcollisionsAtSomeSlots = 000,146; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,011,811,160,065; 000,000,002 x MAXcollisionsAtSomeSlots = 000,146; HASHfreeSLOTS = 0,000,000,000
FNV1A_marline          : KT_DumpCounter = 0,011,945,377,793; 000,000,001 x MAXcollisionsAtSomeSlots = 000,147; HASHfreeSLOTS = 0,000,000,000
CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,011,945,377,793; 000,000,002 x MAXcollisionsAtSomeSlots = 000,147; HASHfreeSLOTS = 0,000,000,000
...
*/



// "There it now stands for ever. Black on white.
// I can't get away from it. Ahoy, Yorikke, ahoy, hoy, ho!
// Go to hell now if you wish. What do I care? It's all the same now to me.
// I am part of you now. Where you go I go, where you leave I leave, when you go to the devil I go. Married.
// Vanished from the living. Damned and doomed. Of me there is not left a breath in all the vast world.
// Ahoy, Yorikke! Ahoy, hoy, ho!
// I am not buried in the sea,
// The death ship is now part of me
// So far from sunny New Orleans
// So far from lovely Louisiana."
// /An excerpt from 'THE DEATH SHIP - THE STORY OF AN AMERICAN SAILOR' by B.TRAVEN/
// 
// "Walking home to our good old Yorikke, I could not help thinking of this beautiful ship, with a crew on board that had faces as if they were seeing ghosts by day and by night.
// Compared to that gilded Empress, the Yorikke was an honorable old lady with lavender sachets in her drawers.
// Yorikke did not pretend to anything she was not. She lived up to her looks. Honest to her lowest ribs and to the leaks in her bilge.
// Now, what is this? I find myself falling in love with that old jane.
// All right, I cannot pass by you, Yorikke; I have to tell you I love you. Honest, baby, I love you.
// I have six black finger-nails, and four black and green-blue nails on my toes, which you, honey, gave me when necking you.
// Grate-bars have crushed some of my toes. And each finger-nail has its own painful story to tell.
// My chest, my back, my arms, my legs are covered with scars of burns and scorchings.
// Each scar, when it was being created, caused me pains which I shall surely never forget.
// But every outcry of pain was a love-cry for you, honey.
// You are no hypocrite. Your heart does not bleed tears when you do not feel heart-aches deeply and truly.
// You do not dance on the water if you do not feel like being jolly and kicking chasers in the pants.
// Your heart never lies. It is fine and clean like polished gold. Never mind the rags, honey dear.
// When you laugh, your whole soul and all your body is laughing.
// And when you weep, sweety, then you weep so that even the reefs you pass feel like weeping with you.
// I never want to leave you again, honey. I mean it. Not for all the rich and elegant buckets in the world.
// I love you, my gypsy of the sea!"
// /An excerpt from 'THE DEATH SHIP - THE STORY OF AN AMERICAN SAILOR' by B.TRAVEN/
uint32_t FNV1A_Hash_Yorikke(const char *str, uint32_t wrdlen)
{
    const uint32_t PRIME = 709607;
    uint32_t hash32 = 2166136261;
    uint32_t hash32B = 2166136261;
    const char *p = str;

    for(; wrdlen >= 2*2*sizeof(uint32_t); wrdlen -= 2*2*sizeof(uint32_t), p += 2*2*sizeof(uint32_t)) {
        hash32 = (hash32 ^ (_rotl_KAZE(*(uint32_t *)(p+0),5) ^ *(uint32_t *)(p+4))) * PRIME;        
        hash32B = (hash32B ^ (_rotl_KAZE(*(uint32_t *)(p+8),5) ^ *(uint32_t *)(p+12))) * PRIME;        
    }

    // Cases: 0,1,2,3,4,5,6,7,...,15
    if (wrdlen & 2*sizeof(uint32_t)) {
		hash32 = (hash32 ^ *(uint32_t*)(p+0)) * PRIME;
		hash32B = (hash32B ^ *(uint32_t*)(p+4)) * PRIME;
		p += 4*sizeof(uint16_t);
    }
    // Cases: 0,1,2,3,4,5,6,7
    if (wrdlen & sizeof(uint32_t)) {
		hash32 = (hash32 ^ *(uint16_t*)(p+0)) * PRIME;
		hash32B = (hash32B ^ *(uint16_t*)(p+2)) * PRIME;
		p += 2*sizeof(uint16_t);
    }
    if (wrdlen & sizeof(uint16_t)) {
        hash32 = (hash32 ^ *(uint16_t*)p) * PRIME;
        p += sizeof(uint16_t);
    }
    if (wrdlen & 1) 
        hash32 = (hash32 ^ *p) * PRIME;

    hash32 = (hash32 ^ _rotl_KAZE(hash32B,5) ) * PRIME;
    return hash32 ^ (hash32 >> 16);
}


// CRC-32
//#define CRCPOLY 0xEDB88320
//0x8F6E37A0 // Castagnoli (iSCSI): HD=6 for 178-5243; HD=8 for 48-177
#define CRCPOLY 0x8F6E37A0
#define CRCINIT 0xFFFFFFFF

uint32_t g_crc_precalc[4][256];

void CRC32Init(void) {
uint32_t i;
uint32_t x;
uint32_t j;
uint32_t c;
	for(i = 0; i <= 0xFF; i++) {
		x = i;
		for(j = 0; j < 8; j++)
			x = (x>>1) ^ (CRCPOLY & (-(int)(x & 1)));
		g_crc_precalc[0][i] = x;
	}

	for(i = 0; i <= 0xFF; i++) {
		c = g_crc_precalc[0][i];
		for(j = 1; j < 4; j++) {
			c = g_crc_precalc[0][c & 0xFF] ^ (c >> 8);
			g_crc_precalc[j][i] = c;
		}
	}
}

uint32_t CRC32(const char* key, uint32_t len) {
	uint32_t crc = CRCINIT;
	uint32_t ndwords = len / sizeof(uint32_t);
uint32_t c;
	for(; ndwords; ndwords--) {
		crc ^= *(uint32_t*)key;
		crc =
			g_crc_precalc[3][(crc      ) & 0xFF] ^
			g_crc_precalc[2][(crc >>  8) & 0xFF] ^
			g_crc_precalc[1][(crc >> 16) & 0xFF] ^
			g_crc_precalc[0][(crc >> 24) & 0xFF];
		key += sizeof(uint32_t);
	}
	if (len & sizeof(uint16_t)) {
		c = crc ^ *(uint16_t*)key;
		crc = g_crc_precalc[1][(c     ) & 0xFF] ^
			  g_crc_precalc[0][(c >> 8) & 0xFF] ^ (crc >> 16);
		key += sizeof(uint16_t);
	}
	//if (len & sizeof(BYTE))
	if (len & 1)
		crc = g_crc_precalc[0][(crc ^ *key) & 0xFF] ^ (crc >> 8);
	return ~crc;
}


void x64toaKAZE (      /* stdcall is faster and smaller... Might as well use it for the helper. */
        unsigned long long val,
        char *buf,
        unsigned radix,
        int is_neg
        )
{
        char *p;                /* pointer to traverse string */
        char *firstdig;         /* pointer to first digit */
        char temp;              /* temp char */
        unsigned digval;        /* value of digit */

        p = buf;

        if ( is_neg )
        {
            *p++ = '-';         /* negative, so output '-' and negate */
            val = (unsigned long long)(-(long long)val);
        }

        firstdig = p;           /* save pointer to first digit */

        do {
            digval = (unsigned) (val % radix);
            val /= radix;       /* get next digit */

            /* convert to ascii and store */
            if (digval > 9)
                *p++ = (char) (digval - 10 + 'a');  /* a letter */
            else
                *p++ = (char) (digval + '0');       /* a digit */
        } while (val > 0);

        /* We now have the digit of the number in the buffer, but in reverse
           order.  Thus we reverse them now. */

        *p-- = '\0';            /* terminate string; p points to last digit */

        do {
            temp = *p;
            *p = *firstdig;
            *firstdig = temp;   /* swap *p and *firstdig */
            --p;
            ++firstdig;         /* advance to next two digits */
        } while (firstdig < p); /* repeat until halfway */
}

/* Actual functions just call conversion helper with neg flag set correctly,
   and return pointer to buffer. */

char * _i64toaKAZE (
        long long val,
        char *buf,
        int radix
        )
{
        x64toaKAZE((unsigned long long)val, buf, radix, (radix == 10 && val < 0));
        return buf;
}

char * _ui64toaKAZE (
        unsigned long long val,
        char *buf,
        int radix
        )
{
        x64toaKAZE(val, buf, radix, 0);
        return buf;
}

char * _ui64toaKAZEzerocomma (
        unsigned long long val,
        char *buf,
        int radix
        )
{
                        char *p;
                        char temp;
                        int txpman;
                        int pxnman;
        x64toaKAZE(val, buf, radix, 0);
                        p = buf;
                        do {
                        } while (*++p != '\0');
                        p--; // p points to last digit
                             // buf points to first digit
                        buf[26] = 0;
                        txpman = 1;
                        pxnman = 0;
                        do
                        { if (buf <= p)
                          { temp = *p;
                            buf[26-txpman] = temp; pxnman++;
                            p--;
                            if (pxnman % 3 == 0)
                            { txpman++;
                              buf[26-txpman] = (char) (',');
                            }
                          }
                          else
                          { buf[26-txpman] = (char) ('0'); pxnman++;
                            if (pxnman % 3 == 0)
                            { txpman++;
                              buf[26-txpman] = (char) (',');
                            }
                          }
                          txpman++;
                        } while (txpman <= 26);
        return buf;
}

char * _ui64toaKAZEcomma (
        unsigned long long val,
        char *buf,
        int radix
        )
{
                        char *p;
                        char temp;
                        int txpman;
                        int pxnman;
        x64toaKAZE(val, buf, radix, 0);
                        p = buf;
                        do {
                        } while (*++p != '\0');
                        p--; // p points to last digit
                             // buf points to first digit
                        buf[26] = 0;
                        txpman = 1;
                        pxnman = 0;
                        while (buf <= p)
                        { temp = *p;
                          buf[26-txpman] = temp; pxnman++;
                          p--;
                          if (pxnman % 3 == 0 && buf <= p)
                          { txpman++;
                            buf[26-txpman] = (char) (',');
                          }
                          txpman++;
                        } 
        return buf+26-(txpman-1);
}

// Modified C Code by Kaze, original C Code by Kurt White.

// Can a knight placed on a chess board and jump to all 63 remaining squares
// only landing on each square once?
// Lets find out :)

#include <stdio.h>
#include <stdlib.h>
#include <string.h> //memcpy
#include <time.h>

clock_t start,finish;
double duration;

/* List of valid moves a knight can make from any square */
int list[65][9] = { 0,0,0,0,0,0,0,0,0,
                                        11,18,0,0,0,0,0,0,0,    //1
                                        17,12,19,0,0,0,0,0,0,   //2
                                        9,13,18,20,0,0,0,0,0,   //3
                                        10,14,19,21,0,0,0,0,0,  //4
                                        15,11,20,22,0,0,0,0,0,  //5
                                        16,12,23,21,0,0,0,0,0,  //6
                                        24,13,22,0,0,0,0,0,0,   //7
                                        14,23,0,0,0,0,0,0,0,    //8
                                        3,26,19,0,0,0,0,0,0,    //9
                                        4,25,20,27,0,0,0,0,0,   //10
                                        1,5,17,26,21,28,0,0,0,  //11
                                        2,6,18,22,27,29,0,0,0,  //12
                                        7,3,23,19,28,30,0,0,0,  //13
                                        8,4,24,31,20,29,0,0,0,  //14
                                        5,32,21,30,0,0,0,0,0,   //15
                                        6,31,22,0,0,0,0,0,0,    //16
                                        2,11,34,27,0,0,0,0,0,   //17
                                        1,3,33,12,28,35,0,0,0,  //18
                                        2,9,4,25,13,34,29,36,0, //19
                                        3,5,10,14,26,30,35,37,0,//20
                                        4,6,15,11,31,27,36,38,0,//21
                                        7,16,5,32,12,39,28,37,0,//22
                                        8,6,40,13,29,38,0,0,0,  //23
                                        7,14,39,30,0,0,0,0,0,   //24
                                        10,42,19,35,0,0,0,0,0,  //25
                                        9,41,11,20,36,43,0,0,0, //26
                                        10,17,33,12,42,21,37,44,0, //27
                                        11,13,18,34,22,38,43,45,0, //28
                                        12,14,23,39,19,35,44,46,0, //29
                                        15,24,40,13,47,20,36,45,0, //30
                                        16,48,14,21,37,46,0,0,0,   //31
                                        15,47,22,38,0,0,0,0,0,  //32
                                        50,18,27,43,0,0,0,0,0,  //33
                                        49,17,51,19,28,44,0,0,0, //34
                                        25,41,50,52,18,20,29,45,0, //35
                                        26,42,51,53,19,21,30,46,0, //36
                                        31,47,52,54,20,22,27,43,0, //37
                                        32,48,55,53,23,21,28,44,0, //38
                                        56,24,54,22,29,45,0,0,0, //39
                                        55,23,30,46,0,0,0,0,0,  //40
                                        58,26,51,35,0,0,0,0,0,  //41
                                        57,25,59,52,27,36,0,0,0, //42
                                        49,58,33,60,26,53,28,37,0, //43
                                        59,61,50,54,34,27,29,38,0, //44
                                        60,62,55,39,51,28,30,35,0, //45
                                        63,56,61,40,52,31,29,36,0, //46
                                        64,62,32,53,30,37,0,0,0, //47
                                        63,31,54,38,0,0,0,0,0,  //48
                                        59,34,43,0,0,0,0,0,0,   //49
                                        33,60,35,44,0,0,0,0,0,  //50
                                        57,61,41,34,36,45,0,0,0, //51
                                        58,62,42,35,37,46,0,0,0, //52
                                        63,59,47,36,38,43,0,0,0, //53
                                        64,48,60,39,37,44,0,0,0, //54
                                        40,61,38,45,0,0,0,0,0,  //55
                                        62,39,46,0,0,0,0,0,0,   //56
                                        42,51,0,0,0,0,0,0,0,    //57
                                        41,52,43,0,0,0,0,0,0,   //58
                                        49,42,53,44,0,0,0,0,0,  //59
                                        50,54,43,45,0,0,0,0,0,  //60
                                        55,51,44,46,0,0,0,0,0,  //61
                                        56,47,52,45,0,0,0,0,0,  //62
                                        48,53,46,0,0,0,0,0,0,   //63
                                        47,54,0,0,0,0,0,0,0     //64
};

//     1  2  3  4  5  6  7  8
// 0: 02 03 04 04 04 04 03 02
// 1: 03 04 06 06 06 06 04 03
// 2: 04 06 08 08 08 08 06 04
// 3: 04 06 08 08 08 08 06 04
// 4: 04 06 08 08 08 08 06 04
// 5: 04 06 08 08 08 08 06 04
// 6: 03 04 06 06 06 06 04 03
// 7: 02 03 04 04 04 04 03 02

void play( int );
void winner( void );

int board[65] = {0}; /* the Chess board   */
int moves[65];       /* list of moves     */
int k = 0;           /* move counter      */
  char llTOaDigits[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
  char llTOaDigits2[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
  char llTOaDigits3[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
  char llTOaDigits4[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
  char llTOaDigits5[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
  unsigned long long wincount = 0;
  unsigned long long Sequences = 0, Jumps = 0;
  int Verbose=0;
  #define KAZE_toupper(c) ( (((c) >= 'a') && ((c) <= 'z')) ? ((c) - 'a' + 'A') : (c) )
  char Bunyo1, Bunyo2;
  //int KT;
  unsigned long long KT;

      char *pointerflush, *pointerflushUNALIGN;
      char *pointerflush2, *pointerflushUNALIGN2;
      unsigned long memory_size;
      uint32_t Slot;
      char KTstring[128+1]; 
      char KTstringREVERSE[128+1]; 
      char KTstringLWR[128+1]; 
      char KTstringREVERSELWR[128+1]; 
      char KTstringBRUTUS[128+1]; 
      uint32_t PseudoLinkedPointer=0;
      uint32_t MAXcollisionsAtSomeSlots=0;
      uint32_t MAXcollisionsAtSomeSlots2=0;
      uint32_t MAXcollisionsAtSomeSlotsSUM=0;
      uint32_t MAXcollisionsAtSomeSlotsSUM2=0;
      uint32_t HASHfreeSLOTS;
      uint32_t HASHfreeSLOTS2;
      uint64_t KT_DumpCounter=0;

int main(int argc, char *argv[])
{
           //printf("Knight-tour.exe, revision 8dump.\n");
           //printf("Purpose: Can a knight placed on a chess board and jump to all 63 remaining squares only landing on each square once? Let's find out.\n");
 
   if (argc != 3)
   {
printf("Knight-Tour_FNV1A_YoshimitsuTRIADii_vs_CRC32_TRISMUS, subrevision Efix, written by Kaze (based on Kurt White's code), downloadable at www.sanmayce.com/Fastest_Hash\n");
printf("Purpose: To compare FNV1A_YoshimitsuTRIADii and CRC32 by giving the highest number of collisions i.e. the deepest nest/layer, the-lesser-the-better.\n");
printf("Note: In this subrevision a KT is transformed to lowercase at each position ONCE, KT is transformed to lowercase and then to uppercase at each position ONCE,\n");
printf("      and these two 2x64 sequences reversed, i.e. all the 4x64 combinations.\n");
printf("      Thus excluding the original KT we can hash 1+ trillion 1Kb UNIQUE chunks by having only 4 billion KTs.\n");
printf("Example: D:\\>Knight-Tour_FNV1A_YoshimitsuTRIADii_vs_CRC32_TRISMUS a8 4000000000\n");
printf("Note1: In above example it hashes first 4 billion Knight-tours (and their 4x64 variants) starting from A8.\n");
printf("Note2: The result (after some 384h of computing):\n");
printf("FNV1A_YoshimitsuTRIADii: KT_DumpCounter = 0,000,134,217,729; 000,000,001 x MAXcollisionsAtSomeSlots = 000,012; HASHfreeSLOTS = 0,050,530,128\n");
printf("CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 0,000,134,217,729; 000,000,004 x MAXcollisionsAtSomeSlots = 000,011; HASHfreeSLOTS = 0,049,561,215\n");
printf("...\n");
printf("FNV1A_YoshimitsuTRIADii: KT_DumpCounter = 1,000,056,291,329; 000,000,001 x MAXcollisionsAtSomeSlots = 007,930; HASHfreeSLOTS = 0,000,000,000\n");
printf("CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = 1,000,056,291,329; 000,000,002 x MAXcollisionsAtSomeSlots = 007,910; HASHfreeSLOTS = 0,000,000,000\n");
printf("...\n");
	   return 0;
           printf("Knight-tour.exe, revision 8dump, Yorikke.\n");
           printf("Example: D:\\>Knight-tour a8 100000000\n");
           printf("Note: In above example it lists first 100 million Knight-tours starting from A8.\n");
           printf("Usage: Knight-tour square [V|F|T]\n");
           printf("       square represents a board position, as A1(bottom-left), H8(top-right);\n");
           printf("       V, F and T are optional parameters for verbose output;\n");
           printf("       V lists 'Tours Sequences' & progress bar;\n");
           printf("       F lists 'Attempts Sequences' i.e. TOUR sequences and FAILURE sequences\n");
           printf("       i.e. moves from start position till either 64th or dead-end position.\n");
           printf("       T lists first 40,000,000 'Tours Sequences';\n");
           printf("Note1: Modified C Code by Kaze, original C Code by Kurt White.\n");
           printf("Note2: An amateurish program. Anyway, whatever!\n");
           printf("Note3: It is useful to redirect output to a file for studying, benchmarking.\n");
           printf("Note4: When not using Warnsdorf's heuristic A8 first tour appeared after\n");
           printf("       17,739,768 recursive calls(knight's moves), it is:\n");
           printf("       A8C7E8G7E6D8B7D6C8A7C6B8D7F8H7F6G8E7G6H8F7H6F5D4B5A3C4B6D5B4A6C5\n");
           printf("       A4B2D3E5G4H2F1E3D1F2H1G3H5F4H3G5E4D2B1C3A2C1E2G1F3H4G2E1C2A1B3A5, for\n");
           printf("       H1 though, first tour didn't appear even after 2,614,840,115,968 calls\n");
           printf("       which took 166470.77 seconds i.e. at rate 15,707,502+ jumps(knight's\n");
           printf("       moves) per second on AMD Barton 2600+(1919MHz).\n");
           printf("Note5: When using Warnsdorf's heuristic A8 first tour appeared after\n");
           printf("       5,909 recursive calls(knight's moves), it is:\n");
           printf("       A8C7E8G7H5G3H1F2H3G1E2C1A2B4A6B8D7F8H7G5F7H8G6H4G2E1C2A1B3A5B7D8\n");
           printf("       C6A7C8E7G8H6G4H2F1D2B1A3B5D6F5D4F3E5C4B2D3F4E6C5A4B6D5F6E4C3D1E3, for\n");
           printf("       H1, first tour appeared after 497 calls(245 dead-end sequences), it is:\n");
           printf("       H1G3F1H2G4H6G8E7C8A7B5A3B1D2B3A1C2E1G2H4G6H8F7D8B7A5C6B8A6C7A8B6\n");
           printf("       A4B2D1F2H3G1E2C1A2B4D5F6H7F8D7C5E6G5F3D4F5E3C4E5D3F4H5G7E8D6E4C3.\n");
           printf("Note6: On T7500 2.2GHz and D:\\>Knight-tour_Microsoft_V16_32bit_Ox.exe a8 t:\n");
           printf("       |Sequences(only failures):  |Jumps i.e. knight's moves: |Elapsed seconds:\n");
           printf("       |00,000,000,003,578,340,111 |00,000,000,004,464,360,629 |218.35\n");
           printf("       A8C7E8G7H5G3H1F2H3G1E2C1A2B4A6B8D7F8H7G5F7H8G6H4G2E1C2A1B3A5B7D8E6F4D5F6G4H6G8E7F5D6E4D2B1C3B5A3C4E5C6A7C8B6A4C5D3B2D1E3F1H2F3D4\n");
           printf("Note7: On T7500 2.2GHz and D:\\>Knight-tour_Intel_V12_32bit_Ox.exe a8 t:\n");
           printf("       |Sequences(only failures):  |Jumps i.e. knight's moves: |Elapsed seconds:\n");
           printf("       |00,000,000,003,578,340,111 |00,000,000,004,464,360,629 |238.42\n");
           printf("       A8C7E8G7H5G3H1F2H3G1E2C1A2B4A6B8D7F8H7G5F7H8G6H4G2E1C2A1B3A5B7D8E6F4D5F6G4H6G8E7F5D6E4D2B1C3B5A3C4E5C6A7C8B6A4C5D3B2D1E3F1H2F3D4\n");
           printf("Example: D:\\>Knight-tour b4 v\n");
	   return 0;
   }
//if (atoi(argv[1]) < 1) return;
//if (atoi(argv[1]) > 64) return;
// Square takes values from 1 to 64
// 1:top-left, 57:bottom-left, 8:top-right, 64:bottom-right

Bunyo1=*(argv[1]+1);
if (Bunyo1 < '1' || Bunyo1 > '8') {printf("Knight-tour: Incorrect board position!\n"); return 13;}
Bunyo2=KAZE_toupper(*(argv[1]+0));
if (Bunyo2 < 'A' || Bunyo2 > 'H') {printf("Knight-tour: Incorrect board position!\n"); return 13;}

   if (argc == 3)
   {
          if (KAZE_toupper(*argv[2]) == 'V') Verbose=1;
          if (KAZE_toupper(*argv[2]) == 'F') Verbose=2;
          if (KAZE_toupper(*argv[2]) == 'T') Verbose=3;
   }

// This revision is all about dumping, so others are disabled:
Verbose=3;
//KT=atoi(argv[2]);
KT=atoll(argv[2]); //KT=_atoi64(argv[2]); // what is thecounterpart for GCC? atoll
goto oldold;

printf("\n");
printf("PUBLIC  _play                                                      \n");
printf("; Function compile flags: /Ogty                                    \n");
printf("_TEXT   SEGMENT                                                    \n");
printf("_square$ = 8                                            ; size = 4 \n");
printf("_play   PROC NEAR                                                  \n");
printf("                                                                   \n");
printf("{                                                                  \n");
printf("   board[square] = 1;                                              \n");
printf("   moves[k++] = square;                                            \n");
printf("                                                                   \n");
printf("        mov     eax, DWORD PTR _k                                  \n");
printf("        push    edi                                                \n");
printf("        mov     edi, DWORD PTR _square$[esp]                       \n");
printf("        mov     DWORD PTR _moves[eax*4], edi                       \n");
printf("        inc     eax                                                \n");
printf("                                                                   \n");
printf("   if (k == 64)                                                    \n");
printf("   {                                                               \n");
printf("      board[square] = 0; k--; return;                              \n");
printf("   }                                                               \n");
printf("                                                                   \n");
printf("        cmp     eax, 64                                 ; 00000040H\n");
printf("        mov     DWORD PTR _board[edi*4], 1                         \n");
printf("        mov     DWORD PTR _k, eax                                  \n");
printf("        jne     SHORT $L1327                                       \n");
printf("        mov     DWORD PTR _board[edi*4], 0                         \n");
printf("        mov     DWORD PTR _k, 63                        ; 0000003fH\n");
printf("        pop     edi                                                \n");
printf("        ret     0                                                  \n");
printf("$L1327:                                                            \n");
printf("                                                                   \n");
printf("   for (i = 0; list[square][i] != 0; i++)                          \n");
printf("   {                                                               \n");
printf("                                                                   \n");
printf("        lea     eax, DWORD PTR [edi+edi*8]                         \n");
printf("        mov     ecx, DWORD PTR _list[eax*4]                        \n");
printf("        test    ecx, ecx                                           \n");
printf("        lea     eax, DWORD PTR _list[eax*4]                        \n");
printf("        je      SHORT $L1330                                       \n");
printf("        push    esi                                                \n");
printf("        lea     esi, DWORD PTR [edi+edi*8]                         \n");
printf("        lea     esi, DWORD PTR _list[esi*4]                        \n");
printf("        npad    2                                                  \n");
printf("$L1328:                                                            \n");
printf("                                                                   \n");
printf("      if (board[list[square][i]] == 0)                             \n");
printf("                                                                   \n");
printf("        mov     eax, DWORD PTR [eax]                               \n");
printf("        mov     ecx, DWORD PTR _board[eax*4]                       \n");
printf("        test    ecx, ecx                                           \n");
printf("        jne     SHORT $L1329                                       \n");
printf("                                                                   \n");
printf("         play(list[square][i]);                                    \n");
printf("   }                                                               \n");
printf("                                                                   \n");
printf("        push    eax                                                \n");
printf("        call    _play                                              \n");
printf("        add     esp, 4                                             \n");
printf("$L1329:                                                            \n");
printf("        mov     ecx, DWORD PTR [esi+4]                             \n");
printf("        add     esi, 4                                             \n");
printf("        test    ecx, ecx                                           \n");
printf("        mov     eax, esi                                           \n");
printf("        jne     SHORT $L1328                                       \n");
printf("        pop     esi                                                \n");
printf("$L1330:                                                            \n");
printf("                                                                   \n");
printf("   board[square] = 0; k--; return;                                 \n");
printf("                                                                   \n");
printf("        mov     eax, DWORD PTR _k                                  \n");
printf("        dec     eax                                                \n");
printf("        mov     DWORD PTR _board[edi*4], 0                         \n");
printf("        mov     DWORD PTR _k, eax                                  \n");
printf("        pop     edi                                                \n");
printf("                                                                   \n");
printf("}                                                                  \n");
printf("                                                                   \n");
printf("        ret     0                                                  \n");
printf("_play   ENDP                                                       \n");
printf("_TEXT   ENDS                                                       \n");
printf("\n");
oldold:

// [
/*
printf("Knight-Tour_FNV1A_YoshimitsuTRIADii_vs_CRC32_TRISMUS, subrevision Efix, written by Kaze (based on Kurt White's code), downloadable at www.sanmayce.com/Fastest_Hash\n");
printf("Purpose: to compare FNV1A_YoshimitsuTRIADii and CRC32 by giving the highest number of collisions i.e. the deepest nest/layer, the-lesser-the-better.\n");
printf("Note: In this subrevision a KT is transformed to lowercase at each position ONCE, KT is transformed to lowercase and then to uppercase at each position ONCE,\n");
printf("      and these two 2x64 sequences reversed, i.e. all the 4x64 combinations.\n");
printf("      Thus excluding the original KT we can hash 1+ trillion 1Kb UNIQUE chunks by having only 4 billion KTs.\n");
printf("Example: D:\\>Knight-Tour_FNV1A_YoshimitsuTRIADii_vs_CRC32_TRISMUS a8 4000000000\n");

printf("Polynomial used:\n");
printf("CRC32: 0x8F6E37A0 \n");

printf("KEYS to be hashed = %sx4x64\n", _ui64toaKAZEzerocomma(KT, llTOaDigits, 10)+(26-13));
//KT=KT*64*4;
printf("HashSizeInBits = %s\n", _ui64toaKAZEcomma(HashSizeInBits, llTOaDigits, 10));
printf("ReportAtEvery = %s\n", _ui64toaKAZEcomma(ReportAtEvery, llTOaDigits, 10));

memory_size = ( (1<<HashSizeInBits)*sizeof(uint32_t) ) + 1 + 64;
printf( "Allocating HASH memory %luMB ... ", (memory_size>>20) );
pointerflushUNALIGN = (char *)malloc( memory_size );
if( pointerflushUNALIGN == NULL )
{ puts( "\nKnight-tour_r8dump_Yorikke: Needed memory allocation denied!\n" ); return( 1 ); }
pointerflush = pointerflushUNALIGN + 64 - (((size_t)pointerflushUNALIGN) % 64);
//offset=64-int((long)data&63);
printf( "OK\n");
memset(pointerflush, 0, (1<<HashSizeInBits)*sizeof(uint32_t));

memory_size = ( (1<<HashSizeInBits)*sizeof(uint32_t) ) + 1 + 64;
printf( "Allocating HASH memory %luMB ... ", (memory_size>>20) );
pointerflushUNALIGN2 = (char *)malloc( memory_size );
if( pointerflushUNALIGN2 == NULL )
{ puts( "\nKnight-tour_r8dump_Yorikke: Needed memory allocation denied!\n" ); return( 1 ); }
pointerflush2 = pointerflushUNALIGN2 + 64 - (((size_t)pointerflushUNALIGN2) % 64);
//offset=64-int((long)data&63);
printf( "OK\n");
memset(pointerflush2, 0, (1<<HashSizeInBits)*sizeof(uint32_t));
*/
// ]

CRC32Init();

                        start = clock();

   //printf("\nCode (00508-00270+1=665bytes long compiled with Microsoft V16 32bit /Ox) is being executed, recursive exhaustive depth-first searching ...\n");
   //if (Verbose==1) printf("|Sequences(only failures):  |Jumps i.e. knight's moves: |Elapsed seconds:\n");

   // 1 2 3 ... 8   a8 b8 ... h8
   // 9 ...         a7 ...
   // ...      64   ...       h1
   play( (Bunyo2-'A') + (8-(Bunyo1-'1'+1))*8 + 1 );
   printf("\n");
   printf("Total recursions(jumps i.e. knight's moves): %I64d\n", Jumps);
   printf("Total solutions(tours): %I64d\n", wincount);
exit(0);
}



//char BarIndicator[65]; 
unsigned long nTrys_High = 0, nTrys_Low = 0;



void play( int square )
{
  int i;

  //Jumps++;
  // nTrys_Low++; if (nTrys_Low == 0) nTrys_High++;

   board[square] = 1;
   moves[k++] = square;

             //for (i=1; i<65;i++) if (i-k>0) BarIndicator[i]=' '; else BarIndicator[i]='#';
             //printf(" [%s]\n", &BarIndicator[1]);

//if ((++nTrys_Low & 0x0FFFFFFF) == 0x0FFFFFFF) { // 4x 16 millions
//                        finish = clock();
//                        duration = (double) (finish - start) / CLOCKS_PER_SEC;
//             if (Verbose==1) printf("|%s |%s |%.2f \r", _ui64toaKAZEzerocomma(Sequences, llTOaDigits, 10)+(26-26), _ui64toaKAZEzerocomma(Jumps, llTOaDigits2, 10)+(26-26), duration);
//                               }

   if (k == 64)
   {
             wincount++;
//                        finish = clock();
//                        duration = (double) (finish - start) / CLOCKS_PER_SEC;
//             if (Verbose==1) {
//                 printf("|%s |%s |%.2f \r", _ui64toaKAZEzerocomma(Sequences, llTOaDigits, 10)+(26-26), _ui64toaKAZEzerocomma(Jumps, llTOaDigits2, 10)+(26-26), duration);
//                 winner();
//             } else if (Verbose==3) {
                 winner();
                 if ( wincount > KT ) {
                 //printf("|%s |%s |%.2f \r", _ui64toaKAZEzerocomma(Sequences, llTOaDigits, 10)+(26-26), _ui64toaKAZEzerocomma(Jumps, llTOaDigits2, 10)+(26-26), duration);
free(pointerflushUNALIGN);
free(pointerflushUNALIGN2);
                 exit(1);
                 }
//             } else if (Verbose==2) {
//                 winner();
//             } else {
//             }

      board[square] = 0; k--; return;
   }
   for (i = 0; list[square][i] != 0; i++)
   {
      if (board[list[square][i]] == 0)
         play(list[square][i]);
//      else
//         if (list[square][i+1] == 0)
//         {
//         Sequences++;
//         if (Verbose==2) winner();
//         }
   }
   board[square] = 0; k--; return;


free(pointerflushUNALIGN);
free(pointerflushUNALIGN2);

}



void winner( void )
{
   int i;
   int BrutusLet;
   int BrutusPos;
   int BrutusBIN;

     for (i = 0; i < k; i++) {
         //printf( "%c%d", 'A'+( (moves[i]-1)%8+1 )-1, 9-( (moves[i]-1)/8+1 ) );
         KTstring[i*2] = 'A'+( (moves[i]-1)%8+1 )-1;
         KTstring[i*2+1] = '0'+9-( (moves[i]-1)/8+1 );
         KTstringREVERSE[i*2] = 'A'+( (moves[(k-1)-i]-1)%8+1 )-1;
         KTstringREVERSE[i*2+1] = '0'+9-( (moves[(k-1)-i]-1)/8+1 );
          KTstringLWR[i*2] = 'a'+( (moves[i]-1)%8+1 )-1;
          KTstringLWR[i*2+1] = '0'+9-( (moves[i]-1)/8+1 );
          KTstringREVERSELWR[i*2] = 'a'+( (moves[(k-1)-i]-1)%8+1 )-1;
          KTstringREVERSELWR[i*2+1] = '0'+9-( (moves[(k-1)-i]-1)/8+1 );
     }

     //printf("\n");

	KTstring[128] = 0;
	KTstringBRUTUS[128] = 0;
	//printf("%s\n",KTstring);
	//KT_DumpCounter++;

   //if (Verbose==1) printf("\n|Sequences(only failures):  |Jumps i.e. knight's moves: |Elapsed seconds:\n");
     
//if (PrintTheFirstKTvariants == 0) {
//	printf("The first KT:\n%s\ngives following 4x64 UNIQUE derivatives:\n",KTstring);
//}

	for (BrutusLet = 0; BrutusLet < 4; BrutusLet++) {
	 for (BrutusPos = 0; BrutusPos < 64; BrutusPos++) {
		if (BrutusLet == 0) {
			memcpy( KTstringBRUTUS, KTstring, 128 );
			KTstringBRUTUS[BrutusPos*2] = KAZE_tolower(KTstring[BrutusPos*2]);
		} else if (BrutusLet == 1) {
			memcpy( KTstringBRUTUS, KTstringREVERSE, 128 );
			KTstringBRUTUS[BrutusPos*2] = KAZE_tolower(KTstringREVERSE[BrutusPos*2]);
		} else if (BrutusLet == 2) {
			memcpy( KTstringBRUTUS, KTstringLWR, 128 );
			KTstringBRUTUS[BrutusPos*2] = KAZE_toupper(KTstringLWR[BrutusPos*2]);
		} else {
			memcpy( KTstringBRUTUS, KTstringREVERSELWR, 128 );
			KTstringBRUTUS[BrutusPos*2] = KAZE_toupper(KTstringREVERSELWR[BrutusPos*2]);
		}

		KT_DumpCounter++;
//		if (PrintTheFirstKTvariants == 0) {
			printf("%s\n",KTstringBRUTUS);
//		}
		if (KT_DumpCounter==KT) exit(0);

/*
	Slot = ( FNV1A_farolito(KTstringBRUTUS, 128) & ((1<<HashSizeInBits)-1) )<<2;

	memcpy( &PseudoLinkedPointer, pointerflush+Slot, 4 );
	PseudoLinkedPointer++;
	memcpy( pointerflush+Slot, &PseudoLinkedPointer, 4 );

	Slot = ( CRC32(KTstringBRUTUS, 128) & ((1<<HashSizeInBits)-1) )<<2;

	memcpy( &PseudoLinkedPointer, pointerflush2+Slot, 4 );
	PseudoLinkedPointer++;
	memcpy( pointerflush2+Slot, &PseudoLinkedPointer, 4 );
	
	HASHfreeSLOTS = 0;
	HASHfreeSLOTS2 = 0;
	MAXcollisionsAtSomeSlotsSUM = 0;
	MAXcollisionsAtSomeSlotsSUM2 = 0;
	if (KT_DumpCounter % ReportAtEvery == 0) {
		for (i = 0; i < 1<<HashSizeInBits; i++) {
			memcpy( &PseudoLinkedPointer, pointerflush+((i)<<2), 4 );
			if (PseudoLinkedPointer == 0 ) HASHfreeSLOTS++;
			if (PseudoLinkedPointer > MAXcollisionsAtSomeSlots ) MAXcollisionsAtSomeSlots = PseudoLinkedPointer;
			memcpy( &PseudoLinkedPointer, pointerflush2+((i)<<2), 4 );
			if (PseudoLinkedPointer == 0 ) HASHfreeSLOTS2++;
			if (PseudoLinkedPointer > MAXcollisionsAtSomeSlots2 ) MAXcollisionsAtSomeSlots2 = PseudoLinkedPointer;
		}
		for (i = 0; i < 1<<HashSizeInBits; i++) {
			memcpy( &PseudoLinkedPointer, pointerflush+((i)<<2), 4 );
			if (PseudoLinkedPointer == MAXcollisionsAtSomeSlots ) MAXcollisionsAtSomeSlotsSUM++;
			memcpy( &PseudoLinkedPointer, pointerflush2+((i)<<2), 4 );
			if (PseudoLinkedPointer == MAXcollisionsAtSomeSlots2 ) MAXcollisionsAtSomeSlotsSUM2++;
		}
	printf("FNV1A_farolito         : KT_DumpCounter = %s; %s x MAXcollisionsAtSomeSlots = %s; HASHfreeSLOTS = %s\n", _ui64toaKAZEzerocomma(KT_DumpCounter, llTOaDigits, 10)+(26-17), _ui64toaKAZEzerocomma( MAXcollisionsAtSomeSlotsSUM, llTOaDigits5, 10)+(26-11), _ui64toaKAZEzerocomma(MAXcollisionsAtSomeSlots, llTOaDigits2, 10)+(26-7), _ui64toaKAZEzerocomma(HASHfreeSLOTS, llTOaDigits3, 10)+(26-13) ); // ; HashUtilization = %s%%  _ui64toaKAZEzerocomma(( (double)(((1<<HashSizeInBits)-HASHfreeSLOTS)*100) / (double)(1<<HashSizeInBits) ), llTOaDigits4, 10)+(26-3) // Buggy
	printf("CRC32 0x8F6E37A0, iSCSI: KT_DumpCounter = %s; %s x MAXcollisionsAtSomeSlots = %s; HASHfreeSLOTS = %s\n", _ui64toaKAZEzerocomma(KT_DumpCounter, llTOaDigits, 10)+(26-17), _ui64toaKAZEzerocomma( MAXcollisionsAtSomeSlotsSUM2, llTOaDigits5, 10)+(26-11), _ui64toaKAZEzerocomma(MAXcollisionsAtSomeSlots2, llTOaDigits2, 10)+(26-7), _ui64toaKAZEzerocomma(HASHfreeSLOTS2, llTOaDigits3, 10)+(26-13) ); // ; HashUtilization = %s%%  _ui64toaKAZEzerocomma(( (double)(((1<<HashSizeInBits)-HASHfreeSLOTS2)*100) / (double)(1<<HashSizeInBits) ), llTOaDigits4, 10)+(26-3) // Buggy
	}
*/

	 } //for (BrutusPos...
	} //for (BrutusLet...

	PrintTheFirstKTvariants = 1;

}
