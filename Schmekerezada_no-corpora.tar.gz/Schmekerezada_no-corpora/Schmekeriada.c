﻿// Written by Kaze, BUGFIX (2023-Jul-10) in multi-thread section - forgot to mask the dummy threads, 2022-Oct-25
// 2022-Oct-12: Fixed a compare bug: forgot to change 'memcmpKAZE_QWORD_reverse' with 'memcmpKAZE_QWORD_reversePTR'

void x64toaKAZE (      /* stdcall is faster and smaller... Might as well use it for the helper. */
        unsigned long long val,
        char *buf,
        unsigned radix,
        int is_neg
        )
{
        char *p;                /* pointer to traverse string */
        char *firstdig;         /* pointer to first digit */
        char temp;              /* temp char */
        unsigned digval;        /* value of digit */

        p = buf;

        if ( is_neg )
        {
            *p++ = '-';         /* negative, so output '-' and negate */
            val = (unsigned long long)(-(long long)val);
        }

        firstdig = p;           /* save pointer to first digit */

        do {
            digval = (unsigned) (val % radix);
            val /= radix;       /* get next digit */

            /* convert to ascii and store */
            if (digval > 9)
                *p++ = (char) (digval - 10 + 'a');  /* a letter */
            else
                *p++ = (char) (digval + '0');       /* a digit */
        } while (val > 0);

        /* We now have the digit of the number in the buffer, but in reverse
           order.  Thus we reverse them now. */

        *p-- = '\0';            /* terminate string; p points to last digit */

        do {
            temp = *p;
            *p = *firstdig;
            *firstdig = temp;   /* swap *p and *firstdig */
            --p;
            ++firstdig;         /* advance to next two digits */
        } while (firstdig < p); /* repeat until halfway */
}

/* Actual functions just call conversion helper with neg flag set correctly,
   and return pointer to buffer. */

char * _i64toaKAZE (
        long long val,
        char *buf,
        int radix
        )
{
        x64toaKAZE((unsigned long long)val, buf, radix, (radix == 10 && val < 0));
        return buf;
}

char * _ui64toaKAZE (
        unsigned long long val,
        char *buf,
        int radix
        )
{
        x64toaKAZE(val, buf, radix, 0);
        return buf;
}

char * _ui64toaKAZEzerocomma (
        unsigned long long val,
        char *buf,
        int radix
        )
{
                        char *p;
                        char temp;
                        int txpman;
                        int pxnman;
        x64toaKAZE(val, buf, radix, 0);
                        p = buf;
                        do {
                        } while (*++p != '\0');
                        p--; // p points to last digit
                             // buf points to first digit
                        buf[26] = 0;
                        txpman = 1;
                        pxnman = 0;
                        do
                        { if (buf <= p)
                          { temp = *p;
                            buf[26-txpman] = temp; pxnman++;
                            p--;
                            if (pxnman % 3 == 0)
                            { txpman++;
                              buf[26-txpman] = (char) (',');
                            }
                          }
                          else
                          { buf[26-txpman] = (char) ('0'); pxnman++;
                            if (pxnman % 3 == 0)
                            { txpman++;
                              buf[26-txpman] = (char) (',');
                            }
                          }
                          txpman++;
                        } while (txpman <= 26);
        return buf;
}

char * _ui64toaKAZEcomma (
        unsigned long long val,
        char *buf,
        int radix
        )
{
                        char *p;
                        char temp;
                        int txpman;
                        int pxnman;
        x64toaKAZE(val, buf, radix, 0);
                        p = buf;
                        do {
                        } while (*++p != '\0');
                        p--; // p points to last digit
                             // buf points to first digit
                        buf[26] = 0;
                        txpman = 1;
                        pxnman = 0;
                        while (buf <= p)
                        { temp = *p;
                          buf[26-txpman] = temp; pxnman++;
                          p--;
                          if (pxnman % 3 == 0 && buf <= p)
                          { txpman++;
                            buf[26-txpman] = (char) (',');
                          }
                          txpman++;
                        } 
        return buf+26-(txpman-1);
}

// The idea is to compare the built-in qsort vs my 'Magnetica' Quicksort, using "perf stat -d" in this fashion: https://github.com/facebook/zstd/issues/2551
// How to compile?
/*
F:\Quicksort_says_rev9+_finished>type make_elf.sh
gcc -S -O3 -m64 -static -fomit-frame-pointer QS_bench_r13.c -o QS_bench_r13.elf.asm -D_N_HIGH_PRIORITY_GCC
gcc -O3 -m64 -static -fomit-frame-pointer QS_bench_r13.c -o QS_bench_r13_GCC11.2.1.elf -D_N_HIGH_PRIORITY_GCC
gcc -O3 -m64 -static -fomit-frame-pointer QS_bench_r13.c -o QS_bench_r13_GCC11.2.1_FULL-FLEDGED.elf -D_N_HIGH_PRIORITY_GCC -DFinishWithInsertionSort
x86_64-w64-mingw32-gcc -O3 -m64 -static -fomit-frame-pointer QS_bench_r13.c -o QS_bench_r13_GCC11.2.1.exe -D_N_HIGH_PRIORITY
x86_64-w64-mingw32-gcc -O3 -m64 -static -fomit-frame-pointer QS_bench_r13.c -o QS_bench_r13_GCC11.2.1_FULL-FLEDGED.exe -D_N_HIGH_PRIORITY -DFinishWithInsertionSort

F:\Quicksort_says_rev9+_finished>type MAKE_EXE.bat
@rem icl QS_bench_r8.c /arch:SSE4.1 /FAcs /O3 /Qopenmp /Qopenmp-link:static -DCommence_OpenMP -D_N_HIGH_PRIORITY
icl QS_bench_r13.c /S /O3 -D_N_HIGH_PRIORITY
icl QS_bench_r13.c /FAcs /O3 /FeQS_bench_r13_ICL15.0_64bit_FULL-FLEDGED.exe -DFinishWithInsertionSort -D_N_HIGH_PRIORITY
icl QS_bench_r13.c /FAcs /O3 /FeQS_bench_r13_ICL15.0_64bit.exe -D_N_HIGH_PRIORITY

F:\Quicksort_says_rev9+_finished>
*/

// Results on laptop with i5-7200U 36GB DDR4 2133MHz:
/*
c:\Resources_Quicksort_2022-Jun\QS_Collatz>QS_bench_r14_GCC11.3.0_rev5bypass.exe CS 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 27465MB ...
Sorting in single-thread 3600000000 elements...
AVX2 check. UNSORTEDNESS (in permyriads) = 1666+ O/ooo = (Number_of_Minimum_Unsorted_Keys = 600000002)*10000/(Number_of_All_Keys = 3600000000)
Done in 147 seconds.
Checking whether sort went correct... OK. Unique keys = 47586732
Sorting sorted elements...
Done in 6 seconds.
Checking whether sort went correct... OK. Unique keys = 47586732
AVX2 check. Number_of_Minimum_Unsorted_Keys = 0
UNIQUENESS/Entropy = 0.013218536417 = (Number_of_Unique_Keys - 0.9 = 47586731)/(Number_of_All_Keys = 3600000000)

c:\Resources_Quicksort_2022-Jun\QS_Collatz>QS_bench_r14_GCC11.3.0_rev5bypass.exe BM 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 27465MB ...
Sorting in single-thread 3600000000 elements...
AVX2 check. UNSORTEDNESS (in permyriads) = 1666+ O/ooo = (Number_of_Minimum_Unsorted_Keys = 600000002)*10000/(Number_of_All_Keys = 3600000000)
Done in 229 seconds.
Checking whether sort went correct... OK. Unique keys = 47586732
Sorting sorted elements...
Done in 51 seconds.
Checking whether sort went correct... OK. Unique keys = 47586732
AVX2 check. Number_of_Minimum_Unsorted_Keys = 0
UNIQUENESS/Entropy = 0.013218536417 = (Number_of_Unique_Keys - 0.9 = 47586731)/(Number_of_All_Keys = 3600000000)

c:\Resources_Quicksort_2022-Jun\QS_Collatz>QS_bench_r14_GCC11.3.0_rev5bypass.exe Magnetica 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 27465MB ...
Sorting in single-thread 3600000000 elements...
AVX2 check. UNSORTEDNESS (in permyriads) = 1666+ O/ooo = (Number_of_Minimum_Unsorted_Keys = 600000002)*10000/(Number_of_All_Keys = 3600000000)
Done in 214 seconds.
Checking whether sort went correct... OK. Unique keys = 47586732
Sorting sorted elements...
Done in 47 seconds.
Checking whether sort went correct... OK. Unique keys = 47586732
AVX2 check. Number_of_Minimum_Unsorted_Keys = 0
UNIQUENESS/Entropy = 0.013218536417 = (Number_of_Unique_Keys - 0.9 = 47586731)/(Number_of_All_Keys = 3600000000)

c:\Resources_Quicksort_2022-Jun\QS_Collatz>QS_bench_r14_GCC11.3.0_rev5bypass.exe qsort 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 27465MB ...
Sorting in single-thread 3600000000 elements...
AVX2 check. UNSORTEDNESS (in permyriads) = 1666+ O/ooo = (Number_of_Minimum_Unsorted_Keys = 600000002)*10000/(Number_of_All_Keys = 3600000000)
Done in 473 seconds.
Checking whether sort went correct... OK. Unique keys = 47586732
Sorting sorted elements...
Done in 155 seconds.
Checking whether sort went correct... OK. Unique keys = 47586732
AVX2 check. Number_of_Minimum_Unsorted_Keys = 0
UNIQUENESS/Entropy = 0.013218536417 = (Number_of_Unique_Keys - 0.9 = 47586731)/(Number_of_All_Keys = 3600000000)

c:\Resources_Quicksort_2022-Jun\QS_Collatz>
*/

/*
__m128d _mm_cmpgt_pd (__m128d a, __m128d b)
#include <emmintrin.h>
Instruction: cmppd xmm, xmm, imm8
CPUID Flags: SSE2
Description
Compare packed double-precision (64-bit) floating-point elements in a and b for greater-than, and store the results in dst.
Operation
FOR j := 0 to 1
    i := j*64
    dst[i+63:i] := (a[i+63:i] > b[i+63:i]) ? 0xFFFFFFFFFFFFFFFF : 0
ENDFOR

Performance
Architecture    Latency Throughput (CPI)
Skylake 4   0.5
Broadwell   3   1
Haswell 3   1
Ivy Bridge  3   1
*/

/*
__m128d _mm_cmpeq_pd (__m128d a, __m128d b)
#include <emmintrin.h>
Instruction: cmppd xmm, xmm, imm8
CPUID Flags: SSE2
Description
Compare packed double-precision (64-bit) floating-point elements in a and b for equality, and store the results in dst.
Operation
FOR j := 0 to 1
    i := j*64
    dst[i+63:i] := (a[i+63:i] == b[i+63:i]) ? 0xFFFFFFFFFFFFFFFF : 0
ENDFOR

Performance
Architecture    Latency Throughput (CPI)
Skylake 4   0.5
Broadwell   3   1
Haswell 3   1
Ivy Bridge  3   1
*/

/*
__m256d _mm256_permutevar_pd (__m256d a, __m256i b)
#include <immintrin.h>
Instruction: vpermilpd ymm, ymm, ymm
CPUID Flags: AVX
Description
Shuffle double-precision (64-bit) floating-point elements in a within 128-bit lanes using the control in b, and store the results in dst.
Operation
IF (b[1] == 0) dst[63:0] := a[63:0]; FI
IF (b[1] == 1) dst[63:0] := a[127:64]; FI
IF (b[65] == 0) dst[127:64] := a[63:0]; FI
IF (b[65] == 1) dst[127:64] := a[127:64]; FI
IF (b[129] == 0) dst[191:128] := a[191:128]; FI
IF (b[129] == 1) dst[191:128] := a[255:192]; FI
IF (b[193] == 0) dst[255:192] := a[191:128]; FI
IF (b[193] == 1) dst[255:192] := a[255:192]; FI
dst[MAX:256] := 0

Performance
Architecture    Latency Throughput (CPI)
Icelake 1   -
Skylake 1   1
Broadwell   1   1
Haswell 1   1
Ivy Bridge  1   1
*/

/*
__mmask8 _mm256_cmpgt_epu64_mask (__m256i a, __m256i b)
#include <immintrin.h>
Instruction: vpcmpuq k, ymm, ymm
CPUID Flags: AVX512F + AVX512VL
Description
Compare packed unsigned 64-bit integers in a and b for greater-than, and store the results in mask vector k.
Operation
FOR j := 0 to 3
    i := j*64
    k[j] := ( a[i+63:i] > b[i+63:i] ) ? 1 : 0
ENDFOR
k[MAX:4] := 0

Performance
Architecture    Latency Throughput (CPI)
Skylake 3   1
*/

/*
__m256i _mm256_cmpgt_epi64 (__m256i a, __m256i b)
#include <immintrin.h>
Instruction: vpcmpgtq ymm, ymm, ymm
CPUID Flags: AVX2
Description
Compare packed signed 64-bit integers in a and b for greater-than, and store the results in dst.
Operation
FOR j := 0 to 3
    i := j*64
    dst[i+63:i] := ( a[i+63:i] > b[i+63:i] ) ? 0xFFFFFFFFFFFFFFFF : 0
ENDFOR
dst[MAX:256] := 0

Performance
Architecture    Latency Throughput (CPI)
Icelake 3   1
Skylake 3   1
Broadwell   5   1
Haswell 5   1
*/

/*
__m256i _mm256_cmpeq_epi64 (__m256i a, __m256i b)
#include <immintrin.h>
Instruction: vpcmpeqq ymm, ymm, ymm
CPUID Flags: AVX2
Description
Compare packed 64-bit integers in a and b for equality, and store the results in dst.
Operation
FOR j := 0 to 3
    i := j*64
    dst[i+63:i] := ( a[i+63:i] == b[i+63:i] ) ? 0xFFFFFFFFFFFFFFFF : 0
ENDFOR
dst[MAX:256] := 0

Performance
Architecture    Latency Throughput (CPI)
Icelake 1   0.5
Skylake 1   0.5
Broadwell   1   0.5
Haswell 1   0.5
*/

// __m256i _mm256_setr_epi32 (int e7, int e6, int e5, int e4, int e3, int e2, int e1, int e0)
// #include <immintrin.h>
// Instruction: Sequence
// CPUID Flags: AVX
// Description
// Set packed 32-bit integers in dst with the supplied values in reverse order.
// Operation
// dst[31:0] := e7
// dst[63:32] := e6
// dst[95:64] := e5
// dst[127:96] := e4
// dst[159:128] := e3
// dst[191:160] := e2
// dst[223:192] := e1
// dst[255:224] := e0
// dst[MAX:256] := 0

// __m256i _mm256_setr_epi64x (__int64 e3, __int64 e2, __int64 e1, __int64 e0)
// #include <immintrin.h>
// Instruction: Sequence
// CPUID Flags: AVX
// Description
// Set packed 64-bit integers in dst with the supplied values in reverse order.
// Operation
// dst[63:0] := e3
// dst[127:64] := e2
// dst[191:128] := e1
// dst[255:192] := e0
// dst[MAX:256] := 0

// __m256i _mm256_permutevar8x32_epi32 (__m256i a, __m256i idx)
// #include <immintrin.h>
// Instruction: vpermd ymm, ymm, ymm
// CPUID Flags: AVX2
// Description
// Shuffle 32-bit integers in a across lanes using the corresponding index in idx, and store the results in dst.
// Operation
// FOR j := 0 to 7
//  i := j*32
//  id := idx[i+2:i]*32
//  dst[i+31:i] := a[id+31:id]
// ENDFOR
// dst[MAX:256] := 0
// Performance
// Architecture Latency Throughput (CPI)
// Icelake  3   1
// Skylake  3   1

// __m256i _mm256_cmpgt_epi32 (__m256i a, __m256i b)
// #include <immintrin.h>
// Instruction: vpcmpgtd ymm, ymm, ymm
// CPUID Flags: AVX2
// Description
// Compare packed signed 32-bit integers in a and b for greater-than, and store the results in dst.
// Operation
// FOR j := 0 to 7
//  i := j*32
//  dst[i+31:i] := ( a[i+31:i] > b[i+31:i] ) ? 0xFFFFFFFF : 0
// ENDFOR
// dst[MAX:256] := 0
// Performance
// Architecture Latency Throughput (CPI)
// Icelake  1   0.5
// Skylake  1   0.5

// int _mm256_testz_si256 (__m256i a, __m256i b)
// #include <immintrin.h>
// Instruction: vptest ymm, ymm
// CPUID Flags: AVX
// Description
// Compute the bitwise AND of 256 bits (representing integer data) in a and b, and set ZF to 1 if the result is zero, otherwise set ZF to 0. Compute the bitwise NOT of a and then AND with b, and set CF to 1 if the result is zero, otherwise set CF to 0. Return the ZF value.
// Operation
// IF ((a[255:0] AND b[255:0]) == 0)
//  ZF := 1
// ELSE
//  ZF := 0
// FI
// IF (((NOT a[255:0]) AND b[255:0]) == 0)
//  CF := 1
// ELSE
//  CF := 0
// FI
// RETURN ZF
// Performance
// Architecture Latency Throughput (CPI)
// Icelake  -   1
// Skylake  3   1


// My thread with the Magnetica's source and binaries (Linux and Windows):
// https://www.overclock.net/threads/benchmark-quicksort-says-sorting-2-billion-qwords.1794855/
// https://www.qb64.org/forum/index.php?topic=3518.msg137645#msg137645
/*
' Written by Sanmayce, 2021-Nov-06
' The indexes are signed, but the elements are unsigned.
_Define A-Z As _INTEGER64
Sub Quicksort_QB64_v3 (QWORDS~&&())
    InsertionsortTHRESHOLD = 0 '19
    Left = LBound(QWORDS~&&)
    Right = UBound(QWORDS~&&)
    ReDim Stack&&(Left To Right)
    StackPtr = 0
    StackPtr = StackPtr + 1
    Stack&&(StackPtr + LeftMargin) = Left
    StackPtr = StackPtr + 1
    Stack&&(StackPtr + LeftMargin) = Right
    Do 'Until StackPtr = 0
        Right = Stack&&(StackPtr)
        Left = Stack&&(StackPtr - 1)
        StackPtr = StackPtr - 2
        Do 'Until Left >= Right

            ''Classica' partitioning [
            'Pivot~&& = QWORDS~&&((Left + Right) \ 2)
            'Indx = Left
            'Jndx = Right
            'Do
            '    Do While (QWORDS~&&(Indx) < Pivot~&&)
            '        Indx = Indx + 1
            '    Loop
            '    Do While (QWORDS~&&(Jndx) > Pivot~&&)
            '        Jndx = Jndx - 1
            '    Loop
            '    If Indx <= Jndx Then
            '        If Indx < Jndx Then Swap QWORDS~&&(Indx), QWORDS~&&(Jndx)
            '        Indx = Indx + 1
            '        Jndx = Jndx - 1
            '    End If
            'Loop While Indx <= Jndx
            ''Classica' partitioning ]

            ' 'Magnetica' partitioning [
            Jndx = Right
            PL = Left
            PR = Left
            Swap QWORDS~&&((Left + Right) \ 2), QWORDS~&&(PR)
            Pivot~&& = QWORDS~&&(PR)
            Do While PR < Jndx
                If Pivot~&& > QWORDS~&&(PR + 1) Then
                    Swap QWORDS~&&(PL), QWORDS~&&(PR + 1)
                    PL = PL + 1
                    PR = PR + 1
                ElseIf Pivot~&& = QWORDS~&&(PR + 1) Then
                    PR = PR + 1
                Else ' < i.e. Pivot~&& < QWORDS~&&(PR + 1)
                    Do While Pivot~&& < QWORDS~&&(Jndx)
                        Jndx = Jndx - 1
                    Loop
                    If PR + 1 < Jndx Then Swap QWORDS~&&(PR + 1), QWORDS~&&(Jndx)
                    Jndx = Jndx - 1
                End If
            Loop
            Jndx = PL - 1
            Indx = PR + 1
            ' 'Magnetica' partitioning ]

            If Indx + InsertionsortTHRESHOLD < Right Then 'if the remaining chunk is bigger than 'InsertionsortTHRESHOLD' push it to stack, otherwise leave all such chunks unsorted
                StackPtr = StackPtr + 2
                Stack&&(StackPtr - 1) = Indx
                Stack&&(StackPtr) = Right
            End If
            Right = Jndx
        Loop Until Left >= Right
    Loop Until StackPtr = 0
    'Left = LBound(QWORDS~&&)
    'Right = UBound(QWORDS~&&)
    'For i = Left + 1 To Right ' i.e. 1 to size-1 omitting the first (which is 0)
    '    j = i
    '    Do While j >= 1 'Nah, start using a sentinel
    '        If QWORDS~&&(j - 1) > QWORDS~&&(j) Then Swap QWORDS~&&(j - 1), QWORDS~&&(j) Else Exit Do
    '        j = j - 1
    '    Loop
    'Next i
End Sub
*/

// On i5-7200U 3.1GHz (2cores/4threads), 64bit code by gcc version 10.2.1, Fedora 33:
/*
[kaze@kaze ~]$ cd /run/media/kaze/Sanmayce_223GB_A/Quicksort_says_rev3
[kaze@kaze Quicksort_says_rev3]$ dir
22338618_QWORDS.bin  Fedora-Workstation-Live-x86_64-35-1.2.iso  Px437_Cordata_PPC-400.ttf  Quicksort_says      Quicksort_says_rev3_Kaby-Lake_Fedora-33.png
bench.sh         MEM.H                  QS_bench_r3.c          Quicksort_says.bas  Quicksort_says_rev3_Kaby-Lake_Windows-10.png
ColumnChart.ico      mobythesaurus.txt              QS_bench_r3.exe        Quicksort_says.exe  Sir_Tony_Hoare_IMG_5125.png
[kaze@kaze Quicksort_says_rev3]$ gcc -O3 QS_bench_r3.c -o QS_bench_r3
QS_bench_r3.c:473:1: warning: return type defaults to ‘int’ [-Wimplicit-int]
  473 | g(d,h){for(i=s;i<1<<25;i*=2)d=d*1LL*d%m;for(p=t;p<t+N;p+=s)for(i=s,c=1;i;i--)a=p[s]*(h?c:1LL)%m,p[s]=(m*1U+*p-a)*(h?1LL:c)%m,*p=(a*1U+*p)%m,p++,c=c*1LL*d%m;}
      | ^
QS_bench_r3.c: In function ‘g’:
QS_bench_r3.c:473:1: warning: type of ‘d’ defaults to ‘int’ [-Wimplicit-int]
QS_bench_r3.c:473:1: warning: type of ‘h’ defaults to ‘int’ [-Wimplicit-int]
QS_bench_r3.c: In function ‘main’:
QS_bench_r3.c:557:6: warning: implicit declaration of function ‘strcmp’ [-Wimplicit-function-declaration]
  557 |  if (strcmp(argv[2],"many")==0) {
      |      ^~~~~~
[kaze@kaze Quicksort_says_rev3]$ perf stat -d ./QS_bench_r3 qsort few
Allocating AUX-Buffer 21MB ...
Allocating Master-Buffer 17043MB ...
Sorting in single-thread 2233861800 elements...
Checking whether sort went correct... OK. Unique keys = 10

 Performance counter stats for './QS_bench_r3 qsort few':

        325,465.05 msec task-clock:u              #    0.998 CPUs utilized          
                 0      context-switches:u        #    0.000 K/sec                  
                 0      cpu-migrations:u          #    0.000 K/sec                  
         4,363,063      page-faults:u             #    0.013 M/sec                  
   980,631,883,041      cycles:u                  #    3.013 GHz                      (50.00%)
 3,279,551,895,331      instructions:u            #    3.34  insn per cycle           (62.50%)
   650,482,999,545      branches:u                # 1998.626 M/sec                    (62.50%)
     5,582,924,930      branch-misses:u           #    0.86% of all branches          (62.50%)
   734,186,209,415      L1-dcache-loads:u         # 2255.807 M/sec                    (62.50%)
     6,753,617,333      L1-dcache-load-misses:u   #    0.92% of all L1-dcache accesses  (62.50%)
       404,414,575      LLC-loads:u               #    1.243 M/sec                    (50.00%)
       111,254,842      LLC-load-misses:u         #   27.51% of all LL-cache accesses  (50.00%)

     326.101784425 seconds time elapsed

     317.871539000 seconds user
       5.577791000 seconds sys


[kaze@kaze Quicksort_says_rev3]$ perf stat -d ./QS_bench_r3 Magnetica  few
Allocating AUX-Buffer 21MB ...
Allocating Master-Buffer 17043MB ...
Sorting in single-thread 2233861800 elements...
Checking whether sort went correct... OK. Unique keys = 10

 Performance counter stats for './QS_bench_r3 Magnetica few':

         45,479.14 msec task-clock:u              #    1.000 CPUs utilized          
                 0      context-switches:u        #    0.000 K/sec                  
                 0      cpu-migrations:u          #    0.000 K/sec                  
         4,363,068      page-faults:u             #    0.096 M/sec                  
   121,955,292,590      cycles:u                  #    2.682 GHz                      (50.00%)
   112,449,514,935      instructions:u            #    0.92  insn per cycle           (62.50%)
    24,092,559,780      branches:u                #  529.750 M/sec                    (62.50%)
     3,384,288,209      branch-misses:u           #   14.05% of all branches          (62.50%)
    13,329,400,797      L1-dcache-loads:u         #  293.088 M/sec                    (62.50%)
     1,655,811,975      L1-dcache-load-misses:u   #   12.42% of all L1-dcache accesses  (62.50%)
        70,845,055      LLC-loads:u               #    1.558 M/sec                    (50.00%)
        62,316,430      LLC-load-misses:u         #   87.96% of all LL-cache accesses  (50.00%)

      45.492587322 seconds time elapsed

      39.738044000 seconds user
       5.413636000 seconds sys


[kaze@kaze Quicksort_says_rev3]$ perf stat -d ./QS_bench_r3 BM  few
Allocating AUX-Buffer 21MB ...
Allocating Master-Buffer 17043MB ...
Sorting in single-thread 2233861800 elements...
Checking whether sort went correct... OK. Unique keys = 10

 Performance counter stats for './QS_bench_r3 BM few':

         51,751.74 msec task-clock:u              #    1.000 CPUs utilized          
                 0      context-switches:u        #    0.000 K/sec                  
                 0      cpu-migrations:u          #    0.000 K/sec                  
         4,363,064      page-faults:u             #    0.084 M/sec                  
   140,850,991,285      cycles:u                  #    2.722 GHz                      (50.00%)
   141,773,758,594      instructions:u            #    1.01  insn per cycle           (62.50%)
    29,021,682,740      branches:u                #  560.787 M/sec                    (62.50%)
     2,964,754,548      branch-misses:u           #   10.22% of all branches          (62.49%)
    20,759,616,908      L1-dcache-loads:u         #  401.139 M/sec                    (62.50%)
     2,253,507,095      L1-dcache-load-misses:u   #   10.86% of all L1-dcache accesses  (62.50%)
       240,693,428      LLC-loads:u               #    4.651 M/sec                    (50.00%)
       119,509,033      LLC-load-misses:u         #   49.65% of all LL-cache accesses  (50.00%)

      51.765804273 seconds time elapsed

      45.999839000 seconds user
       5.392254000 seconds sys


[kaze@kaze Quicksort_says_rev3]$ perf stat -d ./QS_bench_r3 qsort many
Allocating FILE-Buffer 23MB ...
Allocating AUX-Buffer 189MB ...
Allocating Master-Buffer 18938MB ...
Sorting in single-thread 2482300900 elements...
Checking whether sort went correct... OK. Unique keys = 2847531

 Performance counter stats for './QS_bench_r3 qsort many':

        517,942.56 msec task-clock:u              #    0.999 CPUs utilized          
                 0      context-switches:u        #    0.000 K/sec                  
                 0      cpu-migrations:u          #    0.000 K/sec                  
         4,896,779      page-faults:u             #    0.009 M/sec                  
 1,569,421,552,908      cycles:u                  #    3.030 GHz                      (50.00%)
 2,937,315,064,269      instructions:u            #    1.87  insn per cycle           (62.50%)
   656,656,940,988      branches:u                # 1267.818 M/sec                    (62.50%)
    25,008,235,993      branch-misses:u           #    3.81% of all branches          (62.50%)
   675,474,160,813      L1-dcache-loads:u         # 1304.149 M/sec                    (62.50%)
     8,374,868,618      L1-dcache-load-misses:u   #    1.24% of all L1-dcache accesses  (62.50%)
       244,454,547      LLC-loads:u               #    0.472 M/sec                    (50.00%)
       132,791,156      LLC-load-misses:u         #   54.32% of all LL-cache accesses  (50.00%)

     518.237032044 seconds time elapsed

     508.735040000 seconds user
       5.950954000 seconds sys


[kaze@kaze Quicksort_says_rev3]$ perf stat -d ./QS_bench_r3 Magnetica many
Allocating FILE-Buffer 23MB ...
Allocating AUX-Buffer 189MB ...
Allocating Master-Buffer 18938MB ...
Sorting in single-thread 2482300900 elements...
Checking whether sort went correct... OK. Unique keys = 2847531

 Performance counter stats for './QS_bench_r3 Magnetica many':

        230,292.26 msec task-clock:u              #    1.000 CPUs utilized          
                 0      context-switches:u        #    0.000 K/sec                  
                 0      cpu-migrations:u          #    0.000 K/sec                  
         4,896,782      page-faults:u             #    0.021 M/sec                  
   686,398,758,890      cycles:u                  #    2.981 GHz                      (50.00%)
   801,299,477,504      instructions:u            #    1.17  insn per cycle           (62.50%)
   152,341,819,141      branches:u                #  661.515 M/sec                    (62.50%)
    19,420,019,786      branch-misses:u           #   12.75% of all branches          (62.50%)
   105,227,165,554      L1-dcache-loads:u         #  456.929 M/sec                    (62.50%)
     9,758,775,155      L1-dcache-load-misses:u   #    9.27% of all L1-dcache accesses  (62.50%)
       331,205,631      LLC-loads:u               #    1.438 M/sec                    (50.00%)
       260,265,720      LLC-load-misses:u         #   78.58% of all LL-cache accesses  (50.00%)

     230.399202449 seconds time elapsed

     222.654274000 seconds user
       5.973146000 seconds sys


[kaze@kaze Quicksort_says_rev3]$ perf stat -d ./QS_bench_r3 BM many
Allocating FILE-Buffer 23MB ...
Allocating AUX-Buffer 189MB ...
Allocating Master-Buffer 18938MB ...
Sorting in single-thread 2482300900 elements...
Checking whether sort went correct... OK. Unique keys = 2847531

 Performance counter stats for './QS_bench_r3 BM many':

        234,206.73 msec task-clock:u              #    1.000 CPUs utilized          
                 0      context-switches:u        #    0.000 K/sec                  
                 0      cpu-migrations:u          #    0.000 K/sec                  
         4,896,781      page-faults:u             #    0.021 M/sec                  
   698,588,697,890      cycles:u                  #    2.983 GHz                      (50.00%)
   656,081,987,764      instructions:u            #    0.94  insn per cycle           (62.50%)
   165,692,577,479      branches:u                #  707.463 M/sec                    (62.50%)
    18,927,109,180      branch-misses:u           #   11.42% of all branches          (62.50%)
    85,146,879,545      L1-dcache-loads:u         #  363.554 M/sec                    (62.50%)
     8,623,541,343      L1-dcache-load-misses:u   #   10.13% of all L1-dcache accesses  (62.50%)
       286,352,303      LLC-loads:u               #    1.223 M/sec                    (50.00%)
       227,490,519      LLC-load-misses:u         #   79.44% of all LL-cache accesses  (50.00%)

     234.306277225 seconds time elapsed

     226.632611000 seconds user
       5.938060000 seconds sys


[kaze@kaze Quicksort_says_rev3]$ perf stat -d ./QS_bench_r3 qsort ALL
Allocating FILE-Buffer 1916MB ...
Allocating AUX-Buffer 15329MB ...
Allocating Master-Buffer 15329MB ...
Sorting in single-thread 2009333753 elements...
Checking whether sort went correct... OK. Unique keys = 1912608132

 Performance counter stats for './QS_bench_r3 qsort ALL':

        520,097.93 msec task-clock:u              #    0.993 CPUs utilized          
                 0      context-switches:u        #    0.000 K/sec                  
                 0      cpu-migrations:u          #    0.000 K/sec                  
         7,849,014      page-faults:u             #    0.015 M/sec                  
 1,553,894,682,781      cycles:u                  #    2.988 GHz                      (50.00%)
 2,271,179,443,512      instructions:u            #    1.46  insn per cycle           (62.50%)
   536,952,307,468      branches:u                # 1032.406 M/sec                    (62.50%)
    28,368,595,067      branch-misses:u           #    5.28% of all branches          (62.50%)                           
   520,144,933,578      L1-dcache-loads:u         # 1000.090 M/sec                    (62.50%)
     6,723,006,421      L1-dcache-load-misses:u   #    1.29% of all L1-dcache accesses  (62.50%)
       193,261,861      LLC-loads:u               #    0.372 M/sec                    (50.00%)
       102,759,148      LLC-load-misses:u         #   53.17% of all LL-cache accesses  (50.00%)

     524.002327535 seconds time elapsed

     504.423911000 seconds user
      12.294510000 seconds sys


[kaze@kaze Quicksort_says_rev3]$ perf stat -d ./QS_bench_r3 Magnetica ALL
Allocating FILE-Buffer 1916MB ...
Allocating AUX-Buffer 15329MB ...
Allocating Master-Buffer 15329MB ...
Sorting in single-thread 2009333753 elements...
Checking whether sort went correct... OK. Unique keys = 1912608132

 Performance counter stats for './QS_bench_r3 Magnetica ALL':

        306,913.60 msec task-clock:u              #    0.990 CPUs utilized          
                 0      context-switches:u        #    0.000 K/sec                  
                 0      cpu-migrations:u          #    0.000 K/sec                  
         7,849,020      page-faults:u             #    0.026 M/sec                  
   899,578,515,950      cycles:u                  #    2.931 GHz                      (50.00%)
 1,077,947,210,852      instructions:u            #    1.20  insn per cycle           (62.50%)
   202,031,197,397      branches:u                #  658.267 M/sec                    (62.50%)
    25,788,554,132      branch-misses:u           #   12.76% of all branches          (62.50%)
   143,089,373,092      L1-dcache-loads:u         #  466.220 M/sec                    (62.50%)
     7,361,011,433      L1-dcache-load-misses:u   #    5.14% of all L1-dcache accesses  (62.50%)
       240,367,987      LLC-loads:u               #    0.783 M/sec                    (50.00%)
       189,560,929      LLC-load-misses:u         #   78.86% of all LL-cache accesses  (50.00%)

     310.137967617 seconds time elapsed

     292.453199000 seconds user
      12.266850000 seconds sys


[kaze@kaze Quicksort_says_rev3]$ perf stat -d ./QS_bench_r3 BM ALL
Allocating FILE-Buffer 1916MB ...
Allocating AUX-Buffer 15329MB ...
Allocating Master-Buffer 15329MB ...
Sorting in single-thread 2009333753 elements...
Checking whether sort went correct... OK. Unique keys = 1912608132

 Performance counter stats for './QS_bench_r3 BM ALL':

        322,688.09 msec task-clock:u              #    0.992 CPUs utilized          
                 0      context-switches:u        #    0.000 K/sec                  
                 0      cpu-migrations:u          #    0.000 K/sec                  
         7,849,403      page-faults:u             #    0.024 M/sec                  
   943,352,167,992      cycles:u                  #    2.923 GHz                      (50.00%)
   896,389,731,553      instructions:u            #    0.95  insn per cycle           (62.50%)
   226,893,780,871      branches:u                #  703.137 M/sec                    (62.50%)
    26,011,308,958      branch-misses:u           #   11.46% of all branches          (62.50%)
   119,844,660,142      L1-dcache-loads:u         #  371.395 M/sec                    (62.50%)
     7,940,603,646      L1-dcache-load-misses:u   #    6.63% of all L1-dcache accesses  (62.50%)
       258,555,901      LLC-loads:u               #    0.801 M/sec                    (50.00%)
       217,482,356      LLC-load-misses:u         #   84.11% of all LL-cache accesses  (50.00%)

     325.339098420 seconds time elapsed

     306.791354000 seconds user
      13.564926000 seconds sys


[kaze@kaze Quicksort_says_rev3]$ 
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h> // Needed for uint32_t
#include<time.h>
#include <string.h> // for memcmp() and strchr()
#ifdef Commence_OpenMP
#include <omp.h>
#endif

int32_t memcmpKAZE_QWORD_reversePTR (uint64_t *buf1, uint64_t *buf2, size_t count, size_t NumberOfLFs);

//#include <sys/time.h>
//        double  t4 = tick();
//  ...
//        double  t5 = tick();
//        fprintf(stderr, "sserank: %.4f\n", t5 - t4);
/*
static double tick(void)
{
    struct timeval t;

    gettimeofday(&t, 0);
    return t.tv_sec + 1E-6 * t.tv_usec;
}
*/

/*
Many thanks go to Mark Blacher,Joachim Giesen,Lars Kühne for 'Fast and Robust Vectorized In-Place Sorting of Primitive Types' and the code along it:
sort_8_int.cpp: 
*/
// #include <cstdio>
// #include <immintrin.h>
// 
// /*
//  * Bitonic sort of 8 elements with two vectors.
//  * Each vector has a capacity of 4 elements.
//  */
// 
// /* compute 4 COEX modules */
// inline void COEX(__m128i &a, __m128i &b) {
//   /* copy vector a to c */
//   __m128i c = a;
//   /* pairwise minimum */
//   a = _mm_min_epi32(a, b);
//   /* pairwise maximum */
//   b = _mm_max_epi32(c, b);
// }
// 
// /* shuffle 2 __m128i vectors */
// #define SHUFFLE_TWO_VECS(a, b, mask)                                           \
//   reinterpret_cast<__m128i>(_mm_shuffle_ps(                                    \
//       reinterpret_cast<__m128>(a), reinterpret_cast<__m128>(b), mask));
// 
// int main() {
//   int arr[8] = {11, 29, 13, 23, 37, 17, 19, 31};
// 
//   /* load vectors */
//   __m128i v1 = _mm_loadu_si128(reinterpret_cast<__m128i *>(arr));
//   __m128i v2 = _mm_loadu_si128(reinterpret_cast<__m128i *>(arr + 4));
// 
//   /* step 1 */
//   COEX(v1, v2);
//   v2 = _mm_shuffle_epi32(v2, _MM_SHUFFLE(2, 3, 0, 1));
// 
//   /* step 2 */
//   COEX(v1, v2);
//   auto tmp = v1;
//   v1 = SHUFFLE_TWO_VECS(v1, v2, 0b10001000);
//   v2 = SHUFFLE_TWO_VECS(tmp, v2, 0b11011101);
// 
//   /* step 3 */
//   COEX(v1, v2);
//   v2 = _mm_shuffle_epi32(v2, _MM_SHUFFLE(0, 1, 2, 3));
// 
//   /* step 4 */
//   COEX(v1, v2);
//   tmp = v1;
//   v1 = SHUFFLE_TWO_VECS(v1, v2, 0b01000100);
//   v2 = SHUFFLE_TWO_VECS(tmp, v2, 0b11101110);
// 
//   /* step 5 */
//   COEX(v1, v2);
//   tmp = v1;
//   v1 = SHUFFLE_TWO_VECS(v1, v2, 0b10001000);
//   v2 = SHUFFLE_TWO_VECS(tmp, v2, 0b11011101);
// 
//   /* step 6 */
//   COEX(v1, v2);
// 
//   /* restore order */
//   tmp = _mm_shuffle_epi32(v1, _MM_SHUFFLE(2, 3, 0, 1));
//   auto tmp2 = _mm_shuffle_epi32(v2, _MM_SHUFFLE(2, 3, 0, 1));
//   v2 = _mm_blend_epi32(tmp, v2, 0b00001010);
//   v1 = _mm_blend_epi32(v1, tmp2, 0b00001010);
// 
//   /* save vectors */
//   _mm_storeu_si128(reinterpret_cast<__m128i *>(arr), v1);
//   _mm_storeu_si128(reinterpret_cast<__m128i *>(arr + 4), v2);
// 
//   for (int i = 0; i < 8; ++i)
//     printf("%d ", arr[i]);
// }
/*
sort_16_int.cpp:
*/
// #include <cstdio>
// #include <immintrin.h>
// 
// /*
//  * Bitonic Sort of 16 elements with two vectors.
//  * Each vector has a capacity of 8 elements.
//  */
// 
// /* compute 8 COEX modules */
// inline void COEX(__m256i &a, __m256i &b) {
//   /* copy vector a to c */
//   __m256i c = a;
//   /* pairwise minimum */
//   a = _mm256_min_epi32(a, b);
//   /* pairwise maximum */
//   b = _mm256_max_epi32(c, b);
// }
// 
// /* shuffle 2 vectors, instruction for int is missing so use instruction for floats */
// #define SHUFFLE_2_VECS(a, b, mask)                                             \
//   reinterpret_cast<__m256i>(_mm256_shuffle_ps(                                 \
//       reinterpret_cast<__m256>(a), reinterpret_cast<__m256>(b), mask));
// 
// /* bitonic sort for 16 integer */
// inline void sort_16(__m256i &v1, __m256i &v2) {
//   /* step 1 */
//   COEX(v1, v2);
// 
//   /* step 2 */
//   v2 = _mm256_shuffle_epi32(v2, _MM_SHUFFLE(2, 3, 0, 1));
//   COEX(v1, v2);
// 
//   /* step 3 */
//   auto tmp = v1;
//   v1 = SHUFFLE_2_VECS(v1, v2, 0b10001000);
//   v2 = SHUFFLE_2_VECS(tmp, v2, 0b11011101);
//   COEX(v1, v2);
// 
//   /* step 4 */
//   v2 = _mm256_shuffle_epi32(v2, _MM_SHUFFLE(0, 1, 2, 3));
//   COEX(v1, v2);
// 
//   /* step 5 */
//   tmp = v1;
//   v1 = SHUFFLE_2_VECS(v1, v2, 0b01000100);
//   v2 = SHUFFLE_2_VECS(tmp, v2, 0b11101110);
//   COEX(v1, v2);
// 
//   /* step 6 */
//   tmp = v1;
//   v1 = SHUFFLE_2_VECS(v1, v2, 0b11011000);
//   v2 = SHUFFLE_2_VECS(tmp, v2, 0b10001101);
//   COEX(v1, v2);
// 
//   /* step 7 */
//   v2 = _mm256_permutevar8x32_epi32(v2, _mm256_setr_epi32(7, 6, 5, 4, 3, 2, 1, 0));
//   COEX(v1, v2);
// 
//   /* step 8 */
//   tmp = v1;
//   v1 = SHUFFLE_2_VECS(v1, v2, 0b11011000);
//   v2 = SHUFFLE_2_VECS(tmp, v2, 0b10001101);
//   COEX(v1, v2);
// 
//   /* step 9 */
//   tmp = v1;
//   v1 = SHUFFLE_2_VECS(v1, v2, 0b11011000);
//   v2 = SHUFFLE_2_VECS(tmp, v2, 0b10001101);
//   COEX(v1, v2);
// 
//   /* permute to restore order more easily */
//   v1 = _mm256_permutevar8x32_epi32(v1, _mm256_setr_epi32(0, 4, 1, 5, 6, 2, 7, 3));
//   v2 = _mm256_permutevar8x32_epi32(v2, _mm256_setr_epi32(0,4,1,5,6,2,7,3));
//   
//   /* step 10 */
//   tmp = v1;
//   v1 = SHUFFLE_2_VECS(v1, v2, 0b10001000);
//   v2 = SHUFFLE_2_VECS(tmp, v2, 0b11011101);
//   COEX(v1, v2);
// 
//   /* restore order */
//   auto b2 = _mm256_shuffle_epi32(v2,0b10110001);
//   auto b1 = _mm256_shuffle_epi32(v1,0b10110001);
//   v1 = _mm256_blend_epi32(v1, b2, 0b10101010);
//   v2 = _mm256_blend_epi32(b1, v2, 0b10101010);
// }
// 
// int main() {
//   int arr[16] = {11, 3, 29, 7, 13, 23, 37, 1, 17, 8, 19, 31, 2, 33, 5, 14};
// 
//   /* load vectors */
//   __m256i v1 = _mm256_loadu_si256(reinterpret_cast<__m256i *>(arr));
//   __m256i v2 = _mm256_loadu_si256(reinterpret_cast<__m256i *>(arr + 8));
// 
//   /* sort */
//   sort_16(v1, v2);
// 
//   /* save vectors */
//   _mm256_storeu_si256(reinterpret_cast<__m256i *>(arr), v1);
//   _mm256_storeu_si256(reinterpret_cast<__m256i *>(arr + 8), v2);
// 
//   for (int i = 0; i < 16; ++i)
//     printf("%d ", arr[i]);
// }

//#define Commence_AVX
// if above (only as an estimate, no shuffle in AVX across lanes) is commented, then AVX2 is commenced

//#include <immintrin.h>

size_t is_sorted_avx2_QWORD(uint64_t* a, size_t n) {

//      //const __m256i shuffle_pattern = _mm256_setr_epi32(1, 2, 3, 4, 5, 6, 7, 7);
//  __m256i shuffle_pattern = _mm256_setr_epi32(2, 3, 4, 5, 6, 7, 6, 7);
//  __m256i curr;
//  __m256i next;
//  __m256i mask;
uint64_t mm;
int PointerInBytes = 8; //sizeof(a); // 4 for int32_t
int VectorInBytes = 32; // 32B for AVX/AVX2
    size_t MinimumKeysUnsorted = 0;
    size_t MinimumKeysUnsortedSCALAR = 0;
    size_t i;
    for (i=0; i + 1 < n; i++) {
        if (a[i] > a[i + 1])
            //return false;
            MinimumKeysUnsortedSCALAR++; //return !(-1);
    }
//      i = 0;
//      while (i < n - VectorInBytes/PointerInBytes) {
//          // curr = [ a0 | a1 | a2 | a3 | a4 | a5 | a6 | a7 ]
//          //const __m256i curr = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(a + i));
//      curr = _mm256_loadu_si256((__m256i*)(a + i));
//      //__m128i _mm_cmpgt_epi64 (__m128i a, __m128i b)
//          // next = [ a1 | a2 | a3 | a4 | a5 | a6 | a7 | a7 ]
//          //const __m256i next = _mm256_permutevar8x32_epi32(curr, shuffle_pattern);
//  // I need to shift the loaded register left by 64 bits, but AVX permutation is not working across the lanes, grmbl.
//  /*
//  __m256d _mm256_permutevar_pd (__m256d a, __m256i b)
//  #include <immintrin.h>
//  Instruction: vpermilpd ymm, ymm, ymm
//  CPUID Flags: AVX
//  Description
//  Shuffle double-precision (64-bit) floating-point elements in a within 128-bit lanes using the control in b, and store the results in dst.
//  Operation
//  IF (b[1] == 0) dst[63:0] := a[63:0]; FI
//  IF (b[1] == 1) dst[63:0] := a[127:64]; FI
//  IF (b[65] == 0) dst[127:64] := a[63:0]; FI
//  IF (b[65] == 1) dst[127:64] := a[127:64]; FI
//  IF (b[129] == 0) dst[191:128] := a[191:128]; FI
//  IF (b[129] == 1) dst[191:128] := a[255:192]; FI
//  IF (b[193] == 0) dst[255:192] := a[191:128]; FI
//  IF (b[193] == 1) dst[255:192] := a[255:192]; FI
//  dst[MAX:256] := 0
//  Performance
//  Architecture    Latency Throughput (CPI)
//  Icelake     1   -
//  Skylake     1   1
//  Broadwell   1   1
//  Haswell     1   1
//  Ivy Bridge  1   1
//  */
//  #ifdef Commence_AVX
//      next = _mm256_loadu_si256((__m256i*)(a + i + 1)); // Only as an estimate
//  #else
//      //next = _mm256_castpd_si256( _mm256_permute4x64_pd(_mm256_castsi256_pd(curr), 0b11111001) ); //AVX2
//      next = _mm256_permutevar8x32_epi32(curr, shuffle_pattern); //AVX2
//  #endif
//          // Note: the last element of curr and next is a7, thus for this element 
//          //       the comparison result is always zero.
//          //
//          // In fact, the first 7 elements are being tested.
//          //const __m256i mask = _mm256_cmpgt_epi32(curr, next);
//          // In fact, the first 3 elements are being tested.
//          // curr = [ a0 | a1 | a2 | a3 ]
//          // next = [ a1 | a2 | a3 | a3 ]
//  #ifdef Commence_AVX
//      mask = _mm256_castpd_si256( _mm256_cmp_pd (_mm256_castsi256_pd(curr), _mm256_castsi256_pd(next), 14) ); // either 14 or 30 (on GCC)
//  #else
//      // What is this, this line works with ICL, but above line does not!? Above line works with GCC 11.3.0
//      mask = _mm256_cmpgt_epi64(curr, next);  // UGH! BUGGY WHEN SIGN BIT IS SET! FOR POINTERS and HAILSTONE numbers WORKS THOUGH! Only Signed64 for AVX2, Unsigned64 is for AVX512F
//                          // For example, with 'manyC' i.e. linux_testset after checking the sorted:
//                          // Checking whether sort went correct... OK. Unique keys = 77275994
//                          // MinimumKeysUnsortedSCALAR = 0
//                          // (AVX is not exact, AVX2 should be exact) MinimumKeysUnsorted = 1
//                          // AVX2 check... Number_of_Unsorted_Keys = 0
//                          // Also, for 'ALL', before sorting:
//                          // MinimumKeysUnsortedSCALAR = 1001101913
//                          // (AVX is not exact, AVX2 should be exact) MinimumKeysUnsorted = 1001101912
//                          // AVX2 check... UNSORTEDNESS (in permyriads) = 4982 O/ooo = (Number_Unsorted_Keys = 1001101913)*10000/(Number_of_All_Keys = 2009333753)
//      //mask = _mm256_castpd_si256( _mm256_cmp_pd (_mm256_castsi256_pd(curr), _mm256_castsi256_pd(next), 30) ); // either 14 or 30 (on GCC)
//  #endif
//          if (!_mm256_testz_si256(mask, mask)) {
//              //return false;
//              mm = _mm256_movemask_pd(_mm256_castsi256_pd(mask));
//              MinimumKeysUnsorted += _mm_popcnt_u64((mm)); //return !(-1);
//          }
//  //__m128d _mm_cmpgt_pd (__m128d a, __m128d b) //SSE2
//          //i += (8-1);
//          i += (VectorInBytes/PointerInBytes-1); //3chunks by 8B
//      }
//  
//      for (/**/; i + 1 < n; i++) {
//          if (a[i] > a[i + 1])
//              //return false;
//              MinimumKeysUnsorted++; //return !(-1);
//      }
//  
//      //return true;
//      //return !0;
//      //if (MinimumKeysUnsorted) return !(-1); else return !0;
//      if (MinimumKeysUnsortedSCALAR != MinimumKeysUnsorted) {
//      printf("MinimumKeysUnsortedSCALAR = %lld\n", MinimumKeysUnsortedSCALAR);    
//      printf("(AVX is not exact, AVX2 should be exact) MinimumKeysUnsorted = %lld\n", MinimumKeysUnsorted);   
//  //Sorting in multi-thread 1800000000 elements...
//  //MinimumKeysUnsortedSCALAR = 1,194,844,247
//  //MinimumKeysUnsorted =       1,593,145,417
//  //[kaze@w8 QS_Collatz]$ 
//      };
    return MinimumKeysUnsortedSCALAR;
}

/*
__m256d _mm256_castsi256_pd (__m256i a)
#include <immintrin.h>
CPUID Flags: AVX
Description
Cast vector of type __m256i to type __m256d. This intrinsic is only used for compilation and does not generate any instructions, thus it has zero latency.
*/

/*
int _mm256_movemask_pd (__m256d a)
#include <immintrin.h>
Instruction: vmovmskpd r32, ymm
CPUID Flags: AVX
Description
Set each bit of mask dst based on the most significant bit of the corresponding packed double-precision (64-bit) floating-point element in a.
Operation
FOR j := 0 to 3
    i := j*64
    IF a[i+63]
        dst[j] := 1
    ELSE
        dst[j] := 0
    FI
ENDFOR
dst[MAX:4] := 0

Performance
Architecture    Latency Throughput (CPI)
Skylake 2   1
Broadwell   2   1
Haswell 2   1
Ivy Bridge  1   1
*/
/*
__int64 _mm_popcnt_u64 (unsigned __int64 a)
#include <immintrin.h>
Instruction: popcnt r64, r64
CPUID Flags: POPCNT
Description
Count the number of bits set to 1 in unsigned 64-bit integer a, and return that count in dst.
Operation
dst := 0
FOR i := 0 to 63
    IF a[i]
        dst := dst + 1
    FI
ENDFOR

Performance
Architecture    Latency Throughput (CPI)
Icelake 3   1
Skylake 3   1
Broadwell   3   1
Haswell 3   1
Ivy Bridge  3   1
*/

//   /* which elements are larger than the pivot */
//   __m256i compared = _mm256_cmpgt_epi32(curr_vec, pivot_vec);
//   /* update the smallest and largest values of the array */
//   smallest_vec = _mm256_min_epi32(curr_vec, smallest_vec);
//   biggest_vec = _mm256_max_epi32(curr_vec, biggest_vec);
//   /* extract the most significant bit from each integer of the vector */
//   int mm = _mm256_movemask_ps(_mm256_castsi256_ps(compared));
//   /* how many ones, each 1 stands for an element greater than pivot */
//   int amount_gt_pivot = _mm_popcnt_u32((mm));
//   /* permute elements larger than pivot to the right, and,
//    * smaller than or equal to the pivot, to the left */
//   curr_vec = _mm256_permutevar8x32_epi32(curr_vec, permutation_masks[mm]);
//   /* return how many elements are greater than pivot */
//   return amount_gt_pivot; }

/*
__m256d _mm256_cmp_pd (__m256d a, __m256d b, const int imm8)
#include <immintrin.h>
Instruction: vcmppd ymm, ymm, ymm, imm8
CPUID Flags: AVX
Description
Compare packed double-precision (64-bit) floating-point elements in a and b based on the comparison operand specified by imm8, and store the results in dst.
Operation
CASE (imm8[4:0]) OF
0: OP := _CMP_EQ_OQ
1: OP := _CMP_LT_OS
2: OP := _CMP_LE_OS
3: OP := _CMP_UNORD_Q 
4: OP := _CMP_NEQ_UQ
5: OP := _CMP_NLT_US
6: OP := _CMP_NLE_US
7: OP := _CMP_ORD_Q
8: OP := _CMP_EQ_UQ
9: OP := _CMP_NGE_US
10: OP := _CMP_NGT_US
11: OP := _CMP_FALSE_OQ
12: OP := _CMP_NEQ_OQ
13: OP := _CMP_GE_OS
14: OP := _CMP_GT_OS
15: OP := _CMP_TRUE_UQ
16: OP := _CMP_EQ_OS
17: OP := _CMP_LT_OQ
18: OP := _CMP_LE_OQ
19: OP := _CMP_UNORD_S
20: OP := _CMP_NEQ_US
21: OP := _CMP_NLT_UQ
22: OP := _CMP_NLE_UQ
23: OP := _CMP_ORD_S
24: OP := _CMP_EQ_US
25: OP := _CMP_NGE_UQ 
26: OP := _CMP_NGT_UQ 
27: OP := _CMP_FALSE_OS 
28: OP := _CMP_NEQ_OS 
29: OP := _CMP_GE_OQ
30: OP := _CMP_GT_OQ
31: OP := _CMP_TRUE_US
ESAC
FOR j := 0 to 3
    i := j*64
    dst[i+63:i] := ( a[i+63:i] OP b[i+63:i] ) ? 0xFFFFFFFFFFFFFFFF : 0
ENDFOR
dst[MAX:256] := 0

Performance
Architecture    Latency Throughput (CPI)
Icelake 4   0.5
Skylake 4   0.5
Broadwell   3   1
Haswell 3   1
Ivy Bridge  3   1
*/

/*
__m128d _mm_cmpgt_sd (__m128d a, __m128d b)
#include <emmintrin.h>
Instruction: cmpsd xmm, xmm, imm8
CPUID Flags: SSE2
Description
Compare the lower double-precision (64-bit) floating-point elements in a and b for greater-than, store the result in the lower element of dst, and copy the upper element from a to the upper element of dst.
Operation
dst[63:0] := (a[63:0] > b[63:0]) ? 0xFFFFFFFFFFFFFFFF : 0
dst[127:64] := a[127:64]

Performance
Architecture    Latency Throughput (CPI)
Skylake 4   0.5
Broadwell   3   1
Haswell 3   1
Ivy Bridge  3   1
*/

/*
__m128i _mm_cmpgt_epi64 (__m128i a, __m128i b)
#include <nmmintrin.h>
Instruction: pcmpgtq xmm, xmm
CPUID Flags: SSE4.2
Description
Compare packed signed 64-bit integers in a and b for greater-than, and store the results in dst.
Operation
FOR j := 0 to 1
    i := j*64
    dst[i+63:i] := ( a[i+63:i] > b[i+63:i] ) ? 0xFFFFFFFFFFFFFFFF : 0
ENDFOR

Performance
Architecture    Latency Throughput (CPI)
Skylake 3   1
*/

void swap(uint64_t *a, uint64_t *b) {
  uint64_t t = *a;
  *a = *b;
  *b = t;
}

void QuickSortHoare(uint64_t array[], int64_t low, int64_t high) {
int64_t I,J;
uint64_t Pivot;

    if (low < high) {
    //swap(&array[(low + high)>>1], &array[high]);
    //Pivot=array[high];
    Pivot=array[(low + high)>>1];
    I = low; J = high;
    do {
                while (array[I] < Pivot) I = I + 1;
                while (array[J] > Pivot) J = J - 1;
            if (I <= J) {
            swap(&array[I], &array[J]);
            I += 1;
            J -= 1;
        }
    } while (I <= J);
    //swap(&array[I], &array[high]);
// Problems with GCC and ICL, with bigdata:
/*
        #ifdef Commence_OpenMP
        #pragma omp parallel sections
        #endif
        {
            #ifdef Commence_OpenMP
            #pragma omp section
            #endif
            {
            QuickSortHoare(array, low, J);
            }
            #ifdef Commence_OpenMP
            #pragma omp section
            #endif
            {
            QuickSortHoare(array, I, high);
            }
        }
*/
            QuickSortHoare(array, low, J);
            QuickSortHoare(array, I, high);
    }//if (low < high) {
}


void quicksort_Bentley_McIlroy_3way_partitioning(uint64_t a[], int64_t l, int64_t r)
{ 
    int64_t i = l-1, j = r, p = l-1, q = r; 
    int64_t k; 
    uint64_t v;
    if (r <= l) return;
    swap(&a[r], &a[(r+l)>>1]); // Modified by Kaze
    v = a[r];
    for (;;)
    {
        while (a[++i] < v) ;
        while (v < a[--j]) if (j == l) break;
        if (i >= j) break;
        swap(&a[i], &a[j]);
        if (a[i] == v) { p++; swap(&a[p], &a[i]); }
        if (v == a[j]) { q--; swap(&a[j], &a[q]); }
    }
    swap(&a[i], &a[r]); 
    j = i-1; i = i+1;
    for (k = l; k < p; k++, j--) swap(&a[k], &a[j]);
    for (k = r-1; k > q; k--, i++) swap(&a[i], &a[k]);
// Problems with GCC and ICL, with bigdata:
/*
        #ifdef Commence_OpenMP
        #pragma omp parallel sections
        #endif
        {
            #ifdef Commence_OpenMP
            #pragma omp section
            #endif
            {
    quicksort_Bentley_McIlroy_3way_partitioning(a, l, j);
            }
            #ifdef Commence_OpenMP
            #pragma omp section
            #endif
            {
    quicksort_Bentley_McIlroy_3way_partitioning(a, i, r);
            }
        }
*/
    quicksort_Bentley_McIlroy_3way_partitioning(a, l, j);
    quicksort_Bentley_McIlroy_3way_partitioning(a, i, r);
}

/*
; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
; mark_description "-S -O3 -D_N_HIGH_PRIORITY";

;418 void quicksort_Bentley_McIlroy_3way_partitioning(uint64_t a[], int64_t l, int64_t r)
;419 { 
;420    int64_t i = l-1, j = r, p = l-1, q = r; 
;421    int64_t k; 
;422    uint64_t v = a[r];
;423    if (r <= l) return;
;424    for (;;)
;425    {
;426        while (a[++i] < v) ;
;427        while (v < a[--j]) if (j == l) break;
;428        if (i >= j) break;
;429        swap(&a[i], &a[j]);
;430        if (a[i] == v) { p++; swap(&a[p], &a[i]); }
;431        if (v == a[j]) { q--; swap(&a[j], &a[q]); }
;432    }
;433    swap(&a[i], &a[r]); j = i-1; i = i+1;
;434    for (k = l; k < p; k++, j--) swap(&a[k], &a[j]);
;435    for (k = r-1; k > q; k--, i++) swap(&a[i], &a[k]);
;436    quicksort_Bentley_McIlroy_3way_partitioning(a, l, j);
;437    quicksort_Bentley_McIlroy_3way_partitioning(a, i, r);
;438 }

quicksort_Bentley_McIlroy_3way_partitioning PROC 
; parameter 1: rcx
; parameter 2: rdx
; parameter 3: r8
.B2.1::                         ; Preds .B2.0
        push      rbx                                           ;419.1
        push      rsi                                           ;419.1
        push      rdi                                           ;419.1
        push      r12                                           ;419.1
        push      r13                                           ;419.1
        push      r14                                           ;419.1
        push      r15                                           ;419.1
        push      rbp                                           ;419.1
        sub       rsp, 88                                       ;419.1
        lea       r10, QWORD PTR [rcx+r8*8]                     ;422.15
        mov       rax, r8                                       ;421.2
        lea       r9, QWORD PTR [-1+r8]                         ;421.2
        mov       QWORD PTR [64+rsp], r9                        ;421.2
        mov       rbx, rax                                      ;421.2
        mov       QWORD PTR [56+rsp], r10                       ;421.2
        mov       rsi, rcx                                      ;421.2
        mov       QWORD PTR [72+rsp], r8                        ;421.2
                                
.B2.2::                         ; Preds .B2.42 .B2.1
        mov       r10, QWORD PTR [72+rsp]                       ;420.39
        lea       r9, QWORD PTR [-1+rdx]                        ;420.16
        mov       rdi, rbx                                      ;420.23
        mov       rax, r9                                       ;420.32
        mov       rbx, r10                                      ;420.39
        cmp       r10, rdx                                      ;423.11
        mov       rbp, QWORD PTR [rsi+r10*8]                    ;422.15
        jg        .B2.5         ; Prob 72%                      ;423.11
                                
.B2.3::                         ; Preds .B2.2
        add       rsp, 88                                       ;423.14
        pop       rbp                                           ;423.14
        pop       r15                                           ;423.14
        pop       r14                                           ;423.14
        pop       r13                                           ;423.14
        pop       r12                                           ;423.14
        pop       rdi                                           ;423.14
        pop       rsi                                           ;423.14
        pop       rbx                                           ;423.14
        ret                                                     ;423.14
                                
.B2.5::                         ; Preds .B2.2 .B2.17 .B2.18
        inc       r9                                            ;426.14
        lea       r11, QWORD PTR [rsi+r9*8]                     ;426.10
        mov       r8, QWORD PTR [r11]                           ;426.10
        cmp       r8, rbp                                       ;426.19
        jae       .B2.9         ; Prob 10%                      ;426.19
                                
.B2.6::                         ; Preds .B2.5
        xor       r8d, r8d                                      ;426.3
                                
.B2.7::                         ; Preds .B2.7 .B2.6
        inc       r8                                            ;426.3
        cmp       rbp, QWORD PTR [r11+r8*8]                     ;426.19
        ja        .B2.7         ; Prob 82%                      ;426.19
                                
.B2.8::                         ; Preds .B2.7
        add       r9, r8                                        ;426.14
        mov       r8, QWORD PTR [rsi+r9*8]                      ;429.3
                                
.B2.9::                         ; Preds .B2.8 .B2.5
        dec       rdi                                           ;427.18
        mov       r14, rdi                                      ;427.18
        cmp       rbp, QWORD PTR [rsi+rdi*8]                    ;427.14
        jae       .B2.14        ; Prob 10%                      ;427.14
                                
.B2.10::                        ; Preds .B2.9
        xor       r12d, r12d                                    ;
        lea       r13, QWORD PTR [rsi+rdi*8]                    ;427.14
        xor       r11d, r11d                                    ;
                                
.B2.11::                        ; Preds .B2.12 .B2.10
        dec       r11                                           ;427.3
        add       r12, -8                                       ;427.3
        lea       r15, QWORD PTR [1+r14+r11]                    ;427.22
        cmp       rdx, r15                                      ;427.31
        lea       rcx, QWORD PTR [r14+r11]                      ;427.22
        je        .B2.14        ; Prob 20%                      ;427.31
                                
.B2.12::                        ; Preds .B2.11
        mov       rdi, rcx                                      ;427.18
        cmp       rbp, QWORD PTR [r12+r13]                      ;427.14
        jb        .B2.11        ; Prob 82%                      ;427.14
                                
.B2.14::                        ; Preds .B2.11 .B2.12 .B2.9
        cmp       r9, rdi                                       ;428.12
        jge       .B2.19        ; Prob 20%                      ;428.12
                                
.B2.15::                        ; Preds .B2.14
        mov       r11, QWORD PTR [rsi+rdi*8]                    ;429.3
        mov       QWORD PTR [rsi+r9*8], r11                     ;429.3
        mov       QWORD PTR [rsi+rdi*8], r8                     ;429.3
        mov       r11, QWORD PTR [rsi+r9*8]                     ;430.7
        cmp       r11, rbp                                      ;430.15
        jne       .B2.17        ; Prob 78%                      ;430.15
                                
.B2.16::                        ; Preds .B2.15
        inc       rax                                           ;430.20
        mov       r8, QWORD PTR [rsi+rax*8]                     ;430.25
        mov       QWORD PTR [rsi+rax*8], r11                    ;430.25
        mov       QWORD PTR [rsi+r9*8], r8                      ;430.25
        mov       r8, QWORD PTR [rsi+rdi*8]                     ;431.12
                                
.B2.17::                        ; Preds .B2.16 .B2.15
        cmp       rbp, r8                                       ;431.12
        jne       .B2.5         ; Prob 78%                      ;431.12
                                
.B2.18::                        ; Preds .B2.17
        dec       r10                                           ;431.20
        mov       r11, QWORD PTR [rsi+r10*8]                    ;431.25
        mov       QWORD PTR [rsi+rdi*8], r11                    ;431.25
        mov       QWORD PTR [rsi+r10*8], r8                     ;431.25
        jmp       .B2.5         ; Prob 100%                     ;431.25
                                
.B2.19::                        ; Preds .B2.14                  ; Infreq
        mov       rdi, QWORD PTR [72+rsp]                       ;433.2
        mov       r11, rdx                                      ;434.31
        mov       rbp, QWORD PTR [rsi+rdi*8]                    ;433.2
        mov       QWORD PTR [rsi+r9*8], rbp                     ;433.2
        lea       rbp, QWORD PTR [1+r9]                         ;433.37
        mov       QWORD PTR [rsi+rdi*8], r8                     ;433.2
        lea       r8, QWORD PTR [-1+r9]                         ;433.28
        sub       r11, r8                                       ;434.31
        mov       rdi, r8                                       ;433.22
        add       r11, -2                                       ;434.7
        mov       QWORD PTR [48+rsp], rbp                       ;433.31
        cmp       r11, 64                                       ;434.2
        jle       .B2.27        ; Prob 50%                      ;434.2
                                
.B2.20::                        ; Preds .B2.19                  ; Infreq
        cmp       rdx, rax                                      ;434.18
        jge       .B2.34        ; Prob 15%                      ;434.18
                                
.B2.21::                        ; Preds .B2.20                  ; Infreq
        sub       rax, rdx                                      ;434.2
        mov       r15d, 1                                       ;434.2
        mov       r12, rax                                      ;434.2
        shr       r12, 63                                       ;434.2
        add       r12, rax                                      ;434.2
        sar       r12, 1                                        ;434.2
        lea       r11, QWORD PTR [1+rax]                        ;434.2
        sub       r8, r11                                       ;434.31
        xor       r11d, r11d                                    ;434.2
        xor       r13d, r13d                                    ;
        inc       r8                                            ;434.31
        xor       r14d, r14d                                    ;
        test      r12, r12                                      ;434.2
        jbe       .B2.25        ; Prob 15%                      ;434.2
                                
.B2.22::                        ; Preds .B2.21                  ; Infreq
        mov       QWORD PTR [32+rsp], rsi                       ;434.31
        lea       r15, QWORD PTR [rsi+rdx*8]                    ;434.31
        mov       QWORD PTR [40+rsp], rdx                       ;434.31
        lea       rcx, QWORD PTR [rsi+rdi*8]                    ;434.31
                                
.B2.23::                        ; Preds .B2.23 .B2.22           ; Infreq
        mov       rdx, QWORD PTR [r14+rcx]                      ;434.31
        inc       r11                                           ;434.2
        mov       rsi, QWORD PTR [r13+r15]                      ;434.31
        mov       QWORD PTR [r13+r15], rdx                      ;434.31
        mov       QWORD PTR [r14+rcx], rsi                      ;434.31
        mov       rdx, QWORD PTR [-8+r14+rcx]                   ;434.31
        mov       rsi, QWORD PTR [8+r13+r15]                    ;434.31
        mov       QWORD PTR [8+r13+r15], rdx                    ;434.31
        add       r13, 16                                       ;434.2
        mov       QWORD PTR [-8+r14+rcx], rsi                   ;434.31
        add       r14, -16                                      ;434.2
        cmp       r11, r12                                      ;434.2
        jb        .B2.23        ; Prob 64%                      ;434.2
                                
.B2.24::                        ; Preds .B2.23                  ; Infreq
        mov       rsi, QWORD PTR [32+rsp]                       ;
        lea       r15, QWORD PTR [1+r11*2]                      ;434.2
        mov       rdx, QWORD PTR [40+rsp]                       ;
                                
.B2.25::                        ; Preds .B2.24 .B2.21           ; Infreq
        lea       r11, QWORD PTR [-1+r15]                       ;434.2
        cmp       rax, r11                                      ;434.2
        ja        .B2.33        ; Prob 84%                      ;434.2
        jmp       .B2.34        ; Prob 100%                     ;434.2
                                
.B2.27::                        ; Preds .B2.19                  ; Infreq
        cmp       rdx, rax                                      ;434.18
        jge       .B2.34        ; Prob 15%                      ;434.18
                                
.B2.28::                        ; Preds .B2.27                  ; Infreq
        sub       rax, rdx                                      ;434.2
        mov       r15d, 1                                       ;434.2
        mov       r12, rax                                      ;434.2
        shr       r12, 63                                       ;434.2
        add       r12, rax                                      ;434.2
        sar       r12, 1                                        ;434.2
        lea       r11, QWORD PTR [1+rax]                        ;434.2
        sub       r8, r11                                       ;434.31
        xor       r11d, r11d                                    ;434.2
        xor       r13d, r13d                                    ;
        inc       r8                                            ;434.31
        xor       r14d, r14d                                    ;
        test      r12, r12                                      ;434.2
        jbe       .B2.32        ; Prob 15%                      ;434.2
                                
.B2.29::                        ; Preds .B2.28                  ; Infreq
        mov       QWORD PTR [32+rsp], rsi                       ;434.31
        lea       r15, QWORD PTR [rsi+rdx*8]                    ;434.31
        mov       QWORD PTR [40+rsp], rdx                       ;434.31
        lea       rcx, QWORD PTR [rsi+rdi*8]                    ;434.31
                                
.B2.30::                        ; Preds .B2.30 .B2.29           ; Infreq
        mov       rdx, QWORD PTR [r14+rcx]                      ;434.31
        inc       r11                                           ;434.2
        mov       rsi, QWORD PTR [r13+r15]                      ;434.31
        mov       QWORD PTR [r13+r15], rdx                      ;434.31
        mov       QWORD PTR [r14+rcx], rsi                      ;434.31
        mov       rdx, QWORD PTR [-8+r14+rcx]                   ;434.31
        mov       rsi, QWORD PTR [8+r13+r15]                    ;434.31
        mov       QWORD PTR [8+r13+r15], rdx                    ;434.31
        add       r13, 16                                       ;434.2
        mov       QWORD PTR [-8+r14+rcx], rsi                   ;434.31
        add       r14, -16                                      ;434.2
        cmp       r11, r12                                      ;434.2
        jb        .B2.30        ; Prob 64%                      ;434.2
                                
.B2.31::                        ; Preds .B2.30                  ; Infreq
        mov       rsi, QWORD PTR [32+rsp]                       ;
        lea       r15, QWORD PTR [1+r11*2]                      ;434.2
        mov       rdx, QWORD PTR [40+rsp]                       ;
                                
.B2.32::                        ; Preds .B2.31 .B2.28           ; Infreq
        lea       r11, QWORD PTR [-1+r15]                       ;434.2
        cmp       rax, r11                                      ;434.2
        jbe       .B2.34        ; Prob 15%                      ;434.2
                                
.B2.33::                        ; Preds .B2.25 .B2.32           ; Infreq
        sub       rdi, r15                                      ;434.31
        lea       r11, QWORD PTR [rdx+r15]                      ;434.2
        mov       r12, QWORD PTR [-8+rsi+r11*8]                 ;434.31
        mov       r15, QWORD PTR [8+rsi+rdi*8]                  ;434.31
        mov       QWORD PTR [-8+rsi+r11*8], r15                 ;434.31
        mov       QWORD PTR [8+rsi+rdi*8], r12                  ;434.31
                                
.B2.34::                        ; Preds .B2.20 .B2.27 .B2.33 .B2.32 .B2.25
                                ;                               ; Infreq
        cmp       r10, QWORD PTR [64+rsp]                       ;435.20
        jge       .B2.41        ; Prob 0%                       ;435.20
                                
.B2.35::                        ; Preds .B2.34                  ; Infreq
        mov       rdi, QWORD PTR [72+rsp]                       ;435.28
        neg       r10                                           ;435.28
        xor       r13d, r13d                                    ;435.2
        mov       eax, 1                                        ;435.2
        lea       rbp, QWORD PTR [rdi+r9]                       ;435.28
        add       rbp, r10                                      ;435.28
        lea       r9, QWORD PTR [rdi+r10]                       ;435.2
        lea       r10, QWORD PTR [-1+rdi+r10]                   ;435.2
        mov       r11, r10                                      ;435.2
        shr       r11, 63                                       ;435.2
        lea       r9, QWORD PTR [-1+r9+r11]                     ;435.2
        xor       r11d, r11d                                    ;
        sar       r9, 1                                         ;435.2
        xor       r12d, r12d                                    ;
        test      r9, r9                                        ;435.2
        jbe       .B2.39        ; Prob 10%                      ;435.2
                                
.B2.36::                        ; Preds .B2.35                  ; Infreq
        mov       rdi, QWORD PTR [48+rsp]                       ;435.33
        lea       rax, QWORD PTR [rsi+rdi*8]                    ;435.33
        mov       rdi, QWORD PTR [56+rsp]                       ;435.33
                                
.B2.37::                        ; Preds .B2.37 .B2.36           ; Infreq
        mov       r14, QWORD PTR [-8+r12+rdi]                   ;435.33
        inc       r13                                           ;435.2
        mov       r15, QWORD PTR [r11+rax]                      ;435.33
        mov       QWORD PTR [r11+rax], r14                      ;435.33
        mov       QWORD PTR [-8+r12+rdi], r15                   ;435.33
        mov       r14, QWORD PTR [-16+r12+rdi]                  ;435.33
        mov       r15, QWORD PTR [8+r11+rax]                    ;435.33
        mov       QWORD PTR [8+r11+rax], r14                    ;435.33
        add       r11, 16                                       ;435.2
        mov       QWORD PTR [-16+r12+rdi], r15                  ;435.33
        add       r12, -16                                      ;435.2
        cmp       r13, r9                                       ;435.2
        jb        .B2.37        ; Prob 64%                      ;435.2
                                
.B2.38::                        ; Preds .B2.37                  ; Infreq
        lea       rax, QWORD PTR [1+r13*2]                      ;435.2
                                
.B2.39::                        ; Preds .B2.38 .B2.35           ; Infreq
        lea       rdi, QWORD PTR [-1+rax]                       ;435.2
        cmp       r10, rdi                                      ;435.2
        jbe       .B2.41        ; Prob 10%                      ;435.2
                                
.B2.40::                        ; Preds .B2.39                  ; Infreq
        mov       r9, QWORD PTR [48+rsp]                        ;435.2
        add       r9, rax                                       ;435.2
        shl       rax, 3                                        ;435.33
        neg       rax                                           ;435.33
        add       rax, QWORD PTR [56+rsp]                       ;435.33
        mov       r10, QWORD PTR [-8+rsi+r9*8]                  ;435.33
        mov       rdi, QWORD PTR [rax]                          ;435.33
        mov       QWORD PTR [-8+rsi+r9*8], rdi                  ;435.33
        mov       QWORD PTR [rax], r10                          ;435.33
                                
.B2.41::                        ; Preds .B2.34 .B2.39 .B2.40    ; Infreq
        mov       rcx, rsi                                      ;436.2
        call      quicksort_Bentley_McIlroy_3way_partitioning   ;436.2
                                
.B2.42::                        ; Preds .B2.41                  ; Infreq
        mov       rdx, rbp                                      ;437.2
        jmp       .B2.2         ; Prob 100%                     ;437.2
        ALIGN     16
                                
.B2.44::
; mark_end;
quicksort_Bentley_McIlroy_3way_partitioning ENDP
*/

// Magnetica r.5BB:
/*
; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
; mark_description "-S -O3 -D_N_HIGH_PRIORITY";

Quicksort_QB64_v9   PROC 
; parameter 1: rcx
; parameter 2: rdx
; parameter 3: r8
.B12.1::                        ; Preds .B12.0
        push      r13                                           ;1172.72
        push      r14                                           ;1172.72
        push      r15                                           ;1172.72
        push      rbp                                           ;1172.72
        mov       eax, 800024                                   ;1172.72
        call      __chkstk                                      ;1172.72
        sub       rsp, 800024                                   ;1172.72
        mov       eax, 2                                        ;1191.5
        mov       QWORD PTR [40+rsp], rdx                       ;1190.17
        mov       QWORD PTR [48+rsp], r8                        ;1191.17
                                
.B12.2::                        ; Preds .B12.20 .B12.1
        mov       rdx, QWORD PTR [32+rsp+rax*8]                 ;1193.17
        mov       r13, QWORD PTR [24+rsp+rax*8]                 ;1194.16
        add       rax, -2                                       ;1195.31
        cmp       r13, rdx                                      ;1197.47
        jge       .B12.20       ; Prob 10%                      ;1197.47
                                
.B12.3::                        ; Preds .B12.2
        mov       r9, r13                                       ;1199.13
                                
.B12.4::                        ; Preds .B12.18 .B12.3
        mov       r10, QWORD PTR [rcx+r13*8]                    ;1229.13
        lea       r15, QWORD PTR [r13+rdx]                      ;1229.48
        sar       r15, 1                                        ;1229.56
        mov       r14, r13                                      ;1200.13
        mov       r11, rdx                                      ;1198.13
        mov       rbp, r9                                       ;1199.13
        mov       r9, r14                                       ;1200.13
        mov       r8, QWORD PTR [rcx+r15*8]                     ;1229.13
        mov       QWORD PTR [rcx+r15*8], r10                    ;1229.13
        mov       QWORD PTR [rcx+r13*8], r8                     ;1229.13
                                
.B12.5::                        ; Preds .B12.4 .B12.13
        inc       r14                                           ;1282.27
        mov       r10, QWORD PTR [rcx+r14*8]                    ;1283.29
        cmp       r8, r10                                       ;1283.29
        ja        .B12.12       ; Prob 22%                      ;1283.29
                                
.B12.6::                        ; Preds .B12.5
        jae       .B12.13       ; Prob 50%                      ;1287.36
                                
.B12.7::                        ; Preds .B12.6
        mov       r15, QWORD PTR [rcx+r11*8]                    ;1288.35
        cmp       r8, r15                                       ;1288.35
        jae       .B12.11       ; Prob 10%                      ;1288.35
                                
.B12.9::                        ; Preds .B12.7 .B12.9
        dec       r11                                           ;1289.39
        mov       r15, QWORD PTR [rcx+r11*8]                    ;1288.35
        cmp       r8, r15                                       ;1288.35
        jb        .B12.9        ; Prob 82%                      ;1288.35
                                
.B12.11::                       ; Preds .B12.9 .B12.7
        mov       QWORD PTR [rcx+r14*8], r15                    ;1291.21
        dec       r14                                           ;1296.31
        mov       QWORD PTR [rcx+r11*8], r10                    ;1291.21
        dec       r11                                           ;1295.35
        jmp       .B12.13       ; Prob 100%                     ;1295.35
                                
.B12.12::                       ; Preds .B12.5
        mov       r15, QWORD PTR [rcx+rbp*8]                    ;1284.21
        mov       QWORD PTR [rcx+rbp*8], r10                    ;1284.21
        inc       rbp                                           ;1285.31
        mov       QWORD PTR [rcx+r14*8], r15                    ;1284.21
                                
.B12.13::                       ; Preds .B12.12 .B12.11 .B12.6
        cmp       r14, r11                                      ;1281.24
        jl        .B12.5        ; Prob 82%                      ;1281.24
                                
.B12.14::                       ; Preds .B12.13
        jle       .B12.16       ; Prob 78%                      ;1299.22
                                
.B12.15::                       ; Preds .B12.14
        mov       r8, QWORD PTR [8+rcx+r11*8]                   ;1300.21
        mov       r10, QWORD PTR [8+rcx+r14*8]                  ;1300.21
        mov       QWORD PTR [8+rcx+r14*8], r8                   ;1300.21
        mov       QWORD PTR [8+rcx+r11*8], r10                  ;1300.21
                                
.B12.16::                       ; Preds .B12.14 .B12.15
        inc       r14                                           ;1655.25
        cmp       rdx, r14                                      ;1730.49
        jle       .B12.18       ; Prob 62%                      ;1730.49
                                
.B12.17::                       ; Preds .B12.16
        add       rax, 2                                        ;1731.39
        mov       QWORD PTR [24+rsp+rax*8], r14                 ;1732.17
        mov       QWORD PTR [32+rsp+rax*8], rdx                 ;1733.17
                                
.B12.18::                       ; Preds .B12.17 .B12.16
        lea       rdx, QWORD PTR [-1+rbp]                       ;1654.25
        cmp       r13, rdx                                      ;1197.47
        jl        .B12.4        ; Prob 82%                      ;1197.47
                                
.B12.20::                       ; Preds .B12.18 .B12.2
        DB        15                                            ;1743.28
        DB        31                                            ;1743.28
        DB        64                                            ;1743.28
        DB        0                                             ;1743.28
        DB        15                                            ;1743.28
        DB        31                                            ;1743.28
        DB        128                                           ;1743.28
        DB        0                                             ;1743.28
        DB        0                                             ;1743.28
        DB        0                                             ;1743.28
        DB        0                                             ;1743.28
        test      rax, rax                                      ;1743.28
        jne       .B12.2        ; Prob 99%                      ;1743.28
                                
.B12.21::                       ; Preds .B12.20
        add       rsp, 800024                                   ;1753.1
        pop       rbp                                           ;1753.1
        pop       r15                                           ;1753.1
        pop       r14                                           ;1753.1
        pop       r13                                           ;1753.1
        ret                                                     ;1753.1
        ALIGN     16
                                
.B12.22::
; mark_end;
Quicksort_QB64_v9 ENDP
*/


//    _____                                __  .__               
//   /     \ _____     ____   ____   _____/  |_|__| ____ _____   
//  /  \ /  \\__  \   / ___\ /    \_/ __ \   __\  |/ ___\\__  \
// /    Y    \/ __ \_/ /_/  >   |  \  ___/|  | |  \  \___ / __ \_
// \____|__  (____  /\___  /|___|  /\___  >__| |__|\___  >____  /
//         \/     \//_____/      \/     \/             \/     \/ 
void Quicksort_QB64_v4(uint64_t QWORDS[], int64_t Left, int64_t Right) {
    int InsertionsortTHRESHOLD = 0;
    int64_t Indx, Jndx, PL, PR;
    int64_t Stack[99999];
    int64_t StackPtr = 0;
    uint64_t Pivot;
    StackPtr++; Stack[StackPtr] = Left;
    StackPtr++; Stack[StackPtr] = Right;

    do {
        Right = Stack[StackPtr];
        Left = Stack[StackPtr - 1];
        StackPtr = StackPtr - 2;
        do {
            // 'Magnetica' partitioning rev.2[
            Jndx = Right;
            PL = Left;
            PR = Left;
            swap (&QWORDS[(Left + Right)>>1], &QWORDS[PR]);
            Pivot = QWORDS[PR];
            for (;PR < Jndx;) {
                PR = PR + 1;
                if (Pivot > QWORDS[PR]) {
                    swap (&QWORDS[PL], &QWORDS[PR]);
                    PL = PL + 1;
                //} else if (Pivot == QWORDS[PR]) {
                } else if (Pivot < QWORDS[PR]) {
                    for (;Pivot < QWORDS[Jndx];) {
                        Jndx = Jndx - 1;
                    }
                    if (PR < Jndx) swap (&QWORDS[PR], &QWORDS[Jndx]);
                    Jndx = Jndx - 1;
                    PR = PR - 1;
                }
            }
            Jndx = PL - 1;
            Indx = PR + 1;
            // 'Magnetica' partitioning rev.2]
/*
; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
; ae-64+2=76 bytes i.e. (94-76=18 less), 5/1 conditional/unconditional jumps i.e. 2-1=1 less unconditional jump
; 'Magnetica' partitioning, mainloop rev.2[
.B4.5::                         
  00064 48 ff c5         inc rbp                                
  00067 48 8b 14 e9      mov rdx, QWORD PTR [rcx+rbp*8]         
  0006b 4c 3b ea         cmp r13, rdx                           
  0006e 77 2c            ja .B4.14 
.B4.6::                         
  00070 73 39            jae .B4.15 
.B4.7::                         
  00072 4e 8b 3c d9      mov r15, QWORD PTR [rcx+r11*8]         
  00076 4d 3b ef         cmp r13, r15                           
  00079 73 0c            jae .B4.11 
.B4.9::                         
  0007b 49 ff cb         dec r11                                
  0007e 4e 8b 3c d9      mov r15, QWORD PTR [rcx+r11*8]         
  00082 4d 3b ef         cmp r13, r15                           
  00085 72 f4            jb .B4.9 
.B4.11::                        
  00087 49 3b eb         cmp rbp, r11                           
  0008a 7d 08            jge .B4.13 
.B4.12::                        
  0008c 4c 89 3c e9      mov QWORD PTR [rcx+rbp*8], r15         
  00090 4a 89 14 d9      mov QWORD PTR [rcx+r11*8], rdx         
.B4.13::                        
  00094 49 ff cb         dec r11                                
  00097 48 ff cd         dec rbp                                
  0009a eb 0f            jmp .B4.15 
.B4.14::                        
  0009c 4e 8b 3c f1      mov r15, QWORD PTR [rcx+r14*8]         
  000a0 4a 89 14 f1      mov QWORD PTR [rcx+r14*8], rdx         
  000a4 49 ff c6         inc r14                                
  000a7 4c 89 3c e9      mov QWORD PTR [rcx+rbp*8], r15         
.B4.15::                        
  000ab 49 3b eb         cmp rbp, r11                           
  000ae 7c b4            jl .B4.5 
; 'Magnetica' partitioning, mainloop rev.2]
*/

/*
            // 'Magnetica' partitioning [
            Jndx = Right;
            PL = Left;
            PR = Left;
            swap (&QWORDS[(Left + Right)>>1], &QWORDS[PR]);
            Pivot = QWORDS[PR];
            for (;PR < Jndx;) {
                if (Pivot > QWORDS[PR + 1]) {
                    swap (&QWORDS[PL], &QWORDS[PR + 1]);
                    PL = PL + 1;
                    PR = PR + 1;
                } else if (Pivot == QWORDS[PR + 1]) {
                    PR = PR + 1;
                } else {
                    for (;Pivot < QWORDS[Jndx];) {
                        Jndx = Jndx - 1;
                    }
                    if (PR + 1 < Jndx) swap (&QWORDS[PR + 1], &QWORDS[Jndx]);
                    Jndx = Jndx - 1;
                }
            }
            Jndx = PL - 1;
            Indx = PR + 1;
            // 'Magnetica' partitioning ]
*/
/*
; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
; c6-6a+2=94 bytes, 5/2 conditional/unconditional jumps
; 'Magnetica' partitioning, mainloop [
.B4.5::                         
  0006a 4e 3b 5c e9 08   cmp r11, QWORD PTR [8+rcx+r13*8]       
  0006f 77 37            ja .B4.15 
.B4.6::                         
  00071 75 08            jne .B4.8 
.B4.7::                         
  00073 49 89 d5         mov r13, rdx                           
  00076 48 ff c2         inc rdx                                
  00079 eb 48            jmp .B4.16 
.B4.8::                         
  0007b 4e 8b 34 c1      mov r14, QWORD PTR [rcx+r8*8]          
  0007f 4d 3b de         cmp r11, r14                           
  00082 73 0c            jae .B4.12 
.B4.10::                        
  00084 49 ff c8         dec r8                                 
  00087 4e 8b 34 c1      mov r14, QWORD PTR [rcx+r8*8]          
  0008b 4d 3b de         cmp r11, r14                           
  0008e 72 f4            jb .B4.10 
.B4.12::                        
  00090 4c 3b c2         cmp r8, rdx                            
  00093 7e 0e            jle .B4.14 
.B4.13::                        
  00095 4e 8b 7c e9 08   mov r15, QWORD PTR [8+rcx+r13*8]       
  0009a 4e 89 74 e9 08   mov QWORD PTR [8+rcx+r13*8], r14       
  0009f 4e 89 3c c1      mov QWORD PTR [rcx+r8*8], r15          
.B4.14::                        
  000a3 49 ff c8         dec r8                                 
  000a6 eb 1b            jmp .B4.16 
.B4.15::                        
  000a8 4e 8b 74 e9 08   mov r14, QWORD PTR [8+rcx+r13*8]       
  000ad 4e 8b 3c e1      mov r15, QWORD PTR [rcx+r12*8]         
  000b1 4e 89 34 e1      mov QWORD PTR [rcx+r12*8], r14         
  000b5 49 ff c4         inc r12                                
  000b8 4e 89 7c e9 08   mov QWORD PTR [8+rcx+r13*8], r15       
  000bd 49 89 d5         mov r13, rdx                           
  000c0 48 ff c2         inc rdx                                
.B4.16::                        
  000c3 4d 3b e8         cmp r13, r8                            
  000c6 7c a2            jl .B4.5 
; 'Magnetica' partitioning, mainloop ]
*/

            if (Indx + InsertionsortTHRESHOLD < Right) {
                StackPtr = StackPtr + 2;
                Stack[StackPtr - 1] = Indx;
                Stack[StackPtr] = Right;
            }
            Right = Jndx;
        } while (Left < Right);
    } while (StackPtr != 0);
}


// 113 lines of scalar C:
/*
00,001 #define StackEntries 99999
00,002 #define FinishWithInsertionSort
00,003 #define revision4
00,004 void swapUnconditional(uint64_t *a, uint64_t *b) { uint64_t t = *a; *a = *b; *b = t; }
00,005 #define minSO(x, y) (y ^ ((x ^ y) & -(x < y)))
00,006 #define maxSO(x, y) (x ^ ((x ^ y) & -(x < y)))
00,007 //    _____                                __  .__               
00,008 //   /     \ _____     ____   ____   _____/  |_|__| ____ _____   
00,009 //  /  \ /  \\__  \   / ___\ /    \_/ __ \   __\  |/ ___\\__  \
00,010 // /    Y    \/ __ \_/ /_/  >   |  \  ___/|  | |  \  \___ / __ \_
00,011 // \____|__  (____  /\___  /|___|  /\___  >__| |__|\___  >____  /
00,012 //         \/     \//_____/      \/     \/             \/     \/ 
00,013 // Written by Sanmayce, 2021-Dec-02
00,014 void Quicksort_QB64_v7(uint64_t QWORDS[], int64_t Left, int64_t Right) {
00,015     #ifdef FinishWithInsertionSort
00,016     int InsertionsortTHRESHOLD = 17;
00,017     #else
00,018     int InsertionsortTHRESHOLD = 0;
00,019     #endif
00,020     int64_t Indx, Jndx, PL, PR;
00,021     int64_t Stack[StackEntries];
00,022     int64_t StackPtr = 0;
00,023     uint64_t Pivot;
00,024     int64_t LeftBackup = Left;
00,025     int64_t RightBackup = Right;
00,026     register uint64_t x0,x1,x2,x3,x4,x5,x6;
00,027     int o0,o1,o2,o3,o4,o5,o6;
00,028     int64_t TheMiddleOfMiddle;
00,029     int GearBox = 0; // 0 is Median of 3; 1 is Median of 7; Shifting to higher gear if BiggerPartition:SmallerPartition ratio is > 64:1
00,030     StackPtr++; Stack[StackPtr] = Left;
00,031     StackPtr++; Stack[StackPtr] = Right;
00,032     do {
00,033         Right = Stack[StackPtr];
00,034         Left = Stack[StackPtr - 1];
00,035         StackPtr = StackPtr - 2;
00,036         for(;(Left + InsertionsortTHRESHOLD < Right);) { // For instance, 1 + 17 < 19 i.e. (19-1)/4+6 < 19
00,037             Jndx = Right;
00,038             PL = Left;
00,039             PR = Left;
00,040     #ifdef FinishWithInsertionSort
00,041             TheMiddleOfMiddle = Left + ((Right-Left)>>2); // (4Left + Right - Left)/4; Caution: [TheMiddleOfMiddle+6] should be <= [Right] i.e. 6+(4Left + Right - Left)/4 <= Right or 4*6+(4Left + Right - Left) <= 4Right or 4*6 <= 3Right-3Left or (4*6)/3 <= Right-Left i.e. 8 <= Right-Left as a minimum condition to enter the 'for'.
00,042             x0 = QWORDS[TheMiddleOfMiddle+0];
00,043             x1 = QWORDS[TheMiddleOfMiddle+1];
00,044             x2 = QWORDS[TheMiddleOfMiddle+2];
00,045 if (GearBox == 0) { // Median of 5 proves more effective than 7, however 7 betters better the nastiest N^2
00,046             o0 = (x0>x1)+(x0>x2);
00,047             o1 = (x1>=x0)+(x1>x2);
00,048             o2 = (0+1+2)-(o0+o1);
00,049             QWORDS[TheMiddleOfMiddle+o0]=x0; QWORDS[TheMiddleOfMiddle+o1]=x1; QWORDS[TheMiddleOfMiddle+o2]=x2;
00,050             swapUnconditional (&QWORDS[TheMiddleOfMiddle+1], &QWORDS[PR]); //2nd
00,051 } else {
00,052             x3 = QWORDS[TheMiddleOfMiddle+3];
00,053             x4 = QWORDS[TheMiddleOfMiddle+4];
00,054             x5 = QWORDS[TheMiddleOfMiddle+5];
00,055             x6 = QWORDS[TheMiddleOfMiddle+6];
00,056             o0 = (x0>x1)+(x0>x2)+(x0>x3)+(x0>x4)+(x0>x5)+(x0>x6);
00,057             o1 = (x1>=x0)+(x1>x2)+(x1>x3)+(x1>x4)+(x1>x5)+(x1>x6);
00,058             o2 = (x2>=x0)+(x2>=x1)+(x2>x3)+(x2>x4)+(x2>x5)+(x2>x6);
00,059             o3 = (x3>=x0)+(x3>=x1)+(x3>=x2)+(x3>x4)+(x3>x5)+(x3>x6);
00,060             o4 = (x4>=x0)+(x4>=x1)+(x4>=x2)+(x4>=x3)+(x4>x5)+(x4>x6);
00,061             o5 = (x5>=x0)+(x5>=x1)+(x5>=x2)+(x5>=x3)+(x5>=x4)+(x5>x6);
00,062             o6 = (0+1+2+3+4+5+6)-(o0+o1+o2+o3+o4+o5);
00,063             QWORDS[TheMiddleOfMiddle+o0]=x0; QWORDS[TheMiddleOfMiddle+o1]=x1; QWORDS[TheMiddleOfMiddle+o2]=x2; QWORDS[TheMiddleOfMiddle+o3]=x3; QWORDS[TheMiddleOfMiddle+o4]=x4; QWORDS[TheMiddleOfMiddle+o5]=x5; QWORDS[TheMiddleOfMiddle+o6]=x6;
00,064             swapUnconditional (&QWORDS[TheMiddleOfMiddle+3], &QWORDS[PR]); //4th
00,065 }
00,066             Pivot = QWORDS[PR];
00,067     #else
00,068             swapUnconditional (&QWORDS[(Left + Right)>>1], &QWORDS[PR]);
00,069             Pivot = QWORDS[PR];
00,070     #endif
00,071     #ifdef revision4
00,072             for (;PR < Jndx;) {
00,073                 PR = PR + 1;
00,074                 if (Pivot > QWORDS[PR]) {
00,075                     swapUnconditional (&QWORDS[PL], &QWORDS[PR]);
00,076                     PL = PL + 1;
00,077                 } else if (Pivot < QWORDS[PR]) {
00,078                     for (;Pivot < QWORDS[Jndx];) {
00,079                         Jndx = Jndx - 1;
00,080                     }
00,081                     if (PR < Jndx) swapUnconditional (&QWORDS[PR], &QWORDS[Jndx]);
00,082                     Jndx = Jndx - 1;
00,083                     PR = PR - 1;
00,084                 }
00,085             }
00,086     #endif
00,087             Jndx = PL - 1;
00,088             Indx = PR + 1;
00,089     #ifdef FinishWithInsertionSort
00,090             GearBox = ( maxSO((Right-Indx), (Jndx-Left)) > minSO((Right-Indx), (Jndx-Left))<<6 ); // same as MAX/MIN > 64, i.e. Gear=1 if we need Median of 7
00,091     #endif
00,092             if (Indx + InsertionsortTHRESHOLD < Right) { // still refusing to go (always) with the smaller partition first...
00,093                 StackPtr = StackPtr + 2;
00,094                 Stack[StackPtr - 1] = Indx;
00,095                 Stack[StackPtr] = Right;
00,096     #ifdef FinishWithInsertionSort
00,097                 StackPtr = StackPtr*(StackPtr + 2 <= StackEntries-1);  // StackPtr should be enforced FALSE; also, ensure the next 'push' above is sanctioned - the max index of Stack[] being 'StackEntries-1'
00,098                 Right = Right*(StackPtr + 2 <= StackEntries-1); // Left + InsertionsortTHRESHOLD < Right should be enforced FALSE:
00,099     #endif
00,100             }
00,101             Right = Jndx;
00,102         } //while (Left + InsertionsortTHRESHOLD < Right);
00,103     } while ( (StackPtr != 0) );
00,104     #ifdef FinishWithInsertionSort
00,105     for (Indx=LeftBackup+1; Indx <= RightBackup; Indx++) {
00,106         Jndx = Indx;
00,107         for (;Jndx >= 1;) {
00,108             if (QWORDS[Jndx-1] > QWORDS[Jndx]) swapUnconditional (&QWORDS[Jndx-1], &QWORDS[Jndx]); else break;
00,109             Jndx = Jndx - 1;
00,110         }
00,111     }
00,112     #endif
00,113 }
*/

// 380 lines scalar Assembly:
/*
00,001 ; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
00,002 ; mark_description "-S -Os";
00,003 
00,004 Quicksort_QB64_v7    PROC 
00,005 .B4.1::                         
00,006         push      rbx                                           
00,007         push      rsi                                           
00,008         push      rdi                                           
00,009         push      r12                                           
00,010         push      r13                                           
00,011         push      r14                                           
00,012         push      r15                                           
00,013         push      rbp                                           
00,014         mov       eax, 800152                                   
00,015         call      __chkstk                                      
00,016         sub       rsp, 800152                                   
00,017         mov       r13, rcx                                      
00,018         mov       QWORD PTR [800064+rsp], r8                    
00,019         xor       r14d, r14d                                    
00,020         mov       QWORD PTR [40+rsp], rdx                       
00,021         mov       QWORD PTR [56+rsp], rdx                       
00,022         mov       QWORD PTR [32+rsp], 2                         
00,023         mov       QWORD PTR [64+rsp], r8                        
00,024 .B4.2::                         
00,025         mov       rax, QWORD PTR [32+rsp]                       
00,026         mov       rdx, QWORD PTR [40+rsp+rax*8]                 
00,027         mov       r12, QWORD PTR [48+rsp+rax*8]                 
00,028         add       rax, -2                                       
00,029         mov       QWORD PTR [800040+rsp], rdx                   
00,030         mov       QWORD PTR [32+rsp], rax                       
00,031         lea       rcx, QWORD PTR [17+rdx]                       
00,032         mov       QWORD PTR [800072+rsp], rcx                   
00,033         cmp       r12, rcx                                      
00,034         jle       .B4.27        
00,035 .B4.3::                         
00,036         mov       QWORD PTR [800056+rsp], rdx                   
00,037         lea       rax, QWORD PTR [r13+rdx*8]                    
00,038         mov       QWORD PTR [800048+rsp], rax                   
00,039 .B4.4::                         
00,040         mov       r8, r12                                       
00,041         xor       eax, eax                                      
00,042         mov       rbp, QWORD PTR [800040+rsp]                   
00,043         sub       r8, rbp                                       
00,044         sar       r8, 2                                         
00,045         xor       edx, edx                                      
00,046         add       r8, rbp                                       
00,047         xor       r15d, r15d                                    
00,048         mov       rbx, QWORD PTR [800056+rsp]                   
00,049         mov       rdi, r12                                      
00,050         mov       QWORD PTR [800056+rsp], rbp                   
00,051         lea       rsi, QWORD PTR [rbp*8]                        
00,052         lea       rcx, QWORD PTR [r13+r8*8]                     
00,053         mov       r10, QWORD PTR [rcx]                          
00,054         mov       r11, QWORD PTR [8+rcx]                        
00,055         cmp       r10, r11                                      
00,056         mov       r9, QWORD PTR [16+rcx]                        
00,057         seta      al                                            
00,058         cmp       r10, r9                                       
00,059         seta      dl                                            
00,060         add       eax, edx                                      
00,061         xor       edx, edx                                      
00,062         cmp       r11, r10                                      
00,063         setae     dl                                            
00,064         cmp       r11, r9                                       
00,065         seta      r15b                                          
00,066         add       edx, r15d                                     
00,067         test      r14d, r14d                                    
00,068         jne       .B4.6         
00,069 .B4.5::                         
00,070         add       rcx, 8                                        
00,071         lea       r14, QWORD PTR [r8+rax]                       
00,072         mov       QWORD PTR [r13+r14*8], r10                    
00,073         lea       r10, QWORD PTR [r8+rdx]                       
00,074         sub       r8, rax                                       
00,075         sub       r8, rdx                                       
00,076         mov       QWORD PTR [r13+r10*8], r11                    
00,077         mov       QWORD PTR [24+r13+r8*8], r9                   
00,078         jmp       .B4.7         
00,079 .B4.6::                         
00,080         mov       QWORD PTR [800104+rsp], rsi                   
00,081         xor       r14d, r14d                                    
00,082         mov       rsi, QWORD PTR [24+rcx]                       
00,083         cmp       r10, rsi                                      
00,084         mov       QWORD PTR [800096+rsp], rdi                   
00,085         mov       rdi, QWORD PTR [32+rcx]                       
00,086         seta      r14b                                          
00,087         xor       r15d, r15d                                    
00,088         cmp       r10, rdi                                      
00,089         mov       QWORD PTR [800088+rsp], r12                   
00,090         push      0                                             
00,091         pop       r12                                           
00,092         seta      r12b                                          
00,093         mov       QWORD PTR [800112+rsp], rbp                   
00,094         add       r14d, r12d                                    
00,095         mov       rbp, QWORD PTR [40+rcx]                       
00,096         xor       r12d, r12d                                    
00,097         cmp       r10, rbp                                      
00,098         mov       QWORD PTR [800120+rsp], rbx                   
00,099         seta      r12b                                          
00,100         mov       rbx, QWORD PTR [48+rcx]                       
00,101         cmp       r10, rbx                                      
00,102         mov       QWORD PTR [800080+rsp], rcx                   
00,103         push      0                                             
00,104         pop       rcx                                           
00,105         seta      cl                                            
00,106         add       eax, r14d                                     
00,107         add       r12d, ecx                                     
00,108         xor       ecx, ecx                                      
00,109         cmp       r11, rsi                                      
00,110         seta      cl                                            
00,111         xor       r14d, r14d                                    
00,112         cmp       r11, rdi                                      
00,113         seta      r15b                                          
00,114         cmp       r11, rbp                                      
00,115         seta      r14b                                          
00,116         add       eax, r12d                                     
00,117         xor       r12d, r12d                                    
00,118         cmp       r11, rbx                                      
00,119         seta      r12b                                          
00,120         add       ecx, r15d                                     
00,121         add       edx, ecx                                      
00,122         xor       ecx, ecx                                      
00,123         cmp       r9, r10                                       
00,124         setae     cl                                            
00,125         xor       r15d, r15d                                    
00,126         add       r14d, r12d                                    
00,127         xor       r12d, r12d                                    
00,128         cmp       r9, r11                                       
00,129         setae     r12b                                          
00,130         add       edx, r14d                                     
00,131         add       ecx, r12d                                     
00,132         xor       r12d, r12d                                    
00,133         cmp       r9, rsi                                       
00,134         seta      r12b                                          
00,135         xor       r14d, r14d                                    
00,136         cmp       r9, rdi                                       
00,137         seta      r15b                                          
00,138         add       r12d, r15d                                    
00,139         xor       r15d, r15d                                    
00,140         add       ecx, r12d                                     
00,141         xor       r12d, r12d                                    
00,142         cmp       r9, rbp                                       
00,143         seta      r12b                                          
00,144         cmp       r9, rbx                                       
00,145         seta      r14b                                          
00,146         cmp       rsi, r10                                      
00,147         setae     r15b                                          
00,148         add       r12d, r14d                                    
00,149         xor       r14d, r14d                                    
00,150         cmp       rsi, r11                                      
00,151         setae     r14b                                          
00,152         add       ecx, r12d                                     
00,153         add       r15d, r14d                                    
00,154         xor       r14d, r14d                                    
00,155         cmp       rsi, r9                                       
00,156         setae     r14b                                          
00,157         xor       r12d, r12d                                    
00,158         cmp       rsi, rdi                                      
00,159         seta      r12b                                          
00,160         add       r14d, r12d                                    
00,161         xor       r12d, r12d                                    
00,162         add       r15d, r14d                                    
00,163         xor       r14d, r14d                                    
00,164         cmp       rsi, rbp                                      
00,165         seta      r14b                                          
00,166         cmp       rsi, rbx                                      
00,167         seta      r12b                                          
00,168         add       r14d, r12d                                    
00,169         xor       r12d, r12d                                    
00,170         add       r15d, r14d                                    
00,171         xor       r14d, r14d                                    
00,172         cmp       rdi, r10                                      
00,173         setae     r14b                                          
00,174         cmp       rdi, r11                                      
00,175         setae     r12b                                          
00,176         add       r14d, r12d                                    
00,177         xor       r12d, r12d                                    
00,178         cmp       rdi, r9                                       
00,179         setae     r12b                                          
00,180         cmp       rdi, rsi                                      
00,181         mov       QWORD PTR [800128+rsp], r15                   
00,182         push      0                                             
00,183         pop       r15                                           
00,184         setae     r15b                                          
00,185         add       r12d, r15d                                    
00,186         xor       r15d, r15d                                    
00,187         add       r14d, r12d                                    
00,188         xor       r12d, r12d                                    
00,189         cmp       rdi, rbp                                      
00,190         seta      r12b                                          
00,191         cmp       rdi, rbx                                      
00,192         seta      r15b                                          
00,193         add       r12d, r15d                                    
00,194         xor       r15d, r15d                                    
00,195         add       r14d, r12d                                    
00,196         xor       r12d, r12d                                    
00,197         cmp       rbp, r10                                      
00,198         setae     r12b                                          
00,199         cmp       rbp, r11                                      
00,200         setae     r15b                                          
00,201         add       r12d, r15d                                    
00,202         xor       r15d, r15d                                    
00,203         cmp       rbp, r9                                       
00,204         setae     r15b                                          
00,205         cmp       rbp, rsi                                      
00,206         mov       QWORD PTR [800136+rsp], r14                   
00,207         push      0                                             
00,208         pop       r14                                           
00,209         setae     r14b                                          
00,210         add       r15d, r14d                                    
00,211         xor       r14d, r14d                                    
00,212         add       r12d, r15d                                    
00,213         xor       r15d, r15d                                    
00,214         cmp       rbp, rdi                                      
00,215         setae     r15b                                          
00,216         cmp       rbp, rbx                                      
00,217         seta      r14b                                          
00,218         add       r15d, r14d                                    
00,219         lea       r14, QWORD PTR [r8+rax]                       
00,220         mov       QWORD PTR [r13+r14*8], r10                    
00,221         lea       r10, QWORD PTR [r8+rdx]                       
00,222         mov       QWORD PTR [r13+r10*8], r11                    
00,223         lea       r11, QWORD PTR [r8+rcx]                       
00,224         mov       r10, QWORD PTR [800128+rsp]                   
00,225         add       r12d, r15d                                    
00,226         mov       QWORD PTR [r13+r11*8], r9                     
00,227         add       rcx, r10                                      
00,228         mov       r11, QWORD PTR [800136+rsp]                   
00,229         lea       r9, QWORD PTR [r8+r10]                        
00,230         mov       QWORD PTR [r13+r9*8], rsi                     
00,231         lea       rsi, QWORD PTR [r8+r11]                       
00,232         add       r11, r12                                      
00,233         mov       QWORD PTR [r13+rsi*8], rdi                    
00,234         add       rcx, r11                                      
00,235         mov       rsi, QWORD PTR [800104+rsp]                   
00,236         lea       rdi, QWORD PTR [r8+r12]                       
00,237         sub       r8, rax                                       
00,238         sub       r8, rdx                                       
00,239         sub       r8, rcx                                       
00,240         mov       QWORD PTR [r13+rdi*8], rbp                    
00,241         mov       rcx, QWORD PTR [800080+rsp]                   
00,242         mov       rbp, QWORD PTR [800112+rsp]                   
00,243         add       rcx, 24                                       
00,244         mov       QWORD PTR [168+r13+r8*8], rbx                 
00,245         mov       rbx, QWORD PTR [800120+rsp]                   
00,246         mov       rdi, QWORD PTR [800096+rsp]                   
00,247         mov       r12, QWORD PTR [800088+rsp]                   
00,248 .B4.7::                         
00,249         mov       rdx, QWORD PTR [800048+rsp]                   
00,250         call      swapUnconditional                             
00,251 .B4.8::                         
00,252         mov       rax, QWORD PTR [800048+rsp]                   
00,253         cmp       r12, QWORD PTR [800040+rsp]                   
00,254         mov       r14, QWORD PTR [rax]                          
00,255         jle       .B4.23        
00,256 .B4.10::                        
00,257         inc       rbp                                           
00,258         lea       rdx, QWORD PTR [r13+rbp*8]                    
00,259         cmp       r14, QWORD PTR [rdx]                          
00,260         jbe       .B4.13        
00,261 .B4.11::                        
00,262         lea       rcx, QWORD PTR [r13+rsi]                      
00,263         call      swapUnconditional                             
00,264 .B4.12::                        
00,265         add       rsi, 8                                        
00,266         inc       rbx                                           
00,267         jmp       .B4.21        
00,268 .B4.13::                        
00,269         jae       .B4.21        
00,270 .B4.14::                        
00,271         lea       rax, QWORD PTR [r13+rdi*8]                    
00,272         cmp       r14, QWORD PTR [rax]                          
00,273         jae       .B4.18        
00,274 .B4.16::                        
00,275         dec       rdi                                           
00,276         lea       rax, QWORD PTR [r13+rdi*8]                    
00,277         cmp       r14, QWORD PTR [rax]                          
00,278         jb        .B4.16        
00,279 .B4.18::                        
00,280         cmp       rbp, rdi                                      
00,281         jge       .B4.20        
00,282 .B4.19::                        
00,283         mov       rcx, rdx                                      
00,284         mov       rdx, rax                                      
00,285         call      swapUnconditional                             
00,286 .B4.20::                        
00,287         dec       rdi                                           
00,288         dec       rbp                                           
00,289 .B4.21::                        
00,290         cmp       rbp, rdi                                      
00,291         jl        .B4.10        
00,292 .B4.23::                        
00,293         dec       rbx                                           
00,294         lea       r9, QWORD PTR [1+rbp]                         
00,295         mov       rdi, r12                                      
00,296         mov       r8, rbx                                       
00,297         sub       r8, QWORD PTR [800040+rsp]                    
00,298         sub       rdi, r9                                       
00,299         xor       edx, edx                                      
00,300         cmp       rdi, r8                                       
00,301         mov       rcx, rdi                                      
00,302         setl      dl                                            
00,303         xor       r14d, r14d                                    
00,304         xor       rcx, r8                                       
00,305         neg       edx                                           
00,306         add       rbp, 18                                       
00,307         movsxd    rdx, edx                                      
00,308         and       rcx, rdx                                      
00,309         xor       r8, rcx                                       
00,310         xor       rdi, rcx                                      
00,311         shl       r8, 6                                         
00,312         cmp       rdi, r8                                       
00,313         setg      r14b                                          
00,314         cmp       r12, rbp                                      
00,315         jle       .B4.25        
00,316 .B4.24::                        
00,317         mov       rax, QWORD PTR [32+rsp]                       
00,318         cmp       rax, 99994                                    
00,319         mov       QWORD PTR [64+rsp+rax*8], r12                 
00,320         push      0                                             
00,321         pop       r12                                           
00,322         setle     r12b                                          
00,323         mov       QWORD PTR [56+rsp+rax*8], r9                  
00,324         add       rax, 2                                        
00,325         imul      rax, r12                                      
00,326         mov       QWORD PTR [32+rsp], rax                       
00,327 .B4.25::                        
00,328         mov       r12, rbx                                      
00,329         cmp       rbx, QWORD PTR [800072+rsp]                   
00,330         jg        .B4.4         
00,331 .B4.27::                        
00,332         cmp       QWORD PTR [32+rsp], 0                         
00,333         jne       .B4.2         
00,334 .B4.28::                        
00,335         mov       rax, QWORD PTR [40+rsp]                       
00,336         inc       rax                                           
00,337         mov       QWORD PTR [40+rsp], rax                       
00,338         cmp       rax, QWORD PTR [800064+rsp]                   
00,339         jg        .B4.39        
00,340 .B4.30::                        
00,341         mov       rbx, QWORD PTR [40+rsp]                       
00,342         test      rbx, rbx                                      
00,343         jle       .B4.28        
00,344 .B4.32::                        
00,345         mov       rax, QWORD PTR [-8+r13+rbx*8]                 
00,346         cmp       rax, QWORD PTR [r13+rbx*8]                    
00,347         jbe       .B4.28        
00,348 .B4.33::                        
00,349         lea       rdx, QWORD PTR [r13+rbx*8]                    
00,350         lea       rcx, QWORD PTR [-8+rdx]                       
00,351         call      swapUnconditional                             
00,352 .B4.34::                        
00,353         dec       rbx                                           
00,354         test      rbx, rbx                                      
00,355         jg        .B4.32        
00,356         jmp       .B4.28        
00,357 .B4.39::                        
00,358         add       rsp, 800152                                   
00,359         pop       rbp                                           
00,360         pop       r15                                           
00,361         pop       r14                                           
00,362         pop       r13                                           
00,363         pop       r12                                           
00,364         pop       rdi                                           
00,365         pop       rsi                                           
00,366         pop       rbx                                           
00,367         ret                                                     
00,368 .B4.40::
00,369 Quicksort_QB64_v7 ENDP
00,370 
00,371 swapUnconditional    PROC 
00,372 .B5.1::                         
00,373         mov       rax, QWORD PTR [rdx]                          
00,374         mov       r8, QWORD PTR [rcx]                           
00,375         mov       QWORD PTR [rcx], rax                          
00,376         mov       QWORD PTR [rdx], r8                           
00,377 .B5.4::                         
00,378         ret                                                     
00,379 .B5.2::
00,380 swapUnconditional ENDP
*/


// Quicksort 'Magnetica' r.6, unbreakable (never overflowing the stack) when '#define FinishWithInsertionSort' is uncommented [
// We have two revisions - r.5BB and r.5FF, standing respectively for Bare-Bone (Pure Quicksort) and Full-Fledged (Fallbacks to Insertionsort).
// If below define is commented then we have "middle Pivot standalone Magnetica", otherwise "median of 3/7 Pivot InsertionSort Magnetica".
// Provide below flag via command line: -DFinishWithInsertionSort
//#define FinishWithInsertionSort
// Roughly speaking:
// - with (median of 1) nastiest quadratic O((N/1)^2) we have 2(N/1) (due to Left+Right=2, a pair) stack usage;
// - with (median of 3) less nastier quadratic O((N/2)^2) we have 2(N/2) (due to Left+Right=2, a pair) stack usage;
// - with (median of 5) even less nastier quadratic O((N/3)^2) we have 2(N/3) (due to Left+Right=2, a pair) stack usage;
// - with (median of 7) even more less nastier quadratic O((N/4)^2) we have 2(N/4) (due to Left+Right=2, a pair) stack usage;
// Value below allows 2(N/4)= 2((Right-Left+1)/4) = (99999-1) i.e. N=2(99999-1) or ~200,000 elements
#define StackEntries 99999
// Uncomment either 4 (fastest so far) or 3 (for reference only):
//#define revision6
#define revision5
//#define revision4
//#define revision3
// Thus we have 4 variants:
// Variant #1: "middle Pivot standalone Magnetica r.4"
// Variant #2: "middle Pivot standalone Magnetica r.3"
// Variant #3: "median of 3/7 Pivot InsertionSort Magnetica r.4"
// Variant #4: "median of 3/7 Pivot InsertionSort Magnetica r.3"
void swapUnconditional(uint64_t *a, uint64_t *b) { uint64_t t = *a; *a = *b; *b = t; }
uint64_t sex(int64_t x) { return x >> (8*sizeof(uint64_t)-1); }
uint64_t minKaze(uint64_t a, uint64_t b) { return b + ((a-b) & sex(a-b)); }
uint64_t maxKaze(uint64_t a, uint64_t b) { return a + ((b-a) & ~sex(b-a)); }
// Many thanks go to all the coders at: https://stackoverflow.com/questions/2786899/fastest-sort-of-fixed-length-6-int-array
#define minSO(x, y) (y ^ ((x ^ y) & -(x < y)))
#define maxSO(x, y) (x ^ ((x ^ y) & -(x < y)))
//    _____                                __  .__               
//   /     \ _____     ____   ____   _____/  |_|__| ____ _____   
//  /  \ /  \\__  \   / ___\ /    \_/ __ \   __\  |/ ___\\__  \
// /    Y    \/ __ \_/ /_/  >   |  \  ___/|  | |  \  \___ / __ \_
// \____|__  (____  /\___  /|___|  /\___  >__| |__|\___  >____  /
//         \/     \//_____/      \/     \/             \/     \/ 
// Written by Sanmayce, 2022-Feb-26
// The indexes are signed, but the elements are unsigned, targeting 64bit pointers mostly.
void swapConditionalXY_Akkodah(uint64_t X, uint64_t Y, uint64_t *a, uint64_t *b) { int64_t XYsgnd = -(X<Y); int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&XYsgnd; *a = *a-ABsgnd; *b = *b+ABsgnd; } // if X<Y then swap
void swapConditionalXY_BUGGY(uint64_t X, uint64_t Y, uint64_t *a, uint64_t *b) { int64_t XYsgnd = X-Y; int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&(XYsgnd >> 63); *a = *a-ABsgnd; *b = *b+ABsgnd; } // if X<Y then swap
/*
swapConditionalXY_BUGGY PROC 
; parameter 1: rcx
; parameter 2: rdx
; parameter 3: r8
; parameter 4: r9

;;; void swapConditionalXY_BUGGY(uint64_t X, uint64_t Y, uint64_t *a, uint64_t *b) { int64_t XYsgnd = X-Y; int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&(XYsgnd >> 63); *a = *a-ABsgnd; *b = *b+ABsgnd; } // if X<Y then swap

  00000 48 2b ca         sub rcx, rdx                           
  00003 4d 8b 11         mov r10, QWORD PTR [r9]                
  00006 49 f7 da         neg r10                                
  00009 49 8b 00         mov rax, QWORD PTR [r8]                
  0000c 4c 03 d0         add r10, rax                           
  0000f 48 c1 f9 3f      sar rcx, 63                            
  00013 4c 23 d1         and r10, rcx                           
  00016 49 2b c2         sub rax, r10                           
  00019 49 89 00         mov QWORD PTR [r8], rax                
  0001c 4d 01 11         add QWORD PTR [r9], r10                
*/
//void swapConditionalXYinc(uint64_t X, uint64_t Y, uint64_t *a, uint64_t *b, uint64_t *PL) { int64_t XYsgnd = -(X<Y); int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&XYsgnd; *a = *a-ABsgnd; *b = *b+ABsgnd; *PL = *PL-XYsgnd; } // if X<Y then swap
void Quicksort_QB64_v10(uint64_t QWORDS[], int64_t Left, int64_t Right) {
    #ifdef FinishWithInsertionSort
    int InsertionsortTHRESHOLD = 13;
    #else
    int InsertionsortTHRESHOLD = 0;
    #endif
    int64_t Indx, Jndx, PL, PR;
    int64_t Stack[StackEntries];
    int64_t StackPtr = 0;
    uint64_t Pivot;
    int64_t LeftBackup = Left;
    int64_t RightBackup = Right;
    register uint64_t x0,x1,x2,x3,x4,x5,x6;
    int o0,o1,o2,o3,o4,o5,o6;
    int64_t TheMiddleOfMiddle;
    int Stefan_Edelkamp_Armin_Weiss1, Stefan_Edelkamp_Armin_Weiss2, Stefan_Edelkamp_Armin_Weiss3;
    uint64_t tmp;
    int GearBox = 0; // 0 is Median of 3; 1 is Median of 7; Shifting to higher gear if BiggerPartition:SmallerPartition ratio is > 64:1
    StackPtr++; Stack[StackPtr] = Left;
    StackPtr++; Stack[StackPtr] = Right;
    do {
        Right = Stack[StackPtr];
        Left = Stack[StackPtr - 1];
        StackPtr = StackPtr - 2;
        //do {
        for(;(Left + InsertionsortTHRESHOLD < Right);) { // For instance, 1 + 17 < 19 i.e. (19-1)/4+6 < 19
            Jndx = Right;
            PL = Left;
            PR = Left;
    #ifdef FinishWithInsertionSort
            TheMiddleOfMiddle = Left + ((Right-Left)>>2); // (4Left + Right - Left)/4; Caution: [TheMiddleOfMiddle+6] should be <= [Right] i.e. 6+(4Left + Right - Left)/4 <= Right or 4*6+(4Left + Right - Left) <= 4Right or 4*6 <= 3Right-3Left or (4*6)/3 <= Right-Left i.e. 8 <= Right-Left as a minimum condition to enter the 'for'.
            x0 = QWORDS[TheMiddleOfMiddle+0];
            x1 = QWORDS[TheMiddleOfMiddle+1];
            x2 = QWORDS[TheMiddleOfMiddle+2];
if (GearBox == 0) { // Median of 5 proves more effective than 7, however 7 betters better the nastiest N^2
            o0 = (x0>x1)+(x0>x2);
            o1 = (x1>=x0)+(x1>x2);
            o2 = (0+1+2)-(o0+o1);
            QWORDS[TheMiddleOfMiddle+o0]=x0; QWORDS[TheMiddleOfMiddle+o1]=x1; QWORDS[TheMiddleOfMiddle+o2]=x2;
            swapUnconditional (&QWORDS[TheMiddleOfMiddle+1], &QWORDS[PR]); //2nd
} else {
            x3 = QWORDS[TheMiddleOfMiddle+3];
            x4 = QWORDS[TheMiddleOfMiddle+4];
            x5 = QWORDS[TheMiddleOfMiddle+5];
            x6 = QWORDS[TheMiddleOfMiddle+6];
            o0 = (x0>x1)+(x0>x2)+(x0>x3)+(x0>x4)+(x0>x5)+(x0>x6);
            o1 = (x1>=x0)+(x1>x2)+(x1>x3)+(x1>x4)+(x1>x5)+(x1>x6);
            o2 = (x2>=x0)+(x2>=x1)+(x2>x3)+(x2>x4)+(x2>x5)+(x2>x6);
            o3 = (x3>=x0)+(x3>=x1)+(x3>=x2)+(x3>x4)+(x3>x5)+(x3>x6);
            o4 = (x4>=x0)+(x4>=x1)+(x4>=x2)+(x4>=x3)+(x4>x5)+(x4>x6);
            o5 = (x5>=x0)+(x5>=x1)+(x5>=x2)+(x5>=x3)+(x5>=x4)+(x5>x6);
            o6 = (0+1+2+3+4+5+6)-(o0+o1+o2+o3+o4+o5);
            QWORDS[TheMiddleOfMiddle+o0]=x0; QWORDS[TheMiddleOfMiddle+o1]=x1; QWORDS[TheMiddleOfMiddle+o2]=x2; QWORDS[TheMiddleOfMiddle+o3]=x3; QWORDS[TheMiddleOfMiddle+o4]=x4; QWORDS[TheMiddleOfMiddle+o5]=x5; QWORDS[TheMiddleOfMiddle+o6]=x6;
            swapUnconditional (&QWORDS[TheMiddleOfMiddle+3], &QWORDS[PR]); //4th
}
            Pivot = QWORDS[PR];
    #else
            swapUnconditional (&QWORDS[(Left + Right)>>1], &QWORDS[PR]);
            Pivot = QWORDS[PR];
    #endif

/*
; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
; mark_description "-FAcs -O3 -FeQS_bench_r9+_ICL15.0_64bit.exe -D_N_HIGH_PRIORITY";
; b3-66+2=79 bytes, 3/1 conditional/unconditional jumps; 24 instructions
; 'Magnetica' partitioning, mainloop rev.6[
.B66.5::                        
  00066 49 ff c5         inc r13                                
  00069 4e 8b 14 e9      mov r10, QWORD PTR [rcx+r13*8]         
  0006d 4d 3b c2         cmp r8, r10                            
  00070 77 2f            ja .B66.10 
.B66.6::                        
  00072 73 3c            jae .B66.11 
.B66.7::                        
  00074 41 be 01 00 00 
        00               mov r14d, 1                            
.B66.8::                        
  0007a 45 33 ff         xor r15d, r15d                         
  0007d 4e 3b 04 d9      cmp r8, QWORD PTR [rcx+r11*8]          
  00081 4d 0f 42 fe      cmovb r15, r14                         
  00085 4d 2b df         sub r11, r15                           
  00088 4d 85 ff         test r15, r15                          
  0008b 75 ed            jne .B66.8 
.B66.9::                        
  0008d 4e 8b 34 d9      mov r14, QWORD PTR [rcx+r11*8]         
  00091 4e 89 34 e9      mov QWORD PTR [rcx+r13*8], r14         
  00095 49 ff cd         dec r13                                
  00098 4e 89 14 d9      mov QWORD PTR [rcx+r11*8], r10         
  0009c 49 ff cb         dec r11                                
  0009f eb 0f            jmp .B66.11 
.B66.10::                       
  000a1 4c 8b 34 e9      mov r14, QWORD PTR [rcx+rbp*8]         
  000a5 4c 89 14 e9      mov QWORD PTR [rcx+rbp*8], r10         
  000a9 48 ff c5         inc rbp                                
  000ac 4e 89 34 e9      mov QWORD PTR [rcx+r13*8], r14         
.B66.11::                       
  000b0 4d 3b eb         cmp r13, r11                           
  000b3 7c b1            jl .B66.5 
; 'Magnetica' partitioning, mainloop rev.6]
*/

    #ifdef revision6
            for (;PR < Jndx;) {
                PR = PR + 1;
                if (Pivot > QWORDS[PR]) {
                    swapUnconditional (&QWORDS[PL], &QWORDS[PR]);
                    PL = PL + 1;
                //} else if (Pivot == QWORDS[PR]) {
                } else if (Pivot < QWORDS[PR]) {
Nasty:
                    Stefan_Edelkamp_Armin_Weiss1 = (Pivot < QWORDS[Jndx]);
                    Jndx = Jndx - Stefan_Edelkamp_Armin_Weiss1;
if (Stefan_Edelkamp_Armin_Weiss1) goto Nasty;
                    //for (;Pivot < QWORDS[Jndx];) {
                    //    Jndx = Jndx - 1;
                    //}
                    swapUnconditional (&QWORDS[PR], &QWORDS[Jndx]); // Magnetica r.5
                    //if (PR < Jndx) swapUnconditional (&QWORDS[PR], &QWORDS[Jndx]);
                    //swapConditionalXY_BUGGY(PR, Jndx, &QWORDS[PR], &QWORDS[Jndx]); // Should be faster than "Akkodah" but buggy when wraparounding, inhere 'PR' and 'Jndx' are far below the dangerous values - no pitfall.
                    //swapConditionalXY_Akkodah(PR, Jndx, &QWORDS[PR], &QWORDS[Jndx]); // The safe one, but slower, isn't it?!
                    Jndx = Jndx - 1;
                    PR = PR - 1;
                }
            }
            if (PR > Jndx) { //redeem i.e. undo
                    swapUnconditional (&QWORDS[PR+1], &QWORDS[Jndx+1]);
            }
    #endif


/*
; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
; mark_description "-FAcs -O3 -FeQS_bench_r9+_ICL15.0_64bit.exe -D_N_HIGH_PRIORITY";
; aa-65+2=71 bytes, 4/1 conditional/unconditional jumps; 23 instructions
; 'Magnetica' partitioning, mainloop rev.5[
.B66.5::                        
  00065 49 ff c6         inc r14                                
  00068 4e 8b 14 f1      mov r10, QWORD PTR [rcx+r14*8]         
  0006c 4d 3b c2         cmp r8, r10                            
  0006f 77 27            ja .B66.12 
.B66.6::                        
  00071 73 34            jae .B66.13 
.B66.7::                        
  00073 4e 8b 3c d9      mov r15, QWORD PTR [rcx+r11*8]         
  00077 4d 3b c7         cmp r8, r15                            
  0007a 73 0c            jae .B66.11 
.B66.9::                        
  0007c 49 ff cb         dec r11                                
  0007f 4e 8b 3c d9      mov r15, QWORD PTR [rcx+r11*8]         
  00083 4d 3b c7         cmp r8, r15                            
  00086 72 f4            jb .B66.9 
.B66.11::                       
  00088 4e 89 3c f1      mov QWORD PTR [rcx+r14*8], r15         
  0008c 49 ff ce         dec r14                                
  0008f 4e 89 14 d9      mov QWORD PTR [rcx+r11*8], r10         
  00093 49 ff cb         dec r11                                
  00096 eb 0f            jmp .B66.13 
.B66.12::                       
  00098 4c 8b 3c e9      mov r15, QWORD PTR [rcx+rbp*8]         
  0009c 4c 89 14 e9      mov QWORD PTR [rcx+rbp*8], r10         
  000a0 48 ff c5         inc rbp                                
  000a3 4e 89 3c f1      mov QWORD PTR [rcx+r14*8], r15         
.B66.13::                       
  000a7 4d 3b f3         cmp r14, r11                           
  000aa 7c b9            jl .B66.5 
; 'Magnetica' partitioning, mainloop rev.5]
*/

    #ifdef revision5
            for (;PR < Jndx;) {
                PR = PR + 1;
                if (Pivot > QWORDS[PR]) {
                    swapUnconditional (&QWORDS[PL], &QWORDS[PR]);
                    PL = PL + 1;
                //} else if (Pivot == QWORDS[PR]) {
                } else if (Pivot < QWORDS[PR]) {
                    for (;Pivot < QWORDS[Jndx];) {
                        Jndx = Jndx - 1;
                    }
                    swapUnconditional (&QWORDS[PR], &QWORDS[Jndx]); // Magnetica r.5
                    //if (PR < Jndx) swapUnconditional (&QWORDS[PR], &QWORDS[Jndx]);
                    //swapConditionalXY_BUGGY(PR, Jndx, &QWORDS[PR], &QWORDS[Jndx]); // Should be faster than "Akkodah" but buggy when wraparounding, inhere 'PR' and 'Jndx' are far below the dangerous values - no pitfall.
                    //swapConditionalXY_Akkodah(PR, Jndx, &QWORDS[PR], &QWORDS[Jndx]); // The safe one, but slower, isn't it?!
                    Jndx = Jndx - 1;
                    PR = PR - 1;
                }
            }
            if (PR > Jndx) { //redeem i.e. undo
                    swapUnconditional (&QWORDS[PR+1], &QWORDS[Jndx+1]);
            }
    #endif

// Test run: 2022-Feb-27:
// Laptop "Compressionette", Intel 'Kaby Lake' i5-7200U 3.1GHz max turbo, 36GB DDR4 2133MHz:
// +--------------------+---------------------------+---------------------------+---------------------------+----------------------------+-----------------------------+
// | Performer/Keys     | FEW distinct              | MANY distinct             | ALL distinct              | ALLmore distinct           | ALLmax distinct             |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+--------------+--------------+--------------+
// |  Operating System, | Windows 10, | Fedora 35,  | Windows 10, | Fedora 35,  | Windows 10, | Fedora 35,  | Windows 10, | Fedora 35,   | Windows 10,  | Fedora 35,   |
// |      Compiler, -O3 | Intel v15.0 | GCC 11.2.1  | Intel v15.0 | GCC 11.2.1  | Intel v15.0 | GCC 11.2.1  | Intel v15.0 | GCC 11.2.1   | Intel v15.0  | GCC 11.2.1   |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+--------------+--------------+--------------+
// | qsort              |  60 seconds | 412 seconds | 350 seconds | 565 seconds | 450 seconds | 551 seconds | 881 seconds | 1066 seconds |         N.A. |         N.A. |
// | Bentley-McIlroy    |  38 seconds |  40 seconds | 204 seconds | 220 seconds | 276 seconds | 296 seconds | 542 seconds |  582 seconds |         N.A. |         N.A. |
// | Magnetica r.5BB    |  31 seconds |  33 seconds | 204 seconds | 216 seconds | 272 seconds | 286 seconds | 537 seconds |  565 seconds |         N.A. |         N.A. |
// | Magnetica r.5FF    |  32 seconds |  38 seconds | 209 seconds | 239 seconds | 265 seconds | 319 seconds | 525 seconds |  625 seconds |         N.A. |         N.A. |
// | Fluxsort           |  38 seconds |  38 seconds | 137 seconds | 138 seconds | 256 seconds | 197 seconds | 933 seconds |  641 seconds |         N.A. |         N.A. |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+--------------+--------------+--------------+
// | Best Time (bare    |                           |                           |                           |                            |                             |
// | bone in-place QS): |  31s for Magnetica r.5BB  | 204s PARITY               | 272s for Magnetica r.5BB  | 537s for Magnetica r.5BB   | N.A.                        |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+----------------------------+-----------------------------+
// Bottomline: Realistically - 3 wins out of 4 runs both for Magnetica vs qsort & Bentley-McIlroy, the rest is PARITY.
// Note: Scandum's Fluxsort is superior speedwise, but using out-of-place RAM is problematic when RAM is not sufficient, virtual trashing happens.
//
// Legend (The time is exactly the Sort process time):
// FEW = 2,233,861,800 keys, of them distinct = 10; 178,708,944 bytes 22338618_QWORDS.bin; elements = 178,708,944/8 *100; // Keys are 100 times duplicated
// MANY = 2,482,300,900 keys, of them distinct = 2,847,531; 24,823,016 bytes mobythesaurus.txt; elements = 24823016 -8+1; // BuildingBlocks are size-order+1, they are 100 times duplicated
// ALL = 2,009,333,753 keys, of them distinct = 1,912,608,132; 2,009,333,760 bytes Fedora-Workstation-Live-x86_64-35-1.2.iso; elements = 2009333760 -8+1; // BuildingBlocks are size-order+1
// ALLmore = 3,803,483,825 keys, of them distinct = 3,346,259,533; 3,803,483,832 bytes Fedora-Workstation-35-1.2.aarch64.raw.xz; elements = 3803483832 -8+1; // BuildingBlocks are size-order+1
// ALLmax = 7,798,235,435 keys, of them distinct = 6,770,144,405; 7,798,235,442 bytes math.stackexchange.com_en_all_2019-02.zim; elements = 7798235442 -8+1; // BuildingBlocks are size-order+1
// 
// Notes:
// - All the runs were in "Current priority class is REALTIME_PRIORITY_CLASS" for Windows and "Current priority is -20." for Linux;
// - Better speeds for Magnetica r.5FF with Insertionsort Threshold 13 instead of 31;
// - Benchmark needs 32GB RAM, and 64GB for the 5th testset;
// - The whole package (except the 3rd, 4th and 5th datasets) is downloadable at:
//   www.sanmayce.com/Quicksort_says_rev9+_finished 
// - To reproduce the roster, run on Windows or Linux:
//   - BENCH_ICL32GB.BAT
//   - BENCH_ICL64GB.BAT
//   - sh bench_gcc32GB.sh
//   - sh bench_gcc64GB.sh
// - 3rd dataset is downloadable at:
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/x86_64/iso/Fedora-Workstation-Live-x86_64-35-1.2.iso 
// - 4th dataset is downloadable at:
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/aarch64/images/Fedora-Workstation-35-1.2.aarch64.raw.xz 
// - 5th dataset is downloadable at:
// https://download.kiwix.org/zim/stack_exchange/math.stackexchange.com_en_all_2019-02.zim

// Note: Variant r.6 is much slower than r.5?! Didn't expect that.
// Note: When the "slower" variant r.5- (swapConditionalXY_BUGGY) was used, it was faster with ICL v.15.0, but was slower with GCC, so I commented it out. It has great potential if the elements are DWORDS i.e. 32bit, debranchifying awaits... a great sorter can be done...

// Laptop "Brutalitto", AMD 'Renoir' 4800H 4.3GHz max turbo, 64GB DDR4 3200MHz:
// +--------------------+---------------------------+---------------------------+---------------------------+----------------------------+-----------------------------+
// | Performer/Keys     | FEW distinct              | MANY distinct             | ALL distinct              | ALLmore distinct           | ALLmax distinct             |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+--------------+--------------+--------------+
// |  Operating System, | Windows 10, | Windows 10, | Windows 10, | Windows 10, | Windows 10, | Windows 10, | Windows 10, | Windows 10,  | Windows 10,  | Windows 10,  |
// |      Compiler, -O3 | Intel v15.0 | GCC 11.2.1  | Intel v15.0 | GCC 11.2.1  | Intel v15.0 | GCC 11.2.1  | Intel v15.0 | GCC 11.2.1   | Intel v15.0  | GCC 11.2.1   |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+--------------+--------------+--------------+
// | qsort              |  48 seconds |  45 seconds | 286 seconds | 282 seconds | 371 seconds | 366 seconds | 724 seconds |  714 seconds | 1505 seconds | 1497 seconds |
// | Bentley-McIlroy    |  24 seconds |  25 seconds | 148 seconds | 143 seconds | 202 seconds | 195 seconds | 393 seconds |  381 seconds |  888 seconds |  832 seconds |
// | Magnetica r.5BB    |  22 seconds |  24 seconds | 144 seconds | 152 seconds | 195 seconds | 206 seconds | 380 seconds |  403 seconds |  818 seconds |  852 seconds |
// | Magnetica r.5FF    |  25 seconds |  25 seconds | 158 seconds | 158 seconds | 205 seconds | 243 seconds | 403 seconds |  478 seconds |  972 seconds |  987 seconds |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+--------------+--------------+--------------+
// | Best Time:         |  22s for Magnetica r.5BB  | 143s for Bentley-McIlroy  | 195s PARITY               | 380s for Magnetica r.5BB   |  818s for Magnetica r.5BB   |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+----------------------------+-----------------------------+
// Bottomline: Realistically - 2 wins out of 5 runs, the rest 3 are PARITY.
//
// Laptop "Compressionette", Intel 'Kaby Lake' i5-7200U 3.1GHz max turbo, 36GB DDR4 2133MHz:
// +--------------------+---------------------------+---------------------------+---------------------------+----------------------------+-----------------------------+
// | Performer/Keys     | FEW distinct              | MANY distinct             | ALL distinct              | ALLmore distinct           | ALLmax distinct             |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+--------------+--------------+--------------+
// |  Operating System, | Windows 10, | Fedora 35,  | Windows 10, | Fedora 35,  | Windows 10, | Fedora 35,  | Windows 10, | Fedora 35,   | Windows 10,  | Fedora 35,   |
// |      Compiler, -O3 | Intel v15.0 | GCC 11.2.1  | Intel v15.0 | GCC 11.2.1  | Intel v15.0 | GCC 11.2.1  | Intel v15.0 | GCC 11.2.1   | Intel v15.0  | GCC 11.2.1   |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+--------------+--------------+--------------+
// | qsort              |  62 seconds | 387 seconds | 372 seconds | 553 seconds | 474 seconds | 529 seconds | 927 seconds | 1034 seconds |         N.A. |         N.A. |
// | Bentley-McIlroy    |  37 seconds |  40 seconds | 202 seconds | 219 seconds | 275 seconds | 295 seconds | 538 seconds |  580 seconds |         N.A. |         N.A. |
// | Magnetica r.5BB    |  32 seconds |  34 seconds | 215 seconds | 218 seconds | 285 seconds | 289 seconds | 561 seconds |  571 seconds |         N.A. |         N.A. |
// | Magnetica r.5FF    |  34 seconds |  39 seconds | 215 seconds | 240 seconds | 274 seconds | 343 seconds | 539 seconds |  673 seconds |         N.A. |         N.A. |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+--------------+--------------+--------------+
// | Best Time:         |  32s for Magnetica r.5BB  | 202s for Bentley-McIlroy  | 274s for Magnetica r.5FF  | 538s for Bentley-McIlroy   | N.A.                        |
// +--------------------+-------------+-------------+-------------+-------------+-------------+-------------+----------------------------+-----------------------------+
// Bottomline: Realistically - 1 win out of 4 runs both for Magnetica and Bentley-McIlroy, the rest 2 are PARITY.
//
// Legend (The time is exactly the Sort process time):
// FEW = 2,233,861,800 keys, of them distinct = 10; 178,708,944 bytes 22338618_QWORDS.bin; elements = 178,708,944/8 *100; // Keys are 100 times duplicated
// MANY = 2,482,300,900 keys, of them distinct = 2,847,531; 24,823,016 bytes mobythesaurus.txt; elements = 24823016 -8+1; // BuildingBlocks are size-order+1, they are 100 times duplicated
// ALL = 2,009,333,753 keys, of them distinct = 1,912,608,132; 2,009,333,760 bytes Fedora-Workstation-Live-x86_64-35-1.2.iso; elements = 2009333760 -8+1; // BuildingBlocks are size-order+1
// ALLmore = 3,803,483,825 keys, of them distinct = 3,346,259,533; 3,803,483,832 bytes Fedora-Workstation-35-1.2.aarch64.raw.xz; elements = 3803483832 -8+1; // BuildingBlocks are size-order+1
// ALLmax = 7,798,235,435 keys, of them distinct = 6,770,144,405; 7,798,235,442 bytes math.stackexchange.com_en_all_2019-02.zim; elements = 7798235442 -8+1; // BuildingBlocks are size-order+1
// 
// Notes:
// - All the runs were in "Current priority class is REALTIME_PRIORITY_CLASS" for Windows and "Current priority is -20." for Linux;
// - Benchmark needs 32GB RAM, and 64GB for the 5th testset;
// - The whole package (except the 3rd, 4th and 5th datasets) is downloadable at:
//   www.sanmayce.com/Quicksort_says_rev9.zip 
// - To reproduce the roster, run on Windows or Linux:
//   - BENCH_ICL32GB.BAT
//   - BENCH_ICL64GB.BAT
//   - sh bench_gcc32GB.sh
//   - sh bench_gcc64GB.sh
// - 3rd dataset is downloadable at:
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/x86_64/iso/Fedora-Workstation-Live-x86_64-35-1.2.iso 
// - 4th dataset is downloadable at:
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/aarch64/images/Fedora-Workstation-35-1.2.aarch64.raw.xz 
// - 5th dataset is downloadable at:
// https://download.kiwix.org/zim/stack_exchange/math.stackexchange.com_en_all_2019-02.zim


//# //https://stackoverflow.com/questions/2061245/how-to-subtract-two-unsigned-ints-with-wrap-around-or-overflow
//# /*
//# Here's a little more detail of why it 'just works' when you subtract the 'smaller' from the 'larger'.
//# 
//# A couple of things going into this…
//# 1. In hardware, subtraction uses addition: The appropriate operand is simply negated before being added.
//# 2. In two’s complement (which pretty much everything uses), an integer is negated by inverting all the bits then adding 1.
//# 
//# Hardware does this more efficiently than it sounds from the above description, but that’s the basic algorithm for subtraction (even when values are unsigned).
//# 
//# So, lets figure 2 – 250 using 8bit unsigned integers. In binary we have
//# 
//#   0 0 0 0 0 0 1 0  
//# - 1 1 1 1 1 0 1 0
//# We negate the operand being subtracted and then add. Recall that to negate we invert all the bits then add 1. After inverting the bits of the second operand we have
//# 
//# 0 0 0 0 0 1 0 1  
//# Then after adding 1 we have
//# 
//# 0 0 0 0 0 1 1 0  
//# Now we perform addition...
//# 
//#   0 0 0 0 0 0 1 0   
//# + 0 0 0 0 0 1 1 0
//# 
//# = 0 0 0 0 1 0 0 0 = 8, which is the result we wanted from 2 - 250
//# */
//# 
//# //https://stackoverflow.com/questions/7221409/is-unsigned-integer-subtraction-defined-behavior?noredirect=1
//# 
//# #include <stdint.h>
//# #include <stdio.h>
//# 
//# int main()
//# {
//# 
//# uint64_t SGNDmax = 1LL<<63;
//# uint64_t UNSGNDmax = -1;
//# //[[[
//#     uint8_t x = 0xff;
//#     uint8_t y = x + 20;
//#     int8_t res1;
//#     int8_t res2;
//# //]]]
//# 
//# //Well, an unsigned integer subtraction has defined behavior, also it is a tricky thing. 
//# //When you subtract two unsigned integers, result is promoted to higher type int if result (lvalue) type is not specified explicitly. 
//# //In the latter case, for example, int8_t result = a - b; (where a and b have int8_t type) you can obtain very weird behavior. 
//# //I mean you may loss transitivity property (i.e. if a > b and b > c it is true that a > c). 
//# //The loss of transitivity can destroy a tree-type data structure work. 
//# //Care must be taken not to provide comparison function for sorting, searching, tree building that uses unsigned integer subtraction to deduce which key is higher or lower.
//# //See example below.
//# 
//#     uint8_t a = 255;
//#     uint8_t b = 100;
//#     uint8_t c = 150;
//# 
//# //In Linux it is %llu and in Windows it is %I64u
//# printf("uint64_t SGNDmax = 1LL<<63 = %llu\n", SGNDmax);
//# printf("uint64_t UNSGNDmax = -1 = %llu\n\n", UNSGNDmax);
//# printf("uint64_t SGNDmax = 1LL<<63 = 0x%llX\n", SGNDmax);
//# printf("uint64_t UNSGNDmax = -1 = 0x%llX\n\n", UNSGNDmax);
//# 
//# //[[[
//#     printf("(uint8_t)x = %d\n", (uint8_t)x);
//#     printf("(uint8_t)y = %d\n", (uint8_t)y);
//# 
//#     printf("(int8_t)x = %d\n", (int8_t)x);
//#     printf("(int8_t)y = %d\n", (int8_t)y);
//# 
//#     res1 = (int8_t)x - y;
//#     res2 = (int8_t)y - x;
//#     printf("(int8_t)x - y = %d\n", res1);
//#     printf("(int8_t)y - x = %d\n", res2);
//# 
//#     res1 = (uint8_t)x - (uint8_t)y;
//#     res2 = (uint8_t)y - (uint8_t)x;
//#     printf("x and y: %d and %d\n", x, y);
//#     printf("(uint8_t)x - (uint8_t)y = %d\n", res1);
//#     printf("(uint8_t)y - (uint8_t)x = %d\n\n", res2);
//# //]]]
//# 
//#     printf("uint8_t a = %+d, b = %+d, c = %+d\n\n", a, b, c);
//# 
//#     printf("          b - a  = %+d\tpromotion to int type\n"
//#            " (int8_t)(b - a) = %+d\n\n"
//#            "          b + a  = %+d\tpromotion to int type\n"
//#            "(uint8_t)(b + a) = %+d\tmodular arithmetic\n"
//#            "     b + a %% %d = %+d\n\n", 
//#            b - a,  (int8_t)(b - a), 
//#            b + a, (uint8_t)(b + a),
//#            UINT8_MAX + 1,
//#            (b + a) % (UINT8_MAX + 1));
//# 
//# // Modified by Kaze:
//#     printf("b %s c (b - c = %d), b %s a (b - a = %d), AND c %s a (c - a = %d)\n",
//#            (int8_t)(b - c) < 0 ? "<" : ">", (int8_t)(b - c),
//#            (int8_t)(b - a) < 0 ? "<" : ">", (int8_t)(b - a),
//#            (int8_t)(c - a) < 0 ? "<" : ">", (int8_t)(c - a));
//#     return 0;
//# }
//# 
//# /*
//# F:\Quicksort_says_rev8++>notepad e.c
//# 
//# F:\Quicksort_says_rev8++>icl e.c
//# Intel(R) C++ Compiler XE for applications running on IA-32, Version 15.0.0.108 Build 20140726
//# Copyright (C) 1985-2014 Intel Corporation.  All rights reserved.
//# 
//# e.c
//# Microsoft (R) Incremental Linker Version 10.00.40219.01
//# Copyright (C) Microsoft Corporation.  All rights reserved.
//# 
//# -out:e.exe
//# e.obj
//# 
//# F:\Quicksort_says_rev8++>e
//# uint64_t SGNDmax = 1LL<<63 = 9223372036854775808
//# uint64_t UNSGNDmax = -1 = 18446744073709551615
//# 
//# uint64_t SGNDmax = 1LL<<63 = 0x8000000000000000
//# uint64_t UNSGNDmax = -1 = 0xFFFFFFFFFFFFFFFF
//# 
//# (uint8_t)x = 255
//# (uint8_t)y = 19
//# (int8_t)x = -1
//# (int8_t)y = 19
//# (int8_t)x - y = -20
//# (int8_t)y - x = 20
//# x and y: 255 and 19
//# (uint8_t)x - (uint8_t)y = -20
//# (uint8_t)y - (uint8_t)x = 20
//# 
//# uint8_t a = +255, b = +100, c = +150
//# 
//#           b - a  = -155 promotion to int type
//#  (int8_t)(b - a) = +101
//# 
//#           b + a  = +355 promotion to int type
//# (uint8_t)(b + a) = +99  modular arithmetic
//#      b + a % 256 = +99
//# 
//# b < c (b - c = -50), b > a (b - a = 101), AND c < a (c - a = -105)
//# 
//# F:\Quicksort_says_rev8++>
//# */


/*
; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
; mark_description "-FAcs -O3 -D_N_HIGH_PRIORITY";
; ae-64+2=76 bytes, 5/1 conditional/unconditional jumps
; 'Magnetica' partitioning, mainloop rev.4[

.B15.5::                        
  00064 49 ff c6         inc r14                                
  00067 4e 8b 14 f1      mov r10, QWORD PTR [rcx+r14*8]         
  0006b 4d 3b ea         cmp r13, r10                           
  0006e 77 2c            ja .B15.14 
.B15.6::                        
  00070 73 39            jae .B15.15 
.B15.7::                        
  00072 4e 8b 3c c1      mov r15, QWORD PTR [rcx+r8*8]          
  00076 4d 3b ef         cmp r13, r15                           
  00079 73 0c            jae .B15.11 
.B15.9::                        
  0007b 49 ff c8         dec r8                                 
  0007e 4e 8b 3c c1      mov r15, QWORD PTR [rcx+r8*8]          
  00082 4d 3b ef         cmp r13, r15                           
  00085 72 f4            jb .B15.9 
.B15.11::                       
  00087 4d 3b f0         cmp r14, r8                            
  0008a 7d 08            jge .B15.13 
.B15.12::                       
  0008c 4e 89 3c f1      mov QWORD PTR [rcx+r14*8], r15         
  00090 4e 89 14 c1      mov QWORD PTR [rcx+r8*8], r10          
.B15.13::                       
  00094 49 ff c8         dec r8                                 
  00097 49 ff ce         dec r14                                
  0009a eb 0f            jmp .B15.15 
.B15.14::                       
  0009c 4c 8b 3c e9      mov r15, QWORD PTR [rcx+rbp*8]         
  000a0 4c 89 14 e9      mov QWORD PTR [rcx+rbp*8], r10         
  000a4 48 ff c5         inc rbp                                
  000a7 4e 89 3c f1      mov QWORD PTR [rcx+r14*8], r15         
.B15.15::                       
  000ab 4d 3b f0         cmp r14, r8                            
  000ae 7c b4            jl .B15.5 
; 'Magnetica' partitioning, mainloop rev.4]
*/

    #ifdef revision4
            for (;PR < Jndx;) {
                PR = PR + 1;
                if (Pivot > QWORDS[PR]) {
                    swapUnconditional (&QWORDS[PL], &QWORDS[PR]);
                    PL = PL + 1;
                //} else if (Pivot == QWORDS[PR]) {
                } else if (Pivot < QWORDS[PR]) {
                    for (;Pivot < QWORDS[Jndx];) {
                        Jndx = Jndx - 1;
                    }
                    if (PR < Jndx) swapUnconditional (&QWORDS[PR], &QWORDS[Jndx]);
                    Jndx = Jndx - 1;
                    PR = PR - 1;
                }
            }
    #endif
/*
; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
; ae-64+2=76 bytes i.e. (94-76=18 less), 5/1 conditional/unconditional jumps i.e. 2-1=1 less unconditional jump than r.1
; 'Magnetica' partitioning, mainloop rev.2[
.B4.5::                         
  00064 48 ff c5         inc rbp                                
  00067 48 8b 14 e9      mov rdx, QWORD PTR [rcx+rbp*8]         
  0006b 4c 3b ea         cmp r13, rdx                           
  0006e 77 2c            ja .B4.14 
.B4.6::                         
  00070 73 39            jae .B4.15 
.B4.7::                         
  00072 4e 8b 3c d9      mov r15, QWORD PTR [rcx+r11*8]         
  00076 4d 3b ef         cmp r13, r15                           
  00079 73 0c            jae .B4.11 
.B4.9::                         
  0007b 49 ff cb         dec r11                                
  0007e 4e 8b 3c d9      mov r15, QWORD PTR [rcx+r11*8]         
  00082 4d 3b ef         cmp r13, r15                           
  00085 72 f4            jb .B4.9 
.B4.11::                        
  00087 49 3b eb         cmp rbp, r11                           
  0008a 7d 08            jge .B4.13 
.B4.12::                        
  0008c 4c 89 3c e9      mov QWORD PTR [rcx+rbp*8], r15         
  00090 4a 89 14 d9      mov QWORD PTR [rcx+r11*8], rdx         
.B4.13::                        
  00094 49 ff cb         dec r11                                
  00097 48 ff cd         dec rbp                                
  0009a eb 0f            jmp .B4.15 
.B4.14::                        
  0009c 4e 8b 3c f1      mov r15, QWORD PTR [rcx+r14*8]         
  000a0 4a 89 14 f1      mov QWORD PTR [rcx+r14*8], rdx         
  000a4 49 ff c6         inc r14                                
  000a7 4c 89 3c e9      mov QWORD PTR [rcx+rbp*8], r15         
.B4.15::                        
  000ab 49 3b eb         cmp rbp, r11                           
  000ae 7c b4            jl .B4.5 
; 'Magnetica' partitioning, mainloop rev.2]
*/
    #ifdef revision3
            for (;PR < Jndx;) {
                // Many thanks go to Orson Peters for sharing his Pattern-defeating quicksort (pdqsort) at GitHub.
                // This is due to a new technique described in "BlockQuicksort: How Branch Mispredictions don't affect Quicksort" by Stefan Edelkamp and Armin Weiss.
                Stefan_Edelkamp_Armin_Weiss1 = (Pivot > QWORDS[PR + 1]);
                Stefan_Edelkamp_Armin_Weiss2 = (Pivot == QWORDS[PR + 1]);
                Stefan_Edelkamp_Armin_Weiss3 = (Pivot < QWORDS[PR + 1]);
                tmp = minSO(QWORDS[PL], QWORDS[PR + 1]); QWORDS[PR + 1] = maxSO(QWORDS[PL], QWORDS[PR + 1]); QWORDS[PL] = tmp; // Since Pivot is equal to QWORDS[PL]
                PL = PL + Stefan_Edelkamp_Armin_Weiss1;
                PR = PR + Stefan_Edelkamp_Armin_Weiss1;
                PR = PR + Stefan_Edelkamp_Armin_Weiss2;
                if (Stefan_Edelkamp_Armin_Weiss3) {
                    for (;Pivot < QWORDS[Jndx];) {
                        Jndx = Jndx - 1;
                    }
                    if (PR + 1 < Jndx) swapUnconditional (&QWORDS[PR + 1], &QWORDS[Jndx]);
                    Jndx = Jndx - 1;
                }
            }
    #endif
/*
; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
; f9-73+6=140 bytes, 4/0 conditional/unconditional jumps
; 'Magnetica' partitioning, mainloop rev.3[
.B7.5::                         
  00073 4a 8b 5c f1 08   mov rbx, QWORD PTR [8+rcx+r14*8]       
  00078 33 d2            xor edx, edx                           
  0007a 4c 3b eb         cmp r13, rbx                           
  0007d 4a 8b 2c c1      mov rbp, QWORD PTR [rcx+r8*8]          
  00081 49 0f 47 d4      cmova rdx, r12                         
  00085 45 33 ff         xor r15d, r15d                         
  00088 48 3b eb         cmp rbp, rbx                           
  0008b 48 89 ee         mov rsi, rbp                           
  0008e 41 0f 92 c7      setb r15b                              
  00092 48 33 f3         xor rsi, rbx                           
  00095 41 f7 df         neg r15d                               
  00098 4d 63 ff         movsxd r15, r15d                       
  0009b 49 23 f7         and rsi, r15                           
  0009e 48 33 ee         xor rbp, rsi                           
  000a1 4c 3b eb         cmp r13, rbx                           
  000a4 4a 89 6c f1 08   mov QWORD PTR [8+rcx+r14*8], rbp       
  000a9 bd 00 00 00 00   mov ebp, 0                             
  000ae 49 0f 44 ec      cmove rbp, r12                         
  000b2 48 33 f3         xor rsi, rbx                           
  000b5 4a 89 34 c1      mov QWORD PTR [rcx+r8*8], rsi          
  000b9 4c 03 c2         add r8, rdx                            
  000bc 48 03 d5         add rdx, rbp                           
  000bf 4c 03 f2         add r14, rdx                           
  000c2 4c 3b eb         cmp r13, rbx                           
  000c5 73 2f            jae .B7.13 
.B7.6::                         
  000c7 4a 8b 14 c9      mov rdx, QWORD PTR [rcx+r9*8]          
  000cb 4c 3b ea         cmp r13, rdx                           
  000ce 73 0c            jae .B7.10 
.B7.8::                         
  000d0 49 ff c9         dec r9                                 
  000d3 4a 8b 14 c9      mov rdx, QWORD PTR [rcx+r9*8]          
  000d7 4c 3b ea         cmp r13, rdx                           
  000da 72 f4            jb .B7.8 
.B7.10::                        
  000dc 49 8d 5e 01      lea rbx, QWORD PTR [1+r14]             
  000e0 4c 3b cb         cmp r9, rbx                            
  000e3 7e 0e            jle .B7.12 
.B7.11::                        
  000e5 4a 8b 5c f1 08   mov rbx, QWORD PTR [8+rcx+r14*8]       
  000ea 4a 89 54 f1 08   mov QWORD PTR [8+rcx+r14*8], rdx       
  000ef 4a 89 1c c9      mov QWORD PTR [rcx+r9*8], rbx          
.B7.12::                        ; Preds .B7.10 .B7.11
  000f3 49 ff c9         dec r9                                 
.B7.13::                        
  000f6 4d 3b f1         cmp r14, r9                            
  000f9 0f 8c 74 ff ff 
        ff               jl .B7.5 
; 'Magnetica' partitioning, mainloop rev.3]
*/
            Jndx = PL - 1;
            Indx = PR + 1;
/*
            // 'Magnetica' partitioning [
            Jndx = Right;
            PL = Left;
            PR = Left;
            swap (&QWORDS[(Left + Right)>>1], &QWORDS[PR]);
            Pivot = QWORDS[PR];
            for (;PR < Jndx;) {
                if (Pivot > QWORDS[PR + 1]) {
                    swap (&QWORDS[PL], &QWORDS[PR + 1]);
                    PL = PL + 1;
                    PR = PR + 1;
                } else if (Pivot == QWORDS[PR + 1]) {
                    PR = PR + 1;
                } else {
                    for (;Pivot < QWORDS[Jndx];) {
                        Jndx = Jndx - 1;
                    }
                    if (PR + 1 < Jndx) swap (&QWORDS[PR + 1], &QWORDS[Jndx]);
                    Jndx = Jndx - 1;
                }
            }
            Jndx = PL - 1;
            Indx = PR + 1;
            // 'Magnetica' partitioning ]
*/
/*
; mark_description "Intel(R) C++ Compiler XE for applications running on Intel(R) 64, Version 15.0.0.108 Build 20140726";
; c6-6a+2=94 bytes, 5/2 conditional/unconditional jumps
; 'Magnetica' partitioning, mainloop [
.B4.5::                         
  0006a 4e 3b 5c e9 08   cmp r11, QWORD PTR [8+rcx+r13*8]       
  0006f 77 37            ja .B4.15 
.B4.6::                         
  00071 75 08            jne .B4.8 
.B4.7::                         
  00073 49 89 d5         mov r13, rdx                           
  00076 48 ff c2         inc rdx                                
  00079 eb 48            jmp .B4.16 
.B4.8::                         
  0007b 4e 8b 34 c1      mov r14, QWORD PTR [rcx+r8*8]          
  0007f 4d 3b de         cmp r11, r14                           
  00082 73 0c            jae .B4.12 
.B4.10::                        
  00084 49 ff c8         dec r8                                 
  00087 4e 8b 34 c1      mov r14, QWORD PTR [rcx+r8*8]          
  0008b 4d 3b de         cmp r11, r14                           
  0008e 72 f4            jb .B4.10 
.B4.12::                        
  00090 4c 3b c2         cmp r8, rdx                            
  00093 7e 0e            jle .B4.14 
.B4.13::                        
  00095 4e 8b 7c e9 08   mov r15, QWORD PTR [8+rcx+r13*8]       
  0009a 4e 89 74 e9 08   mov QWORD PTR [8+rcx+r13*8], r14       
  0009f 4e 89 3c c1      mov QWORD PTR [rcx+r8*8], r15          
.B4.14::                        
  000a3 49 ff c8         dec r8                                 
  000a6 eb 1b            jmp .B4.16 
.B4.15::                        
  000a8 4e 8b 74 e9 08   mov r14, QWORD PTR [8+rcx+r13*8]       
  000ad 4e 8b 3c e1      mov r15, QWORD PTR [rcx+r12*8]         
  000b1 4e 89 34 e1      mov QWORD PTR [rcx+r12*8], r14         
  000b5 49 ff c4         inc r12                                
  000b8 4e 89 7c e9 08   mov QWORD PTR [8+rcx+r13*8], r15       
  000bd 49 89 d5         mov r13, rdx                           
  000c0 48 ff c2         inc rdx                                
.B4.16::                        
  000c3 4d 3b e8         cmp r13, r8                            
  000c6 7c a2            jl .B4.5 
; 'Magnetica' partitioning, mainloop ]
*/
    #ifdef FinishWithInsertionSort
            GearBox = ( maxSO((Right-Indx), (Jndx-Left)) > minSO((Right-Indx), (Jndx-Left))<<6 ); // same as MAX/MIN > 64, i.e. Gear=1 if we need Median of 7
    #endif
            if (Indx + InsertionsortTHRESHOLD < Right) { // still refusing to go (always) with the smaller partition first...
                StackPtr = StackPtr + 2;
                Stack[StackPtr - 1] = Indx;
                Stack[StackPtr] = Right;
    #ifdef FinishWithInsertionSort
                // Stack is full, bail out and finalize with Insertionsort [
                StackPtr = StackPtr*(StackPtr + 2 <= StackEntries-1);  // StackPtr should be enforced FALSE; also, ensure the next 'push' above is sanctioned - the max index of Stack[] being 'StackEntries-1'
                Right = Right*(StackPtr + 2 <= StackEntries-1); // Left + InsertionsortTHRESHOLD < Right should be enforced FALSE:
                // Stack is full, bail out and finalize with Insertionsort ]
    #endif
            }
            Right = Jndx;
        } //while (Left + InsertionsortTHRESHOLD < Right);
    } while ( (StackPtr != 0) );
    #ifdef FinishWithInsertionSort
    for (Indx=LeftBackup+1; Indx <= RightBackup; Indx++) {
        Jndx = Indx;
        for (;Jndx >= 1;) {
            if (QWORDS[Jndx-1] > QWORDS[Jndx]) swapUnconditional (&QWORDS[Jndx-1], &QWORDS[Jndx]); else break;
            Jndx = Jndx - 1;
        }
    }
    #endif
}
// My threads with Magnetica's source and binaries (Linux and Windows):
// https://www.overclock.net/threads/benchmark-quicksort-says-sorting-2-billion-qwords.1794855/
// https://www.qb64.org/forum/index.php?topic=3518.msg137645#msg137645
// https://www.linuxquestions.org/questions/programming-9/qsort-vs-%27magnetica%27-quicksort-4175703333/#post6299782
// Quicksort 'Magnetica' r.6, unbreakable (never overflowing the stack) when '#define FinishWithInsertionSort' is uncommented ]


/*
void scalar_partition_epi32(uint32_t* array, const uint32_t pivot, int& left, int& right) {
    while (left <= right) {
        while (array[left] < pivot) {
            left += 1;
        }
        while (array[right] > pivot) {
            right -= 1;
        }
        if (left <= right) {
            const uint32_t t = array[left];
            array[left]      = array[right];
            array[right]     = t;
            left  += 1;
            right -= 1;
        }
    }
}

int lomuto_partition_epi32(uint32_t* array, int lo, int hi) {
    const uint32_t pivot = array[(lo + hi)/2];
    const uint32_t hi_value = array[hi];
    array[(lo + hi)/2] = hi_value;
    array[hi] = pivot;
    int i = lo;

    for (int j=lo; j < hi; j++) {
        if (array[j] <= pivot) {
            const uint32_t t = array[i];
            array[i] = array[j];
            array[j] = t;
            i += 1;
        }
    }
    {
        const uint32_t t = array[i];
        array[i]  = array[hi];
        array[hi] = t;
        i += 1;
    }
    return i;
}
*/





// https://stackoverflow.com/questions/2786899/fastest-sort-of-fixed-length-6-int-array

//    //#define SWAP(x,y) asm("mov %0, %2 ; cmp %1, %0 ; cmovg %1, %0 ; cmovg %2, %1" : "=r" (x), "=r" (y), "=r" (tmp) : "0" (x), "1" (y) : "cc");
//    #define SWAP(x,y) { int dx = d[x]; int dy = d[y]; int tmp = d[x] = dx < dy ? dx : dy; d[y] ^= dx ^ tmp; }

/*
    static inline void sort6_sorting_network_v4(int * d){
    #define min(x, y) (y ^ ((x ^ y) & -(x < y)))
    #define max(x, y) (x ^ ((x ^ y) & -(x < y)))
    #define SWAP(x,y) { int tmp = min(d[x], d[y]); d[y] = max(d[x], d[y]); d[x] = tmp; }
        SWAP(1, 2);
        SWAP(4, 5);
        SWAP(0, 2);
        SWAP(3, 5);
        SWAP(0, 1);
        SWAP(3, 4);
        SWAP(1, 4);
        SWAP(0, 3);
        SWAP(2, 5);
        SWAP(1, 3);
        SWAP(2, 4);
        SWAP(2, 3);
    #undef SWAP
    #undef min
    #undef max
    }
*/

/*
    static inline void sort6_rank_order_reg(int *d) {
        register int x0,x1,x2,x3,x4,x5;
        x0 = d[0];
        x1 = d[1];
        x2 = d[2];
        x3 = d[3];
        x4 = d[4];
        x5 = d[5];
        int o0 = (x0>x1)+(x0>x2)+(x0>x3)+(x0>x4)+(x0>x5);
        int o1 = (x1>=x0)+(x1>x2)+(x1>x3)+(x1>x4)+(x1>x5);
        int o2 = (x2>=x0)+(x2>=x1)+(x2>x3)+(x2>x4)+(x2>x5);
        int o3 = (x3>=x0)+(x3>=x1)+(x3>=x2)+(x3>x4)+(x3>x5);
        int o4 = (x4>=x0)+(x4>=x1)+(x4>=x2)+(x4>=x3)+(x4>x5);
        int o5 = 15-(o0+o1+o2+o3+o4);
        d[o0]=x0; d[o1]=x1; d[o2]=x2; d[o3]=x3; d[o4]=x4; d[o5]=x5;
    }
*/

/*
    static inline void sort6_inlined_bubble(int * d){
    #define SWAP(x,y) { int dx = d[x], dy = d[y], tmp; tmp = d[x] = dx < dy ? dx : dy; d[y] ^= dx ^ tmp; }
        SWAP(0,1); SWAP(1,2); SWAP(2,3); SWAP(3,4); SWAP(4,5);
        SWAP(0,1); SWAP(1,2); SWAP(2,3); SWAP(3,4);
        SWAP(0,1); SWAP(1,2); SWAP(2,3);
        SWAP(0,1); SWAP(1,2);
        SWAP(0,1);
    #undef SWAP
    }
*/

// Sandy Bridge (i7-2600k)
// =======================
// Direct call to qsort library function      559.97   451.88   464.84   491.35   458.11
// Naive implementation (insertion sort)      341.15   160.26   160.45   154.40   106.54
// Insertion Sort (Daniel Stutzbach)          284.17   136.74   132.69   123.85   121.77
// Insertion Sort Unrolled                    239.40   110.49   114.81   110.79   117.30
// Rank Order                                 114.24   76.42    45.31    36.96    36.73
// Rank Order with registers                  105.09   32.31    48.54    32.51    33.29
// Sorting Networks (Daniel Stutzbach)        210.56   115.68   116.69   107.05   124.08
// Sorting Networks (Paul R)                  364.03   66.02    61.64    45.70    44.19
// Sorting Networks 12 with Fast Swap         246.97   41.36    59.03    41.66    38.98
// Sorting Networks 12 reordered Swap         235.39   38.84    47.36    38.61    37.29
// Reordered Sorting Network w/ fast swap     115.58   27.23    27.75    27.25    26.54



void printArray(uint64_t array[], int64_t size) {
int64_t i;
for (i = 0; i < size; ++i) printf("%016llX\n", (unsigned long long)array[i]);
}

//int cmpfunc (const void * a, const void * b) {
//  if ( *(uint64_t*)a > *(uint64_t*)b ) return 1;
//  else if ( *(uint64_t*)a < *(uint64_t*)b ) return -1;
//  //else ( *(uint64_t*)a = *(uint64_t*)b ) return 0;
//  return 0;
//}

int cmpfunc (const void * a, const void * b) { return (*(uint64_t *)a > *(uint64_t *)b) - (*(uint64_t *)a < *(uint64_t *)b); }
/*
;;; int M16_Scandum_UINT64p(uint64_t *a, uint64_t *b) { return (*a > *b) - (*a < *b); }
  00000 45 33 c0         xor r8d, r8d                           
  00003 48 8b 01         mov rax, QWORD PTR [rcx]               
  00006 48 3b 02         cmp rax, QWORD PTR [rdx]               
  00009 44 89 c0         mov eax, r8d                           
  0000c 0f 97 c0         seta al                                
  0000f 41 0f 92 c0      setb r8b                               
  00013 41 2b c0         sub eax, r8d                           
  00016 c3               ret                                    
*/

//int cmpfunc (uint64_t a, uint64_t b) { return (a > b) - (a < b); } // if a G b then 1
/*
;;; int M16_Scandum_UINT64v(uint64_t a, uint64_t b) { return (a > b) - (a < b); }
  00000 45 33 c0         xor r8d, r8d                           
  00003 33 c0            xor eax, eax                           
  00005 48 3b ca         cmp rcx, rdx                           
  00008 0f 97 c0         seta al                                
  0000b 41 0f 92 c0      setb r8b                               
  0000f 41 2b c0         sub eax, r8d                           
  00012 c3               ret                                    
*/

// taken from bench.c by Scandum in order to have the same comparer:
int cmp_8(const void * a, const void * b)
{
    //return *(uint64_t *)a > *(uint64_t *)b ? 1 : 0;
    return (*(uint64_t *)a > *(uint64_t *)b) - (*(uint64_t *)a < *(uint64_t *)b);
}


int m=1811939329,N=1,t[1<<26]={2},a,*p,i,e=73421233,s,c,U=1;
void gg(int d, int h){for(i=s;i<1<<25;i*=2)d=d*1LL*d%m;for(p=t;p<t+N;p+=s)for(i=s,c=1;i;i--)a=p[s]*(h?c:1LL)%m,p[s]=(m*1U+*p-a)*(h?1LL:c)%m,*p=(a*1U+*p)%m,p++,c=c*1LL*d%m;}

#include <time.h>
#include <string.h> // gcc complains for strcmp

#include "quadsort.h"
//#include "fluxsort.h"
#include "crumsort.h"
//#include "Magnetica_v12.h"
//#include "Magnetica_v13.h"
//#include "Magnetica_v14.h"
//#include "Magnetica_v15.h"
//#include "Magnetica_v16.h"
#include "Akkodah_v3.h"

#ifdef _N_HIGH_PRIORITY
// https://msdn.microsoft.com/en-us/library/windows/desktop/ms686219.aspx
#include <stdio.h>
#include <windows.h>
#include <tchar.h>
#endif

//#define _WIN32_ENVIRONMENT_
//#define _POSIX_ENVIRONMENT_

#if defined(_WIN32_ENVIRONMENT_)
#include <io.h> // needed for Windows' 'lseeki64' and 'telli64'
//Above line must be commented in order to compile with Intel C compiler: an error "can't find io.h" occurs.
#else
#endif /* defined(_WIN32_ENVIRONMENT_)  */

#ifdef _N_HIGH_PRIORITY_GCC
//#include <sys/time.h>
#include <sys/resource.h>
//int main(){
//    setpriority(PRIO_PROCESS, 0, -20);
//}
//Note that you must be running as superuser for this to work. (for more info, type 'man setpriority' at a prompt.)
#endif

#include <emmintrin.h>
#include <smmintrin.h>
//#include <immintrin.h>
//Hamid
size_t memcount_sse2(const void *s, int c, size_t n) {    
    __m128i cv = _mm_set1_epi8(c), sum = _mm_setzero_si128(), acr0,acr1,acr2,acr3;
    const char *p,*pe;						    											   
	for(p = s; p != (char *)s+(n- (n % (252*16)));) { 
	  for(acr0 = acr1 = acr2 = acr3 = _mm_setzero_si128(),pe = p+252*16; p != pe; p += 64) { 
		acr0 = _mm_add_epi8(acr0, _mm_cmpeq_epi8(cv, _mm_loadu_si128((const __m128i *)p))); 
		acr1 = _mm_add_epi8(acr1, _mm_cmpeq_epi8(cv, _mm_loadu_si128((const __m128i *)(p+16)))); 
		acr2 = _mm_add_epi8(acr2, _mm_cmpeq_epi8(cv, _mm_loadu_si128((const __m128i *)(p+32)))); 
		acr3 = _mm_add_epi8(acr3, _mm_cmpeq_epi8(cv, _mm_loadu_si128((const __m128i *)(p+48))));
#if defined(_WIN32_ENVIRONMENT_)
		//forgot the Intel counterpart, see Nakamichi.c
#else
		__builtin_prefetch(p+1024);
#endif // defined(_WIN32_ENVIRONMENT_)
	  }
      sum = _mm_add_epi64(sum, _mm_sad_epu8(_mm_sub_epi8(_mm_setzero_si128(), acr0), _mm_setzero_si128()));
      sum = _mm_add_epi64(sum, _mm_sad_epu8(_mm_sub_epi8(_mm_setzero_si128(), acr1), _mm_setzero_si128()));
      sum = _mm_add_epi64(sum, _mm_sad_epu8(_mm_sub_epi8(_mm_setzero_si128(), acr2), _mm_setzero_si128()));
      sum = _mm_add_epi64(sum, _mm_sad_epu8(_mm_sub_epi8(_mm_setzero_si128(), acr3), _mm_setzero_si128()));
    }
    size_t count = _mm_extract_epi64(sum, 0) + _mm_extract_epi64(sum, 1);   
    while(p != (char *)s + n) count += *p++ == c;
    return count;
}

/*
size_t memcount_avx2(const void *s, int c, size_t n) {    
    __m256i cv = _mm256_set1_epi8(c), zv = _mm256_setzero_si256(), sum = zv, acr0,acr1,acr2,acr3;
    const char *p,*pe;						    											   
	for(p = s; p != (char *)s+(n- (n % (252*32)));) { 
	  for(acr0 = acr1 = acr2 = acr3 = zv,pe = p+252*32; p != pe; p += 128) { 
		acr0 = _mm256_add_epi8(acr0, _mm256_cmpeq_epi8(cv, _mm256_lddqu_si256((const __m256i *)p))); 
		acr1 = _mm256_add_epi8(acr1, _mm256_cmpeq_epi8(cv, _mm256_lddqu_si256((const __m256i *)(p+32)))); 
		acr2 = _mm256_add_epi8(acr2, _mm256_cmpeq_epi8(cv, _mm256_lddqu_si256((const __m256i *)(p+64)))); 
		acr3 = _mm256_add_epi8(acr3, _mm256_cmpeq_epi8(cv, _mm256_lddqu_si256((const __m256i *)(p+96))));
#if defined(_WIN32_ENVIRONMENT_)
		//forgot the Intel counterpart, see Nakamichi.c
		_mm_prefetch(p+1024, _MM_HINT_T0);
#else
		__builtin_prefetch(p+1024);
#endif // defined(_WIN32_ENVIRONMENT_)
	  }
      sum = _mm256_add_epi64(sum, _mm256_sad_epu8(_mm256_sub_epi8(zv, acr0), zv));
      sum = _mm256_add_epi64(sum, _mm256_sad_epu8(_mm256_sub_epi8(zv, acr1), zv));
      sum = _mm256_add_epi64(sum, _mm256_sad_epu8(_mm256_sub_epi8(zv, acr2), zv));
      sum = _mm256_add_epi64(sum, _mm256_sad_epu8(_mm256_sub_epi8(zv, acr3), zv));
    }	
    for(acr0=zv; p+32 < (char *)s + n; p += 32)  
      acr0 = _mm256_add_epi8(acr0, _mm256_cmpeq_epi8(cv, _mm256_lddqu_si256((const __m256i *)p))); 
    sum = _mm256_add_epi64(sum, _mm256_sad_epu8(_mm256_sub_epi8(zv, acr0), zv));
    size_t count = _mm256_extract_epi64(sum, 0) + _mm256_extract_epi64(sum, 1) + _mm256_extract_epi64(sum, 2) + _mm256_extract_epi64(sum, 3);   
    while(p != (char *)s + n) count += *p++ == c;
    return count;
}
*/

int main(int argc, char **argv)
{
    uint64_t data[] = {8, 7, 2, 1, 0, 9, 6, 15};
    uint64_t QWORDS[] = {8, 7, 2, 1, 0, 9, 6};
    int64_t n = sizeof(data) / sizeof(data[0]);
time_t time1,time2,time3;

//FILE *fp_outLINE;
FILE *fp_outLINE2;
FILE *fp_outLINE3;
FILE *fp_in;
uint64_t size_in64;
uint64_t digit[1];
uint64_t elements;
uint64_t counter;
uint64_t *FabriceBellard_DIGITS;
uint64_t *xgamsCACHE;
uint64_t *xgamsCACHElen;
char *AvoidSEEKS;
char *AvoidManyFWRITEs;
int64_t i,j,k,l,m,r,q,w,a,z,g,h;
uint64_t UniqueElements = 1, Previous;
int ditto;
uint64_t HAILSTONE;
size_t MinimumKeysUnsortedSCALAR = 0;
uint64_t NumberOfLFs;
uint64_t NumberOfCRs;
char *ForLF=NULL;

char *Auberge[4] = {"|\0","/\0","-\0","\\\0"};
int Melnitchka=0;
clock_t clocks1, clocks2;
clock_t clocks3, clocks4;

#define BufferSize 1024*384
char workbyte;
char workK[BufferSize];
long workKoffset = -1;
uint64_t Over4billionLines = 0;
uint64_t Longest10Line = 0;
uint64_t Current10Line = 0;

char llTOaDigits[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
char llTOaDigits2[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)
char llTOaDigits3[27]; // 9,223,372,036,854,775,807: 1(sign or carry)+19(digits)+1('\0')+6(,)

uint64_t Left;
uint64_t Right;

uint64_t         CurrentLine;
uint64_t         LongestLine;
uint64_t         ShortestLine=-1;

int PlusOneOrTwo;
int OrderFixedOrDynamic;

#ifdef _N_HIGH_PRIORITY
   DWORD dwError, dwPriClass;
#endif

uint64_t MicroPartition;

/*
i=10;
j=300;
MicroPartition=j-i;

MicroPartition=8192;
MicroPartition = (1*!!((MicroPartition)>>13)) + (1*!!((MicroPartition)>>9)); // 8192[+] 512[+] 13..511
        printf("%d",MicroPartition);

MicroPartition=512;
MicroPartition = (1*!!((MicroPartition)>>13)) + (1*!!((MicroPartition)>>9)); // 8192[+] 512[+] 13..511
        printf("%d",MicroPartition);

MicroPartition=511;
MicroPartition = (1*!!((MicroPartition)>>13)) + (1*!!((MicroPartition)>>9)); // 8192[+] 512[+] 13..511
        printf("%d",MicroPartition);

// MicroPartition=2 for 8192[+]
// MicroPartition=1 for 512[+]
// MicroPartition=0 for 511[-]
*/

//MicroPartition=14*(MicroPartition>(1LL<<13));
//switch (MicroPartition) {
//  case 14:
//      printf("14");
//  case 13:
//      printf("13");
//      break;
//  case 0:
//      printf("Mid-MId; Mid; 3rd");
//  default:
//      printf("def");      
//}
//exit(1);

/*
    register uint64_t x0,x1,x2,x3,x4,x5,x6;
    int o0,o1,o2,o3,o4,o5,o6;
    int TheMiddleOfMiddle=0;
    printf("Unsorted Array:\n");
    printArray(QWORDS, 7);
  
            x0 = QWORDS[TheMiddleOfMiddle+0];
            x1 = QWORDS[TheMiddleOfMiddle+1];
            x2 = QWORDS[TheMiddleOfMiddle+2];
            x3 = QWORDS[TheMiddleOfMiddle+3];
            x4 = QWORDS[TheMiddleOfMiddle+4];
            x5 = QWORDS[TheMiddleOfMiddle+5];
            x6 = QWORDS[TheMiddleOfMiddle+6];
            o0 = (x0>x1)+(x0>x2)+(x0>x3)+(x0>x4)+(x0>x5)+(x0>x6);
            o1 = (x1>=x0)+(x1>x2)+(x1>x3)+(x1>x4)+(x1>x5)+(x1>x6);
            o2 = (x2>=x0)+(x2>=x1)+(x2>x3)+(x2>x4)+(x2>x5)+(x2>x6);
            o3 = (x3>=x0)+(x3>=x1)+(x3>=x2)+(x3>x4)+(x3>x5)+(x3>x6);
            o4 = (x4>=x0)+(x4>=x1)+(x4>=x2)+(x4>=x3)+(x4>x5)+(x4>x6);
            o5 = (x5>=x0)+(x5>=x1)+(x5>=x2)+(x5>=x3)+(x5>=x4)+(x5>x6);
            o6 = (0+1+2+3+4+5+6)-(o0+o1+o2+o3+o4+o5);
            QWORDS[TheMiddleOfMiddle+o0]=x0; QWORDS[TheMiddleOfMiddle+o1]=x1; QWORDS[TheMiddleOfMiddle+o2]=x2; QWORDS[TheMiddleOfMiddle+o3]=x3; QWORDS[TheMiddleOfMiddle+o4]=x4; QWORDS[TheMiddleOfMiddle+o5]=x5; QWORDS[TheMiddleOfMiddle+o6]=x6;
  
  
    printf("Sorted array in ascending order: \n");
    printArray(QWORDS, 7);
    exit(0);
*/

/*
  printf("   _________        .__                       __                    __             .___         \n");
  printf("  /   _____/  ____  |  |__    _____    ____  |  | __  ____ _______ |__|_____     __| _/_____    \n");
  printf("  \\\x5f____  \\ _/ ___\\ |  |  \\  /     \\ _/ __ \\ |  |/ /_/ __ \\\\\x5f  __ \\\x7c  |\\\x5f_  \\   / __ | \\\x5f_  \\   \n");
  printf("  /        \\\\  \\\x5f__ |   Y  \\\x7c  Y Y  \\\\  ___/ |    < \\  ___/ |  | \\\x2f|  | / __ \\\x5f/ /_/ |  / __ \\\x5f \n");
  printf(" /_______  / \\\x5f__  >|___|  /|__|_|  / \\\x5f__  >|__|_ \\ \\\x5f__  >|__|   |__|(____  /\\\x5f___ | (____  / \n");
  printf("         \\\x2f      \\\x2f      \\\x2f       \\\x2f      \\\x2f      \\\x2f     \\\x2f                 \\\x2f      \\\x2f      \\\x2f   \n");
*/
  printf("   _________        .__                       __                                               .___        \n");
  printf("  /   _____/  ____  |  |__    _____    ____  |  | __  ____ _______   ____  _____________     __| _/_____   \n");
  printf("  \\_____  \\ _/ ___\\ |  |  \\  /     \\ _/ __ \\ |  |/ /_/ __ \\\\_  __ \\_/ __ \\ \\___   /\\__  \\   / __ | \\__  \\  \n");
  printf("  /        \\\\  \\___ |   Y  \\|  Y Y  \\\\  ___/ |    < \\  ___/ |  | \\/\\  ___/  /    /  / __ \\_/ /_/ |  / __ \\_\n");
  printf(" /_______  / \\___  >|___|  /|__|_|  / \\___  >|__|_ \\ \\___  >|__|    \\___  >/_____ \\(____  /\\____ | (____  /\n");
  printf("         \\/      \\/      \\/       \\/      \\/      \\/     \\/             \\/       \\/     \\/      \\/      \\/ \n");

/* 
  _________        .__                       __                                               .___        
 /   _____/  ____  |  |__    _____    ____  |  | __  ____ _______   ____  _____________     __| _/_____   
 \_____  \ _/ ___\ |  |  \  /     \ _/ __ \ |  |/ /_/ __ \\_  __ \_/ __ \ \___   /\__  \   / __ | \__  \  
 /        \\  \___ |   Y  \|  Y Y  \\  ___/ |    < \  ___/ |  | \/\  ___/  /    /  / __ \_/ /_/ |  / __ \_
/_______  / \___  >|___|  /|__|_|  / \___  >|__|_ \ \___  >|__|    \___  >/_____ \(____  /\____ | (____  /
        \/      \/      \/       \/      \/      \/     \/             \/       \/     \/      \/      \/ 
*/
printf("This build (2023-Jul-10) features Quicksort-Magnetica, buffered dump of sorted data;\nbugfix: forgot to mask the dummy threads; forgotten renaming of old function; a branch debranchified.\nThis tool is 100%% FREE and open-source, for improvements: sanmayce@sanmayce.com, enfun!\n");
#ifdef _N_HIGH_PRIORITY_GCC
setpriority(PRIO_PROCESS, 0, -20);

// setpriority(3) - Linux man page
// #include <sys/resource.h>
// int getpriority(int which, id_t who);
// int setpriority(int which, id_t who, int value); 
// The getpriority() function shall obtain the nice value of a process, process group, or user. The setpriority() function shall set the nice value of a process, process group, or user to value+ {NZERO}.
// Target processes are specified by the values of the which and who arguments. The which argument may be one of the following values: PRIO_PROCESS, PRIO_PGRP, or PRIO_USER, indicating that the who argument is to be interpreted as a process ID, a process group ID, or an effective user ID, respectively. A 0 value for the who argument specifies the current process, process group, or user.
//int which = PRIO_PROCESS;
//id_t pid;
//int ret;
//pid = getpid();
//ret = getpriority(which, pid);

printf("Current priority is %d.\n",getpriority(PRIO_PROCESS, 0));
#endif

#ifdef _N_HIGH_PRIORITY
   if(!SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS))
   {
//      _tprintf(TEXT("Already REALTIME_PRIORITY.\n"));
//      goto Cleanup;
   } 
   if(!SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS))
   {
//      _tprintf(TEXT("Already REALTIME_PRIORITY.\n"));
//      goto Cleanup;
   } 
   // Display priority class

   dwPriClass = GetPriorityClass(GetCurrentProcess());

   //_tprintf(TEXT("Current priority class is 0x%x\n"), dwPriClass);

//if (argc == 2) {} else // 2020-Jan-13
   if (dwPriClass==0x00000080) printf("Current priority class is HIGH_PRIORITY_CLASS.\n");
//if (argc == 2) {} else // 2020-Jan-13
   if (dwPriClass==0x00000100) printf("Current priority class is REALTIME_PRIORITY_CLASS.\n");
#endif

#ifdef _N_HIGH_PRIORITY
// https://habrahabr.ru/post/113682/
// Andrew Aksyonoff [

//SetProcessAffinityMask(GetCurrentProcess(), 1); // 2020-Dec-09, causes problems in real-time priority with newer Windows 10

    //volatile int zomg = 1;
    //for ( int i=1; i<1000000000; i++ )
    //  zomg *= i;
// Andrew Aksyonoff ]
#endif

/*
    printf("Unsorted Array:\n");
    printArray(data, n);
  
    QuickSortHoare(data, 0, n - 1);
  
    printf("Sorted array in ascending order: \n");
    printArray(data, n);
    exit(0);
*/

//srand(time(0));
//while (1){
//int64_t RandIndex;
    //RandIndex = rand()%(10 - 0) + 0; //0..9
    //RandIndex = rand()%(10 - 2) + 2; //2..9
    //RandIndex = rand()%(11 - 2) + 2; //2..10
    //RandIndex = rand()%(11 - 10) + 10; //10
    //RandIndex = rand()%(2 - 0); // 0..1
    //printf( "%lu\n", RandIndex );
//}

// Too lazy to get the size... 24823016

goto SkipGene;
    printf("Generating the dataset ... ");  
    while(e/=2){
    N*=2;U=U*1LL*(m+1)/2%m;
    for(s=N;s/=2;)gg(136,0);
    for(p=t;p<t+N;p++)*p=*p*1LL**p%m*U%m;
    for(s=1;s<N;s*=2)gg(839354248,1);
    for(a=0,p=t;p<t+N;)a+=*p<<(e&1),*p++=a%10,a/=10;
    }
    printf("Done.\n");  
    while(!*--p);
    //for(t[0]--;p>=t;)putchar(48+*p--);

//if( ( fp_outLINE = fopen( "Fabrice_at-each-position.txt", "wb" ) ) == NULL )
//{ printf( "Can't open 'Fabrice_at-each-position.txt' file.\n" ); return( 1 ); }
// 178,708,944/8=22,338,618
elements = 22338618LL;
printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8 );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if( ( fp_outLINE2 = fopen( "22338618_QWORDS.bin", "wb" ) ) == NULL )
{ printf( "Can't open '22338618_QWORDS.bin' file.\n" ); return( 1 ); }
if( ( fp_outLINE3 = fopen( "22338618_QWORDS.bin.sorted", "wb" ) ) == NULL )
{ printf( "Can't open '22338618_QWORDS.bin.sorted' file.\n" ); return( 1 ); }
counter=0;
    for(t[0]--;p>=t;) {
        digit[0]=(48+*p--);
        //fprintf( fp_outLINE, "%c", (48+*p--));
        fwrite( &digit[0], 8, 1, fp_outLINE2 );
        xgamsCACHE[counter]=digit[0];
        counter++;
    }
fflush(fp_outLINE2);

SkipGene:

if (argc==1) {
printf( "Usage1: Schmekeriada filename\n" );
printf( "Usage2: Schmekeriada sortertag corpustag\n" );
printf( "Usage3: Schmekeriada filename startingEXPonent endingEXPonent\n" );
printf( "Example1: Schmekeriada README.TXT - sorts README.TXT to 'Schmekeriada.txt'\n" );
printf( "Example2: Schmekeriada Akkoda manyC - sorts 'linux-5.15.25.tar' with Akkoda\n" );
printf( "Example3: Schmekeriada enwik9 0 10 - reports UBBs i.e. Unique-Building-Blocks for (powers of 2 only) orders 2^0 to 2^10\n" );
exit (0);
}

if (argc==2) { // Line sorter...
if( ( fp_in = fopen( argv[1], "rb" ) ) == NULL )
{ printf( "Schmekeriada: Can't open file %s \n", argv[1] ); return( 1 ); }

#if defined(_WIN32_ENVIRONMENT_)
   // 64bit:
_lseeki64( fileno(fp_in), 0L, SEEK_END );
size_in64 = _telli64( fileno(fp_in) );
_lseeki64( fileno(fp_in), 0L, SEEK_SET );
#else
   // 64bit:
fseeko( fp_in, 0L, SEEK_END );
size_in64 = ftello( fp_in );
fseeko( fp_in, 0L, SEEK_SET );
#endif /* defined(_WIN32_ENVIRONMENT_)  */

printf( "Size of input file: %s\n",  _ui64toaKAZEcomma(size_in64, llTOaDigits, 10));
        time3=time(NULL); //fix of bigtime
/*
        for( i = 0; i < size_in64; i++ )
	{
                // ~~~~~~~~~~~~ Buffering fread [
                if (workKoffset == -1) {
Melnitchka = Melnitchka & 3; // 0 1 2 3: 00 01 10 11
printf( "%s Lines Found: %s; \r", Auberge[Melnitchka++], _ui64toaKAZEzerocomma(Over4billionLines, llTOaDigits, 10)+(26-15));
                        if (i + BufferSize < size_in64) {
                                fread( &workK[0], 1, BufferSize, fp_in );
                                workKoffset = 0;
                                workbyte = workK[workKoffset];
                        } else {
                        fread( &workbyte, 1, 1, fp_in );
			}
                } else {
                        workKoffset++;
                        workbyte = workK[workKoffset];
                        if (workKoffset == BufferSize - 1) workKoffset = -1;
                }
                // ~~~~~~~~~~~~ Buffering fread ]
		Current10Line++;
		if (workbyte == 10) {
			Over4billionLines++;
			Current10Line--;
			if (Current10Line > Longest10Line) {Longest10Line=Current10Line;}
			Current10Line=0;
		}
        } // i 'for'
Melnitchka = Melnitchka & 3; // 0 1 2 3: 00 01 10 11
printf( "%s Lines Found: %s; \n", Auberge[Melnitchka++], _ui64toaKAZEzerocomma(Over4billionLines, llTOaDigits, 10)+(26-15));
if (Over4billionLines==0) { puts( "Schmekeriada: Not a single [CR]LF line found!\n" ); return( 1 ); }
//printf( "Lines encountered: %s\n", _ui64toaKAZEcomma(Over4billionLines, llTOaDigits, 10));
printf( "Longest line (including CR if present): %d\n", Longest10Line);
*/

elements = size_in64;

printf( "Allocating FILE-Buffer %lluMB ...\n", (unsigned long long)(elements>>20) );
AvoidSEEKS = (char *)malloc( elements +2); // +2 in order to insert LF or CRLF i.e. ASCII 10 or 1310 at the end if the last byte is not LF
if( AvoidSEEKS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

#if defined(_WIN32_ENVIRONMENT_)
   // 64bit:
_lseeki64( fileno(fp_in), 0L, SEEK_SET );
#else
   // 64bit:
fseeko( fp_in, 0L, SEEK_SET );
#endif /* defined(_WIN32_ENVIRONMENT_)  */

printf( "Counting lines ... " );
fread( AvoidSEEKS, elements, 1, fp_in );

/*
//https://stackoverflow.com/questions/54541129/how-to-count-character-occurrences-using-simd
size_t memcount_sse2(const void *s, int c, size_t n) {    
    __m128i cv = _mm_set1_epi8(c), sum = _mm_setzero_si128(), acr0,acr1,acr2,acr3;
    const char *p,*pe;						    											   
	for(p = s; p != (char *)s+(n- (n % (252*16)));) { 
	  for(acr0 = acr1 = acr2 = acr3 = _mm_setzero_si128(),pe = p+252*16; p != pe; p += 64) { 
		acr0 = _mm_add_epi8(acr0, _mm_cmpeq_epi8(cv, _mm_loadu_si128((const __m128i *)p))); 
		acr1 = _mm_add_epi8(acr1, _mm_cmpeq_epi8(cv, _mm_loadu_si128((const __m128i *)(p+16)))); 
		acr2 = _mm_add_epi8(acr2, _mm_cmpeq_epi8(cv, _mm_loadu_si128((const __m128i *)(p+32)))); 
		acr3 = _mm_add_epi8(acr3, _mm_cmpeq_epi8(cv, _mm_loadu_si128((const __m128i *)(p+48)))); __builtin_prefetch(p+1024);
	  }
      sum = _mm_add_epi64(sum, _mm_sad_epu8(_mm_sub_epi8(_mm_setzero_si128(), acr0), _mm_setzero_si128()));
      sum = _mm_add_epi64(sum, _mm_sad_epu8(_mm_sub_epi8(_mm_setzero_si128(), acr1), _mm_setzero_si128()));
      sum = _mm_add_epi64(sum, _mm_sad_epu8(_mm_sub_epi8(_mm_setzero_si128(), acr2), _mm_setzero_si128()));
      sum = _mm_add_epi64(sum, _mm_sad_epu8(_mm_sub_epi8(_mm_setzero_si128(), acr3), _mm_setzero_si128()));
    }
    size_t count = _mm_extract_epi64(sum, 0) + _mm_extract_epi64(sum, 1);   
    while(p != (char *)s + n) count += *p++ == c;
    return count;
}

//https://stackoverflow.com/questions/20927710/quickly-count-number-of-zero-valued-bytes-in-an-array?noredirect=1
nzeros_total = 0;
#pragma omp parallel for reduction(+:nzeros_total)
    for (i=0;i<NDATA;i++)
    {
        //if (v[i]==0) nzeros_total++;
	nzeros_total += v[i] == 0;
    }
*/

        //time1=time(NULL); //fix of bigtime
        //while (time1==time(NULL));
        time1=time(NULL); //fix of bigtime
        clocks1 = clock();

	NumberOfLFs=0;
	NumberOfCRs=0;
        CurrentLine=0;
        LongestLine=0;

        NumberOfLFs = memcount_sse2(&AvoidSEEKS[0], 10, size_in64);
        NumberOfCRs = memcount_sse2(&AvoidSEEKS[0], 13, size_in64);
        //NumberOfLFs = memcount_avx2(&AvoidSEEKS[0], 10, size_in64);
        //NumberOfCRs = memcount_avx2(&AvoidSEEKS[0], 13, size_in64);
        //#pragma omp parallel for reduction(+:NumberOfLFs)
        //for(j=0;j<size_in64;j++) NumberOfLFs += (AvoidSEEKS[j] == 10);
        //#pragma omp parallel for reduction(+:NumberOfCRs)
        //for(j=0;j<size_in64;j++) NumberOfCRs += (AvoidSEEKS[j] == 13);
/*
        for(j=0;j<size_in64;j++) {
                CurrentLine++;
		if (AvoidSEEKS[j]==13) NumberOfCRs++;
		if (AvoidSEEKS[j]==10) {
                        NumberOfLFs++; CurrentLine--;
                        if (LongestLine<CurrentLine) LongestLine=CurrentLine;
                        CurrentLine=0;
                }
        }
*/
        //printf("Done in %d seconds.\n", (int)(time(NULL) - time1));
        clocks2 = clock();
        printf("Done in %s clocks, %0.2f seconds.\n", _ui64toaKAZEcomma(clocks2 - clocks1, llTOaDigits, 10), (double)(clocks2 - clocks1) /CLOCKS_PER_SEC);

printf( "Number of LF-ending lines: %s\n",  _ui64toaKAZEcomma(NumberOfLFs, llTOaDigits, 10));

PlusOneOrTwo=0+1;//bug (crashes the malloc below) fixed
if (AvoidSEEKS[size_in64-1]!=10) {
        if (NumberOfLFs == NumberOfCRs) {
                PlusOneOrTwo=2;
                AvoidSEEKS[size_in64]=13;
                AvoidSEEKS[size_in64+1]=10;
                NumberOfCRs++;
                NumberOfLFs++;
                printf( "Postfixing the last \"line\" with a CRLF.\n");
        } else {
                PlusOneOrTwo=1;
                AvoidSEEKS[size_in64]=10;
                NumberOfLFs++;
                printf( "Postfixing the last \"line\" with a LF.\n");
        }
}
//if (NumberOfLFs == NumberOfCRs)
//printf( "Number of CRLF-ending lines: %s\n",  _ui64toaKAZEcomma(NumberOfLFs, llTOaDigits, 10));
//else
//printf( "Number of LF-ending lines: %s\n",  _ui64toaKAZEcomma(NumberOfLFs, llTOaDigits, 10));

printf( "Allocating Master-Buffer (Offsets+Lengths) NumberOfLFs*8*2 = %lluMB ... ", (unsigned long long)((NumberOfLFs)*8*2>>20) );
xgamsCACHE = (uint64_t *)malloc( (NumberOfLFs)*8*2 ); // Instead of allocating second buffer for 'xgamsCACHElen', use it at the end. Ideally, should be grouped as OFF-LEN pairs - for speed - to-do.
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if ( (((size_t)xgamsCACHE) % 64) == 0 ) printf("Aligned to 64 bytes boundary.\n");
else if ( (((size_t)xgamsCACHE) % 32) == 0 ) printf("Aligned to 32 bytes boundary.\n");
else if ( (((size_t)xgamsCACHE) % 16) == 0 ) printf("Aligned to 16 bytes boundary.\n");
else printf("Aligned NOT to 64/32/16 bytes boundary.\n");
//xgamsCACHE = xgamsCACHEUNALIGN + 64 - (((size_t)xgamsCACHEUNALIGN) % 64); //offset=64-int((long)data&63);

//printf( "Allocating Master-Buffer #2 %lluMB ...\n", (unsigned long long)((NumberOfLFs+PlusOneOrTwo)*8>>20) );
//xgamsCACHElen = (uint64_t *)malloc( (NumberOfLFs+PlusOneOrTwo)*8 );
//if( xgamsCACHElen == NULL )
//{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

        //time1=time(NULL); //fix of bigtime
        //while (time1==time(NULL));
        time1=time(NULL); //fix of bigtime
//clock_t clocks1, clocks2;
//clock_t clocks3, clocks4;

printf( "Assigning pairs (of pointers and lengths) to lines ... " ); // When dumping, should add LF after every *(xgamsCACHElen+j) bytes
OrderFixedOrDynamic=0; // Assuming (0) lines are with different lengths i.e. lines are not records of fixed length (non 0)
// In order to use the much faster fixed-length, use smart setting of OrderFixedOrDynamic, to-do...
        clocks1 = clock();
	j=0;
	i=0;
        *(xgamsCACHE+j) = (uint64_t)(AvoidSEEKS+i);
        for(i=0;i<size_in64+PlusOneOrTwo;i++) {
                CurrentLine++;
		if (AvoidSEEKS[i]==10) {
                        CurrentLine--;
                        //*(xgamsCACHElen+j) = CurrentLine;
		        *((xgamsCACHE+NumberOfLFs) +j) = CurrentLine;
                        if (LongestLine<CurrentLine) LongestLine=CurrentLine;
                        if (ShortestLine>CurrentLine) ShortestLine=CurrentLine;
                        CurrentLine=0;
			if (j+1<NumberOfLFs) {
				j++;
			        *(xgamsCACHE+j) = (uint64_t)(AvoidSEEKS+i+1);
			}
		}
        }
if ( LongestLine==ShortestLine ) OrderFixedOrDynamic=ShortestLine;

// Strange, this "faster" variant is 5x (10s vs 2s) slower than above, for 'github.com_llvm-project-14.0.6.src.tar'
/*
	j=0;
	i=0;
        *(xgamsCACHE+j) = (uint64_t)(AvoidSEEKS+i);
        for(i=0;i<size_in64+PlusOneOrTwo;i++) {
                ForLF = strchr((AvoidSEEKS+i),10);
                if ( ForLF != NULL ) {
			if (j+1<NumberOfLFs) {
				j++;
        		        i = i+  (uint64_t)( ForLF - (AvoidSEEKS+i) ); //if LF is back-to-back with LF then 0 but i++ in the 'for' advances
			        *(xgamsCACHE+j) = (uint64_t)(ForLF+1);
			}
		}
        }
*/
        //printf("Done in %d seconds.\n", (int)(time(NULL) - time1));
        clocks2 = clock();
        printf("Done in %s clocks, %0.2f seconds.\n", _ui64toaKAZEcomma(clocks2 - clocks1, llTOaDigits, 10), (double)(clocks2 - clocks1) /CLOCKS_PER_SEC);

printf( "ShortestLine = %s\n", _ui64toaKAZEcomma(ShortestLine, llTOaDigits, 10) );
printf( "LongestLine = %s\n", _ui64toaKAZEcomma(LongestLine, llTOaDigits, 10) );
/*
        // 'a' as pivot for 000..255 partitioning, mainloop [
	i=0;
	j=NumberOfLFs-1;
			do {
				while ( (*(signed char *)*(xgamsCACHE+i))<'a' && i<j ) i++;
				while ( (*(signed char *)*(xgamsCACHE+j))>='a' && i<j ) j--;
				AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+i), (uint64_t*)(xgamsCACHE+j));
			} while (i<j);
		if ( (*(signed char *)*(xgamsCACHE+i))>='a' && (i>0) ) i--;
		if ( (*(signed char *)*(xgamsCACHE+j))<'a' && (j<NumberOfLFs-1) ) j++;
        // 'a' as pivot for 000..255 partitioning, mainloop ]

        // '5' as pivot for 000..('a'-1) partitioning, mainloop [
	k=0;
	l=i;
			do {
				while ( (*(signed char *)*(xgamsCACHE+k))<'5' && k<l ) k++;
				while ( (*(signed char *)*(xgamsCACHE+l))>='5' && k<l ) l--;
				AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+k), (uint64_t*)(xgamsCACHE+l));
			} while (k<l);
		if ( (*(signed char *)*(xgamsCACHE+k))>='5' && (k>0) ) k--;
		if ( (*(signed char *)*(xgamsCACHE+l))<'5' && (l<i) ) l++;
        // '5' as pivot for 000..('a'-1) partitioning, mainloop ]

        // 'L' as pivot for 000..('a'-1) partitioning, mainloop [
	q=l;
	w=i;
			do {
				while ( (*(signed char *)*(xgamsCACHE+q))<'L' && q<w ) q++;
				while ( (*(signed char *)*(xgamsCACHE+w))>='L' && q<w ) w--;
				AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+q), (uint64_t*)(xgamsCACHE+w));
			} while (q<w);
		if ( (*(signed char *)*(xgamsCACHE+q))>='L' && (q>l) ) q--;
		if ( (*(signed char *)*(xgamsCACHE+w))<'L' && (w<i) ) w++;
        // 'L' as pivot for 000..('a'-1) partitioning, mainloop ]

        // 'l' as pivot for 'a'..255 partitioning, mainloop [
	m=j;
	r=NumberOfLFs-1;
			do {
				while ( (*(signed char *)*(xgamsCACHE+m))<'l' && m<r ) m++;
				while ( (*(signed char *)*(xgamsCACHE+r))>='l' && m<r ) r--;
				AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+m), (uint64_t*)(xgamsCACHE+r));
			} while (m<r);
		if ( (*(signed char *)*(xgamsCACHE+m))>='l' && (m>j) ) m--;
		if ( (*(signed char *)*(xgamsCACHE+r))<'l' && (r<NumberOfLFs-1) ) r++;
        // 'l' as pivot for 'a'..255 partitioning, mainloop ]
*/

        //time1=time(NULL); //fix of bigtime
        //while (time1==time(NULL));
        time1=time(NULL); //fix of bigtime
	if (OrderFixedOrDynamic==0) {
        printf( "Sorting pointers to lines with 'Strongfool' a.k.a. 'Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO' ...\n" );
        } else {
        printf( "Sorting pointers to lines with 'Strongfool' a.k.a. 'Quicksort_Magnetica_v19_BalxchonkaForte_indirect' ...\n" );
        }
		// For Single-thread, uncomment next two lines:
#ifdef SingleT
	if (OrderFixedOrDynamic==0) {
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[0], &xgamsCACHE[NumberOfLFs-1], OrderFixedOrDynamic, NumberOfLFs); // (uint64_t)(&xgamsCACHE[NumberOfLFs-1]-&xgamsCACHE[0]+1) == NumberOfLFs
	} else {
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[0], &xgamsCACHE[NumberOfLFs-1], OrderFixedOrDynamic, NumberOfLFs); // (uint64_t)(&xgamsCACHE[NumberOfLFs-1]-&xgamsCACHE[0]+1) == NumberOfLFs
	}
        goto skipskip; // Single or Multi
#endif
		a=0; k=0;
		l=0; g=0;
		h=0; q=0;
		r=0; z=0;
// Step #1 of 3 [[[
	i=0; 
	j=NumberOfLFs-1; 
        Left=i;
        Right=j;
if ((1LL<<19) >= Right-Left) {
		a=Left;
		k=Right;
		// [a-kl-gh-qr-z] where gh=ij
} else {

	if (OrderFixedOrDynamic==0) {
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (1*(Right-Left)>>3) -27], &xgamsCACHE[Left + (1*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (2*(Right-Left)>>3) -27], &xgamsCACHE[Left + (2*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (3*(Right-Left)>>3) -27], &xgamsCACHE[Left + (3*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
      //Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(Left + (4*(Right-Left)>>3) -27, Left + (4*(Right-Left)>>3) +27, OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (5*(Right-Left)>>3) -27], &xgamsCACHE[Left + (5*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (6*(Right-Left)>>3) -27], &xgamsCACHE[Left + (6*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (7*(Right-Left)>>3) -27], &xgamsCACHE[Left + (7*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);

        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (1*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-3], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (2*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (3*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-1], NumberOfLFs);
      //M18_swapUnconditional (Left + (4*(Right-Left)>>3), Left + (4*(Right-Left)>>3)-0);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (5*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+1], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (6*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (7*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+3], NumberOfLFs);

        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (4*(Right-Left)>>3) -3], &xgamsCACHE[Left + (4*(Right-Left)>>3) +3], OrderFixedOrDynamic, NumberOfLFs);
	} else {
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (1*(Right-Left)>>3) -27], &xgamsCACHE[Left + (1*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (2*(Right-Left)>>3) -27], &xgamsCACHE[Left + (2*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (3*(Right-Left)>>3) -27], &xgamsCACHE[Left + (3*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
      //Quicksort_Magnetica_v18_BalxchonkaForte_indirect(Left + (4*(Right-Left)>>3) -27, Left + (4*(Right-Left)>>3) +27, OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (5*(Right-Left)>>3) -27], &xgamsCACHE[Left + (5*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (6*(Right-Left)>>3) -27], &xgamsCACHE[Left + (6*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (7*(Right-Left)>>3) -27], &xgamsCACHE[Left + (7*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);

        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (1*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-3], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (2*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (3*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-1], NumberOfLFs);
      //M18_swapUnconditional (Left + (4*(Right-Left)>>3), Left + (4*(Right-Left)>>3)-0);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (5*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+1], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (6*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (7*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+3], NumberOfLFs);

        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (4*(Right-Left)>>3) -3], &xgamsCACHE[Left + (4*(Right-Left)>>3) +3], OrderFixedOrDynamic, NumberOfLFs);
	}
// Splitting [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
/*
	do { // BUGGY! The "pivot" could be changed since it is not in the variable! Consider the splitting from Glupendxr itself:
		while ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+i), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) < 0) && i<j ) i++;
		while ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+j), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) >= 0) && i<j ) j--;
		AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+i), (uint64_t*)(xgamsCACHE+j));
	} while (i<j);
        if ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+i), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) >= 0) && (i>Left) ) i--;
        if ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+j), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) < 0) && (j<Right) ) j++;
*/
/*
                for(;(0 < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
                                        Jndx = Right;
                                        Pivot = *(Left + (2*(Right-Left)>>2)); //Pivot = *(Left + ((Right-Left)>>1));
                                        PL = Left;                                            
                                        //for (;*PL < Pivot; PL++) {                            
                                        for (;memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)Pivot, Order) < 0; PL++) {
                                        }                                                     
                                        PR = PL;                                              
                                        M18_swapUnconditional (Left + ((Right-Left)>>1), PL); 
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP [
                                        for (;PR < Jndx;) {
                                                PR = PR + 1;
                                                //if (Pivot > *PR) { // *PL == Pivot
                                                //if (*PL > *PR) { // *PL == Pivot
                                                DontRelyOnCompiler = memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)*PR, Order);
                                                if (DontRelyOnCompiler > 0) {
                                                        M18_swapUnconditional (PL, PR);
                                                        // *PL=*PR; *PR=Pivot;
                                                        PL = PL + 1;
                                                //} else if (Pivot < *PR) {
                                                } else if (DontRelyOnCompiler < 0) {
                                                        //for (;Pivot < *Jndx;) {
                                                    for (;memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)*Jndx, Order) < 0;) {
                                                                Jndx = Jndx - 1;
                                                        }
                                                        M18_swapUnconditional (PR, Jndx);
                                                        Jndx = Jndx - 1;                 
                                                        PR = PR - 1;                     
                                                }
                                        }
                                        M18_SwapConditional_ifXbY_BUGGY((uint64_t)Jndx, (uint64_t)PR, PR+1, Jndx+1);
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP ]
                                        StackPtr = StackPtr + 2;
                                        Stack[StackPtr - 1] = PR + 1;
                                        Stack[StackPtr] = Right;
                                        Right = PL - 1;
                } //for(;(0 < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
*/
	//AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+Left), (uint64_t*)(xgamsCACHE+(Left + (4*(Right-Left)>>3)-0)));
	M18_swapUnconditionalPAIR ((uint64_t*)(xgamsCACHE+Left), (uint64_t*)(xgamsCACHE+(Left + (4*(Right-Left)>>3)-0)), NumberOfLFs);
	i++;
	for (;;) {
		while ( (memcmpKAZE_QWORD_reversePTR((uint64_t*)(xgamsCACHE+i), (uint64_t*)&xgamsCACHE[Left], 0, NumberOfLFs) < 0) && i<j ) i++;
		while ( (memcmpKAZE_QWORD_reversePTR((uint64_t*)(xgamsCACHE+j), (uint64_t*)&xgamsCACHE[Left], 0, NumberOfLFs) >= 0) && i<j ) j--;
		//if (i<j) AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+i), (uint64_t*)(xgamsCACHE+j)); else break;
		if (i<j) M18_swapUnconditionalPAIR ((uint64_t*)(xgamsCACHE+i), (uint64_t*)(xgamsCACHE+j), NumberOfLFs); else break;
	}
	//AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+i-1), (uint64_t*)(xgamsCACHE+Left));
	M18_swapUnconditionalPAIR ((uint64_t*)(xgamsCACHE+i-1), (uint64_t*)(xgamsCACHE+Left), NumberOfLFs); // Caramba, why have I written like that?!
		if ( (i != j) ) {printf("Fatal error: i != j\n");exit(17);}
        //if ( (i>Left) && (memcmpKAZE_QWORD_reversePTR((uint64_t*)(xgamsCACHE+i-1), (uint64_t*)(xgamsCACHE+i), 0, NumberOfLFs) <= 0) ) i--;
        //if ( (j<Right) && (memcmpKAZE_QWORD_reversePTR((uint64_t*)(xgamsCACHE+j+1), (uint64_t*)(xgamsCACHE+j), 0, NumberOfLFs) >= 0) ) j++;
// Splitting ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
	g=i; 
	h=j; 

	//printf("Pools [a-kl-gh-qr-z] = %llu-%llu %llu-%llu %llu-%llu %llu-%llu\n", (unsigned long long)(uint64_t)(a), (unsigned long long)(uint64_t)(k), (unsigned long long)(uint64_t)(l), (unsigned long long)(uint64_t)(g), (unsigned long long)(uint64_t)(h), (unsigned long long)(uint64_t)(q), (unsigned long long)(uint64_t)(r), (unsigned long long)(uint64_t)(z));

		//Bi-threaded: [
		//a=a; k=g;
		//l=h; g=NumberOfLFs-1;
		//h=0; 
		//goto jasta;
		//Bi-threaded: ]

#ifdef Commence_OpenMP
#pragma omp parallel shared(xgamsCACHE,a,k,l,g,h,q,r,z,NumberOfLFs,OrderFixedOrDynamic) private(i,j,Right,Left)
#endif
{
#ifdef Commence_OpenMP
    #pragma omp sections
#endif
    {
#ifdef Commence_OpenMP
        #pragma omp section
#endif
	{
// Step #2 of 3 [[[
	i=a; 
	j=g; 
        Left=i;
        Right=j;
if ((1LL<<19) >= Right-Left) {
		a=Left;
		k=Right;
		l=0; g=0; // CARAMBA, forgot to nullify the next pool - BUGFIX (2023-Jul-10)
		// [a-kl-gh-qr-z] where gh=ij
} else {
	if (OrderFixedOrDynamic==0) {
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (1*(Right-Left)>>3) -27], &xgamsCACHE[Left + (1*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (2*(Right-Left)>>3) -27], &xgamsCACHE[Left + (2*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (3*(Right-Left)>>3) -27], &xgamsCACHE[Left + (3*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        //Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(Left + (4*(Right-Left)>>3) -27, Left + (4*(Right-Left)>>3) +27, OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (5*(Right-Left)>>3) -27], &xgamsCACHE[Left + (5*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (6*(Right-Left)>>3) -27], &xgamsCACHE[Left + (6*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (7*(Right-Left)>>3) -27], &xgamsCACHE[Left + (7*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);

        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (1*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-3], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (2*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (3*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-1], NumberOfLFs);
        //M18_swapUnconditional (Left + (4*(Right-Left)>>3), Left + (4*(Right-Left)>>3)-0);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (5*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+1], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (6*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (7*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+3], NumberOfLFs);

        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (4*(Right-Left)>>3) -3], &xgamsCACHE[Left + (4*(Right-Left)>>3) +3], OrderFixedOrDynamic, NumberOfLFs);
	} else {
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (1*(Right-Left)>>3) -27], &xgamsCACHE[Left + (1*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (2*(Right-Left)>>3) -27], &xgamsCACHE[Left + (2*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (3*(Right-Left)>>3) -27], &xgamsCACHE[Left + (3*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        //Quicksort_Magnetica_v18_BalxchonkaForte_indirect(Left + (4*(Right-Left)>>3) -27, Left + (4*(Right-Left)>>3) +27, OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (5*(Right-Left)>>3) -27], &xgamsCACHE[Left + (5*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (6*(Right-Left)>>3) -27], &xgamsCACHE[Left + (6*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (7*(Right-Left)>>3) -27], &xgamsCACHE[Left + (7*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);

        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (1*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-3], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (2*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (3*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-1], NumberOfLFs);
        //M18_swapUnconditional (Left + (4*(Right-Left)>>3), Left + (4*(Right-Left)>>3)-0);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (5*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+1], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (6*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (7*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+3], NumberOfLFs);

        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (4*(Right-Left)>>3) -3], &xgamsCACHE[Left + (4*(Right-Left)>>3) +3], OrderFixedOrDynamic, NumberOfLFs);
	}
// Splitting [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
/*
	do { // BUGGY! The "pivot" could be changed since it is not in the variable! Consider the splitting from Glupendxr itself:
		while ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+i), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) < 0) && i<j ) i++;
		while ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+j), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) >= 0) && i<j ) j--;
		AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+i), (uint64_t*)(xgamsCACHE+j));
	} while (i<j);
        if ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+i), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) >= 0) && (i>Left) ) i--;
        if ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+j), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) < 0) && (j<Right) ) j++;
*/
	//AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+Left), (uint64_t*)(xgamsCACHE+(Left + (4*(Right-Left)>>3)-0)));
	M18_swapUnconditionalPAIR ((uint64_t*)(xgamsCACHE+Left), (uint64_t*)(xgamsCACHE+(Left + (4*(Right-Left)>>3)-0)), NumberOfLFs);
	i++;
	for (;;) {
		while ( (memcmpKAZE_QWORD_reversePTR((uint64_t*)(xgamsCACHE+i), (uint64_t*)&xgamsCACHE[Left], 0, NumberOfLFs) < 0) && i<j ) i++;
		while ( (memcmpKAZE_QWORD_reversePTR((uint64_t*)(xgamsCACHE+j), (uint64_t*)&xgamsCACHE[Left], 0, NumberOfLFs) >= 0) && i<j ) j--;
		//if (i<j) AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+i), (uint64_t*)(xgamsCACHE+j)); else break;
		if (i<j) M18_swapUnconditionalPAIR ((uint64_t*)(xgamsCACHE+i), (uint64_t*)(xgamsCACHE+j), NumberOfLFs); else break;
	}
	//AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+i-1), (uint64_t*)(xgamsCACHE+Left));
	M18_swapUnconditionalPAIR ((uint64_t*)(xgamsCACHE+i-1), (uint64_t*)(xgamsCACHE+Left), NumberOfLFs); // Caramba, why have I written like that?!
// Splitting ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
	k=i; 
	l=j; 
		a=Left; k=i;
		// [a-kl-gh-qr-z] where gh=ij
		l=j; g=Right;
} //if ((1LL<<9) >= Right-Left) {
// Step #2 of 3 ]]]
	} //#pragma omp section
#ifdef Commence_OpenMP
        #pragma omp section
#endif
	{
// Step #3 of 3 [[[
	i=h; 
	j=NumberOfLFs-1; 
        Left=i;
        Right=j;
if ((1LL<<19) >= Right-Left) {
		// [a-kl-gh-qr-z] where gh=ij
		h=Left; q=Right;
		r=0; z=0; // CARAMBA, forgot to nullify the next pool - BUGFIX (2023-Jul-10)
} else {
	if (OrderFixedOrDynamic==0) {
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (1*(Right-Left)>>3) -27], &xgamsCACHE[Left + (1*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (2*(Right-Left)>>3) -27], &xgamsCACHE[Left + (2*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (3*(Right-Left)>>3) -27], &xgamsCACHE[Left + (3*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        //Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(Left + (4*(Right-Left)>>3) -27, Left + (4*(Right-Left)>>3) +27, OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (5*(Right-Left)>>3) -27], &xgamsCACHE[Left + (5*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (6*(Right-Left)>>3) -27], &xgamsCACHE[Left + (6*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (7*(Right-Left)>>3) -27], &xgamsCACHE[Left + (7*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);

        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (1*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-3], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (2*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (3*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-1], NumberOfLFs);
        //M18_swapUnconditional (Left + (4*(Right-Left)>>3), Left + (4*(Right-Left)>>3)-0);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (5*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+1], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (6*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (7*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+3], NumberOfLFs);

        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[Left + (4*(Right-Left)>>3) -3], &xgamsCACHE[Left + (4*(Right-Left)>>3) +3], OrderFixedOrDynamic, NumberOfLFs);
	} else {
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (1*(Right-Left)>>3) -27], &xgamsCACHE[Left + (1*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (2*(Right-Left)>>3) -27], &xgamsCACHE[Left + (2*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (3*(Right-Left)>>3) -27], &xgamsCACHE[Left + (3*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        //Quicksort_Magnetica_v18_BalxchonkaForte_indirect(Left + (4*(Right-Left)>>3) -27, Left + (4*(Right-Left)>>3) +27, OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (5*(Right-Left)>>3) -27], &xgamsCACHE[Left + (5*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (6*(Right-Left)>>3) -27], &xgamsCACHE[Left + (6*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);
        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (7*(Right-Left)>>3) -27], &xgamsCACHE[Left + (7*(Right-Left)>>3) +27], OrderFixedOrDynamic, NumberOfLFs);

        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (1*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-3], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (2*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (3*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)-1], NumberOfLFs);
        //M18_swapUnconditional (Left + (4*(Right-Left)>>3), Left + (4*(Right-Left)>>3)-0);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (5*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+1], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (6*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+2], NumberOfLFs);
        M18_swapUnconditionalPAIR (&xgamsCACHE[Left + (7*(Right-Left)>>3)], &xgamsCACHE[Left + (4*(Right-Left)>>3)+3], NumberOfLFs);

        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[Left + (4*(Right-Left)>>3) -3], &xgamsCACHE[Left + (4*(Right-Left)>>3) +3], OrderFixedOrDynamic, NumberOfLFs);
	}
// Splitting [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
/*
	do { // BUGGY! The "pivot" could be changed since it is not in the variable! Consider the splitting from Glupendxr itself:
		while ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+i), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) < 0) && i<j ) i++;
		while ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+j), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) >= 0) && i<j ) j--;
		AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+i), (uint64_t*)(xgamsCACHE+j));
	} while (i<j);
        if ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+i), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) >= 0) && (i>Left) ) i--;
        if ( (memcmpKAZE_QWORD_reverse((const void *)*(xgamsCACHE+j), (const void *)xgamsCACHE[(Left + (4*(Right-Left)>>3)-0)], 0) < 0) && (j<Right) ) j++;
*/
	//AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+Left), (uint64_t*)(xgamsCACHE+(Left + (4*(Right-Left)>>3)-0)));
	M18_swapUnconditionalPAIR ((uint64_t*)(xgamsCACHE+Left), (uint64_t*)(xgamsCACHE+(Left + (4*(Right-Left)>>3)-0)), NumberOfLFs);
	i++;
	for (;;) {
		while ( (memcmpKAZE_QWORD_reversePTR((uint64_t*)(xgamsCACHE+i), (uint64_t*)&xgamsCACHE[Left], 0, NumberOfLFs) < 0) && i<j ) i++;
		while ( (memcmpKAZE_QWORD_reversePTR((uint64_t*)(xgamsCACHE+j), (uint64_t*)&xgamsCACHE[Left], 0, NumberOfLFs) >= 0) && i<j ) j--;
		//if (i<j) AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+i), (uint64_t*)(xgamsCACHE+j)); else break;
		if (i<j) M18_swapUnconditionalPAIR ((uint64_t*)(xgamsCACHE+i), (uint64_t*)(xgamsCACHE+j), NumberOfLFs); else break;
	}
	//AKKODAH_swapUnconditional ((uint64_t*)(xgamsCACHE+i-1), (uint64_t*)(xgamsCACHE+Left));
	M18_swapUnconditionalPAIR ((uint64_t*)(xgamsCACHE+i-1), (uint64_t*)(xgamsCACHE+Left), NumberOfLFs); // Caramba, why have I written like that?!
// Splitting ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
	q=i; 
	r=j; 
		// [a-kl-gh-qr-z] where gh=ij
		h=Left; q=i;
		r=j; z=Right;
} //if ((1LL<<9) >= Right-Left) {
// Step #3 of 3 ]]]
	} //#pragma omp section
    } //#pragma omp sections
} //#pragma omp parallel shared(xgamsCACHE,a,k,l,g,h,q,r,z,NumberOfLFs) private(i,j,Right,Left)

} //if ((1LL<<9) >= Right-Left) {
// Step #1 of 3 ]]]

jasta:;
	// [a-kl-gh-qr-z] where gh=ij
	printf("Pools [a-kl-gh-qr-z] = %llu-%llu %llu-%llu %llu-%llu %llu-%llu\n", (unsigned long long)(uint64_t)(a), (unsigned long long)(uint64_t)(k), (unsigned long long)(uint64_t)(l), (unsigned long long)(uint64_t)(g), (unsigned long long)(uint64_t)(h), (unsigned long long)(uint64_t)(q), (unsigned long long)(uint64_t)(r), (unsigned long long)(uint64_t)(z));
	printf("Thread #1 of 4 sorting partition size=%llu\n", (unsigned long long)(uint64_t)(k)-(unsigned long long)(uint64_t)(a) +1);
	printf("Thread #2 of 4 sorting partition size=%llu\n", (unsigned long long)(uint64_t)(g)-(unsigned long long)(uint64_t)(l) +1);
	printf("Thread #3 of 4 sorting partition size=%llu\n", (unsigned long long)(uint64_t)(q)-(unsigned long long)(uint64_t)(h) +1);
	printf("Thread #4 of 4 sorting partition size=%llu\n", (unsigned long long)(uint64_t)(z)-(unsigned long long)(uint64_t)(r) +1);

	#ifdef Commence_OpenMP
		#pragma omp parallel sections
	#endif
		{
		#ifdef Commence_OpenMP
			#pragma omp section
		#endif
			{
	if (OrderFixedOrDynamic==0) {
                        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[a], &xgamsCACHE[k], OrderFixedOrDynamic, NumberOfLFs);
	} else {
                        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[a], &xgamsCACHE[k], OrderFixedOrDynamic, NumberOfLFs);
	}
			}
		#ifdef Commence_OpenMP
			#pragma omp section
		#endif
			{
	if (OrderFixedOrDynamic==0) {
                        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[l], &xgamsCACHE[g], OrderFixedOrDynamic, NumberOfLFs);
	} else {
                        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[l], &xgamsCACHE[g], OrderFixedOrDynamic, NumberOfLFs);
	}
			}
		#ifdef Commence_OpenMP
			#pragma omp section
		#endif
			{
	if (OrderFixedOrDynamic==0) {
                        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[h], &xgamsCACHE[q], OrderFixedOrDynamic, NumberOfLFs);
	} else {
                        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[h], &xgamsCACHE[q], OrderFixedOrDynamic, NumberOfLFs);
	}
			}
		#ifdef Commence_OpenMP
			#pragma omp section
		#endif
			{
	if (OrderFixedOrDynamic==0) {
                        Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO(&xgamsCACHE[r], &xgamsCACHE[z], OrderFixedOrDynamic, NumberOfLFs);
	} else {
                        Quicksort_Magnetica_v18_BalxchonkaForte_indirect(&xgamsCACHE[r], &xgamsCACHE[z], OrderFixedOrDynamic, NumberOfLFs);
	}
			}
		}
skipskip:;
        printf("Done (just sorting) in %d seconds.\n", (int)(time(NULL) - time1));

fclose(fp_in);
if( ( fp_in = fopen( "Schmekeriada.txt", "wb" ) ) == NULL )
{ printf( "Schmekeriada: Can't open file %s \n", "Schmekeriada.txt" ); return( 1 ); }
printf( "Writing sorted lines to 'Schmekeriada.txt' ... " );
        //time1=time(NULL); //fix of bigtime
        //while (time1==time(NULL));
        time1=time(NULL); //fix of bigtime
goto BufferedFWRITE;
        for(j=0;j<NumberOfLFs;j++) { // this line-by-line dump is good, but when 219 million lines have to be written then it is bad, have to use buffer of 1GB in order to reduce (to ~15) fwrite invocations.
		if ( fwrite( ((char *)xgamsCACHE[j]), *((xgamsCACHE+NumberOfLFs) +j)+1, 1, fp_in ) == 0 ) {printf("Error: fwrite() failed.\n"); exit(14);}
/*
		i=0;
		Bunacho:
		i++;
		//fwrite( ((char *)xgamsCACHE[j] + (i-1)), 1, 1, fp_in );
		if ( *((char *)xgamsCACHE[j] + (i-1)) != 10 ) goto Bunacho;
		if ( fwrite( ((char *)xgamsCACHE[j]), i, 1, fp_in ) == 0 ) {printf("Error: fwrite() failed.\n"); exit(14);}
*/
		//ForLF = strchr((char *)xgamsCACHE[j],10);
		//if ( ForLF == NULL ) ForLF = (char *)xgamsCACHE[j]; // It is sure there is a LF
		//i= (uint64_t)( ForLF - (char *)xgamsCACHE[j] +1 );
		//fwrite( ((char *)xgamsCACHE[j]), i, 1, fp_in );

//buggy with llvm.tar
/*
                ForLF = strchr((char *)xgamsCACHE[j],10);
                if ( ForLF != NULL ) {
        		fwrite( (char *)xgamsCACHE[j], (uint64_t)( ForLF - (char *)xgamsCACHE[j] +1 ), 1, fp_in );
                }
*/
	}
BufferedFWRITE:
elements = 1024LL*1024LL*1024LL;
printf( "Allocating DUMP-Buffer (for 'fwrite()') %lluMB ...\n", (unsigned long long)(elements>>20) );
AvoidManyFWRITEs = (char *)malloc( elements );
if( AvoidManyFWRITEs == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }
        i=0;
        for(j=0;j<NumberOfLFs;j++) { // this line-by-line dump is good, but when 219 million lines have to be written then it is bad, have to use buffer of 1GB in order to reduce (to ~15x for Japanese Wikipedia) fwrite invocations.
                if (i +*((xgamsCACHE+NumberOfLFs) +j)+1 > elements) { //flush
                        if (i !=0) { // empty?
                		if ( fwrite( AvoidManyFWRITEs, i, 1, fp_in ) == 0 ) {printf("Error: fwrite() failed.\n"); exit(14);}
                                i=0; // means flushed
                        } // Fittable or not fittable in buffer, dump it
              		if ( fwrite( ((char *)xgamsCACHE[j]), *((xgamsCACHE+NumberOfLFs) +j)+1, 1, fp_in ) == 0 ) {printf("Error: fwrite() failed.\n"); exit(14);}
                } else { // add to buffer
                        memcpy ( AvoidManyFWRITEs +i, (char *)xgamsCACHE[j], *((xgamsCACHE+NumberOfLFs) +j)+1 );
                        i=i+*((xgamsCACHE+NumberOfLFs) +j)+1;
                }
	}
                        if (i !=0) { // empty?
                		if ( fwrite( AvoidManyFWRITEs, i, 1, fp_in ) == 0 ) {printf("Error: fwrite() failed.\n"); exit(14);}
                                i=0; // means flushed
                        }

        printf("Done (just writing) in %d seconds.\n", (int)(time(NULL) - time1));
        printf( "Total LPS performance: %s Lines-Per-Second\n", _ui64toaKAZEcomma(NumberOfLFs/(uint64_t)(time(NULL) - time3 +1), llTOaDigits, 10) );
        printf( "Total BPS performance: %s Bytes-Per-Second\n", _ui64toaKAZEcomma(size_in64/(uint64_t)(time(NULL) - time3 +1), llTOaDigits, 10) );

exit (0);
} //if (argc==2) { // Line sorter...

// On i5-7200U 36GB DDR4, 254/63=4.03x faster:
/*
C:\mingw64\z\Quicksort_says_19_BUGZILLA++>sort_vs_Schmekeriada.bat

C:\mingw64\z\Quicksort_says_19_BUGZILLA++>copy www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna nul
        1 file(s) copied.

C:\mingw64\z\Quicksort_says_19_BUGZILLA++>timer64 Schmekeriada_CLANG_14.0.1_rev5bypass.exe www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna
Current priority class is REALTIME_PRIORITY_CLASS.
Size of input file: 3,313,061,631
Allocating FILE-Buffer 3159MB ...
Number of LF-ending lines: 40,902,071
Allocating Master-Buffer 39MB ...
Assigning pointers to lines ...
Sorting pointers to lines with 'Quicksort_Magnetica_v18_Balxchonka_indirect' ...
Done (just sorting) in 43 seconds.
Writing sorted lines to 'Schmekeriada.txt' ...

Kernel  Time =     7.015 =   11%
User    Time =    56.375 =   89%
Process Time =    63.390 =  100%    Virtual  Memory =   3736 MB
Global  Time =    63.307 =  100%    Physical Memory =   3475 MB

C:\mingw64\z\Quicksort_says_19_BUGZILLA++>timer64 sort www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna /O q

Kernel  Time =     2.593 =    1%
User    Time =   182.296 =   71%
Process Time =   184.890 =   72%    Virtual  Memory =     61 MB
Global  Time =   254.777 =  100%    Physical Memory =     63 MB

C:\mingw64\z\Quicksort_says_19_BUGZILLA++>
*/

// Building-Blocks...
if (argc==4) {
if( ( fp_in = fopen( argv[1], "rb" ) ) == NULL )
{ printf( "Blockeroo: Can't open file %s \n", argv[1] ); return( 1 ); }

#if defined(_WIN32_ENVIRONMENT_)
   // 64bit:
_lseeki64( fileno(fp_in), 0L, SEEK_END );
size_in64 = _telli64( fileno(fp_in) );
_lseeki64( fileno(fp_in), 0L, SEEK_SET );
#else
   // 64bit:
fseeko( fp_in, 0L, SEEK_END );
size_in64 = ftello( fp_in );
fseeko( fp_in, 0L, SEEK_SET );
#endif /* defined(_WIN32_ENVIRONMENT_)  */

printf( "Size of input file: %s\n",  _ui64toaKAZEcomma(size_in64, llTOaDigits, 10));

for(i=(1<<atoi(argv[2]));i<=(1<<atoi(argv[3]));i=i<<1) {

#if defined(_WIN32_ENVIRONMENT_)
   // 64bit:
_lseeki64( fileno(fp_in), 0L, SEEK_SET );
#else
   // 64bit:
fseeko( fp_in, 0L, SEEK_SET );
#endif /* defined(_WIN32_ENVIRONMENT_)  */

ditto = 1;
elements = size_in64 -i+1; // BuildingBlocks are size-order+1

//printf( "Allocating FILE-Buffer %lluMB ...\n", ((elements -(-i+1))>>20) );
AvoidSEEKS = (char *)malloc( elements -(-i+1) +1); // +1 in order to insert LF i.e. ASCII 10 at the end if the last byte is not LF
if( AvoidSEEKS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

//printf( "Allocating Master-Buffer %lluMB ...\n", ((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

fread( AvoidSEEKS, elements -(-i+1), 1, fp_in );

        for(j=0;j<=elements-1;j++) {
            *(xgamsCACHE+j) = (uint64_t)(AvoidSEEKS+j);
        }

        time1=time(NULL); //fix of bigtime
        while (time1==time(NULL));
        time1=time(NULL); //fix of bigtime

        Quicksort_Magnetica_v18_Balxchonka_indirect(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1], i);        

        UniqueElements=1;
        Previous = xgamsCACHE[0];
        for(counter=0;counter<elements*ditto-1;counter++) {
                //if (xgamsCACHE[counter]>xgamsCACHE[counter+1]) {printf("NOT OK!\n");exit(13);};
                if (CompareOrder(xgamsCACHE[counter], xgamsCACHE[counter+1], i) > 0) { printf("NOT OK!\n");exit(13);};
                //if (Previous != xgamsCACHE[counter]) {UniqueElements++; Previous = xgamsCACHE[counter];};
                if (CompareOrder(Previous, xgamsCACHE[counter], i) != 0) {UniqueElements++; Previous = xgamsCACHE[counter];};
        }

        //printf("Length_of_Keys = %s; Number_of_Unique_Keys = %s; Done in %d seconds.\n", _ui64toaKAZEzerocomma(i, llTOaDigits, 10)+(26-5), _ui64toaKAZEcomma(UniqueElements, llTOaDigits2, 10), (int)(time(NULL) - time1));
        printf("Length_of_Building-Blocks = %s; Number_of_Unique-Building-Blocks = %s; Done in %d seconds.\n", _ui64toaKAZEzerocomma(i, llTOaDigits, 10)+(26-5), _ui64toaKAZEcomma(UniqueElements, llTOaDigits2, 10), (int)(time(NULL) - time1));

        free(xgamsCACHE);
        free(AvoidSEEKS);
}//for(i=1;i<=256;i++) {

}//if (argc==2) {

if (argc==3) {

    if (strcmp(argv[2],"many")==0) {
ditto = 100;
// "mobythesaurus.txt" is 24823016, we need the lof("mobythesaurus.txt")-8+1 QWORDS
elements = 24823016LL-8+1; // BuildingBlocks are size-order+1

printf( "Allocating FILE-Buffer %lluMB ...\n", (unsigned long long)((elements -(-8+1))>>20) );
AvoidSEEKS = (char *)malloc( elements -(-8+1) );
if( AvoidSEEKS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating AUX-Buffer %lluMB ...\n", (unsigned long long)((elements*8)>>20) );
FabriceBellard_DIGITS = (uint64_t *)malloc( elements*8);
if( FabriceBellard_DIGITS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if( ( fp_outLINE2 = fopen( "mobythesaurus.txt", "rb" ) ) == NULL )
{ printf( "Can't open 'mobythesaurus.txt' file.\n" ); return( 1 ); }
if( ( fp_outLINE3 = fopen( "mobythesaurus.txt.sorted", "wb" ) ) == NULL )
{ printf( "Can't open 'mobythesaurus.txt.sorted' file.\n" ); return( 1 ); }

fread( AvoidSEEKS, elements -(-8+1), 1, fp_outLINE2 );

for(j=0;j<=elements-1;j++) {
    FabriceBellard_DIGITS[j] = *(uint64_t *)(AvoidSEEKS+j);
}
    for(i=1;i<=ditto;i++) {
        for(j=0;j<=elements-1;j++) {
            xgamsCACHE[elements * (i - 1) + j] = FabriceBellard_DIGITS[j];
        }
    }
    //printf("Sorting in single-thread %lld elements...\n", elements*ditto);    

    } //if (strcmp(argv[2],"many")==0) {


    if (strcmp(argv[2],"few")==0) {
ditto = 100;
elements = 22338618LL;
printf( "Allocating AUX-Buffer %lluMB ...\n", (unsigned long long)((elements)>>20) );
FabriceBellard_DIGITS = (uint64_t *)malloc( elements*8);
if( FabriceBellard_DIGITS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if( ( fp_outLINE2 = fopen( "22338618_QWORDS.bin", "rb" ) ) == NULL )
{ printf( "Can't open '22338618_QWORDS.bin' file.\n" ); return( 1 ); }
if( ( fp_outLINE3 = fopen( "22338618_QWORDS.bin.sorted", "wb" ) ) == NULL )
{ printf( "Can't open '22338618_QWORDS.bin.sorted' file.\n" ); return( 1 ); }

fread( FabriceBellard_DIGITS, elements*8, 1, fp_outLINE2 );
    for(i=1;i<=ditto;i++) {
        for(j=0;j<=elements-1;j++) {
            xgamsCACHE[elements * (i - 1) + j] = FabriceBellard_DIGITS[j];
        }
    }
    //printf("Sorting in single-thread %lld elements...\n", elements*ditto);    

    } //if (strcmp(argv[2],"few")==0) {


    if (strcmp(argv[2],"ALL")==0) {
ditto = 1;
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/x86_64/iso/Fedora-Workstation-Live-x86_64-35-1.2.iso
// "Fedora-Workstation-Live-x86_64-35-1.2.iso" is 24823016, we need the lof("mobythesaurus.txt")-8+1 QWORDS
elements = 2009333760LL -8+1; // BuildingBlocks are size-order+1

printf( "Allocating FILE-Buffer %lluMB ...\n", (unsigned long long)((elements -(-8+1))>>20) );
AvoidSEEKS = (char *)malloc( elements -(-8+1) );
if( AvoidSEEKS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating AUX-Buffer %lluMB ...\n", (unsigned long long)((elements*8)>>20) );
FabriceBellard_DIGITS = (uint64_t *)malloc( elements*8);
if( FabriceBellard_DIGITS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if( ( fp_outLINE2 = fopen( "Fedora-Workstation-Live-x86_64-35-1.2.iso", "rb" ) ) == NULL )
{ printf( "Can't open 'Fedora-Workstation-Live-x86_64-35-1.2.iso' file.\n" ); return( 1 ); }
if( ( fp_outLINE3 = fopen( "Fedora-Workstation-Live-x86_64-35-1.2.iso.sorted", "wb" ) ) == NULL )
{ printf( "Can't open 'Fedora-Workstation-Live-x86_64-35-1.2.iso.sorted' file.\n" ); return( 1 ); }

fread( AvoidSEEKS, elements -(-8+1), 1, fp_outLINE2 );

for(j=0;j<=elements-1;j++) {
    FabriceBellard_DIGITS[j] = *(uint64_t *)(AvoidSEEKS+j);
}
    for(i=1;i<=ditto;i++) {
        for(j=0;j<=elements-1;j++) {
            xgamsCACHE[elements * (i - 1) + j] = FabriceBellard_DIGITS[j];
        }
    }
    //printf("Sorting in single-thread %lld elements...\n", elements*ditto);    

    } //if (strcmp(argv[2],"ALL")==0) {



// https://cdn.kernel.org/pub/linux/kernel/v5.x/linux-5.15.25.tar.xz
// 1.05 GB (1,137,582,080 bytes)

    if (strcmp(argv[2],"manyC")==0) {
ditto = 1;
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/x86_64/iso/Fedora-Workstation-Live-x86_64-35-1.2.iso
// "Fedora-Workstation-Live-x86_64-35-1.2.iso" is 24823016, we need the lof("mobythesaurus.txt")-8+1 QWORDS
elements = 1137582080LL-8+1; // BuildingBlocks are size-order+1

printf( "Allocating FILE-Buffer %lluMB ...\n", (unsigned long long)((elements -(-8+1))>>20) );
AvoidSEEKS = (char *)malloc( elements -(-8+1) );
if( AvoidSEEKS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

//printf( "Allocating AUX-Buffer %lluMB ...\n", ((elements*8)>>20) );
//FabriceBellard_DIGITS = (uint64_t *)malloc( elements*8);
//if( FabriceBellard_DIGITS == NULL )
//{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if( ( fp_outLINE2 = fopen( "linux-5.15.25.tar", "rb" ) ) == NULL )
{ printf( "Can't open 'linux-5.15.25.tar' file.\n" ); return( 1 ); }
if( ( fp_outLINE3 = fopen( "linux-5.15.25.tar.sorted", "wb" ) ) == NULL )
{ printf( "Can't open 'linux-5.15.25.tar.sorted' file.\n" ); return( 1 ); }

fread( AvoidSEEKS, elements -(-8+1), 1, fp_outLINE2 );

for(j=0;j<=elements-1;j++) {
    xgamsCACHE[j] = *(uint64_t *)(AvoidSEEKS+j);
}
free(AvoidSEEKS);
    //printf("Sorting in single-thread %lld elements...\n", elements*ditto);    

    } //if (strcmp(argv[2],"manyC")==0) {


// https://download.kiwix.org/zim/stack_exchange/math.stackexchange.com_en_all_2019-02.zim
// 7.26 GB (7,798,235,442 bytes)

    if (strcmp(argv[2],"ALLmax")==0) {
ditto = 1;
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/x86_64/iso/Fedora-Workstation-Live-x86_64-35-1.2.iso
// "Fedora-Workstation-Live-x86_64-35-1.2.iso" is 24823016, we need the lof("mobythesaurus.txt")-8+1 QWORDS
elements = 7798235442LL -8+1; // BuildingBlocks are size-order+1

printf( "Allocating FILE-Buffer %lluMB ...\n", (unsigned long long)((elements -(-8+1))>>20) );
AvoidSEEKS = (char *)malloc( elements -(-8+1) );
if( AvoidSEEKS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

//printf( "Allocating AUX-Buffer %lluMB ...\n", ((elements*8)>>20) );
//FabriceBellard_DIGITS = (uint64_t *)malloc( elements*8);
//if( FabriceBellard_DIGITS == NULL )
//{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if( ( fp_outLINE2 = fopen( "math.stackexchange.com_en_all_2019-02.zim", "rb" ) ) == NULL )
{ printf( "Can't open 'math.stackexchange.com_en_all_2019-02.zim' file.\n" ); return( 1 ); }
if( ( fp_outLINE3 = fopen( "math.stackexchange.com_en_all_2019-02.zim.sorted", "wb" ) ) == NULL )
{ printf( "Can't open 'math.stackexchange.com_en_all_2019-02.zim.sorted' file.\n" ); return( 1 ); }

fread( AvoidSEEKS, elements -(-8+1), 1, fp_outLINE2 );

for(j=0;j<=elements-1;j++) {
    xgamsCACHE[j] = *(uint64_t *)(AvoidSEEKS+j);
}
free(AvoidSEEKS);
    //printf("Sorting in single-thread %lld elements...\n", elements*ditto);    

    } //if (strcmp(argv[2],"ALLmax")==0) {


// Download: https://ftp.ncbi.nlm.nih.gov/refseq/H_sapiens/annotation/GRCh38_latest/refseq_identifiers/GRCh38_latest_genomic.fna.gz
// www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 3.08 GB (3,313,061,631 bytes)

    if (strcmp(argv[2],"DNA")==0) {
ditto = 1;
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/x86_64/iso/Fedora-Workstation-Live-x86_64-35-1.2.iso
// "Fedora-Workstation-Live-x86_64-35-1.2.iso" is 24823016, we need the lof("mobythesaurus.txt")-8+1 QWORDS
elements = 3313061631LL -8+1; // BuildingBlocks are size-order+1

printf( "Allocating FILE-Buffer %lluMB ...\n", (unsigned long long)((elements -(-8+1))>>20) );
AvoidSEEKS = (char *)malloc( elements -(-8+1) );
if( AvoidSEEKS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

//printf( "Allocating AUX-Buffer %lluMB ...\n", ((elements*8)>>20) );
//FabriceBellard_DIGITS = (uint64_t *)malloc( elements*8);
//if( FabriceBellard_DIGITS == NULL )
//{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if( ( fp_outLINE2 = fopen( "www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna", "rb" ) ) == NULL )
{ printf( "Can't open 'www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna' file.\n" ); return( 1 ); }
if( ( fp_outLINE3 = fopen( "www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna.sorted", "wb" ) ) == NULL )
{ printf( "Can't open 'www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna.sorted' file.\n" ); return( 1 ); }

fread( AvoidSEEKS, elements -(-8+1), 1, fp_outLINE2 );

for(j=0;j<=elements-1;j++) {
    xgamsCACHE[j] = *(uint64_t *)(AvoidSEEKS+j);
}
free(AvoidSEEKS);
    //printf("Sorting in single-thread %lld elements...\n", elements*ditto);    

    } //if (strcmp(argv[2],"DNA")==0) {

    if (strcmp(argv[2],"DNAi")==0) {
ditto = 1;
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/x86_64/iso/Fedora-Workstation-Live-x86_64-35-1.2.iso
// "Fedora-Workstation-Live-x86_64-35-1.2.iso" is 24823016, we need the lof("mobythesaurus.txt")-8+1 QWORDS
elements = 3313061631LL -8+1; // BuildingBlocks are size-order+1

printf( "Allocating FILE-Buffer %lluMB ...\n", (unsigned long long)((elements -(-8+1))>>20) );
AvoidSEEKS = (char *)malloc( elements -(-8+1) );
if( AvoidSEEKS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

//printf( "Allocating AUX-Buffer %lluMB ...\n", ((elements*8)>>20) );
//FabriceBellard_DIGITS = (uint64_t *)malloc( elements*8);
//if( FabriceBellard_DIGITS == NULL )
//{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if( ( fp_outLINE2 = fopen( "www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna", "rb" ) ) == NULL )
{ printf( "Can't open 'www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna' file.\n" ); return( 1 ); }
if( ( fp_outLINE3 = fopen( "www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna.sorted", "wb" ) ) == NULL )
{ printf( "Can't open 'www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna.sorted' file.\n" ); return( 1 ); }

fread( AvoidSEEKS, elements -(-8+1), 1, fp_outLINE2 );

for(j=0;j<=elements-1;j++) {
    *(xgamsCACHE+j) = (uint64_t)(AvoidSEEKS+j); // Transmuting char* (via uint64t) to uint64t*... with future casting (uint64t*)
    //printf("%d %p %llu %p\n", j, (AvoidSEEKS+j), (uint64_t)(AvoidSEEKS+j), (char *)*(xgamsCACHE+j));
}
//free(AvoidSEEKS);
    //printf("Sorting in single-thread %lld elements...\n", elements*ditto);    

    } //if (strcmp(argv[2],"DNAi")==0) {

// Download: https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/376/725/GCA_000376725.2_Lful_2.0/GCA_000376725.2_Lful_2.0_genomic.fna.gz
// GCA_000376725.2_Lful_2.0_genomic.fna 1.2 GB (1,173,135,641 bytes) i.e. Dragonfly

    if (strcmp(argv[2],"DNA2")==0) {
ditto = 1;
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/x86_64/iso/Fedora-Workstation-Live-x86_64-35-1.2.iso
// "Fedora-Workstation-Live-x86_64-35-1.2.iso" is 24823016, we need the lof("mobythesaurus.txt")-8+1 QWORDS
elements = 1173135641LL -8+1; // BuildingBlocks are size-order+1

printf( "Allocating FILE-Buffer %lluMB ...\n", (unsigned long long)((elements -(-8+1))>>20) );
AvoidSEEKS = (char *)malloc( elements -(-8+1) );
if( AvoidSEEKS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

//printf( "Allocating AUX-Buffer %lluMB ...\n", ((elements*8)>>20) );
//FabriceBellard_DIGITS = (uint64_t *)malloc( elements*8);
//if( FabriceBellard_DIGITS == NULL )
//{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if( ( fp_outLINE2 = fopen( "GCA_000376725.2_Lful_2.0_genomic.fna", "rb" ) ) == NULL )
{ printf( "Can't open 'GCA_000376725.2_Lful_2.0_genomic.fna' file.\n" ); return( 1 ); }
if( ( fp_outLINE3 = fopen( "GCA_000376725.2_Lful_2.0_genomic.fna.sorted", "wb" ) ) == NULL )
{ printf( "Can't open 'GCA_000376725.2_Lful_2.0_genomic.fna.sorted' file.\n" ); return( 1 ); }

fread( AvoidSEEKS, elements -(-8+1), 1, fp_outLINE2 );

for(j=0;j<=elements-1;j++) {
    xgamsCACHE[j] = *(uint64_t *)(AvoidSEEKS+j);
}
free(AvoidSEEKS);
    //printf("Sorting in single-thread %lld elements...\n", elements*ditto);    

    } //if (strcmp(argv[2],"DNA2")==0) {

// GCF_006547405.1_ASM654740v1_genomic.fna 2.4 GB (2363955788 bytes) i.e. Dolphin


// Fedora 35, gcc 11.2.1, i7-3630QM 16GB:1x13732MB elements = 1800000000LL
//                                  32GB:2x13732MB elements = 3600000000LL
//                                  64GB:4x13732MB elements = 7200000000LL
/*
[root@w8 QS_Dragonfly]# ./QS_bench_r14_GCC11.2.1_rev5bypass.elf Akkoda 3n+1
Current priority is -20.
Allocating Master-Buffer 13732MB ...
omp_get_num_procs( ) = 8
omp_get_max_threads( ) = 8
Sorting in multi-thread 1800000000 elements...
Splitting the pool to 'LessTHANa=1800000000/GreaterOrEqualTHANa=0' partitions in 2 seconds.
Partition Ratio: 1.57 (ideal being 1 i.e. Left:Right=1.00)
Thread #1 of 4 sorting 140196595814416..140205382061920, partition size=8786247504
Thread #2 of 4 sorting 140205382632096..140210995814408, partition size=5613182312
Thread #3 of 4 sorting 140210995814408..140210995814408, partition size=0
Thread #4 of 4 sorting 140210995814408..140210995814408, partition size=0
Done in 59 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Splitting the pool to 'LessTHANa=1800000000/GreaterOrEqualTHANa=0' partitions in 2 seconds.
Partition Ratio: 1.00 (ideal being 1 i.e. Left:Right=1.00)
Thread #1 of 4 sorting 140196595814416..140203794848600, partition size=7199034184
Thread #2 of 4 sorting 140203796412056..140210995814408, partition size=7199402352
Thread #3 of 4 sorting 140210995814408..140210995814408, partition size=0
Thread #4 of 4 sorting 140210995814408..140210995814408, partition size=0
Done in 20 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866

[root@w8 QS_Dragonfly]# ./QS_bench_r14_GCC11.2.1_rev5bypass.elf Magnetica 3n+1
Current priority is -20.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
Done in 92 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 21 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866

[root@w8 QS_Dragonfly]# ./QS_bench_r14_GCC11.2.1_rev5bypass.elf CS 3n+1
Current priority is -20.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
Done in 77 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 3 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866

[root@w8 QS_Dragonfly]# ./QS_bench_r14_GCC11.2.1_rev5bypass.elf BM 3n+1
Current priority is -20.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
Done in 99 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 22 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
[root@w8 QS_Dragonfly]# 
*/
    if ( (strcmp(argv[2],"3n+1_16GB")==0) || (strcmp(argv[2],"3n+1_32GB")==0) ) {
ditto = 1;
if (strcmp(argv[2],"3n+1_16GB")==0) elements = 1800000000LL; // to fit in 16GB
if (strcmp(argv[2],"3n+1_32GB")==0) elements = 3600000000LL; // to fit in 32GB
printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

    j=0;
    i=1;
for (;;) {
    HAILSTONE=i;
    //printf("\n%lld: %lld ", HAILSTONE, HAILSTONE);    
    if (j<=elements-1) xgamsCACHE[j++] = (uint64_t)HAILSTONE; else break;
    while (HAILSTONE!=1) {
            if (HAILSTONE%2==0) HAILSTONE=HAILSTONE/2; else HAILSTONE=HAILSTONE*3+1;
            //printf("%lld ", HAILSTONE);   
            if (j<=elements-1) xgamsCACHE[j++] = (uint64_t)HAILSTONE; else break;
    }
    i++;
}
/*
1: 1 
2: 2 1 
3: 3 10 5 16 8 4 2 1 
4: 4 2 1 
5: 5 16 8 4 2 1 
6: 6 3 10 5 16 8 4 2 1 
7: 7 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 
8: 8 4 2 1 
9: 9 28 14 7 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 
10: 10 5 16 8 4 2 1 
11: 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 
12: 12 6 3 10 5 16 8 4 2 1 
13: 13 40 20 10 5 16 8 4 2 1 
14: 14 7 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 
15: 15 46 23 70 35 106 53 160 80 40 20 10 5 16 8 4 2 1 
16: 16 8 4 2 1 
17: 17 52 26 13 40 20 10 5 16 8 4 2 1 
18: 18 9 28 14 7 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 
19: 19 58 29 88 44 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 
20: 20 10 5 16 8 4 2 1 
21: 21 64 32 16 8 4 2 1 
22: 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 
23: 23 70 35 106 53 160 80 40 20 10 5 16 8 4 2 1 
24: 24 12 6 3 10 5 16 8 4 2 1 
25: 25 76 38 19 58 29 88 44 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 
26: 26 13 40 20 10 5 16 8 4 2 1 
27: 27 82 41 124 62 31 94 47 142 71 214 107 322 161 484 242 121 364 182 91 274 137 412 206 103 310 155 466 233 700 350 175 526 263 790 395 1186 593 1780 890 445 1336 668 334 167 502 251 754 377 1132 566 283 850 425 1276 638 319 958 479 1438 719 2158 1079 3238 1619 4858 2429 7288 3644 1822 911 2734 1367 4102 2051 6154 3077 9232 4616 2308 1154 577 1732 866 433 1300 650 325 976 488 244 122 61 184 92 46 23 70 35 106 53 160 80 40 20 10 5 16 8 4 2 1 
28: 28 14 7 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 
29: 29 88 44 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 
30: 30 15 46 23 70 35 106 53 160 80 40 20 10 5 16 8 4 2 1 
*/
    } //if (strcmp(argv[2],"3n+1")==0) {


// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/aarch64/images/Fedora-Workstation-35-1.2.aarch64.raw.xz
// 3.54 GB (3,803,483,832 bytes)

    if (strcmp(argv[2],"ALLmore")==0) {
ditto = 1;
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/x86_64/iso/Fedora-Workstation-Live-x86_64-35-1.2.iso
// "Fedora-Workstation-Live-x86_64-35-1.2.iso" is 24823016, we need the lof("mobythesaurus.txt")-8+1 QWORDS
elements = 3803483832LL -8+1; // BuildingBlocks are size-order+1

printf( "Allocating FILE-Buffer %lluMB ...\n", (unsigned long long)((elements -(-8+1))>>20) );
AvoidSEEKS = (char *)malloc( elements -(-8+1) );
if( AvoidSEEKS == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

//printf( "Allocating AUX-Buffer %lluMB ...\n", ((elements*8)>>20) );
//FabriceBellard_DIGITS = (uint64_t *)malloc( elements*8);
//if( FabriceBellard_DIGITS == NULL )
//{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

printf( "Allocating Master-Buffer %lluMB ...\n", (unsigned long long)((elements*8*ditto)>>20) );
xgamsCACHE = (uint64_t *)malloc( elements*8*ditto );
if( xgamsCACHE == NULL )
{ puts( "Needed memory allocation denied!\n" ); return( 1 ); }

if( ( fp_outLINE2 = fopen( "Fedora-Workstation-35-1.2.aarch64.raw.xz", "rb" ) ) == NULL )
{ printf( "Can't open 'Fedora-Workstation-35-1.2.aarch64.raw.xz' file.\n" ); return( 1 ); }
if( ( fp_outLINE3 = fopen( "Fedora-Workstation-35-1.2.aarch64.raw.xz.sorted", "wb" ) ) == NULL )
{ printf( "Can't open 'Fedora-Workstation-35-1.2.aarch64.raw.xz.sorted' file.\n" ); return( 1 ); }

fread( AvoidSEEKS, elements -(-8+1), 1, fp_outLINE2 );

for(j=0;j<=elements-1;j++) {
    xgamsCACHE[j] = *(uint64_t *)(AvoidSEEKS+j);
}
free(AvoidSEEKS);
    //printf("Sorting in single-thread %lld elements...\n", elements*ditto);    

    } //if (strcmp(argv[2],"ALLmore")==0) {

#ifdef Commence_OpenMP
    //if ( (strcmp(argv[1],"Akkoda")==0) || (strcmp(argv[1],"BM")==0) ) {
    if ( (strcmp(argv[1],"Akkoda")==0) ) {
    printf("omp_get_num_procs( ) = %d\n", omp_get_num_procs( ));
    printf("omp_get_max_threads( ) = %d\n", omp_get_max_threads( ));
    printf("Sorting in multi-thread %lld elements...\n", (long long)elements*ditto);   
    } else printf("Sorting in single-thread %lld elements...\n", (long long)elements*ditto);   
#else
    printf("Sorting in single-thread %lld elements...\n", (long long)elements*ditto);  
#endif


// 2021-Nov-10 fix: Ugh, forgot to duplicate ditto times...

// AVX2[

if (strcmp(argv[1],"BalxchonkaI")==0) {
        MinimumKeysUnsortedSCALAR = 0;
        for (i=0; i + 1 < elements*ditto; i++) {
        //if (xgamsCACHE[counter]>xgamsCACHE[counter+1]) {printf("NOT OK!\n");exit(13);};
                if (CompareOrder(xgamsCACHE[i], xgamsCACHE[i+1], 8) > 0) 
                //if (a[i] > a[i + 1])
                //return false;
                MinimumKeysUnsortedSCALAR++; //return !(-1);
        }
        j = MinimumKeysUnsortedSCALAR;
} else j = is_sorted_avx2_QWORD(xgamsCACHE, elements*ditto);

//  #ifdef Commence_AVX
//  printf("AVX check... UNSORTEDNESS (in permyriads) = %lld O/ooo = (Number_of_Unsorted_Keys = %lld)*10000/(Number_of_All_Keys = %lld)\n", j*10000LL/(elements*ditto),  j, elements*ditto);    
//  #else
//  printf("AVX2 check... UNSORTEDNESS (in permyriads) = %lld O/ooo = (Number_Unsorted_Keys = %lld)*10000/(Number_of_All_Keys = %lld)\n", j*10000LL/(elements*ditto),  j, elements*ditto);  
//  #endif
// AVX2]

        time1=time(NULL); //fix of bigtime
        while (time1==time(NULL));
        time1=time(NULL); //fix of bigtime

//  if (strcmp(argv[1],"qsort")==0) qsort(xgamsCACHE, elements*ditto, sizeof(uint64_t), cmpfunc); //r.9
    if (strcmp(argv[1],"qsort")==0) qsort(xgamsCACHE, elements*ditto, sizeof(uint64_t), KAZE_Scandum_compareQWORD); //r.9+ For some reason cmp_8 doesn't work?!
    if (strcmp(argv[1],"Magnetica10")==0) Quicksort_QB64_v10(xgamsCACHE, 0, elements*ditto - 1);  
//  if (strcmp(argv[1],"Magnetica12")==0) Quicksort_QB64_v12(xgamsCACHE, 0, elements*ditto - 1);  
//  if (strcmp(argv[1],"Magnetica14")==0) Quicksort_QB64_v14(xgamsCACHE, elements*ditto);  
//  if (strcmp(argv[1],"Magnetica")==0) Quicksort_QB64_v15(xgamsCACHE, elements*ditto);  
//  if (strcmp(argv[1],"Magnetica")==0) Quicksort_QB64_v16(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);
    if (strcmp(argv[1],"Koffcheg")==0) Quicksort_Magnetica_v18_Koffcheg(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);
    if (strcmp(argv[1],"Balxchonka")==0) Quicksort_Magnetica_v18_Balxchonka(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);        
    if (strcmp(argv[1],"Glupendxr")==0) Quicksort_Magnetica_v18_Glupendxr(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);        

    if (strcmp(argv[1],"BalxchonkaI")==0) Quicksort_Magnetica_v18_Balxchonka_indirect(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1], 8);        

    if (strcmp(argv[1],"Akkoda")==0) QuickSortAkkoda(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);  

    if (strcmp(argv[1],"Hoare")==0) KAZE_QuickSortHoare(xgamsCACHE, 0, elements*ditto - 1);  
    if (strcmp(argv[1],"BM")==0) KAZE_quicksort_Bentley_McIlroy_3way_partitioning(xgamsCACHE, 0, elements*ditto - 1);  
    //if (strcmp(argv[1],"FS")==0) fluxsort(xgamsCACHE, elements*ditto, sizeof(uint64_t), cmp_8); //r.9+
    if (strcmp(argv[1],"CS")==0) crumsort(xgamsCACHE, elements*ditto, sizeof(uint64_t), cmp_8); //r.11
        printf("Done in %d seconds.\n", (int)(time(NULL) - time1));

    printf("Checking whether sort went correct... ");   
    if (strcmp(argv[1],"BalxchonkaI")==0) {

    UniqueElements=1;
    Previous = xgamsCACHE[0];
    for(counter=0;counter<elements*ditto-1;counter++) {
        //if (xgamsCACHE[counter]>xgamsCACHE[counter+1]) {printf("NOT OK!\n");exit(13);};
        if (CompareOrder(xgamsCACHE[counter], xgamsCACHE[counter+1], 8) > 0) {       printf("counter = %lld\n", (long long)counter);  printf("NOT OK!\n");exit(13);};
        //if (Previous != xgamsCACHE[counter]) {UniqueElements++; Previous = xgamsCACHE[counter];};
        if (CompareOrder(Previous, xgamsCACHE[counter], 8) != 0) {UniqueElements++; Previous = xgamsCACHE[counter];};
    }
    printf("OK. Unique keys = %lld\n", (long long)UniqueElements);

    } else {
    UniqueElements=1;
    Previous = xgamsCACHE[0];
    for(counter=0;counter<elements*ditto-1;counter++) {
        if (xgamsCACHE[counter]>xgamsCACHE[counter+1]) {printf("NOT OK!\n");exit(13);};
        if (Previous != xgamsCACHE[counter]) {UniqueElements++; Previous = xgamsCACHE[counter];};
    }
    printf("OK. Unique keys = %lld\n", (long long)UniqueElements); 
    }

    printf("Sorting sorted elements...\n"); 
        time1=time(NULL); //fix of bigtime
        while (time1==time(NULL));
        time1=time(NULL); //fix of bigtime
//  if (strcmp(argv[1],"qsort")==0) qsort(xgamsCACHE, elements*ditto, sizeof(uint64_t), cmpfunc); //r.9
    if (strcmp(argv[1],"qsort")==0) qsort(xgamsCACHE, elements*ditto, sizeof(uint64_t), KAZE_Scandum_compareQWORD); //r.9+ For some reason cmp_8 doesn't work?!
    if (strcmp(argv[1],"Magnetica10")==0) Quicksort_QB64_v10(xgamsCACHE, 0, elements*ditto - 1);  
//  if (strcmp(argv[1],"Magnetica12")==0) Quicksort_QB64_v12(xgamsCACHE, 0, elements*ditto - 1);  
//  if (strcmp(argv[1],"Magnetica14")==0) Quicksort_QB64_v14(xgamsCACHE, elements*ditto);  
//  if (strcmp(argv[1],"Magnetica")==0) Quicksort_QB64_v15(xgamsCACHE, elements*ditto);  
//  if (strcmp(argv[1],"Magnetica")==0) Quicksort_QB64_v16(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);
    if (strcmp(argv[1],"Koffcheg")==0) Quicksort_Magnetica_v18_Koffcheg(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);
    if (strcmp(argv[1],"Balxchonka")==0) Quicksort_Magnetica_v18_Balxchonka(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);        
    if (strcmp(argv[1],"Glupendxr")==0) Quicksort_Magnetica_v18_Glupendxr(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);        

    if (strcmp(argv[1],"BalxchonkaI")==0) Quicksort_Magnetica_v18_Balxchonka_indirect(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1], 8);        

    if (strcmp(argv[1],"Akkoda")==0) QuickSortAkkoda(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);  

    if (strcmp(argv[1],"Hoare")==0) KAZE_QuickSortHoare(xgamsCACHE, 0, elements*ditto - 1);  
    if (strcmp(argv[1],"BM")==0) KAZE_quicksort_Bentley_McIlroy_3way_partitioning(xgamsCACHE, 0, elements*ditto - 1);  
    //if (strcmp(argv[1],"FS")==0) fluxsort(xgamsCACHE, elements*ditto, sizeof(uint64_t), cmp_8); //r.9+
    if (strcmp(argv[1],"CS")==0) crumsort(xgamsCACHE, elements*ditto, sizeof(uint64_t), cmp_8); //r.11

        printf("Done in %d seconds.\n", (int)(time(NULL) - time1));

    //QuickSortHoare(xgamsCACHE, 0, elements*ditto - 1);  
    printf("Checking whether sort went correct... ");   
    if (strcmp(argv[1],"BalxchonkaI")==0) {

    UniqueElements=1;
    Previous = xgamsCACHE[0];
    for(counter=0;counter<elements*ditto-1;counter++) {
        //if (xgamsCACHE[counter]>xgamsCACHE[counter+1]) {printf("NOT OK!\n");exit(13);};
        if (CompareOrder(xgamsCACHE[counter], xgamsCACHE[counter+1], 8) > 0) {printf("NOT OK!\n");exit(13);};
        //if (Previous != xgamsCACHE[counter]) {UniqueElements++; Previous = xgamsCACHE[counter];};
        if (CompareOrder(Previous, xgamsCACHE[counter], 8) != 0) {UniqueElements++; Previous = xgamsCACHE[counter];};
    }
    printf("OK. Unique keys = %lld\n", (long long)UniqueElements);

    } else {
    UniqueElements=1;
    Previous = xgamsCACHE[0];
    for(counter=0;counter<elements*ditto-1;counter++) {
        if (xgamsCACHE[counter]>xgamsCACHE[counter+1]) {printf("NOT OK!\n");exit(13);};
        if (Previous != xgamsCACHE[counter]) {UniqueElements++; Previous = xgamsCACHE[counter];};
    }
    printf("OK. Unique keys = %lld\n", (long long)UniqueElements); 
    }

// AVX2[
//  #ifdef Commence_AVX
//  printf("AVX check... Number_of_Unsorted_Keys = %lld\n", is_sorted_avx2_QWORD(xgamsCACHE, elements*ditto));  
//  #else
//  printf("AVX2 check... Number_of_Unsorted_Keys = %lld\n", is_sorted_avx2_QWORD(xgamsCACHE, elements*ditto)); 
//  #endif
// AVX2[

printf("Summary:\n");   
printf("Number_of_All_Keys = %lld (%lld MB)\n", (long long)elements*ditto, (long long)(elements*ditto*8LL)>>20);  
printf("Number_of_Unique_Keys = %lld\n", (long long)UniqueElements);   
printf("Number_of_Unsorted_Keys = %lld\n", (long long)j);  
printf("UNIQUENESS = %1.12f (closer to 1, means higher entropy)\n", (double)(UniqueElements-0.9)/(elements*ditto)); 
printf("UNSORTEDNESS (in percents or in permyriads) = %lld O/o or %lld O/ooo\n", (long long)j*100LL/(elements*ditto), (long long)j*10000LL/(elements*ditto)); 
    //fwrite( xgamsCACHE, elements*8, 1, fp_outLINE3 );
} //if (argc==3) {
    exit(0);
}


// https://bellard.org/mersenne.html
// A small C program to print the biggest prime number
// Here it is (448 bytes):
/*
int m=1811939329,N=1,t[1<<26]={2},a,*p,i,e=73421233,s,c,U=1;g(d,h){for(i=s;i<1<<
25;i*=2)d=d*1LL*d%m;for(p=t;p<t+N;p+=s)for(i=s,c=1;i;i--)a=p[s]*(h?c:1LL)%m,p[s]
=(m*1U+*p-a)*(h?1LL:c)%m,*p=(a*1U+*p)%m,p++,c=c*1LL*d%m;}main(){while(e/=2){N*=2
;U=U*1LL*(m+1)/2%m;for(s=N;s/=2;)g(136,0);for(p=t;p<t+N;p++)*p=*p*1LL**p%m*U%m;
for(s=1;s<N;s*=2)g(839354248,1);for(a=0,p=t;p<t+N;)a+=*p<<(e&1),*p++=a%10,a/=10;
}while(!*--p);for(t[0]--;p>=t;)putchar(48+*p--);}
*/
// This program computes 2^74207281-1, which was the biggest known prime number in 2016 (about 23 million digits !). For more information about how it was // found and who found it, look at the GIMPS Project .
// 
// I compiled it successfully with gcc with Linux. In order to compile it, your C compiler must support the 64 bit long long type.
// 
// In order to have a small and yet asymptotically efficient code, I decided to do the computation of 2N-1 directly in base 10. The power involves repeated // squarings and multiplications by two. The squarings are implemented by doing fast convolutions using a Number Theoretic Transform.
// 
// A previous version of this program to compute 2^6972593-1 won the International Obfuscated C Code Contest of Year 2000.
// 
// Thanks to Marco Cecchi who suggested some syntactic changes to save a few characters.
// 
// This program is Freeware.
// 
// Fabrice Bellard - http://bellard.org/ 
// last update: Sep 26, 2016


// bitonic[
/*
    // given an array arr of length n, this code sorts it in place
    // all indices run from 0 to n-1
    for (k = 2; k <= n; k *= 2) // k is doubled every iteration
        for (j = k/2; j > 0; j /= 2) // j is halved at every iteration, with truncation of fractional parts
            for (i = 0; i < n; i++)
                l = bitwiseXOR (i, j); // in C-like languages this is "i ^ j"
                if (l > i)
                    if (  (bitwiseAND (i, k) == 0) AND (arr[i] > arr[l])
                       OR (bitwiseAND (i, k) != 0) AND (arr[i] < arr[l]) )
                          swap the elements arr[i] and arr[l]
*/
// bitonic]

//https://courses.cs.duke.edu//fall08/cps196.1/Pthreads/bitonic.c [
/*
 bitonic.c 

 This file contains two different implementations of the bitonic sort
        recursive  version 
        imperative version :  impBitonicSort() 
 

 The bitonic sort is also known as Batcher Sort. 
 For a reference of the algorithm, see the article titled 
 Sorting networks and their applications by K. E. Batcher in 1968 


 The following codes take references to the codes avaiable at 

 http://www.cag.lcs.mit.edu/streamit/results/bitonic/code/c/bitonic.c

 http://www.tools-of-computing.com/tc/CS/Sorts/bitonic_sort.htm

 http://www.iti.fh-flensburg.de/lang/algorithmen/sortieren/bitonic/bitonicen.htm 
*/
//   Nikos Pitsianis, Duke CS 
/*
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

struct timeval startwtime, endwtime;
double seq_time;

int N;          // data array size
int *a;         // data array to be sorted

const int ASCENDING  = 1;
const int DESCENDING = 0;

void init(void);
void print(void);
void sort(void);
void test(void);
inline void exchange(int i, int j);
void compare(int i, int j, int dir);
void bitonicMerge(int lo, int cnt, int dir);
void recBitonicSort(int lo, int cnt, int dir);
void impBitonicSort(void);

int main(int argc, char **argv) {

  if (argc != 2) {
    printf("Usage: %s n\n  where n is problem size (power of two)\n", argv[0]);
    exit(1);
  }

  N = atoi(argv[1]);
  a = (int *) malloc(N * sizeof(int));
  
  init();

  gettimeofday (&startwtime, NULL);
  impBitonicSort();
  gettimeofday (&endwtime, NULL);

  seq_time = (double)((endwtime.tv_usec - startwtime.tv_usec)/1.0e6
              + endwtime.tv_sec - startwtime.tv_sec);

  printf("Imperative wall clock time = %f\n", seq_time);

  test();
  print();

  init();
  gettimeofday (&startwtime, NULL);
  sort();
  gettimeofday (&endwtime, NULL);

  seq_time = (double)((endwtime.tv_usec - startwtime.tv_usec)/1.0e6
              + endwtime.tv_sec - startwtime.tv_sec);

  printf("Recursive wall clock time = %f\n", seq_time);

  test();
  print();
}

// procedure test() : verify sort results
void test() {
  int pass = 1;
  int i;
  for (i = 1; i < N; i++) {
    pass &= (a[i-1] <= a[i]);
  }
  printf(" TEST %s\n",(pass) ? "PASSed" : "FAILed");
}

// procedure init() : initialize array "a" with data
void init() {
  int i;
  for (i = 0; i < N; i++) {
    a[i] = rand() % N; // (N - i);
    printf("%d\n", a[i]);
  }
}

// procedure  print() : print array elements
void print() {
  int i;
  for (i = 0; i < N; i++) {
    printf("%d\n", a[i]);
  }
  printf("\n");
}

// INLINE procedure exchange() : pair swap
inline void exchange(int i, int j) {
  int t;
  t = a[i];
  a[i] = a[j];
  a[j] = t;
}

// procedure compare() 
// The parameter dir indicates the sorting direction, ASCENDING 
// or DESCENDING; if (a[i] > a[j]) agrees with the direction, 
// then a[i] and a[j] are interchanged.
void compare(int i, int j, int dir) {
  if (dir==(a[i]>a[j])) 
    exchange(i,j);
}

// Procedure bitonicMerge() 
// It recursively sorts a bitonic sequence in ascending order, 
// if dir = ASCENDING, and in descending order otherwise. 
// The sequence to be sorted starts at index position lo,
// the parameter cbt is the number of elements to be sorted. 
void bitonicMerge(int lo, int cnt, int dir) {
  if (cnt>1) {
    int k=cnt/2;
    int i;
    for (i=lo; i<lo+k; i++)
      compare(i, i+k, dir);
    bitonicMerge(lo, k, dir);
    bitonicMerge(lo+k, k, dir);
  }
}

// function recBitonicSort() 
// first produces a bitonic sequence by recursively sorting 
// its two halves in opposite sorting orders, and then
// calls bitonicMerge to make them in the same order 
void recBitonicSort(int lo, int cnt, int dir) {
  if (cnt>1) {
    int k=cnt/2;
    recBitonicSort(lo, k, ASCENDING);
    recBitonicSort(lo+k, k, DESCENDING);
    bitonicMerge(lo, cnt, dir);
  }
}

// function sort() 
// Caller of recBitonicSort for sorting the entire array of length N 
// in ASCENDING order
void sort() {
  recBitonicSort(0, N, ASCENDING);
}

// imperative version of bitonic sort
void impBitonicSort() {

  int i,j,k;
  
  for (k=2; k<=N; k=2*k) {
    for (j=k>>1; j>0; j=j>>1) {
      for (i=0; i<N; i++) {
    int ij=i^j;
    if ((ij)>i) {
      printf("(%d,%d)\n",i,ij);
      if ((i&k)==0 && a[i] > a[ij]) 
          exchange(i,ij);
      if ((i&k)!=0 && a[i] < a[ij])
          exchange(i,ij);
    }
      }
    }
  }
}
*/
//https://courses.cs.duke.edu//fall08/cps196.1/Pthreads/bitonic.c ]

/*
https://metacpan.org/pod/Algorithm::Networksort
Bose-Nelson sorting network, inputs = 4 (in 5 swaps), drawn as a Knuth diagram:
[00]----
    ||  
[01]-|--
     |||
[02]--|-
    | | 
[03]----

Bitonic for 4 keys (in 6 swaps):
[00]----
    || |  
[01]-|--
     ||
[02]--|-
    | || 
[03]----

(0,1)
(2,3)
(0,2)
(1,3)
(0,1)
(2,3)

Bitonic for 8 keys (in 24 swaps):
[00]-----------
    || ||    ||
[01]-|--|----|-
     || ||  || 
[02]-|--||--|--
    || |||| | |
[03]----|||----
        ||||   
[04]----|||----
    || ||||  ||
[05]-|--||---|-
     || ||  || 
[06]-|--|---|--
    || ||   | |
[07]-----------

(0,1)
(2,3)
(4,5)
(6,7)
(0,2)
(1,3)
(4,6)
(5,7)
(0,1)
(2,3)
(4,5)
(6,7)
(0,4)
(1,5)
(2,6)
(3,7)
(0,2)
(1,3)
(4,6)
(5,7)
(0,1)
(2,3)
(4,5)
(6,7)

Bitonic for 16 keys (in 80 swaps):

(0,1)
(2,3)
(4,5)
(6,7)
(8,9)
(10,11)
(12,13)
(14,15)
(0,2)
(1,3)
(4,6)
(5,7)
(8,10)
(9,11)
(12,14)
(13,15)
(0,1)
(2,3)
(4,5)
(6,7)
(8,9)
(10,11)
(12,13)
(14,15)
(0,4)
(1,5)
(2,6)
(3,7)
(8,12)
(9,13)
(10,14)
(11,15)
(0,2)
(1,3)
(4,6)
(5,7)
(8,10)
(9,11)
(12,14)
(13,15)
(0,1)
(2,3)
(4,5)
(6,7)
(8,9)
(10,11)
(12,13)
(14,15)
(0,8)
(1,9)
(2,10)
(3,11)
(4,12)
(5,13)
(6,14)
(7,15)
(0,4)
(1,5)
(2,6)
(3,7)
(8,12)
(9,13)
(10,14)
(11,15)
(0,2)
(1,3)
(4,6)
(5,7)
(8,10)
(9,11)
(12,14)
(13,15)
(0,1)
(2,3)
(4,5)
(6,7)
(8,9)
(10,11)
(12,13)
(14,15)
*/

// i5-7200U
/*

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>timer64 QS_bench_r14_GCC11.3.0_rev5bypass.exe Akkoda 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 13732MB ...
omp_get_num_procs( ) = 4
omp_get_max_threads( ) = 4
Sorting in multi-thread 1800000000 elements...
AVX2 check... UNSORTEDNESS (in permyriads) = 6638 O/ooo = (Number_Unsorted_Keys = 1194844247)*10000/(Number_of_All_Keys = 1800000000)
Splitting the pool to 'LessTHANa=1800000000/GreaterOrEqualTHANa=0' partitions in 2 seconds.
Partition Ratio: 1.57 (ideal being 1 i.e. Left:Right=1.00)
Thread #1 of 4 sorting 2509937848384..2518724095888, partition size=8786247504
Thread #2 of 4 sorting 2518724666064..2524337848376, partition size=5613182312
Thread #3 of 4 sorting 2524337848376..2524337848376, partition size=0
Thread #4 of 4 sorting 2524337848376..2524337848376, partition size=0
Done in 64 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Splitting the pool to 'LessTHANa=1800000000/GreaterOrEqualTHANa=0' partitions in 2 seconds.
Partition Ratio: 1.00 (ideal being 1 i.e. Left:Right=1.00)
Thread #1 of 4 sorting 2509937848384..2517136882568, partition size=7199034184
Thread #2 of 4 sorting 2517138446024..2524337848376, partition size=7199402352
Thread #3 of 4 sorting 2524337848376..2524337848376, partition size=0
Thread #4 of 4 sorting 2524337848376..2524337848376, partition size=0
Done in 23 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
AVX2 check... Number_of_Unsorted_Keys = 0
Summary:
Number_of_All_Keys = 1800000000 (13732 MB)
Number_of_Unique_Keys = 24816866
Number_of_Unsorted_Keys = 1194844247
UNIQUENESS = 0.013787147278 (closer to 1, means higher entropy)
UNSORTEDNESS (in percents or in permyriads) = 66 O/o or 6638 O/ooo


Kernel  Time =     2.296 =    2%
User    Time =   157.375 =  151%
Process Time =   159.671 =  153%    Virtual  Memory =  14018 MB
Global  Time =   103.708 =  100%    Physical Memory =  13737 MB

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>timer64 QS_bench_r14_GCC11.3.0_rev5bypass.exe Magnetica 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
AVX2 check... UNSORTEDNESS (in permyriads) = 6638 O/ooo = (Number_Unsorted_Keys = 1194844247)*10000/(Number_of_All_Keys = 1800000000)
Done in 102 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 23 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
AVX2 check... Number_of_Unsorted_Keys = 0
Summary:
Number_of_All_Keys = 1800000000 (13732 MB)
Number_of_Unique_Keys = 24816866
Number_of_Unsorted_Keys = 1194844247
UNIQUENESS = 0.013787147278 (closer to 1, means higher entropy)
UNSORTEDNESS (in percents or in permyriads) = 66 O/o or 6638 O/ooo


Kernel  Time =     2.375 =    1%
User    Time =   140.546 =   99%
Process Time =   142.921 =  100%    Virtual  Memory =  14018 MB
Global  Time =   141.884 =  100%    Physical Memory =  13737 MB

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>timer64 QS_bench_r14_GCC11.3.0_rev5bypass.exe BM 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
AVX2 check... UNSORTEDNESS (in permyriads) = 6638 O/ooo = (Number_Unsorted_Keys = 1194844247)*10000/(Number_of_All_Keys = 1800000000)
Done in 110 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 25 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
AVX2 check... Number_of_Unsorted_Keys = 0
Summary:
Number_of_All_Keys = 1800000000 (13732 MB)
Number_of_Unique_Keys = 24816866
Number_of_Unsorted_Keys = 1194844247
UNIQUENESS = 0.013787147278 (closer to 1, means higher entropy)
UNSORTEDNESS (in percents or in permyriads) = 66 O/o or 6638 O/ooo


Kernel  Time =     2.625 =    1%
User    Time =   149.781 =   98%
Process Time =   152.406 =  100%    Virtual  Memory =  14018 MB
Global  Time =   151.737 =  100%    Physical Memory =  13737 MB

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>timer64 QS_bench_r14_GCC11.3.0_rev5bypass.exe Hoare 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
AVX2 check... UNSORTEDNESS (in permyriads) = 6638 O/ooo = (Number_Unsorted_Keys = 1194844247)*10000/(Number_of_All_Keys = 1800000000)
Done in 137 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 51 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
AVX2 check... Number_of_Unsorted_Keys = 0
Summary:
Number_of_All_Keys = 1800000000 (13732 MB)
Number_of_Unique_Keys = 24816866
Number_of_Unsorted_Keys = 1194844247
UNIQUENESS = 0.013787147278 (closer to 1, means higher entropy)
UNSORTEDNESS (in percents or in permyriads) = 66 O/o or 6638 O/ooo


Kernel  Time =     2.343 =    1%
User    Time =   203.156 =   99%
Process Time =   205.500 =  100%    Virtual  Memory =  14018 MB
Global  Time =   204.851 =  100%    Physical Memory =  13737 MB

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>timer64 QS_bench_r14_GCC11.3.0_rev5bypass.exe CS 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
AVX2 check... UNSORTEDNESS (in permyriads) = 6638 O/ooo = (Number_Unsorted_Keys = 1194844247)*10000/(Number_of_All_Keys = 1800000000)
Done in 73 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 3 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
AVX2 check... Number_of_Unsorted_Keys = 0
Summary:
Number_of_All_Keys = 1800000000 (13732 MB)
Number_of_Unique_Keys = 24816866
Number_of_Unsorted_Keys = 1194844247
UNIQUENESS = 0.013787147278 (closer to 1, means higher entropy)
UNSORTEDNESS (in percents or in permyriads) = 66 O/o or 6638 O/ooo


Kernel  Time =     2.578 =    2%
User    Time =    90.796 =   98%
Process Time =    93.375 =  100%    Virtual  Memory =  14018 MB
Global  Time =    92.507 =  100%    Physical Memory =  13737 MB

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>
*/
/*

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>timer64 QS_bench_r14_ICL19.0_rev5bypass.exe Akkoda 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 13732MB ...
omp_get_num_procs( ) = 4
omp_get_max_threads( ) = 4
Sorting in multi-thread 1800000000 elements...
AVX2 check... UNSORTEDNESS (in permyriads) = 6638 O/ooo = (Number_Unsorted_Keys = 1194844247)*10000/(Number_of_All_Keys = 1800000000)
Splitting the pool to 'LessTHANa=1800000000/GreaterOrEqualTHANa=0' partitions in 1 seconds.
Partition Ratio: 1.57 (ideal being 1 i.e. Left:Right=1.00)
Thread #1 of 4 sorting 2323363332160..2332149579664, partition size=8786247504
Thread #2 of 4 sorting 2332150149840..2337763332152, partition size=5613182312
Thread #3 of 4 sorting 2337763332152..2337763332152, partition size=0
Thread #4 of 4 sorting 2337763332152..2337763332152, partition size=0
Done in 66 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Splitting the pool to 'LessTHANa=1800000000/GreaterOrEqualTHANa=0' partitions in 1 seconds.
Partition Ratio: 1.00 (ideal being 1 i.e. Left:Right=1.00)
Thread #1 of 4 sorting 2323363332160..2330562366344, partition size=7199034184
Thread #2 of 4 sorting 2330563929800..2337763332152, partition size=7199402352
Thread #3 of 4 sorting 2337763332152..2337763332152, partition size=0
Thread #4 of 4 sorting 2337763332152..2337763332152, partition size=0
Done in 23 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
AVX2 check... Number_of_Unsorted_Keys = 0
Summary:
Number_of_All_Keys = 1800000000 (13732 MB)
Number_of_Unique_Keys = 24816866
Number_of_Unsorted_Keys = 1194844247
UNIQUENESS = 0.013787147278 (closer to 1, means higher entropy)
UNSORTEDNESS (in percents or in permyriads) = 66 O/o or 6638 O/ooo


Kernel  Time =     2.656 =    2%
User    Time =   162.578 =  154%
Process Time =   165.234 =  157%    Virtual  Memory =  14021 MB
Global  Time =   105.225 =  100%    Physical Memory =  13738 MB

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>timer64 QS_bench_r14_ICL19.0_rev5bypass.exe Magnetica 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
AVX2 check... UNSORTEDNESS (in permyriads) = 6638 O/ooo = (Number_Unsorted_Keys = 1194844247)*10000/(Number_of_All_Keys = 1800000000)
Done in 107 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 24 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
AVX2 check... Number_of_Unsorted_Keys = 0
Summary:
Number_of_All_Keys = 1800000000 (13732 MB)
Number_of_Unique_Keys = 24816866
Number_of_Unsorted_Keys = 1194844247
UNIQUENESS = 0.013787147278 (closer to 1, means higher entropy)
UNSORTEDNESS (in percents or in permyriads) = 66 O/o or 6638 O/ooo


Kernel  Time =     2.468 =    1%
User    Time =   144.875 =   98%
Process Time =   147.343 =  100%    Virtual  Memory =  14018 MB
Global  Time =   146.642 =  100%    Physical Memory =  13737 MB

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>timer64 QS_bench_r14_ICL19.0_rev5bypass.exe BM 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
AVX2 check... UNSORTEDNESS (in permyriads) = 6638 O/ooo = (Number_Unsorted_Keys = 1194844247)*10000/(Number_of_All_Keys = 1800000000)
Done in 104 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 23 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
AVX2 check... Number_of_Unsorted_Keys = 0
Summary:
Number_of_All_Keys = 1800000000 (13732 MB)
Number_of_Unique_Keys = 24816866
Number_of_Unsorted_Keys = 1194844247
UNIQUENESS = 0.013787147278 (closer to 1, means higher entropy)
UNSORTEDNESS (in percents or in permyriads) = 66 O/o or 6638 O/ooo


Kernel  Time =     2.437 =    1%
User    Time =   141.437 =   98%
Process Time =   143.875 =  100%    Virtual  Memory =  14018 MB
Global  Time =   143.032 =  100%    Physical Memory =  13737 MB

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>timer64 QS_bench_r14_ICL19.0_rev5bypass.exe Hoare 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
AVX2 check... UNSORTEDNESS (in permyriads) = 6638 O/ooo = (Number_Unsorted_Keys = 1194844247)*10000/(Number_of_All_Keys = 1800000000)
Done in 128 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 41 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
AVX2 check... Number_of_Unsorted_Keys = 0
Summary:
Number_of_All_Keys = 1800000000 (13732 MB)
Number_of_Unique_Keys = 24816866
Number_of_Unsorted_Keys = 1194844247
UNIQUENESS = 0.013787147278 (closer to 1, means higher entropy)
UNSORTEDNESS (in percents or in permyriads) = 66 O/o or 6638 O/ooo


Kernel  Time =     2.531 =    1%
User    Time =   184.468 =   99%
Process Time =   187.000 =  100%    Virtual  Memory =  14018 MB
Global  Time =   185.912 =  100%    Physical Memory =  13737 MB

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>timer64 QS_bench_r14_ICL19.0_rev5bypass.exe CS 3n+1
Current priority class is REALTIME_PRIORITY_CLASS.
Allocating Master-Buffer 13732MB ...
Sorting in single-thread 1800000000 elements...
AVX2 check... UNSORTEDNESS (in permyriads) = 6638 O/ooo = (Number_Unsorted_Keys = 1194844247)*10000/(Number_of_All_Keys = 1800000000)
Done in 89 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
Sorting sorted elements...
Done in 3 seconds.
Checking whether sort went correct... OK. Unique keys = 24816866
AVX2 check... Number_of_Unsorted_Keys = 0
Summary:
Number_of_All_Keys = 1800000000 (13732 MB)
Number_of_Unique_Keys = 24816866
Number_of_Unsorted_Keys = 1194844247
UNIQUENESS = 0.013787147278 (closer to 1, means higher entropy)
UNSORTEDNESS (in percents or in permyriads) = 66 O/o or 6638 O/ooo


Kernel  Time =     2.515 =    2%
User    Time =   105.796 =   98%
Process Time =   108.312 =  101%    Virtual  Memory =  14018 MB
Global  Time =   107.233 =  100%    Physical Memory =  13737 MB

C:\mingw64\Resources_Quicksort_2022-Jun-17\QS_Collatz>
*/

// 2022-Sep-06
//[kaze@kaze Quicksort_says_19_BUGZILLA++++]$ cat test.sh 
//echo performance | tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
//cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
//
//cp www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna /dev/null
//perf stat ./Schmekeriada_CLANG_14.0_rev5bypass.elf www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna
//perf stat ./Schmekeriada_GCC_12.1.1_rev5bypass.elf www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna
//LC_ALL=C perf stat sort -o q www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna --parallel=1
//LC_ALL=C perf stat sort -o q www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna --parallel=8
//sha1sum Schmekeriada.txt
//sha1sum q
/*
[kaze@kaze Quicksort_says_19_BUGZILLA++++]$ su
Password: 
[root@kaze Quicksort_says_19_BUGZILLA++++]# sh test.sh 
performance
performance
   _________        .__                       __                    __             .___         
  /   _____/  ____  |  |__    _____    ____  |  | __  ____ _______ |__|_____     __| _/_____    
  \_____  \ _/ ___\ |  |  \  /     \ _/ __ \ |  |/ /_/ __ \\_  __ \|  |\__  \   / __ | \__  \   
  /        \\  \___ |   Y  \|  Y Y  \\  ___/ |    < \  ___/ |  | \/|  | / __ \_/ /_/ |  / __ \_ 
 /_______  / \___  >|___|  /|__|_|  / \___  >|__|_ \ \___  >|__|   |__|(____  /\____ | (____  / 
         \/      \/      \/       \/      \/      \/     \/                 \/      \/      \/   
Current priority is -20.
Size of input file: 3,313,061,631
Allocating FILE-Buffer 3159MB ...
Counting lines ... Done in 438,264 clocks, 0.44 seconds.
Number of LF-ending lines: 40,902,071
Allocating Master-Buffer #1 312MB ... Aligned to 16 bytes boundary.
Allocating Master-Buffer #2 312MB ...
Assigning pairs (of pointers and lengths) to lines ... Done in 2,629,933 clocks, 2.63 seconds.
LongestLine = 141
Sorting pointers to lines with 'Quicksort_Magnetica_v18_Balxchonka_indirect' ...
Done (just sorting) in 44 seconds.
Writing sorted lines to 'Schmekeriada.txt' ... Done (just writing) in 12 seconds.

 Performance counter stats for './Schmekeriada_CLANG_14.0_rev5bypass.elf www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna':

         61,248.91 msec task-clock                #    0.999 CPUs utilized          
               792      context-switches          #   12.931 /sec                   
                49      cpu-migrations            #    0.800 /sec                   
           888,824      page-faults               #   14.512 K/sec                  
   189,423,012,475      cycles                    #    3.093 GHz                    
   160,825,749,456      instructions              #    0.85  insn per cycle         
    40,932,154,665      branches                  #  668.292 M/sec                  
     1,196,793,333      branch-misses             #    2.92% of all branches        

      61.334747617 seconds time elapsed

      55.752283000 seconds user
       5.306224000 seconds sys


   _________        .__                       __                    __             .___         
  /   _____/  ____  |  |__    _____    ____  |  | __  ____ _______ |__|_____     __| _/_____    
  \_____  \ _/ ___\ |  |  \  /     \ _/ __ \ |  |/ /_/ __ \\_  __ \|  |\__  \   / __ | \__  \   
  /        \\  \___ |   Y  \|  Y Y  \\  ___/ |    < \  ___/ |  | \/|  | / __ \_/ /_/ |  / __ \_ 
 /_______  / \___  >|___|  /|__|_|  / \___  >|__|_ \ \___  >|__|   |__|(____  /\____ | (____  / 
         \/      \/      \/       \/      \/      \/     \/                 \/      \/      \/   
Current priority is -20.
Size of input file: 3,313,061,631
Allocating FILE-Buffer 3159MB ...
Counting lines ... Done in 450,506 clocks, 0.45 seconds.
Number of LF-ending lines: 40,902,071
Allocating Master-Buffer #1 312MB ... Aligned to 16 bytes boundary.
Allocating Master-Buffer #2 312MB ...
Assigning pairs (of pointers and lengths) to lines ... Done in 2,977,197 clocks, 2.98 seconds.
LongestLine = 141
Sorting pointers to lines with 'Quicksort_Magnetica_v18_Balxchonka_indirect' ...
Done (just sorting) in 47 seconds.
Writing sorted lines to 'Schmekeriada.txt' ... Done (just writing) in 12 seconds.

 Performance counter stats for './Schmekeriada_GCC_12.1.1_rev5bypass.elf www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna':

         65,076.56 msec task-clock                #    0.921 CPUs utilized          
             3,241      context-switches          #   49.803 /sec                   
                78      cpu-migrations            #    1.199 /sec                   
           968,666      page-faults               #   14.885 K/sec                  
   201,239,899,229      cycles                    #    3.092 GHz                    
   180,997,738,078      instructions              #    0.90  insn per cycle         
    45,074,958,783      branches                  #  692.645 M/sec                  
     1,195,676,715      branch-misses             #    2.65% of all branches        

      70.638483482 seconds time elapsed

      58.670829000 seconds user
       6.246045000 seconds sys



 Performance counter stats for 'sort -o q www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna --parallel=1':

          45740.80 msec task-clock                #    0.963 CPUs utilized          
              1298      context-switches          #   28.377 /sec                   
                61      cpu-migrations            #    1.334 /sec                   
           1288352      page-faults               #   28.166 K/sec                  
      141454949085      cycles                    #    3.093 GHz                    
       99170581478      instructions              #    0.70  insn per cycle         
       21544608383      branches                  #  471.015 M/sec                  
         512501792      branch-misses             #    2.38% of all branches        

      47.506939437 seconds time elapsed

      39.738847000 seconds user
       5.866944000 seconds sys



 Performance counter stats for 'sort -o q www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna --parallel=8':

          74828.66 msec task-clock                #    2.147 CPUs utilized          
              9897      context-switches          #  132.262 /sec                   
               625      cpu-migrations            #    8.352 /sec                   
           2087238      page-faults               #   27.894 K/sec                  
      231376914688      cycles                    #    3.092 GHz                    
      108895088635      instructions              #    0.47  insn per cycle         
       23527911405      branches                  #  314.424 M/sec                  
         534469880      branch-misses             #    2.27% of all branches        

      34.853209815 seconds time elapsed

      65.435991000 seconds user
       9.013117000 seconds sys


45306b08d6f09207c307fccb7da5a149ff7fe7f3  Schmekeriada.txt
45306b08d6f09207c307fccb7da5a149ff7fe7f3  q
[root@kaze Quicksort_says_19_BUGZILLA++++]# exit
exit
[kaze@kaze Quicksort_says_19_BUGZILLA++++]$ hwinfo
bash: hwinfo: command not found
[kaze@kaze Quicksort_says_19_BUGZILLA++++]$ lscpu
Architecture:            x86_64
  CPU op-mode(s):        32-bit, 64-bit
  Address sizes:         39 bits physical, 48 bits virtual
  Byte Order:            Little Endian
CPU(s):                  4
  On-line CPU(s) list:   0-3
Vendor ID:               GenuineIntel
  Model name:            Intel(R) Core(TM) i5-7200U CPU @ 2.50GHz
    CPU family:          6
    Model:               142
    Thread(s) per core:  2
    Core(s) per socket:  2
    Socket(s):           1
    Stepping:            9
    CPU(s) scaling MHz:  99%
    CPU max MHz:         3100.0000
    CPU min MHz:         400.0000
    BogoMIPS:            5399.81
    Flags:               fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx pdpe1gb rdtscp lm constant_tsc art arch_perfmon pebs bts rep_g
                         ood nopl xtopology nonstop_tsc cpuid aperfmperf pni pclmulqdq dtes64 monitor ds_cpl vmx est tm2 ssse3 sdbg fma cx16 xtpr pdcm pcid sse4_1 sse4_2 x2apic movbe popcnt tsc_deadline_timer aes xsave
                          avx f16c rdrand lahf_lm abm 3dnowprefetch cpuid_fault invpcid_single pti ssbd ibrs ibpb stibp tpr_shadow vnmi flexpriority ept vpid ept_ad fsgsbase tsc_adjust bmi1 avx2 smep bmi2 erms invpcid 
                         mpx rdseed adx smap clflushopt intel_pt xsaveopt xsavec xgetbv1 xsaves dtherm ida arat pln pts hwp hwp_notify hwp_act_window hwp_epp md_clear flush_l1d arch_capabilities
Virtualization features: 
  Virtualization:        VT-x
Caches (sum of all):     
  L1d:                   64 KiB (2 instances)
  L1i:                   64 KiB (2 instances)
  L2:                    512 KiB (2 instances)
  L3:                    3 MiB (1 instance)
NUMA:                    
  NUMA node(s):          1
  NUMA node0 CPU(s):     0-3
Vulnerabilities:         
  Itlb multihit:         KVM: Mitigation: VMX disabled
  L1tf:                  Mitigation; PTE Inversion; VMX conditional cache flushes, SMT vulnerable
  Mds:                   Mitigation; Clear CPU buffers; SMT vulnerable
  Meltdown:              Mitigation; PTI
  Mmio stale data:       Mitigation; Clear CPU buffers; SMT vulnerable
  Retbleed:              Mitigation; IBRS
  Spec store bypass:     Mitigation; Speculative Store Bypass disabled via prctl
  Spectre v1:            Mitigation; usercopy/swapgs barriers and __user pointer sanitization
  Spectre v2:            Mitigation; IBRS, IBPB conditional, RSB filling
  Srbds:                 Mitigation; Microcode
  Tsx async abort:       Not affected
[kaze@kaze Quicksort_says_19_BUGZILLA++++]$ 
*/

// Sandokan remnants [[[
/*
//fsetpos(fp_in, AtPosition64Lpointer);
//fread(&FourGramL[0], Longest10Line+1, 1, fp_in);
char workbyte;
char workK[1024*384];
long workKoffset = -1;
unsigned long long Over4billionLines, j_Over4billion;
char OneChar_ieByte;
unsigned long long SeekPosition;
unsigned long long *PointerToSeekPosition, *PointerToSeekPositionCACHE;
// ASSIGNING POINTERS ... [
   SeekPosition = 0;
   j_Over4billion = 1;
   PointerToSeekPosition[j_Over4billion] = SeekPosition;
	workKoffset = -1;
        for( i = 0; i < Strnglen64; i++ )
	{
                // ~~~~~~~~~~~~ Buffering fread [
                if (workKoffset == -1) {
                        if (i + 1024*384 < Strnglen64) {
                                fread( &workK[0], 1, 1024*384, fp_in );
                                workKoffset = 0;
                                workbyte = workK[workKoffset];
                        } else {
                        fread( &workbyte, 1, 1, fp_in );
			}
                } else {
                        workKoffset++;
                        workbyte = workK[workKoffset];
                        if (workKoffset == 1024*384 - 1) workKoffset = -1;
                }
                // ~~~~~~~~~~~~ Buffering fread ]
		SeekPosition++;
		if (workbyte == 10) {
			j_Over4billion++;
			if (j_Over4billion <= Over4billionLines) PointerToSeekPosition[j_Over4billion] = SeekPosition;
		}
        } // i 'for'
// ASSIGNING POINTERS ... ]
*/
//char *Auberge[4] = {"|\0","/\0","-\0","\\\0"};
//int Melnitchka=0;
//Melnitchka = Melnitchka & 3; // 0 1 2 3: 00 01 10 11
//printf( "%s RightEnd: %s; ", Auberge[Melnitchka++], _ui64toaKAZEzerocomma(RightEnd, llTOaDigits, 10)+(26-15));
// Sandokan remnants ]]]

