#-mavx2 -march=haswell

gcc -msse4.2 -S -O3 -m64 -fomit-frame-pointer Schmekeriada.c -o Schmekerezada_GCC_13.0.1_SSE4.2_TetraThread.elf.asm -D_N_HIGH_PRIORITY_GCC -Drev5bypass -fopenmp -DCommence_OpenMP -D_POSIX_ENVIRONMENT_
gcc -msse4.2 -O3 -m64 -fomit-frame-pointer Schmekeriada.c -o Schmekerezada_GCC_13.0.1_SSE4.2_TetraThread.elf -D_N_HIGH_PRIORITY_GCC -Drev5bypass -fopenmp -DCommence_OpenMP -D_POSIX_ENVIRONMENT_
gcc -msse4.2 -O3 -m64 -fomit-frame-pointer Schmekeriada.c -o Schmekerezada_GCC_13.0.1_SSE4.2_MonoThread.elf -D_N_HIGH_PRIORITY_GCC -Drev5bypass -fopenmp -DCommence_OpenMP -D_POSIX_ENVIRONMENT_ -DSingleT

x86_64-w64-mingw32-gcc -msse4.2 -O3 -m64 -static -fomit-frame-pointer Schmekeriada.c -o Schmekerezada_GCC_13.0.1_SSE4.2_TetraThread.exe -D_N_HIGH_PRIORITY -Drev5bypass -fopenmp -DCommence_OpenMP -D_WIN32_ENVIRONMENT_
x86_64-w64-mingw32-gcc -msse4.2 -O3 -m64 -static -fomit-frame-pointer Schmekeriada.c -o Schmekerezada_GCC_13.0.1_SSE4.2_MonoThread.exe -D_N_HIGH_PRIORITY -Drev5bypass -fopenmp -DCommence_OpenMP -D_WIN32_ENVIRONMENT_ -DSingleT
