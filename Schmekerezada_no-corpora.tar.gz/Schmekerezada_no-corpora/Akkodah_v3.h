// Akkodah_v3.h [
// icl /O3 /Qopenmp -DCommence_OpenMP
// gcc -O3 -fomit-frame-pointer -fopenmp -DCommence_OpenMP
//    _____    __     __               .___.__             
//   /  _  \  |  | __|  | __ ____    __| _/|  |__  _____   
//  /  /_\  \ |  |/ /|  |/ //  _ \  / __ | |  |  \ \__  \
// /    |    \|    < |    <(  <_> )/ /_/ | |   Y  \ / __ \_
// \____|__  /|__|_ \|__|_ \\____/ \____ | |___|  /(____  /
//         \/      \/     \/            \/      \/      \/ 
// Written by Sanmayce, 2022-Jul-07
#include<time.h>
time_t time1,time2;
#if defined(__OMP_H) || defined(OMP_H)
#else
	#ifdef Commence_OpenMP
		#include <omp.h>
	#endif
#endif
#if !defined(Mv18)
	#include "Magnetica_v18.h"
#endif
#define Triad
#define Ennead
#define TrisKaiDecad
#define MINKaze(x,y) (x<y?x:y)
#define MAXKaze(x,y) (x<y?y:x)
void AKKODAH_swapUnconditional (uint64_t *a, uint64_t *b) { uint64_t t = *a; *a = *b; *b = t; }
void AKKODAH_swapconditional1 (uint64_t *a, uint64_t *b) { uint64_t aOLD = *a; uint64_t bOLD = *b; *a = MINKaze(aOLD,bOLD); *b = MAXKaze(aOLD,bOLD); }
void AKKODAH_SwapConditional_ifXbY_BUGGY (int64_t X, int64_t Y, uint64_t *a, uint64_t *b) { int64_t XYsgnd = X-Y; int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&(XYsgnd >> 63); *a = *a-ABsgnd; *b = *b+ABsgnd; } // if X<Y then swap
void QuickSortAkkoda (uint64_t *Left, uint64_t *Right) {
	uint64_t Pivot;
	uint64_t *Indx, *Jndx, *PL, *PR;
	uint64_t *Indx127, *Jndx127;
	uint64_t *Indx128, *Jndx128;
	uint64_t *Left127, *Right127;
	uint64_t *Left128, *Right128;
	uint64_t *LeftTMP, *RightTMP;
	int64_t MicroPartition;
	int i, MicroChunk;
	//if (!is_sorted_Wojciech (Left, (uint64_t)(Right-Left+1))) {
		goto skip;
		// 'NOSIGNED/SIGNED' partitioning, mainloop [
		time1=time(NULL); //fix of bigtime
		while (time1==time(NULL));
		time1=time(NULL); //fix of bigtime
		LeftTMP=Left;
		RightTMP=Right;
		// Use sentinel to speed up the galfoniada further below:
		if ( (*RightTMP >> 63)==0 ) { // No point to enter the faster check if there is a single QWORD with 64th bit set [
			Pivot=*RightTMP;
			*RightTMP=-1;
			while ( (*LeftTMP >> 63)==0 ) LeftTMP++;
			*RightTMP=Pivot;
		} // No point to enter the faster check if there is a single QWORD with 64th bit set ]
		if (LeftTMP==RightTMP) {
		} else {
			LeftTMP=Left;
			// Too slow:
			do {
			        while ( (*LeftTMP >> 63)==0 && LeftTMP<RightTMP ) LeftTMP++;
			        while ( (*RightTMP >> 63)==1 && LeftTMP<RightTMP ) RightTMP--;
				AKKODAH_swapUnconditional (LeftTMP, RightTMP);
			} while (LeftTMP<RightTMP);
			if ( (*LeftTMP >> 63)==1 && (LeftTMP>Left) ) LeftTMP--;
			if ( (*RightTMP >> 63)==0 && (RightTMP<Right) ) RightTMP++;
		}
		Left127=Left; Right127=LeftTMP;
		Left128=RightTMP; Right128=Right;
		//# //In Linux it is %llu and in Windows it is %I64u
		//# printf("uint64_t SGNDmax = 1LL<<63 = %llu\n", SGNDmax);
		//# printf("uint64_t UNSGNDmax = -1 = %llu\n\n", UNSGNDmax);
		//# printf("uint64_t SGNDmax = 1LL<<63 = 0x%llX\n", SGNDmax);
		//# printf("uint64_t UNSGNDmax = -1 = 0x%llX\n\n", UNSGNDmax);
		printf("Splitting the pool to 'NOSIGNED=%lld/SIGNED=%lld' partitions in %d seconds.\n", (long long)((Right127-Left127)>>(3-3)) + !!((Right127-Left127)>>(3-3)), (long long)((Right128-Left128)>>(3-3)) + !!((Right128-Left128)>>(3-3)), (int)(time(NULL) - time1)); // To report the "real" size of a partition, 1 has to be added to a non empty one.
		// 'NOSIGNED/SIGNED' partitioning, mainloop ]
skip:
		// "<'a'" partitioning, mainloop [
		time1=time(NULL); //fix of bigtime
		while (time1==time(NULL));
		time1=time(NULL); //fix of bigtime
		LeftTMP=Left;
		RightTMP=Right;
			do {
				while ( (*LeftTMP >> (64-8))<'a' && LeftTMP<RightTMP ) LeftTMP++;
				while ( (*RightTMP >> (64-8))>='a' && LeftTMP<RightTMP ) RightTMP--;
				AKKODAH_swapUnconditional (LeftTMP, RightTMP);
			} while (LeftTMP<RightTMP);
		if ( (*LeftTMP >> (64-8))>='a' && (LeftTMP>Left) ) LeftTMP--;
		if ( (*RightTMP >> (64-8))<'a' && (RightTMP<Right) ) RightTMP++;
		Left127=Left; Right127=LeftTMP;
		Left128=RightTMP; Right128=Right;
		//# //In Linux it is %llu and in Windows it is %I64u
		//# printf("uint64_t SGNDmax = 1LL<<63 = %llu\n", SGNDmax);
		//# printf("uint64_t UNSGNDmax = -1 = %llu\n\n", UNSGNDmax);
		//# printf("uint64_t SGNDmax = 1LL<<63 = 0x%llX\n", SGNDmax);
		//# printf("uint64_t UNSGNDmax = -1 = 0x%llX\n\n", UNSGNDmax);
		printf("Splitting the pool to 'LessTHANa=%lld/GreaterOrEqualTHANa=%lld' partitions in %d seconds.\n", (long long)((Right127-Left127)>>(3-3)) + !!((Right127-Left127)>>(3-3)), (long long)((Right128-Left128)>>(3-3)) + !!((Right128-Left128)>>(3-3)), (int)(time(NULL) - time1)); // To report the "real" size of a partition, 1 has to be added to a non empty one.
		// "<'a'" partitioning, mainloop ]
		// Presume there will be dummy invocations for QS [
		Jndx127=Left127;
		Indx127=Right127;
		Jndx128=Left128;
		Indx128=Right128;
		// Presume there will be dummy invocations for QS ]
		#ifdef Commence_OpenMP
			#pragma omp parallel private(i,Left,Right,Indx,Jndx,PL,PR,Pivot) //shared() 
		#endif
			{ // pragma [
			#ifdef Commence_OpenMP
				// Cannot use directly //#pragma omp parallel for
				#pragma omp for
			#endif
			for (i=0; i<=1; i++) {
				if (i==0) {Left=Left127; Right=Right127;}
				if (i==1) {Left=Left128; Right=Right128;}
				switch (Right-Left) { // The name of the game "jmp rax"
					case 12: // sorting 13 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5)); AKKODAH_swapconditional1((Left+5),(Left+6)); AKKODAH_swapconditional1((Left+6),(Left+7)); AKKODAH_swapconditional1((Left+7),(Left+8)); AKKODAH_swapconditional1((Left+8),(Left+9)); AKKODAH_swapconditional1((Left+9),(Left+10)); AKKODAH_swapconditional1((Left+10),(Left+11)); AKKODAH_swapconditional1((Left+11),(Left+12));
					case 11: // sorting 12 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5)); AKKODAH_swapconditional1((Left+5),(Left+6)); AKKODAH_swapconditional1((Left+6),(Left+7)); AKKODAH_swapconditional1((Left+7),(Left+8)); AKKODAH_swapconditional1((Left+8),(Left+9)); AKKODAH_swapconditional1((Left+9),(Left+10)); AKKODAH_swapconditional1((Left+10),(Left+11));
					case 10: // sorting 11 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5)); AKKODAH_swapconditional1((Left+5),(Left+6)); AKKODAH_swapconditional1((Left+6),(Left+7)); AKKODAH_swapconditional1((Left+7),(Left+8)); AKKODAH_swapconditional1((Left+8),(Left+9)); AKKODAH_swapconditional1((Left+9),(Left+10));
					case 9: // sorting 10 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5)); AKKODAH_swapconditional1((Left+5),(Left+6)); AKKODAH_swapconditional1((Left+6),(Left+7)); AKKODAH_swapconditional1((Left+7),(Left+8)); AKKODAH_swapconditional1((Left+8),(Left+9));
					case 8: // sorting 9 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5)); AKKODAH_swapconditional1((Left+5),(Left+6)); AKKODAH_swapconditional1((Left+6),(Left+7)); AKKODAH_swapconditional1((Left+7),(Left+8));
					case 7: // sorting 8 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5)); AKKODAH_swapconditional1((Left+5),(Left+6)); AKKODAH_swapconditional1((Left+6),(Left+7));
					case 6: // sorting 7 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5)); AKKODAH_swapconditional1((Left+5),(Left+6));
					case 5: // sorting 6 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5));
					case 4: // sorting 5 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4));
					case 3: // sorting 4 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3));
					case 2: // sorting 3 elements
						AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2));
					case 1: // sorting 2 elements
						AKKODAH_swapconditional1((Left+0),(Left+1));
					case 0:
						break;
					default:
					if (Right-Left > 0) { // Needed since 'Left > Right' could be true!
						Jndx = Right;
						if ( ((Right-Left)>>(3-3)) < (1LL<<19) ) { // The granularity of QWORD pointers is 8, arbitrarily choosing 524,288, Ugh, bug, forgot to cast ((uint64_t)Right-(uint64_t)Left)>>3
							#ifdef Triad
							PL = Left+1;
							PR = Left+1;
							AKKODAH_swapUnconditional (Left + ((Right-Left)>>2) + 0, Left+0);
							AKKODAH_swapUnconditional (Left + ((Right-Left)>>1) + 0, Left+1);
							AKKODAH_swapUnconditional (Right, Left+2);
							AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2));
							AKKODAH_swapconditional1((Left+0),(Left+1));
							PL = PL - (*(Left+1)==*(Left+0));
							#endif
						} else {
							MicroChunk = 117; // Median of 11*9=99 or 117*9=1053
							Quicksort_Magnetica_v18_Koffcheg(Left, Left+(MicroChunk-1));			
							Quicksort_Magnetica_v18_Koffcheg(Left + (1*(Right-Left)>>3), Left + 1*((Right-Left)>>3)+(MicroChunk-1));
							Quicksort_Magnetica_v18_Koffcheg(Left + (2*(Right-Left)>>3), Left + 2*((Right-Left)>>3)+(MicroChunk-1));
							Quicksort_Magnetica_v18_Koffcheg(Left + (3*(Right-Left)>>3), Left + 3*((Right-Left)>>3)+(MicroChunk-1));
							Quicksort_Magnetica_v18_Koffcheg(Left + (4*(Right-Left)>>3), Left + 4*((Right-Left)>>3)+(MicroChunk-1));
							Quicksort_Magnetica_v18_Koffcheg(Left + (5*(Right-Left)>>3), Left + 5*((Right-Left)>>3)+(MicroChunk-1));
							Quicksort_Magnetica_v18_Koffcheg(Left + (6*(Right-Left)>>3), Left + 6*((Right-Left)>>3)+(MicroChunk-1));
							Quicksort_Magnetica_v18_Koffcheg(Left + (7*(Right-Left)>>3), Left + 7*((Right-Left)>>3)+(MicroChunk-1));
							Quicksort_Magnetica_v18_Koffcheg(Right-(MicroChunk-1), Right);
							#ifdef Ennead
							PL = Left+4;
							PR = Left+4;
							AKKODAH_swapUnconditional (Left + (MicroChunk>>1), Left+0);
							AKKODAH_swapUnconditional (Left + (1*(Right-Left)>>3) + (MicroChunk>>1), Left+1);
							AKKODAH_swapUnconditional (Left + (2*(Right-Left)>>3) + (MicroChunk>>1), Left+2);
							AKKODAH_swapUnconditional (Left + (3*(Right-Left)>>3) + (MicroChunk>>1), Left+3);
							AKKODAH_swapUnconditional (Left + (4*(Right-Left)>>3) + (MicroChunk>>1), Left+4);
							AKKODAH_swapUnconditional (Left + (5*(Right-Left)>>3) + (MicroChunk>>1), Left+5);
							AKKODAH_swapUnconditional (Left + (6*(Right-Left)>>3) + (MicroChunk>>1), Left+6);
							AKKODAH_swapUnconditional (Left + (7*(Right-Left)>>3) + (MicroChunk>>1), Left+7);
							AKKODAH_swapUnconditional (Right - 6, Left+8);
							AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5)); AKKODAH_swapconditional1((Left+5),(Left+6)); AKKODAH_swapconditional1((Left+6),(Left+7)); AKKODAH_swapconditional1((Left+7),(Left+8));
							AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5)); AKKODAH_swapconditional1((Left+5),(Left+6)); AKKODAH_swapconditional1((Left+6),(Left+7));
							AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5)); AKKODAH_swapconditional1((Left+5),(Left+6));
							AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4)); AKKODAH_swapconditional1((Left+4),(Left+5));
							AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3)); AKKODAH_swapconditional1((Left+3),(Left+4));
					 		AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2)); AKKODAH_swapconditional1((Left+2),(Left+3));
							AKKODAH_swapconditional1((Left+0),(Left+1)); AKKODAH_swapconditional1((Left+1),(Left+2));
							AKKODAH_swapconditional1((Left+0),(Left+1));
							PL = PL - (*(Left+4)==*(Left+3));
							PL = PL - (*(Left+4)==*(Left+2));
							PL = PL - (*(Left+4)==*(Left+1));
							PL = PL - (*(Left+4)==*(Left+0));
							#endif
						} // if ( ((Right-Left)>>(3-3)) < (1LL<<19) ) { // The granularity of QWORD pointers is 8, arbitrarily choosing 524,288, Ugh, bug, forgot to cast ((uint64_t)Right-(uint64_t)Left)>>3
						Pivot = *PR;
						// 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP [
						for (;PR < Jndx;) {
							PR = PR + 1;
							if (Pivot > *PR) { // *PL == Pivot
								//AKKODAH_swapUnconditional (PL, PR); // Dummy me, using Pivot instead of *PL saves... one 'MOV'	//]-----+
								//BYPASSSWAP:												//]	|
								*PL=*PR; *PR=Pivot;											//<-----/
								PL = PL + 1;
							} else if (Pivot < *PR) {
								for (;Pivot < *Jndx;) {
									Jndx = Jndx - 1;
								}
								//AKKODAH_SwapConditional_ifXbY_BUGGY((uint64_t)PR, (uint64_t)Jndx, PR, Jndx);	//] Slow! Therefore moving it outwith the loop, see Leftover:
								//Jndx = Jndx - 1;								//]-----+
								//PR = PR - 1;									//]	|
																		//]<----/
								AKKODAH_swapUnconditional (PR, Jndx);	//] //CAUTION: Inhere, PR could be BIGGER than Jndx (i.e.  Jndx == PR-1), it needs Leftover:
								Jndx = Jndx - 1;			//]-----+
								PR = PR - 1;				//]	|
								//UNWIND (it doesn't need Leftover:):	//]<----/
								/*
								if (PR > Jndx) {PR--; break;} // It means *Jndx == Pivot because Jndx == PR-1
								Temporary=*Jndx; // Temporary is LE i.e. LESS-or-EQUAL to Pivot
								*Jndx=*(PR);
								Jndx = Jndx - 1;
								//if (Pivot == Temporary) {*PR=Pivot;} //{*PR=Temporary;}	//]
								//else {*PL=Temporary; *PR=Pivot; PL = PL + 1;}			//]----+
																//]<---/
								*(PR)=Pivot;
								if (Pivot > Temporary) {*PL=Temporary; PL = PL + 1;}
								*/
							}
						} //for (;PR < Jndx;) {
						// 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP]
						//if (PR > Jndx) {								//]
						//	AKKODAH_swapUnconditional (&QWORDS[PR+1], &QWORDS[Jndx+1]);		//]-----+
						//}										//]	|
						//Leftover:									//<-----/ Kinda 'Desperate Measures' - debranchifying the mainloop as much as possible
						AKKODAH_SwapConditional_ifXbY_BUGGY((uint64_t)Jndx, (uint64_t)PR, PR+1, Jndx+1);
						// 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP ]
						Jndx = PL - 1;
						Indx = PR + 1;
						#ifdef Commence_OpenMP
							#pragma omp critical
						#endif
							{
							if ( (Jndx-Left)>0 && (Right-Indx)>0 ) {
								if ( ((Jndx-Left)+1) > ((Right-Indx)+1) ) printf("Partition Ratio: %.2f (ideal being 1 i.e. Left:Right=1.00)\n", ( (double)((Jndx-Left)+1)/((Right-Indx)+1) ) );
								else printf("Partition Ratio: %.2f (ideal being 1 i.e. Left:Right=1.00)\n", (double)((Right-Indx)+1)/((Jndx-Left)+1) );
							}
							}
						if (i==0) {Jndx127=Jndx; Indx127=Indx;}
						if (i==1) {Jndx128=Jndx; Indx128=Indx;}
					} //if (Right-Left > 0) { // Needed since 'Left > Right' could be true!
				}//switch (Right-Left) { // The name of the game "jmp rax"
			} //for (i=0; i<=1; i++) {
			} // pragma ]
		printf("Thread #1 of 4 sorting %llu..%llu, partition size=%llu\n",(unsigned long long)(uint64_t)Left127, (unsigned long long)(uint64_t)Jndx127, (unsigned long long)(uint64_t)Jndx127-(unsigned long long)(uint64_t)Left127);
		printf("Thread #2 of 4 sorting %llu..%llu, partition size=%llu\n",(unsigned long long)(uint64_t)Indx127, (unsigned long long)(uint64_t)Right127, (unsigned long long)(uint64_t)Right127-(unsigned long long)(uint64_t)Indx127);
		printf("Thread #3 of 4 sorting %llu..%llu, partition size=%llu\n",(unsigned long long)(uint64_t)Left128, (unsigned long long)(uint64_t)Jndx128, (unsigned long long)(uint64_t)Jndx128-(unsigned long long)(uint64_t)Left128);
		printf("Thread #4 of 4 sorting %llu..%llu, partition size=%llu\n",(unsigned long long)(uint64_t)Indx128, (unsigned long long)(uint64_t)Right128, (unsigned long long)(uint64_t)Right128-(unsigned long long)(uint64_t)Indx128);
		#ifdef Commence_OpenMP
			#pragma omp parallel sections
		#endif
			{
			#ifdef Commence_OpenMP
				#pragma omp section
			#endif
				{
				Quicksort_Magnetica_v18_Koffcheg(Left127, Jndx127);
				}
			#ifdef Commence_OpenMP
				#pragma omp section
			#endif
				{
				Quicksort_Magnetica_v18_Koffcheg(Indx127, Right127);
				}
			#ifdef Commence_OpenMP
				#pragma omp section
			#endif
				{
				Quicksort_Magnetica_v18_Koffcheg(Left128, Jndx128);
				}
			#ifdef Commence_OpenMP
				#pragma omp section
			#endif
				{
				Quicksort_Magnetica_v18_Koffcheg(Indx128, Right128);
				}
			}
	//} //if (!is_sorted_Wojciech (Left, (uint64_t)(Right-Left+1))) {
} //void QuickSortAkkoda (uint64_t *Left, uint64_t *Right) {
// Akkodah_v3.h ]
