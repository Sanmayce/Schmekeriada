// https://gcc.gnu.org/bugzilla/show_bug.cgi?id=106236
// Magnetica_v18.h[
//    _____                                __  .__               
//   /     \ _____     ____   ____   _____/  |_|__| ____ _____   
//  /  \ /  \\__  \   / ___\ /    \_/ __ \   __\  |/ ___\\__  \
// /    Y    \/ __ \_/ /_/  >   |  \  ___/|  | |  \  \___ / __ \_
// \____|__  (____  /\___  /|___|  /\___  >__| |__|\___  >____  /
//         \/     \//_____/      \/     \/             \/     \/
// Written by Sanmayce, 2022-Jul-07
// Feature #1: For chunks with 12.. keys, using median of triad i.e. 1+1+1=3;
// Feature #2: For chunks with 2..11 keys, using Branchless_Bubblesort;
// Feature #3: Initially running Insertionsort, on encountering a fourth "mismatch" fallback to Quicksort - to better fully sorted scenario;
#define Mv18
#define M18_InsertionsortTHRESHOLD 0
#define M18_StackEntries 18001 //(18001-1)/2=9000 pairs/recursions
#define MINKaze(x,y) (x<y?x:y)
#define MAXKaze(x,y) (x<y?y:x)
#define MINKazeSO(x, y) (y ^ ((x ^ y) & -(x < y)))
#define MAXKazeSO(x, y) (x ^ ((x ^ y) & -(x < y)))
void M18_swapUnconditional(uint64_t *a, uint64_t *b) { uint64_t t = *a; *a = *b; *b = t; }
void M18_swapUnconditionalPAIR(uint64_t *a, uint64_t *b, uint64_t NumberOfLFs) { 
uint64_t t2 =  *(a+NumberOfLFs); *(a+NumberOfLFs) = *(b+NumberOfLFs); *(b+NumberOfLFs) = t2;
uint64_t t = *a;  *a = *b;  *b = t; }
void M18_SwapConditional_ifXbY_BUGGYPAIR (int64_t X, int64_t Y, uint64_t *a, uint64_t *b, uint64_t NumberOfLFs) { //2022-Oct-18
int64_t XYsgnd = X-Y; 
int64_t ABsgnd= *(a+NumberOfLFs)-*(b+NumberOfLFs); ABsgnd = ABsgnd&(XYsgnd >> 63); *(a+NumberOfLFs) = *(a+NumberOfLFs)-ABsgnd; *(b+NumberOfLFs) = *(b+NumberOfLFs)+ABsgnd;
int64_t ABsgnd2= *a-*b; ABsgnd2 = ABsgnd2&(XYsgnd >> 63); *a = *a-ABsgnd2; *b = *b+ABsgnd2; } // if X<Y then swap
void M18_swapconditional1_BUGGY (uint64_t *b, uint64_t *a) { int64_t ABsgnd= *a-*b; ABsgnd=ABsgnd&(ABsgnd >> 63);*a = *a-ABsgnd; *b = *b+ABsgnd; } // if a<b then swap
void M18_swapconditional1 (uint64_t *a, uint64_t *b) { uint64_t aOLD = *a; uint64_t bOLD = *b; *a = MINKaze(aOLD,bOLD); *b = MAXKaze(aOLD,bOLD); }
void M18_swapconditional2 (uint64_t *a, uint64_t *b) { uint64_t aOLD = *a; uint64_t bOLD = *b; *a = MINKazeSO(aOLD,bOLD); *b = MAXKazeSO(aOLD,bOLD); }
void M18_SwapConditional_ifXbY_BUGGY (int64_t X, int64_t Y, uint64_t *a, uint64_t *b) { int64_t XYsgnd = X-Y; int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&(XYsgnd >> 63); *a = *a-ABsgnd; *b = *b+ABsgnd; } // if X<Y then swap
void M18_swapConditionalXY_Akkodah (uint64_t X, uint64_t Y, uint64_t *a, uint64_t *b) { int64_t XYsgnd = -(X<Y); int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&XYsgnd; *a = *a-ABsgnd; *b = *b+ABsgnd; } // if X<Y then swap
int M18_SwapConditional_ifXbY_BUGGY_DidWeSwap (int64_t X, int64_t Y, uint64_t *a, uint64_t *b) { int64_t XYsgnd = X-Y; int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&(XYsgnd >> 63); *a = *a-ABsgnd; *b = *b+ABsgnd; return (XYsgnd >> 63); } // if X<Y then swap
int M18_swapConditionalXY_Akkodah_DidWeSwap (uint64_t X, uint64_t Y, uint64_t *a, uint64_t *b) { int64_t XYsgnd = -(X<Y); int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&XYsgnd; *a = *a-ABsgnd; *b = *b+ABsgnd; return XYsgnd; } // if X<Y then swap
//   ________ .__                                      .___                
//  /  _____/ |  |   __ __ ______    ____    ____    __| _/___  __________ 
// /   \  ___ |  |  |  |  \\____ \ _/ __ \  /    \  / __ | \  \/  /\_  __ \
// \    \_\  \|  |__|  |  /|  |_> >\  ___/ |   |  \/ /_/ |  >    <  |  | \/
//  \______  /|____/|____/ |   __/  \___  >|___|  /\____ | /__/\_ \ |__|   
//         \/              |__|         \/      \/      \/       \/
// Written by Sanmayce, 2022-Jul-07
void Quicksort_Magnetica_v18_Glupendxr (uint64_t* Left, uint64_t* Right) {
        uint64_t* Stack[M18_StackEntries];
        uint64_t *Indx, *Jndx, *PL, *PR;
        uint64_t StackPtr = 0;
        uint64_t Pivot;
        StackPtr++; Stack[StackPtr] = Left; // M18_StackEntries minimum is 3 i.e. Stack[0]=unused,Stack[1],Stack[2] i.e. one entry/pair
        StackPtr++; Stack[StackPtr] = Right;
        do { //while ( (StackPtr != 0) );
                Right = Stack[StackPtr];
                Left = Stack[StackPtr - 1];
                StackPtr = StackPtr - 2;
                for(;(M18_InsertionsortTHRESHOLD < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
                                        Jndx = Right;
                                        Pivot = *(Left + ((Right-Left)>>1));                  //]<----------+
                                        PL = Left;                                            //]           |
                                        for (;*PL < Pivot; PL++) {                            //]           |
                                        }                                                     //]           |
                                        PR = PL;                                              //]           |
                                        M18_swapUnconditional (Left + ((Right-Left)>>1), PL); //]           |
                                        //                                                                  |
                                        //PL = Left;                                                //]-----+
                                        //PR = Left;                                                //]
                                        //M18_swapUnconditional (Left + ((Right-Left)>>1), Left+0); //]
                                        //Pivot = *PR;                                              //]
/*
                                        // 'Magnetica' partitioning, mainloop rev.7p [
                                        for (;;) {
                                                for (;Pivot < *Jndx; Jndx--) {
                                                }
                                                // Jndx could be PR i.e. PR == Jndx
                                                if (PR == Jndx) break;
                                                //if (PR == Jndx) goto KUH; //] QS_bench_r14_CLANG_14.0.1_rev5bypass.exe Glupendxr DNA Done in 240/59 seconds.
                                                //PR++;                     //]<----+
                                                //PR = PR + !!(PR - Jndx); //]      |
                                                //PR = PR + (PR != Jndx);  //]------+ QS_bench_r14_CLANG_14.0.1_rev5bypass.exe Glupendxr DNA Done in 256/63 seconds.
                                                PR++;                                   
                                                M18_swapUnconditional (PR, Jndx);
                                                // Inhere Pivot is either == or > *(PR) when PR<Jndx
                                                if (Pivot > *(PR)) {
                                                        *PL=*(PR); PL++; *(PR)=Pivot;                                                                   
                                                }
                                        }
                                        //M18_SwapConditional_ifXbY_BUGGY((uint64_t)Jndx, (uint64_t)PR, PR, Jndx); //] QS_bench_r14_CLANG_14.0.1_rev5bypass.exe Glupendxr DNA Done in 239/57 seconds.
                                        //PR = PR - (PR > Jndx);                                                   //]
                                        //PR = PR + M18_SwapConditional_ifXbY_BUGGY_DidWeSwap((uint64_t)Jndx, (uint64_t)PR, PR, Jndx); //] QS_bench_r14_CLANG_14.0.1_rev5bypass.exe Glupendxr DNA Done in 233/57 seconds.
                                        KUH:;
                                        // 'Magnetica' partitioning, mainloop rev.7p ]
*/
// The core loop (rev.7p) of Quicksort_Magnetica_v18_Glupendxr, 20 instructions, 3 jumps (2 conditional, 1 unconditional), the 4th is for exit - not counted:
/*
.LBB186_7:                       ]<------+                               
	movq	%rdi, (%rdx)             |
	movq	%rdx, %rcx               |
	.p2align	4, 0x90          |
.LBB186_8:                      ]<-----+ |                         
	addq	$8, %rax               | |
	.p2align	4, 0x90        | |
.LBB186_9:                     ]<--+   | |         
	movq	-8(%rax), %rbx     |   | |
	addq	$-8, %rax          |   | |
	cmpq	%rbx, %rdi         |   | |
	jb	.LBB186_9      ]---+   | |
# %bb.10:                              | |      
	cmpq	%rcx, %rax             | |
	je	.LBB186_13             | |
# %bb.11:                              | |    
	leaq	8(%rcx), %rdx          | |
	movq	8(%rcx), %r14          | |
	movq	%rbx, 8(%rcx)          | |
	movq	%r14, (%rax)           | |
	movq	8(%rcx), %rbx          | |
	movq	%rdx, %rcx             | |
	cmpq	%rbx, %rdi             | |
	jbe	.LBB186_8       ]------+ |
# %bb.12:                                |   
	movq	%rbx, (%r11)             |
	addq	$8, %r11                 |
	jmp	.LBB186_7        ]-------+                               
*/

                                        // 'Magnetica' partitioning, mainloop rev.7pGOTO [
                                        Kuhendxr:; //for (;;) {
                                                if (Pivot < *Jndx) { Jndx--; goto Kuhendxr;} //for (;Pivot < *Jndx; Jndx--) {}
												// Jndx could be PR i.e. PR == Jndx
                                                //if (PR == Jndx) break;
                                                if (PR == Jndx) goto KUH; //] QS_bench_r14_CLANG_14.0.1_rev5bypass.exe Glupendxr DNA Done in 240/59 seconds.
                                                //PR++;                     //]<----+
                                                //PR = PR + !!(PR - Jndx); //]      |
                                                //PR = PR + (PR != Jndx);  //]------+ QS_bench_r14_CLANG_14.0.1_rev5bypass.exe Glupendxr DNA Done in 256/63 seconds.
                                                PR++;                                   
                                                M18_swapUnconditional (PR, Jndx);
                                                // Inhere Pivot is either == or > *(PR) when PR<Jndx
                                                //if (Pivot > *(PR)) {
                                                //        *PL=*(PR); PL++; *(PR)=Pivot;                                                                   
                                                //}
												if (Pivot <= *(PR)) goto Kuhendxr;
                                                *PL=*(PR); PL++; *(PR)=Pivot;                                                                   
                                        goto Kuhendxr; //}
                                        //M18_SwapConditional_ifXbY_BUGGY((uint64_t)Jndx, (uint64_t)PR, PR, Jndx); //] QS_bench_r14_CLANG_14.0.1_rev5bypass.exe Glupendxr DNA Done in 239/57 seconds.
                                        //PR = PR - (PR > Jndx);                                                   //]
                                        //PR = PR + M18_SwapConditional_ifXbY_BUGGY_DidWeSwap((uint64_t)Jndx, (uint64_t)PR, PR, Jndx); //] QS_bench_r14_CLANG_14.0.1_rev5bypass.exe Glupendxr DNA Done in 233/57 seconds.
                                        KUH:;
                                        // 'Magnetica' partitioning, mainloop rev.7pGOTO ]

// [kaze@kaze Quicksort_says_19_BUGZILLA++++]$ gcc -v
// gcc version 12.1.1 20220507 (Red Hat 12.1.1-1) (GCC) 
// [kaze@kaze Quicksort_says_19_BUGZILLA++++]$ gcc -g -static -mavx2 -O3 -m64 -fomit-frame-pointer Schmekeriada.c -o Schmekeriada_GCC_12.1.1_rev5bypass.elf.asm -D_N_HIGH_PRIORITY_GCC -Drev5bypass -fopenmp -DCommence_OpenMP -D_POSIX_ENVIRONMENT_
// [kaze@kaze Quicksort_says_19_BUGZILLA++++]$ objdump -d -M intel Schmekeriada_GCC_12.1.1_rev5bypass.elf>d.txt
// The core loop (rev.7pGOTO) of Quicksort_Magnetica_v18_Glupendxr:
/*
  4275b0:	48 8b 3a             	mov    rdi,QWORD PTR [rdx]
  4275b3:	48 39 fe             	cmp    rsi,rdi
  4275b6:	72 33                	jb     4275eb <Quicksort_Magnetica_v18_Glupendxr+0xab>
  4275b8:	4c 8d 40 08          	lea    r8,[rax+0x8]
  4275bc:	48 39 c2             	cmp    rdx,rax
  4275bf:	74 3f                	je     427600 <Quicksort_Magnetica_v18_Glupendxr+0xc0>
  4275c1:	4c 8b 48 08          	mov    r9,QWORD PTR [rax+0x8]
  4275c5:	48 89 78 08          	mov    QWORD PTR [rax+0x8],rdi
  4275c9:	4c 89 0a             	mov    QWORD PTR [rdx],r9
  4275cc:	48 8b 78 08          	mov    rdi,QWORD PTR [rax+0x8]
  4275d0:	48 39 f7             	cmp    rdi,rsi
  4275d3:	73 23                	jae    4275f8 <Quicksort_Magnetica_v18_Glupendxr+0xb8>
  4275d5:	48 89 39             	mov    QWORD PTR [rcx],rdi
  4275d8:	48 83 c1 08          	add    rcx,0x8
  4275dc:	48 89 70 08          	mov    QWORD PTR [rax+0x8],rsi
  4275e0:	48 8b 3a             	mov    rdi,QWORD PTR [rdx]
  4275e3:	4c 89 c0             	mov    rax,r8
  4275e6:	48 39 fe             	cmp    rsi,rdi
  4275e9:	73 cd                	jae    4275b8 <Quicksort_Magnetica_v18_Glupendxr+0x78>
  4275eb:	48 83 ea 08          	sub    rdx,0x8
  4275ef:	eb bf                	jmp    4275b0 <Quicksort_Magnetica_v18_Glupendxr+0x70>
  4275f1:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
  4275f8:	4c 89 c0             	mov    rax,r8
  4275fb:	eb b3                	jmp    4275b0 <Quicksort_Magnetica_v18_Glupendxr+0x70>
  4275fd:	0f 1f 00             	nop    DWORD PTR [rax]
  427600:	
*/

// [kaze@kaze Quicksort_says_19_BUGZILLA++++]$ clang -v
// clang version 14.0.0 (Fedora 14.0.0-1.fc36)
// [kaze@kaze Quicksort_says_19_BUGZILLA++++]$ clang -g -mavx2 -O3 Schmekeriada.c -o Schmekeriada_CLANG_14.0_rev5bypass.elf -D_N_HIGH_PRIORITY_GCC -Drev5bypass -fopenmp -DCommence_OpenMP -D_POSIX_ENVIRONMENT_
// [kaze@kaze Quicksort_says_19_BUGZILLA++++]$ objdump -d -M intel Schmekeriada_CLANG_14.0_rev5bypass.elf>d.txt
// The core loop (rev.7pGOTO) of Quicksort_Magnetica_v18_Glupendxr:
/*
  42aa70:	49 83 c3 f8          	add    r11,0xfffffffffffffff8                          ]<+
  42aa74:	49 8b 03             	mov    rax,QWORD PTR [r11]                               |  ]<----+
  42aa77:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]                          |        |
  42aa7e:	00 00                                                                            |        |
  42aa80:	49 39 c6             	cmp    r14,rax                                           | ]<--+  |
  42aa83:	72 eb                	jb     42aa70 <Quicksort_Magnetica_v18_Glupendxr+0xb0> ]-+     |  |
  42aa85:	4c 39 df             	cmp    rdi,r11                                                 |  |
  42aa88:	74 86                	je     42aa10 <Quicksort_Magnetica_v18_Glupendxr+0x50>         |  |
  42aa8a:	48 8d 5f 08          	lea    rbx,[rdi+0x8]                                           |  |
  42aa8e:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]                                 |  |
  42aa92:	48 89 47 08          	mov    QWORD PTR [rdi+0x8],rax                                 |  |
  42aa96:	49 89 0b             	mov    QWORD PTR [r11],rcx                                     |  |
  42aa99:	48 8b 57 08          	mov    rdx,QWORD PTR [rdi+0x8]                                 |  |
  42aa9d:	48 89 c8             	mov    rax,rcx                                                 |  |
  42aaa0:	48 89 df             	mov    rdi,rbx                                                 |  |
  42aaa3:	49 39 d6             	cmp    r14,rdx                                                 |  |
  42aaa6:	76 d8                	jbe    42aa80 <Quicksort_Magnetica_v18_Glupendxr+0xc0>     ]---+  |
  42aaa8:	49 89 17             	mov    QWORD PTR [r15],rdx                                        |
  42aaab:	49 83 c7 08          	add    r15,0x8                                                    |
  42aaaf:	4c 89 33             	mov    QWORD PTR [rbx],r14                                        |
  42aab2:	48 89 df             	mov    rdi,rbx                                                    |
  42aab5:	eb bd                	jmp    42aa74 <Quicksort_Magnetica_v18_Glupendxr+0xb4>      ]-----+
*/
// clang -mavx2 -S -O3 Schmekeriada.c -o Schmekeriada_CLANG_14.0_rev5bypass.elf.asm -D_N_HIGH_PRIORITY_GCC -Drev5bypass -fopenmp -DCommence_OpenMP -D_POSIX_ENVIRONMENT_
// The core loop (rev.7pGOTO) of Quicksort_Magnetica_v18_Glupendxr, 20 instructions, 3 jumps (2 conditional, 1 unconditional), the 4th is for exit - not counted:
/*
.LBB186_9:                     ]<+             
	addq	$-8, %r11        |
.LBB186_7:                       |   ]<----+       
	movq	(%r11), %rax     |         |
	.p2align	4, 0x90  |         |
.LBB186_8:                       |  ]<--+  |
	cmpq	%rax, %r14       |      |  |
	jb	.LBB186_9      ]-+      |  |
# %bb.10:                               |  |  
	cmpq	%r11, %rdi              |  |
	je	.LBB186_13              |  |
# %bb.11:                               |  |  
	leaq	8(%rdi), %rbx           |  |
	movq	8(%rdi), %rcx           |  |
	movq	%rax, 8(%rdi)           |  |
	movq	%rcx, (%r11)            |  |
	movq	8(%rdi), %rdx           |  |
	movq	%rcx, %rax              |  |
	movq	%rbx, %rdi              |  |
	cmpq	%rdx, %r14              |  |
	jbe	.LBB186_8           ]---+  |
# %bb.12:                                  | 
	movq	%rdx, (%r15)               |
	addq	$8, %r15                   |
	movq	%r14, (%rbx)               |
	movq	%rbx, %rdi                 |
	jmp	.LBB186_7            ]-----+
*/

                                        StackPtr = StackPtr + 2;
                                        Stack[StackPtr - 1] = PR + 1;
                                        Stack[StackPtr] = Right;
                                        Right = PL - 1;
                } //for(;(M18_InsertionsortTHRESHOLD < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
        } while ( (StackPtr != 0) );
}
//QS_bench_r14_ICL19.0_rev5bypass.exe Glupendxr DNA; Done in 243/32 seconds.
//QS_bench_r14_CLANG_14.0.1_rev5bypass.exe Glupendxr DNA; Done in 236/33 seconds.
//QS_bench_r14_GCC11.3.0_rev5bypass.exe Glupendxr DNA; Done in 238/44 seconds.
// clang_14.0.1 -O3 -mavx2 -S -fverbose-asm
/*
// 'Magnetica' partitioning, mainloop rev.7p [
.LBB181_7:                         ]<-----+
        movq    %rax, (%rsi)              |
        movq    %rsi, %rdi                |
        .p2align        4, 0x90           |
.LBB181_8:                        ]<--+   |
        addq    $8, %rcx              |   |
        .p2align        4, 0x90       |   |
.LBB181_9:                       ]<-+ |   |
        movq    -8(%rcx), %rbx      | |   |
        addq    $-8, %rcx           | |   |
        cmpq    %rbx, %rax          | |   |
        jb      .LBB181_9        ]--+ |   |
        cmpq    %rdi, %rcx            |   |
        je      .LBB181_13            |   |
        leaq    8(%rdi), %rsi         |   |
        movq    8(%rdi), %r14         |   |
        movq    %rbx, 8(%rdi)         |   |
        movq    %r14, (%rcx)          |   |
        movq    8(%rdi), %rbx         |   |
        movq    %rsi, %rdi            |   |
        cmpq    %rbx, %rax            |   |
        jbe     .LBB181_8         ]---+   |
        movq    %rbx, (%r11)              |
        addq    $8, %r11                  |
        jmp     .LBB181_7          ]------+
// 'Magnetica' partitioning, mainloop rev.7p ]
*/
// gcc_11.3.0 -S -O3 -mavx2 -m64 -static -fomit-frame-pointer
/*
// 'Magnetica' partitioning, mainloop rev.7p [
.L5597:                        ]<----------------------+<-+
        cmpq    %rcx, %r8                              |  |
        jb      .L5598          ]-------------------+  |  |
.L5609:                       ]<--+                 |  |  |
        leaq    8(%rax), %r11     |                 |  |  |
        cmpq    %rax, %rdx        |                 |  |  |
        je      .L5599            |                 |  |  |
        movq    8(%rax), %r10     |                 |  |  |
        movq    %rcx, 8(%rax)     |                 |  |  |
        movq    %r10, (%rdx)      |                 |  |  |
        movq    8(%rax), %rcx     |                 |  |  |
        cmpq    %r8, %rcx         |                 |  |  |
        jnb     .L5605            | ]---+           |  |  |
        movq    %rcx, (%r9)       |     |           |  |  |
        addq    $8, %r9           |     |           |  |  |
        movq    %r8, 8(%rax)      |     |           |  |  |
        movq    (%rdx), %rcx      |     |           |  |  |
        movq    %r11, %rax        |     |           |  |  |
        cmpq    %rcx, %r8         |     |           |  |  |
        jnb     .L5609        ]---+     |           |  |  |
.L5598:                                 | ]<--------+  |  |
        movq    -8(%rdx), %rcx          |              |  |
        subq    $8, %rdx                |              |  |
        jmp     .L5597                  | ]------------+  |
        .p2align 4,,10                  |                 |
        .p2align 3                      |                 |
.L5605:                        ]<-------+                 |
        movq    %r10, %rcx                                |
        movq    %r11, %rax                                |
        jmp     .L5597         ]--------------------------+
// 'Magnetica' partitioning, mainloop rev.7p ]
*/

// __________         .__                   .__                      __    
// \______   \_____   |  |  ___  ___  ____  |  |__    ____    ____  |  | _______   
//  |    |  _/\__  \  |  |  \  \/  /_/ ___\ |  |  \  /  _ \  /    \ |  |/ /\__  \
//  |    |   \ / __ \_|  |__ >    < \  \___ |   Y  \(  <_> )|   |  \|    <  / __ \_
//  |______  /(____  /|____//__/\_ \ \___  >|___|  / \____/ |___|  /|__|_ \(____  /
//         \/      \/             \/     \/      \/              \/      \/     \/
// Written by Sanmayce, 2022-Jul-07
void Quicksort_Magnetica_v18_Balxchonka (uint64_t* Left, uint64_t* Right) {
        uint64_t* Stack[M18_StackEntries];
        uint64_t *Indx, *Jndx, *PL, *PR;
        uint64_t StackPtr = 0;
        uint64_t Pivot;
        StackPtr++; Stack[StackPtr] = Left; // M18_StackEntries minimum is 3 i.e. Stack[0]=unused,Stack[1],Stack[2] i.e. one entry/pair
        StackPtr++; Stack[StackPtr] = Right;
        do { //while ( (StackPtr != 0) );
                Right = Stack[StackPtr];
                Left = Stack[StackPtr - 1];
                StackPtr = StackPtr - 2;
                for(;(M18_InsertionsortTHRESHOLD < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
                                        Jndx = Right;
                                        Pivot = *(Left + ((Right-Left)>>1));                  //]<----------+
                                        PL = Left;                                            //]           |
                                        for (;*PL < Pivot; PL++) {                            //]           |
                                        }                                                     //]           |
                                        PR = PL;                                              //]           |
                                        M18_swapUnconditional (Left + ((Right-Left)>>1), PL); //]           |
                                        //                                                                  |
                                        //PL = Left;                                                //]-----+
                                        //PR = Left;                                                //]
                                        //M18_swapUnconditional (Left + ((Right-Left)>>1), Left+0); //]
                                        //Pivot = *PR;                                              //]
                                        for (;PR < Jndx;) {
                                                PR = PR + 1;
                                                if (Pivot > *PR) { // *PL == Pivot
                                                        //M18_swapUnconditional (PL, PR); // Dummy me, using Pivot instead of *PL saves... one 'MOV'    //]-----+
                                                        //BYPASSSWAP:                                                                                   //]     |
                                                        *PL=*PR; *PR=Pivot;                                                                             //<-----/
                                                        PL = PL + 1;
                                                } else if (Pivot < *PR) {
                                                        for (;Pivot < *Jndx;) {
                                                                Jndx = Jndx - 1;
                                                        }
                                                        //M18_SwapConditional_ifXbY_BUGGY((uint64_t)PR, (uint64_t)Jndx, PR, Jndx);      //] Slow! Therefore moving it outwith the loop, see Leftover:
                                                        //Jndx = Jndx - 1;                                                              //]-----+
                                                        //PR = PR - 1;                                                                  //]     |
                                                                                                                                        //]<----/
                                                        M18_swapUnconditional (PR, Jndx);       //] //CAUTION: Inhere, PR could be BIGGER than Jndx (i.e.  Jndx == PR-1), it needs Leftover:
                                                        Jndx = Jndx - 1;                        //]-----+
                                                        PR = PR - 1;                            //]     |
                                                        //UNWIND (it doesn't need Leftover:):   //]<----/
                                                        /*
                                                        if (PR > Jndx) {PR--; break;} // It means *Jndx == Pivot because Jndx == PR-1
                                                        Temporary=*Jndx; // Temporary is LE i.e. LESS-or-EQUAL to Pivot
                                                        *Jndx=*(PR);
                                                        Jndx = Jndx - 1;
                                                        //if (Pivot == Temporary) {*PR=Pivot;} //{*PR=Temporary;}       //]
                                                        //else {*PL=Temporary; *PR=Pivot; PL = PL + 1;}                 //]----+
                                                                                                                        //]<---/
                                                        *(PR)=Pivot;
                                                        if (Pivot > Temporary) {*PL=Temporary; PL = PL + 1;}
                                                        */
                                                }
                                        }
                                        //if (PR > Jndx) {                                                              //]
                                        //      M18_swapUnconditional (&QWORDS[PR+1], &QWORDS[Jndx+1]);                 //]-----+
                                        //}                                                                             //]     |
                                        //Leftover:                                                                     //<-----/ Kinda 'Desperate Measures' - debranchifying the mainloop as much as possible
                                        M18_SwapConditional_ifXbY_BUGGY((uint64_t)Jndx, (uint64_t)PR, PR+1, Jndx+1);
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP ]
                                        StackPtr = StackPtr + 2;
                                        Stack[StackPtr - 1] = PR + 1;
                                        Stack[StackPtr] = Right;
                                        Right = PL - 1;
                } //for(;(M18_InsertionsortTHRESHOLD < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
        } while ( (StackPtr != 0) );
}
// gcc version 11.2.1 20211203 (Red Hat 11.2.1-7) (GCC) 
// gcc -S -O3 -m64 -static -fomit-frame-pointer ...
/*
...
*/
//  ____  __.        _____   _____        .__                     
// |    |/ _| ____ _/ ____\_/ ____\ ____  |  |__    ____    ____  
// |      <  /  _ \\   __\ \   __\ / ___\ |  |  \ _/ __ \  / ___\
// |    |  \(  <_> )|  |    |  |  \  \___ |   Y  \\  ___/ / /_/  >
// |____|__ \\____/ |__|    |__|   \___  >|___|  / \___  >\___  /
//         \/                          \/      \/      \//_____/
// Written by Sanmayce, 2022-Jul-14
size_t M18_DidWeSwap (uint64_t *a) { size_t WhetherSwapIsNeeded = (*a > *(a+1)); uint64_t Temporary = *(a+(!WhetherSwapIsNeeded)); *a = *(a+WhetherSwapIsNeeded); *(a+1) = Temporary; return WhetherSwapIsNeeded; } // a and b=a+1 should be adjacent
/*
M18_DidWeSwap:
        movq    8(%rdi), %rdx
        movq    (%rdi), %rcx
        cmpq    %rcx, %rdx
        sbbq    %rax, %rax
        andl    $8, %eax
        cmpq    %rdx, %rcx
        movq    (%rdi,%rax), %xmm0
        setbe   %dl
        seta    %al
        movzbl  %dl, %edx
        movzbl  %al, %eax
        movhps  (%rdi,%rdx,8), %xmm0
        movups  %xmm0, (%rdi)
        ret
*/
// FAST AVX512F CHECK [
// Tomasz Duda showed that following C++ code is nicely vectorized (works only for 4/16 or 4/32 i.e. uint32_t, not for uint64_t, when using AVX2, works for uint64_t with AVX512F only) by clang 9 and newer:
#define ScalarInBytes 8
#define VectorInBytes 64
// c:\QS_Collatz>clang -O3 -S -fverbose-asm -IC:\mingw64\lib\clang\14.0.1\include QS_bench_r14.c -o QS_bench_r14_CLANG_14.0.1_rev5bypass.exe.asm -D_N_HIGH_PRIORITY -Drev5bypass -static-openmp -fopenmp -mavx512f
/*
.LBB185_6:                              
        cmpq    %r8, %rax
        jae     .LBB185_2

        vmovdqu (%rcx,%rax,8), %xmm0
        vmovdqu 16(%rcx,%rax,8), %xmm1
        vmovdqu 32(%rcx,%rax,8), %xmm2
        vmovdqu 48(%rcx,%rax,8), %xmm3
        vinserti128     $1, %xmm3, %ymm2, %ymm4
        vmovq   64(%rcx,%rax,8), %xmm5          
        vinserti128     $1, %xmm5, %ymm3, %ymm3
        vpalignr        $8, %ymm4, %ymm3, %ymm3         
        vinserti128     $1, %xmm1, %ymm0, %ymm0
        vinserti128     $1, %xmm2, %ymm1, %ymm1
        vpalignr        $8, %ymm0, %ymm1, %ymm0         
        vinserti64x4    $1, %ymm3, %zmm0, %zmm0
        vpcmpltuq       (%rcx,%rax,8), %zmm0, %k0
        addq    $8, %rax
        kmovw   %k0, %r9d
        testb   %r9b, %r9b
        je      .LBB185_6

*/
inline int is_sorted_Wojciech (uint64_t* a, uint64_t n) {
uint64_t i = 0;
if (n > VectorInBytes/ScalarInBytes) {
        for (/**/; i < n - VectorInBytes/ScalarInBytes; i += VectorInBytes/ScalarInBytes) {
                if ((a[i] > a[i + 1]) | (a[i + 1] > a[i + 2]) | (a[i + 2] > a[i + 3]) | (a[i + 3] > a[i + 4]) | (a[i + 4] > a[i + 5]) | (a[i + 5] > a[i + 6]) | (a[i + 6] > a[i + 7]) | (a[i + 7] > a[i + 8])) {
                        return 0; //return false;
                }
        }
}
        for (/**/; i + 1 < n; i++) {
                if (a[i] > a[i + 1])
                        return 0; //return false;
        }
return !0; //return true;
}
// FAST AVX512F CHECK ]
void Quicksort_Magnetica_v18_Koffcheg (uint64_t* Left, uint64_t* Right) {
        uint64_t* Stack[M18_StackEntries];
        //uint64_t* TheMiddleOfMiddle;
        //int StackNotOverflow;
        uint64_t* LeftBackup = Left;
        uint64_t* RightBackup = Right;
        uint64_t *Indx, *Jndx, *PL, *PR;
        uint64_t StackPtr = 0;
        //register uint64_t Temporary;
        register uint64_t x0,x1,x2,x3,x4,x5,x6,x7,x8;
        uint64_t Pivot;
        int o0,o1,o2,o3,o4,o5,o6,o7,o8;
        int64_t WhetherSwapIsNeeded;
        int M18_InsertionsortTHRESHOLDcoffin = 0;//17; // or 0 for switch section
//if (!is_sorted_Wojciech (Left, (uint64_t)(Right-Left+1))) {
        StackPtr++; Stack[StackPtr] = Left; // M18_StackEntries minimum is 3 i.e. Stack[0]=unused,Stack[1],Stack[2] i.e. one entry/pair
        StackPtr++; Stack[StackPtr] = Right;
        do { //while ( (StackPtr != 0) );
                Right = Stack[StackPtr];
                Left = Stack[StackPtr - 1];
                StackPtr = StackPtr - 2;
                for(;(M18_InsertionsortTHRESHOLDcoffin < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
                        switch (Right-Left) { // The name of the game "jmp rax"
                              // Looking at the disassembly of CLANG, 11 GP registers are used, no problema for 11 elements:
                              //case 12: // sorting 13 elements
                              //      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2)); M18_swapconditional1((Left+2),(Left+3)); M18_swapconditional1((Left+3),(Left+4)); M18_swapconditional1((Left+4),(Left+5)); M18_swapconditional1((Left+5),(Left+6)); M18_swapconditional1((Left+6),(Left+7)); M18_swapconditional1((Left+7),(Left+8)); M18_swapconditional1((Left+8),(Left+9)); M18_swapconditional1((Left+9),(Left+10)); M18_swapconditional1((Left+10),(Left+11)); M18_swapconditional1((Left+11),(Left+12));
                              //case 11: // sorting 12 elements
                              //      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2)); M18_swapconditional1((Left+2),(Left+3)); M18_swapconditional1((Left+3),(Left+4)); M18_swapconditional1((Left+4),(Left+5)); M18_swapconditional1((Left+5),(Left+6)); M18_swapconditional1((Left+6),(Left+7)); M18_swapconditional1((Left+7),(Left+8)); M18_swapconditional1((Left+8),(Left+9)); M18_swapconditional1((Left+9),(Left+10)); M18_swapconditional1((Left+10),(Left+11));
                              case 10: // sorting 11 elements
                                      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2)); M18_swapconditional1((Left+2),(Left+3)); M18_swapconditional1((Left+3),(Left+4)); M18_swapconditional1((Left+4),(Left+5)); M18_swapconditional1((Left+5),(Left+6)); M18_swapconditional1((Left+6),(Left+7)); M18_swapconditional1((Left+7),(Left+8)); M18_swapconditional1((Left+8),(Left+9)); M18_swapconditional1((Left+9),(Left+10));
                              case 9: // sorting 10 elements
                                      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2)); M18_swapconditional1((Left+2),(Left+3)); M18_swapconditional1((Left+3),(Left+4)); M18_swapconditional1((Left+4),(Left+5)); M18_swapconditional1((Left+5),(Left+6)); M18_swapconditional1((Left+6),(Left+7)); M18_swapconditional1((Left+7),(Left+8)); M18_swapconditional1((Left+8),(Left+9));
                              case 8: // sorting 9 elements
                                      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2)); M18_swapconditional1((Left+2),(Left+3)); M18_swapconditional1((Left+3),(Left+4)); M18_swapconditional1((Left+4),(Left+5)); M18_swapconditional1((Left+5),(Left+6)); M18_swapconditional1((Left+6),(Left+7)); M18_swapconditional1((Left+7),(Left+8));
                              case 7: // sorting 8 elements
                                      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2)); M18_swapconditional1((Left+2),(Left+3)); M18_swapconditional1((Left+3),(Left+4)); M18_swapconditional1((Left+4),(Left+5)); M18_swapconditional1((Left+5),(Left+6)); M18_swapconditional1((Left+6),(Left+7));
                              case 6: // sorting 7 elements
                                      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2)); M18_swapconditional1((Left+2),(Left+3)); M18_swapconditional1((Left+3),(Left+4)); M18_swapconditional1((Left+4),(Left+5)); M18_swapconditional1((Left+5),(Left+6));
                              case 5: // sorting 6 elements
                                      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2)); M18_swapconditional1((Left+2),(Left+3)); M18_swapconditional1((Left+3),(Left+4)); M18_swapconditional1((Left+4),(Left+5));
                              case 4: // sorting 5 elements
                                      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2)); M18_swapconditional1((Left+2),(Left+3)); M18_swapconditional1((Left+3),(Left+4));
                              case 3: // sorting 4 elements
                                      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2)); M18_swapconditional1((Left+2),(Left+3));
                              case 2: // sorting 3 elements
                                      M18_swapconditional1((Left+0),(Left+1)); M18_swapconditional1((Left+1),(Left+2));
                              case 1: // sorting 2 elements
                                      M18_swapconditional1((Left+0),(Left+1));
                                      goto DirtyBypass; //break;
                              default:
                                        //if ( (Right-Left) > (1LL<<15) ) {  // It's overkill [
                                        /*
                                                // sorting 3 elements [
                                                x0 = *(Left + (1*((Right-Left)>>2)-1) +0);
                                                x1 = *(Left + (1*((Right-Left)>>2)-1) +1);
                                                x2 = *(Left + (1*((Right-Left)>>2)-1) +2);
                                                o0 = (x0>x1)+(x0>x2);
                                                o1 = (x1>=x0)+(x1>x2);
                                                o2 = (0+1+2)-(o0+o1);
                                                *(Left+ (1*((Right-Left)>>2)-1) +o0)=x0;
                                                *(Left+ (1*((Right-Left)>>2)-1) +o1)=x1;
                                                *(Left+ (1*((Right-Left)>>2)-1) +o2)=x2;
                                                // sorting 3 elements ]
                                                // sorting 3 elements [
                                                x0 = *(Left + (2*((Right-Left)>>2)-1) +0);
                                                x1 = *(Left + (2*((Right-Left)>>2)-1) +1);
                                                x2 = *(Left + (2*((Right-Left)>>2)-1) +2);
                                                o0 = (x0>x1)+(x0>x2);
                                                o1 = (x1>=x0)+(x1>x2);
                                                o2 = (0+1+2)-(o0+o1);
                                                *(Left+ (2*((Right-Left)>>2)-1) +o0)=x0;
                                                *(Left+ (2*((Right-Left)>>2)-1) +o1)=x1;
                                                *(Left+ (2*((Right-Left)>>2)-1) +o2)=x2;
                                                // sorting 3 elements ]
                                                // sorting 3 elements [
                                                x0 = *(Left + (3*((Right-Left)>>2)-1) +0);
                                                x1 = *(Left + (3*((Right-Left)>>2)-1) +1);
                                                x2 = *(Left + (3*((Right-Left)>>2)-1) +2);
                                                o0 = (x0>x1)+(x0>x2);
                                                o1 = (x1>=x0)+(x1>x2);
                                                o2 = (0+1+2)-(o0+o1);
                                                *(Left+ (3*((Right-Left)>>2)-1) +o0)=x0;
                                                *(Left+ (3*((Right-Left)>>2)-1) +o1)=x1;
                                                *(Left+ (3*((Right-Left)>>2)-1) +o2)=x2;
                                                // sorting 3 elements ]
                                        */
                                                // 23 instructions!
                                                /*
                                                ..1.200_0.TAG.02.0.200::
                                                .B60.35::                       
                                                  00e09 48 8b 3a         mov rdi, QWORD PTR [rdx]               
                                                  00e0c 33 db            xor ebx, ebx                           
                                                  00e0e 4c 8b 42 08      mov r8, QWORD PTR [8+rdx]              
                                                  00e12 49 3b f8         cmp rdi, r8                            
                                                  00e15 4c 8b 4a 10      mov r9, QWORD PTR [16+rdx]             
                                                  00e19 0f 97 c3         seta bl                                
                                                  00e1c 33 c0            xor eax, eax                           
                                                  00e1e 49 3b f9         cmp rdi, r9                            
                                                  00e21 0f 97 c0         seta al                                
                                                  00e24 33 f6            xor esi, esi                           
                                                  00e26 33 ed            xor ebp, ebp                           
                                                  00e28 4c 3b c7         cmp r8, rdi                            
                                                  00e2b 40 0f 93 c6      setae sil                              
                                                  00e2f 4d 3b c1         cmp r8, r9                             
                                                  00e32 40 0f 97 c5      seta bpl                               
                                                  00e36 03 d8            add ebx, eax                           
                                                  00e38 03 f5            add esi, ebp                           
                                                  00e3a 48 89 3c da      mov QWORD PTR [rdx+rbx*8], rdi         
                                                  00e3e 48 03 de         add rbx, rsi                           
                                                  00e41 48 f7 db         neg rbx                                
                                                  00e44 4c 89 04 f2      mov QWORD PTR [rdx+rsi*8], r8          
                                                  00e48 4c 89 4c da 18   mov QWORD PTR [24+rdx+rbx*8], r9       
                                                  00e4d e9 33 f3 ff ff   jmp .B60.19 
                                                */
                                                // sorting 5 elements [
                                                /*
                                                x0 = *(Left+0);
                                                x1 = *(Left+1);
                                                x2 = *(Left+2);
                                                x3 = *(Left+3);
                                                x4 = *(Left+4);
                                                o0 = (x0>x1)+(x0>x2)+(x0>x3)+(x0>x4);
                                                o1 = (x1>=x0)+(x1>x2)+(x1>x3)+(x1>x4);
                                                o2 = (x2>=x0)+(x2>=x1)+(x2>x3)+(x2>x4);
                                                o3 = (x3>=x0)+(x3>=x1)+(x3>=x2)+(x3>x4);
                                                o4 = (0+1+2+3+4)-(o0+o1+o2+o3);
                                                *(Left+o0)=x0;
                                                *(Left+o1)=x1;
                                                *(Left+o2)=x2;
                                                *(Left+o3)=x3;
                                                *(Left+o4)=x4;
                                                */
                                                // sorting 5 elements ]
                                                // sorting 7 elements [
                                                /*
                                                x0 = *(Left+0);
                                                x1 = *(Left+1);
                                                x2 = *(Left+2);
                                                x3 = *(Left+3);
                                                x4 = *(Left+4);
                                                x5 = *(Left+5);
                                                x6 = *(Left+6);
                                                o0 = (x0>x1)+(x0>x2)+(x0>x3)+(x0>x4)+(x0>x5)+(x0>x6);
                                                o1 = (x1>=x0)+(x1>x2)+(x1>x3)+(x1>x4)+(x1>x5)+(x1>x6);
                                                o2 = (x2>=x0)+(x2>=x1)+(x2>x3)+(x2>x4)+(x2>x5)+(x2>x6);
                                                o3 = (x3>=x0)+(x3>=x1)+(x3>=x2)+(x3>x4)+(x3>x5)+(x3>x6);
                                                o4 = (x4>=x0)+(x4>=x1)+(x4>=x2)+(x4>=x3)+(x4>x5)+(x4>x6);
                                                o5 = (x5>=x0)+(x5>=x1)+(x5>=x2)+(x5>=x3)+(x5>=x4)+(x5>x6);
                                                o6 = (0+1+2+3+4+5+6)-(o0+o1+o2+o3+o4+o5);
                                                *(Left+o0)=x0;
                                                *(Left+o1)=x1;
                                                *(Left+o2)=x2;
                                                *(Left+o3)=x3;
                                                *(Left+o4)=x4;
                                                *(Left+o5)=x5;
                                                *(Left+o6)=x6;
                                                */
                                                // sorting 7 elements ]
                                        //} // It's overkill ]
                                        // When already sorted, ugh:
                                        /*
                                        Jndx = Right;
                                        PL = Left+1;
                                        PR = Left+1;
                                        //TheMiddleOfMiddle = Left + ((Right-Left)>>2); // (4Left + Right - Left)/4; 
                                        //Caution: TrisKaiDecad-wise, [TheMiddleOfMiddle+6] should be <= [Right] i.e. 6+(4Left + Right - Left)/4 <= Right or 4*6+(4Left + Right - Left) <= 4Right or 4*6 <= 3Right-3Left or (4*6)/3 <= Right-Left i.e. 8 <= Right-Left as a minimum condition to enter the 'for'.
                                        M18_swapUnconditional (Left + (1*(Right-Left)>>2), Left+0);
                                        M18_swapUnconditional (Left + (2*(Right-Left)>>2), Left+1);
                                        M18_swapUnconditional (Left + (3*(Right-Left)>>2), Left+2);
                                        // On i5-7200U, this fragment (Rex Kerr's rank sort) is faster than Bubblesort?! [
                                        x0 = *(Left+0);
                                        x1 = *(Left+1);
                                        x2 = *(Left+2);
                                        o0 = (x0>x1)+(x0>x2);
                                        o1 = (x1>=x0)+(x1>x2);
                                        o2 = (0+1+2)-(o0+o1);
                                        *(Left+o0)=x0;
                                        *(Left+o1)=x1;
                                        *(Left+o2)=x2;
                                        // On i5-7200U, this fragment (Rex Kerr's rank sort) is faster than Bubblesort?! ]
                                        PL = PL - (*(Left+1)==*(Left+0));
                                        Pivot = *PR;
                                        */
                                        M18_swapUnconditional (Left + (1*(Right-Left)>>2), Left + (2*(Right-Left)>>2)-1);
                                        M18_swapUnconditional (Left + (3*(Right-Left)>>2), Left + (2*(Right-Left)>>2)+1);
                                        x0 = *(Left + (2*(Right-Left)>>2)-1+0);
                                        x1 = *(Left + (2*(Right-Left)>>2)-1+1);
                                        x2 = *(Left + (2*(Right-Left)>>2)-1+2);
                                        o0 = (x0>x1)+(x0>x2);
                                        o1 = (x1>=x0)+(x1>x2);
                                        o2 = (0+1+2)-(o0+o1);
                                        *(Left + (2*(Right-Left)>>2)-1+o0)=x0;
                                        *(Left + (2*(Right-Left)>>2)-1+o1)=x1;
                                        *(Left + (2*(Right-Left)>>2)-1+o2)=x2;
                                        Jndx = Right;
                                        Pivot = *(Left + (2*(Right-Left)>>2));                  
                                        PL = Left;                                            
                                        for (;*PL < Pivot; PL++) {                            
                                        }                                                     
                                        PR = PL;                                              
                                        M18_swapUnconditional (Left + (2*(Right-Left)>>2), PL); 
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP; clang -S -O3 -fverbose-asm -IC:\mingw64\lib\clang\14.0.1\include QS_bench_r14.c ... [
                                        /*
                                                        movq    %rdx, %rbx
                                                        movq    %r8, %rbp
                                                        jmp     .LBB179_13
                                                        .p2align        4, 0x90
                                        +-----> .LBB179_11:                             
                                        |               movq    %rax, (%r9)
                                        |               movq    %rdi, (%rsi)
                                        |               addq    $8, %r9
                                        |       .LBB179_12:                     <-------+<------+
                                        |               movq    %rsi, %rbp              |       |
                                        |               cmpq    %rbx, %rsi              |       |
                                        |               jae     .LBB179_4 ; To Leftover |       |
                                        |       .LBB179_13:                             |       |
                                        |               leaq    8(%rbp), %rsi           |       |
                                        |               movq    8(%rbp), %rax           |       |
                                        |               cmpq    %rax, %rdi              |       |
                                        +-----[         ja      .LBB179_11              |       |
                                                        jae     .LBB179_12      ]-------+       |
                                                        .p2align        4, 0x90                 |
                                                .LBB179_15:                     <-------+       |
                                                        movq    (%rbx), %rcx            |       |
                                                        addq    $-8, %rbx               |       |
                                                        cmpq    %rcx, %rdi              |       |
                                                        jb      .LBB179_15      ]-------+       |
                                                        movq    %rcx, (%rsi)                    |
                                                        movq    %rax, 8(%rbx)                   |
                                                        movq    %rbp, %rsi                      |
                                                        jmp     .LBB179_12      ]---------------+
                                        */
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP; clang -S -O3 -fverbose-asm -IC:\mingw64\lib\clang\14.0.1\include QS_bench_r14.c ... ]
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP [
                                        for (;PR < Jndx;) {
                                                PR = PR + 1;
                                                if (Pivot > *PR) { // *PL == Pivot
                                                        //M18_swapUnconditional (PL, PR); // Dummy me, using Pivot instead of *PL saves... one 'MOV'    //]-----+
                                                        //BYPASSSWAP:                                                                                   //]     |
                                                        *PL=*PR; *PR=Pivot;                                                                             //<-----/
                                                        PL = PL + 1;
                                                } else if (Pivot < *PR) {
                                                        for (;Pivot < *Jndx;) {
                                                                Jndx = Jndx - 1;
                                                        }
                                                        //M18_SwapConditional_ifXbY_BUGGY((uint64_t)PR, (uint64_t)Jndx, PR, Jndx);      //] Slow! Therefore moving it outwith the loop, see Leftover:
                                                        //Jndx = Jndx - 1;                                                              //]-----+
                                                        //PR = PR - 1;                                                                  //]     |
                                                                                                                                        //]<----/
                                                        M18_swapUnconditional (PR, Jndx);       //] //CAUTION: Inhere, PR could be BIGGER than Jndx (i.e.  Jndx == PR-1), it needs Leftover:
                                                        Jndx = Jndx - 1;                        //]-----+
                                                        PR = PR - 1;                            //]     |
                                                        //UNWIND (it doesn't need Leftover:):   //]<----/
                                                        /*
                                                        if (PR > Jndx) {PR--; break;} // It means *Jndx == Pivot because Jndx == PR-1
                                                        Temporary=*Jndx; // Temporary is LE i.e. LESS-or-EQUAL to Pivot
                                                        *Jndx=*(PR);
                                                        Jndx = Jndx - 1;
                                                        //if (Pivot == Temporary) {*PR=Pivot;} //{*PR=Temporary;}       //]
                                                        //else {*PL=Temporary; *PR=Pivot; PL = PL + 1;}                 //]----+
                                                                                                                        //]<---/
                                                        *(PR)=Pivot;
                                                        if (Pivot > Temporary) {*PL=Temporary; PL = PL + 1;}
                                                        */
                                                }
                                        }
                                        //if (PR > Jndx) {                                                              //]
                                        //      M18_swapUnconditional (&QWORDS[PR+1], &QWORDS[Jndx+1]);                 //]-----+
                                        //}                                                                             //]     |
                                        //Leftover:                                                                     //<-----/ Kinda 'Desperate Measures' - debranchifying the mainloop as much as possible
                                        M18_SwapConditional_ifXbY_BUGGY((uint64_t)Jndx, (uint64_t)PR, PR+1, Jndx+1);
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP ]
                                        StackPtr = StackPtr + 2;
                                        Stack[StackPtr - 1] = PR + 1;
                                        Stack[StackPtr] = Right;
                                        Right = PL - 1;
                        } //switch (Right-Left) {
                } //for(;(M18_InsertionsortTHRESHOLDcoffin < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
DirtyBypass:;
        } while ( (StackPtr != 0) );
        //if (!StackNotOverflow) {
        /*
        for (Indx=LeftBackup+1; Indx <= MINKaze(M18_InsertionsortTHRESHOLDcoffin + LeftBackup,RightBackup); Indx++) { // Ensuring (with this sort) the first (M18_InsertionsortTHRESHOLDcoffin + 1) keys are sorted.
                Jndx = Indx;
                for (;Jndx >= LeftBackup+1;) {
                        if (*(Jndx-1) > *Jndx) M18_swapUnconditional (Jndx-1, Jndx); else break;
                        Jndx = Jndx - 1;
                }
        }
        */
// When M18_InsertionsortTHRESHOLDcoffin = 0:
/*
        for (Indx=LeftBackup+1; Indx <= MINKaze(M18_InsertionsortTHRESHOLDcoffin + LeftBackup,RightBackup); Indx++) { // Ensuring (with this sort) the first (M18_InsertionsortTHRESHOLDcoffin + 1) keys are sorted.
                Jndx = Indx;
                WhetherSwapIsNeeded = (*(Jndx-1)>*(Jndx));
                for (;WhetherSwapIsNeeded;) {
                        WhetherSwapIsNeeded = M18_DidWeSwap ((Jndx-1));
                        Jndx = Jndx - (Jndx >= LeftBackup+1);
                }
        }
        for (Indx=LeftBackup+1; Indx <= RightBackup; Indx++) {
                // Variant #1:
                //Jndx = Indx;
                //for (;;) { // No check "Jndx >= LeftBackup+1" needed since the first (M18_InsertionsortTHRESHOLDcoffin + 1) are already sorted and the very first key plays role of sentinel.
                //      if (*(Jndx-1) > *Jndx) M18_swapUnconditional (Jndx-1, Jndx); else break;
                //      Jndx = Jndx - 1;
                //}
                // Variant #2:
                //for (Jndx = Indx; *(Jndx-1) > *Jndx; Jndx--) { // No check "Jndx >= LeftBackup+1" needed since the first (M18_InsertionsortTHRESHOLDcoffin + 1) are already sorted and the very first key plays role of sentinel.
                //      M18_swapUnconditional (Jndx-1, Jndx); 
                //}
                // Variant #3:
                Pivot = *Indx;
                for (Jndx = Indx; *(Jndx-1) > Pivot; Jndx--) { // No check "Jndx >= LeftBackup+1" needed since the first (M18_InsertionsortTHRESHOLDcoffin + 1) are already sorted and the very first key plays role of sentinel.
                        *(Jndx)=*(Jndx-1);
                }
                *Jndx = Pivot;
        }
*/
        //} //if (!StackNotOverflow) {
//} //if (!is_sorted_Wojciech (Left, (uint64_t)(Right-Left+1))) {
} //void Quicksort_Magnetica_v18 (uint64_t* Left, uint64_t* Right) {

// This is the initial variant, without any optimizations:
/*
            // 'Magnetica' partitioning [
            Jndx = Right;
            PL = Left;
            PR = Left;
            swap (&QWORDS[(Left + Right)>>1], &QWORDS[PR]);
            Pivot = QWORDS[PR];
            for (;PR < Jndx;) {
                if (Pivot > QWORDS[PR + 1]) {
                    swap (&QWORDS[PL], &QWORDS[PR + 1]);
                    PL = PL + 1;
                    PR = PR + 1;
                } else if (Pivot == QWORDS[PR + 1]) {
                    PR = PR + 1;
                } else {
                    for (;Pivot < QWORDS[Jndx];) {
                        Jndx = Jndx - 1;
                    }
                    if (PR + 1 < Jndx) swap (&QWORDS[PR + 1], &QWORDS[Jndx]);
                    Jndx = Jndx - 1;
                }
            }
            Jndx = PL - 1;
            Indx = PR + 1;
            // 'Magnetica' partitioning ]
*/

// Test run: 2022-Jul-16:
// Laptop "Compressionette", Intel 'Kaby Lake' i5-7200U 3.1GHz max turbo (2cores/4threads), 36GB DDR4 2133MHz:
// +--------------------+----------------------------+-----------------------------+----------------------------+-----------------------------+------------------------------+-----------------------------+-----------------------------+-----------------------------+
// | Performer/Keys     | #1, FEW distinct           | #2, MANY distinct           | #3, MANYmore distinct      | #4, ALL distinct            | #5, ALLmore distinct         | #6, DNA distinct            | #7, 3n+1_16GB distinct      | #8, 3n+1_32GB distinct      |
// +--------------------+--------------+-------------+--------------+--------------+--------------+-------------+--------------+--------------+---------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
// |  Operating System, |  Windows 10, | Windows 10, |  Windows 10, |  Windows 10, |  Windows 10, | Windows 10, |  Windows 10, |  Windows 10, |   Windows 10, |  Windows 10, |  Windows 10, |  Windows 10, |  Windows 10, |  Windows 10, |  Windows 10, |  Windows 10, |
// |      Compiler, -O3 | CLANG 14.0.1 |  GCC 11.3.0 | CLANG 14.0.1 |   GCC 11.3.0 | CLANG 14.0.1 |  GCC 11.3.0 | CLANG 14.0.1 |   GCC 11.3.0 |  CLANG 14.0.1 |   GCC 11.3.0 | CLANG 14.0.1 |   GCC 11.3.0 | CLANG 14.0.1 |   GCC 11.3.0 | CLANG 14.0.1 |   GCC 11.3.0 |
// +--------------------+--------------+-------------+--------------+--------------+--------------+-------------+--------------+--------------+---------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
// | qsort              |   66/23 sec. |  67/23 sec. | 389/129 sec. | 395/129 sec. |  185/60 sec. | 187/60 sec. |  500/172 sec.| 507/172 sec. |  981/343 sec. | 994/344 sec. | 455/148 sec. | 462/148 sec. |   225/75 sec.|  228/75 sec. |  465/155 sec.| 471/156 sec. |
// | Akkoda v.3         |         N.A. |  29/10 sec. |         N.A. |  105/30 sec. |         N.A. |  36/13 sec. |         N.A. |  101/26 sec. |          N.A. |  203/51 sec. |         N.A. |  102/36 sec. |         N.A. |   70/22 sec. |         N.A. |  157/44 sec. |
// | Koffcheg           |    33/7 sec. |   32/7 sec. |  198/33 sec. |  201/35 sec. |   85/15 sec. |  86/16 sec. |  232/36 sec. |  238/41 sec. |   462/73 sec. |  472/82 sec. |  215/39 sec. |  222/42 sec. |  103/19 sec. |  106/21 sec. |  212/41 sec. |  218/43 sec. |
// +--------------------+--------------+-------------+--------------+--------------+--------------+-------------+--------------+--------------+---------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
// | Balxchonka         |    31/3 sec. |   31/4 sec. |  192/25 sec. |  198/25 sec. |   84/12 sec. |  87/12 sec. |  255/35 sec. |  261/34 sec. |   503/77 sec. |  516/75 sec. |  212/29 sec. |  220/30 sec. |  101/14 sec. |  105/15 sec. |  210/30 sec. |  218/31 sec. |
// | Glupendxr          |    33/5 sec. |   32/5 sec. |  214/27 sec. |  215/32 sec. |   93/13 sec. |  93/15 sec. |  281/34 sec. |  285/41 sec. |   550/74 sec. |  558/88 sec. |  235/32 sec. |  239/37 sec. |  111/16 sec. |  112/18 sec. |  236/33 sec. |  238/38 sec. |
// | Bentley-McIlroy    |   36/11 sec. |  36/11 sec. |  192/32 sec. |  204/38 sec. |   85/18 sec. |  92/22 sec. |  257/42 sec. |  279/53 sec. |   508/94 sec. | 547/118 sec. |  211/39 sec. |  227/45 sec. |  101/21 sec. |  110/25 sec. |  210/45 sec. |  228/52 sec. |
// | Hoare              |   88/59 sec. |  93/65 sec. |  219/51 sec. |  236/69 sec. |   96/26 sec. | 104/34 sec. |  257/36 sec. |  276/53 sec. |   506/78 sec. | 538/113 sec. |  258/73 sec. |  278/93 sec. |  125/40 sec. |  136/51 sec. |  262/84 sec. | 287/106 sec. |
// +--------------------+--------------+-------------+--------------+--------------+--------------+-------------+--------------+--------------+---------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
// | Crumsort           |    24/4 sec. |   27/3 sec. |   103/4 sec. |   118/4 sec. |    49/2 sec. |   56/1 sec. |   141/3 sec. |   160/3 sec. |    276/7 sec. |   314/6 sec. |   117/6 sec. |   136/5 sec. |    63/3 sec. |    73/3 sec. |   128/6 sec. |   147/6 sec. |
// +--------------------+--------------+-------------+--------------+--------------+--------------+-------------+--------------+--------------+---------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
// | Best Time (bare    |                            |                             |                            |                             |                              |                             |                             |                             |
// | bone in-place QS): | 24s for Crumsort           | 103s for Crumsort           | 49s for Crumsort           | 141s for Crumsort           | 276s for Crumsort            | 117s for Crumsort           | 63s for Crumsort            | 128s for Crumsort           |
// +--------------------+----------------------------+-----------------------------+----------------------------+-----------------------------+------------------------------+-----------------------------+-----------------------------+-----------------------------+
//
// Speed Roster, (the base speed 1.00x is GLIBC's qsort):
// Rank #1: 3304/846=  3.90x = 31+110+39+108+217+103+78+160=    846 seconds for Akkoda v.3
// Rank #2: 3304/1050= 3.14x = 27+121+57+163+319+139+74+150=   1050 seconds for Crumsort
// Rank #3: 3304/1584= 2.08x = 33+202+87+243+480+218+104+217=  1584 seconds for Magnetica-Koffcheg   ! 593 lines of Assembly (clang_14.0.1 -O3) code ! 
// Rank #4: 3304/1629= 2.02x = 30+199+86+259+515+221+102+217=  1629 seconds for Magnetica-Balxchonka ! 121 lines of Assembly (clang_14.0.1 -O3) code ! -\
// Rank #5: 3304/1729= 1.91x = 36+206+92+280+550+227+110+228=  1729 seconds for Bentley-McIlroy      ! 203 lines of Assembly (clang_14.0.1 -O3) code !   >  All using median of 1 or rather the middle as pivot
// Rank #6: 3304/1950= 1.69x = 94+236+104+276+541+278+136+285= 1950 seconds for Hoare                !  77 lines of Assembly (clang_14.0.1 -O3) code ! -/
// Rank #7: 3304/3304= 1.00x = 67+394+187+507+992+461+227+469= 3304 seconds for GLIBC's qsort
//
// Legend (The time is exactly the Sort process time, first value is for unsorted, second one is for sorted):
// #1,FEW = 2,233,861,800 keys, of them distinct = 10; UNIQUENESS = 0.000,000,004,074 (closer to 1, means higher entropy); UNSORTEDNESS = 44%; 178,708,944 bytes 22338618_QWORDS.bin; elements = 178,708,944/8 *100; // Keys are 100 times duplicated
// #2,MANY = 2,482,300,900 keys, of them distinct = 2,847,531; UNIQUENESS = 0.001,147,133,331 (closer to 1, means higher entropy); UNSORTEDNESS = 48%; 24,823,016 bytes mobythesaurus.txt; elements = 24823016 -8+1; // BuildingBlocks are size-order+1, they are 100 times duplicated
// #3,MANYmore = 1,137,582,073 keys, of them distinct = 77,275,994; UNIQUENESS = 0.067,930,037,695 (closer to 1, means higher entropy); UNSORTEDNESS = 45%; 1,137,582,080 bytes linux-5.15.25.tar; elements = 1137582080 -8+1; // BuildingBlocks are size-order+1
// #4,ALL = 2,009,333,753 keys, of them distinct = 1,912,608,132; UNIQUENESS = 0.951,861,843,880 (closer to 1, means higher entropy); UNSORTEDNESS = 49%; 2,009,333,760 bytes Fedora-Workstation-Live-x86_64-35-1.2.iso; elements = 2009333760 -8+1; // BuildingBlocks are size-order+1
// #5,ALLmore = 3,803,483,825 keys, of them distinct = 3,346,259,533; UNIQUENESS = 0.879,788,027,520 (closer to 1, means higher entropy); UNSORTEDNESS = 50%; 3,803,483,832 bytes Fedora-Workstation-35-1.2.aarch64.raw.xz; elements = 3803483832 -8+1; // BuildingBlocks are size-order+1
// #6,DNA = 3,313,061,624 keys, of them distinct = 3,411,451; UNIQUENESS = 0.001,029,697,146 (closer to 1, means higher entropy); UNSORTEDNESS = 50%; 3,313,061,631 bytes www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna; elements = 3313061631 -8+1; // BuildingBlocks are size-order+1
// #7,3n+1_16GB = 1,800,000,000 keys, of them distinct = 24,816,866; UNIQUENESS = 0.013,787,147,278 (closer to 1, means higher entropy); UNSORTEDNESS = 66%;
// #8,3n+1_32GB = 3,600,000,000 keys, of them distinct = 47,586,732; UNIQUENESS = 0.013,218,536,417 (closer to 1, means higher entropy); UNSORTEDNESS = 66%;
// #9,ALLmax = 7,798,235,435 keys, of them distinct = 6,770,144,405; 7,798,235,442 bytes math.stackexchange.com_en_all_2019-02.zim; elements = 7798235442 -8+1; // BuildingBlocks are size-order+1
// 
// Test run: 2022-Mar-25: (with a removed MOV instruction, and with removed case 13 i.e. 14 elements partition)
// Laptop "Compressionette", Intel 'Kaby Lake' i5-7200U 3.1GHz max turbo, 36GB DDR4 2133MHz:
// +--------------------+-------------------------+--------------------------+--------------------------+---------------------------+---------------------------+-----------------------------+
// | Performer/Keys     | #1, FEW distinct        | #2, MANY distinct        | #3, MANYmore distinct    | #4, ALL distinct          | #5, ALLmore distinct      | #6, ALLmax distinct         |
// +--------------------+-------------------------+--------------------------+--------------------------+-------------+-------------+---------------------------+--------------+--------------+
// |  Operating System, |   Fedora 35, GCC 11.2.1 |    Fedora 35, GCC 11.2.1 |    Fedora 35, GCC 11.2.1 |     Fedora 35, GCC 11.2.1 |     Fedora 35, GCC 11.2.1 |       Fedora 35, GCC 11.2.1 |
// |      Compiler, -O3 |       instructions; IPC |        instructions; IPC |        instructions; IPC |         instructions; IPC |         instructions; IPC |           instructions; IPC |
// +--------------------+-------------------------+--------------------------+--------------------------+---------------------------+---------------------------+-----------------------------+
// | Magnetica v.15     |            29/5 seconds |           198/40 seconds |            86/19 seconds |            241/57 seconds |           471/117 seconds |                        N.A. |
// |                    |   166,381,316,975; 1.15 |    900,187,723,854; 1.16 |    425,642,587,686; 1.23 |   1,239,303,863,107; 1.26 |   2,375,949,382,682; 1.27 |                        N.A. |
// +--------------------+-------------------------+--------------------------+--------------------------+---------------------------+---------------------------+-----------------------------+
// | Bentley-McIlroy    |           39/12 seconds |           218/42 seconds |            98/23 seconds |            298/56 seconds |           585/122 seconds |                        N.A. |
// |                    |   246,937,992,407; 1.25 |  1,101,300,142,302; 1.30 |    508,701,819,598; 1.27 |   1,477,164,214,606; 1.28 |   2,864,814,224,718; 1.27 |                        N.A. |
// +--------------------+-------------------------+--------------------------+--------------------------+---------------------------+---------------------------+-----------------------------+
// | qsort              |         377/332 seconds |          541/237 seconds |           182/60 seconds |           534/131 seconds |          1036/257 seconds |                        N.A. |
// |                    | 6,448,486,736,095; 2.90 |  4,922,819,922,044; 2.02 |  1,374,050,233,948; 1.78 |   3,249,209,017,221; 1.54 |   6,264,470,257,432; 1.54 |                        N.A. |
// +--------------------+-------------------------+--------------------------+--------------------------+---------------------------+---------------------------+-----------------------------+
// | Crumsort 1.1.5.3   |            30/4 seconds |            136/4 seconds |             65/2 seconds |            182/3  seconds |             358/7 seconds |                        N.A. |
// |                    |   351,111,590,447; 2.40 |  1,285,735,981,027; 2.69 |    606,030,232,243; 2.62 |   1,601,900,333,622; 2.53 |   3,103,229,895,546; 2.59 |                        N.A. |
// +--------------------+-------------------------+--------------------------+--------------------------+---------------------------+---------------------------+-----------------------------+
//
// Notes:
// - Akkoda v.3 in fact is the bithreaded Magnetica-Koffcheg v.18, in MAX turbo... tetrathreaded;
// - Used options for ICL Compiler: /arch:CORE-AVX2 /O3
// - Used options for CLANG Compiler: -O3
// - Used options for GCC Compiler: -O3 -mavx2 -m64 -static -fomit-frame-pointer
// - Scandum's Crumsort is the FASTEST in-place sorter, known to me, hail Scandum!
// - All the runs were in "Current priority class is REALTIME_PRIORITY_CLASS" for Windows and "Current priority is -20." for Linux;
// - All the runs were executed by Core 1 (i.e. SetProcessAffinityMask(GetCurrentProcess(), 1);) in Windows, not in Linux (the task was migrating between the cores);
// To see more stats (the tables were deriving from) see 'log_i5-7200U_MAR14.txt';
// - Benchmark needs 32GB RAM, and 64GB for the 6th testset;
// - The whole package (except the 3rd, 4th, 5th, 6th and 9th datasets) is downloadable at:
//   www.sanmayce.com/QS_showdown_r15.7z
//   https://forum.qb64.org/index.php?topic=3518.msg141225#msg141225
// - To reproduce the roster, run on Windows or Linux:
//   - BENCH_ICL32GB.BAT
//   - BENCH_ICL64GB.BAT
//   - sh bench_gcc32GB.sh
//   - sh bench_gcc64GB.sh
// - 3rd dataset is downloadable at:
// https://cdn.kernel.org/pub/linux/kernel/v5.x/linux-5.15.25.tar.xz
// - 4th dataset is downloadable at:
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/x86_64/iso/Fedora-Workstation-Live-x86_64-35-1.2.iso 
// - 5th dataset is downloadable at:
// https://download.fedoraproject.org/pub/fedora/linux/releases/35/Workstation/aarch64/images/Fedora-Workstation-35-1.2.aarch64.raw.xz 
// - 6th dataset is downloadable at:
// https://ftp.ncbi.nlm.nih.gov/refseq/H_sapiens/annotation/GRCh38_latest/refseq_identifiers/GRCh38_latest_genomic.fna.gz
// - 9th dataset is downloadable at:
// https://download.kiwix.org/zim/stack_exchange/math.stackexchange.com_en_all_2019-02.zim
// - Managed to reduce the mainloop down to 68 bytes (from 71 in r.12), the gain comes from switching to pointers, had to do that long time ago, wanted to keep the etude ARRAY-syntax friendly. Now, r.12 uses arrays, whereas r.13 uses pointers. Another turning point, GCC now beats ICL in all tests.
// - In order to switch to "Benchmark mode":
// cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
// echo performance | tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor

int KAZE_Scandum_compareQWORD (const void * a, const void * b) { return (*(uint64_t*)a > *(uint64_t*)b) - (*(uint64_t*)a < *(uint64_t*)b); } // Taken from bench.c by Scandum in order to have the same comparer.
void KAZE_swap (uint64_t *a, uint64_t *b) { uint64_t t = *a; *a = *b; *b = t; }

void KAZE_QuickSortHoare (uint64_t array[], int64_t low, int64_t high) {
        int64_t I,J;
        uint64_t Pivot;
        if (low < high) {
                Pivot=array[(low + high)>>1];
                I = low; J = high;
                do {
                        while (array[I] < Pivot) I = I + 1;
                        while (array[J] > Pivot) J = J - 1;
                        if (I <= J) { KAZE_swap(&array[I], &array[J]); I += 1; J -= 1; }
                } while (I <= J);
                KAZE_QuickSortHoare(array, low, J);
                KAZE_QuickSortHoare(array, I, high);
        }
}

void KAZE_quicksort_Bentley_McIlroy_3way_partitioning (uint64_t a[], int64_t l, int64_t r) { 
        int64_t i = l-1, j = r, p = l-1, q = r; 
        int64_t k; 
        uint64_t v;
        if (r <= l) return;
        KAZE_swap(&a[r], &a[(r+l)>>1]); // Modified by Kaze, quadratic otherwise when already sorted
        v = a[r];
        for (;;) {
                while (a[++i] < v) ;
                while (v < a[--j]) if (j == l) break;
                if (i >= j) break;
                KAZE_swap(&a[i], &a[j]);
                if (a[i] == v) { p++; KAZE_swap(&a[p], &a[i]); }
                if (v == a[j]) { q--; KAZE_swap(&a[j], &a[q]); }
        }
        KAZE_swap(&a[i], &a[r]); 
        j = i-1; i = i+1;
        for (k = l; k < p; k++, j--) KAZE_swap(&a[k], &a[j]);
        for (k = r-1; k > q; k--, i++) KAZE_swap(&a[i], &a[k]);
        KAZE_quicksort_Bentley_McIlroy_3way_partitioning(a, l, j);
        KAZE_quicksort_Bentley_McIlroy_3way_partitioning(a, i, r);
}

// Magnetica_v18.h]

// How to invoke?
/*
        if (strcmp(argv[1],"qsort")==0) qsort(xgamsCACHE, elements*ditto, sizeof(uint64_t), KAZE_Scandum_compareQWORD);
        if (strcmp(argv[1],"CS")==0) crumsort(xgamsCACHE, elements*ditto, sizeof(uint64_t), KAZE_Scandum_compareQWORD);
        if (strcmp(argv[1],"Koffcheg")==0)     Quicksort_Magnetica_v18_Koffcheg(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);
        if (strcmp(argv[1],"Balxchonka")==0) Quicksort_Magnetica_v18_Balxchonka(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);        
        if (strcmp(argv[1],"Akkoda")==0)                        QuickSortAkkoda(&xgamsCACHE[0], &xgamsCACHE[elements*ditto - 1]);  
        if (strcmp(argv[1],"Hoare")==0)                           KAZE_QuickSortHoare(xgamsCACHE, 0, elements*ditto - 1);  
        if (strcmp(argv[1],"BM")==0) KAZE_quicksort_Bentley_McIlroy_3way_partitioning(xgamsCACHE, 0, elements*ditto - 1);  
*/

/*
; mark_description "Intel(R) C++ Intel(R) 64 Compiler for applications running on Intel(R) 64, Version 19.0.0.117 Build 20180804";
; mark_description "/FAcs /arch:CORE-AVX2 /O3 /D_N_HIGH_PRIORITY /Drev5bypass /Qopenmp /Qopenmp-link:static /DCommence_OpenMP /F";
; mark_description "eQS_bench_r14_ICL19.0_rev5bypass.exe";

;;; void M17_swapUnconditional(uint64_t *a, uint64_t *b) { uint64_t t = *a; *a = *b; *b = t; }
  00000 48 8b 02         mov rax, QWORD PTR [rdx]               
  00003 4c 8b 01         mov r8, QWORD PTR [rcx]                
  00006 48 89 01         mov QWORD PTR [rcx], rax               
  00009 4c 89 02         mov QWORD PTR [rdx], r8                
  0000c c3               ret                                    

;;; void M17_swapconditional1_BUGGY (uint64_t *b, uint64_t *a) { int64_t ABsgnd= *a-*b; ABsgnd=ABsgnd&(ABsgnd >> 63);*a = *a-ABsgnd; *b = *b+ABsgnd; } // if a<b then swap
  00000 4c 8b 09         mov r9, QWORD PTR [rcx]                
  00003 49 f7 d9         neg r9                                 
  00006 4c 8b 02         mov r8, QWORD PTR [rdx]                
  00009 4d 03 c8         add r9, r8                             
  0000c 4c 89 c8         mov rax, r9                            
  0000f 48 c1 f8 3f      sar rax, 63                            
  00013 4c 23 c8         and r9, rax                            
  00016 4d 2b c1         sub r8, r9                             
  00019 4c 89 02         mov QWORD PTR [rdx], r8                
  0001c 4c 01 09         add QWORD PTR [rcx], r9                
  0001f c3               ret                                    

;;; void M17_swapconditional1 (uint64_t *a, uint64_t *b) { uint64_t aOLD = *a; uint64_t bOLD = *b; *a = MINKaze(aOLD,bOLD); *b = MAXKaze(aOLD,bOLD); }
  00000 4c 8b 09         mov r9, QWORD PTR [rcx]                
  00003 4c 8b 02         mov r8, QWORD PTR [rdx]                
  00006 4d 3b c8         cmp r9, r8                             
  00009 4c 89 c0         mov rax, r8                            
  0000c 49 0f 42 c1      cmovb rax, r9                          
  00010 4d 3b c1         cmp r8, r9                             
  00013 48 89 01         mov QWORD PTR [rcx], rax               
  00016 4d 0f 47 c8      cmova r9, r8                           
  0001a 4c 89 0a         mov QWORD PTR [rdx], r9                
  0001d c3               ret                                    

;;; void M17_swapconditional2 (uint64_t *a, uint64_t *b) { uint64_t aOLD = *a; uint64_t bOLD = *b; *a = MINKazeSO(aOLD,bOLD); *b = MAXKazeSO(aOLD,bOLD); }
  00000 33 c0            xor eax, eax                           
  00002 4c 8b 11         mov r10, QWORD PTR [rcx]               
  00005 4d 89 d1         mov r9, r10                            
  00008 4c 8b 02         mov r8, QWORD PTR [rdx]                
  0000b 4d 3b d0         cmp r10, r8                            
  0000e 0f 92 c0         setb al                                
  00011 4d 33 c8         xor r9, r8                             
  00014 f7 d8            neg eax                                
  00016 48 63 c0         movsxd rax, eax                        
  00019 4c 23 c8         and r9, rax                            
  0001c 4d 33 c1         xor r8, r9                             
  0001f 4d 33 d1         xor r10, r9                            
  00022 4c 89 01         mov QWORD PTR [rcx], r8                
  00025 4c 89 12         mov QWORD PTR [rdx], r10               
  00028 c3               ret                                    

;;; void M17_SwapConditional_ifXbY_BUGGY (int64_t X, int64_t Y, uint64_t *a, uint64_t *b) { int64_t XYsgnd = X-Y; int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&(XYsgnd >> 63); *a = *a-ABsgnd; *b = *b+ABsgnd; } // if X<Y then swap
  00000 48 2b ca         sub rcx, rdx                           
  00003 4d 8b 11         mov r10, QWORD PTR [r9]                
  00006 49 f7 da         neg r10                                
  00009 49 8b 00         mov rax, QWORD PTR [r8]                
  0000c 4c 03 d0         add r10, rax                           
  0000f 48 c1 f9 3f      sar rcx, 63                            
  00013 4c 23 d1         and r10, rcx                           
  00016 49 2b c2         sub rax, r10                           
  00019 49 89 00         mov QWORD PTR [r8], rax                
  0001c 4d 01 11         add QWORD PTR [r9], r10                
  0001f c3               ret                                    

;;; void M17_swapConditionalXY_Akkodah (uint64_t X, uint64_t Y, uint64_t *a, uint64_t *b) { int64_t XYsgnd = -(X<Y); int64_t ABsgnd= *a-*b; ABsgnd = ABsgnd&XYsgnd; *a = *a-ABsgnd; *b = *b+ABsgnd; } // if X<Y then swap
  00000 45 33 d2         xor r10d, r10d                         
  00003 48 3b ca         cmp rcx, rdx                           
  00006 41 0f 92 c2      setb r10b                              
  0000a 4d 8b 19         mov r11, QWORD PTR [r9]                
  0000d 41 f7 da         neg r10d                               
  00010 49 f7 db         neg r11                                
  00013 49 8b 00         mov rax, QWORD PTR [r8]                
  00016 4c 03 d8         add r11, rax                           
  00019 4d 63 d2         movsxd r10, r10d                       
  0001c 4d 23 da         and r11, r10                           
  0001f 49 2b c3         sub rax, r11                           
  00022 49 89 00         mov QWORD PTR [r8], rax                
  00025 4d 01 19         add QWORD PTR [r9], r11                
  00028 c3               ret                                    

;;; int KAZE_Scandum_compareQWORD (const void * a, const void * b) { return (*(uint64_t*)a > *(uint64_t*)b) - (*(uint64_t*)a < *(uint64_t*)b); } // Taken from bench.c by Scandum in order to have the same comparer.
  00000 45 33 c0         xor r8d, r8d                           
  00003 48 8b 01         mov rax, QWORD PTR [rcx]               
  00006 48 3b 02         cmp rax, QWORD PTR [rdx]               
  00009 44 89 c0         mov eax, r8d                           
  0000c 0f 97 c0         seta al                                
  0000f 41 0f 92 c0      setb r8b                               
  00013 41 2b c0         sub eax, r8d                           
  00016 c3               ret                                    

;;; void KAZE_swap (uint64_t *a, uint64_t *b) { uint64_t t = *a; *a = *b; *b = t; }
  00000 48 8b 02         mov rax, QWORD PTR [rdx]               
  00003 4c 8b 01         mov r8, QWORD PTR [rcx]                
  00006 48 89 01         mov QWORD PTR [rcx], rax               
  00009 4c 89 02         mov QWORD PTR [rdx], r8                
  0000c c3               ret                                    

... The rest also disappoints, Intel v15.0 was much better than v19.0, some dumbasses ruined the legacy.
*/

// m = _mm256_cmpeq_epi8(x, _mm256_set1_epi8('/'));
// x = _mm256_blendv_epi8(x, _mm256_set1_epi8('_'), m);
// for (size_t i=0; i < size; i++)
//      bytes[i] = bytes[i] == '/' ? '_' : bytes[i];

// test_avx_swap.c [
// //gcc -mavx -o test_avx_swap test_avx_swap.c
// #include <immintrin.h>
// #include <stdio.h>
// #include <stdint.h>
// int main() {
//      double Left[2]={6,7};
//      __m128d PairQWORDS;
//      double* STCK = (double*)&PairQWORDS;
//      //double* STCK = (double*)&Left;
//      //PairQWORDS = _mm_setr_pd (Left[0], Left[1]);
//      PairQWORDS = _mm_loadu_pd ((double*)Left);
//      printf("%lf %lf\n", STCK[0], STCK[1]);
//      PairQWORDS = _mm_permute_pd(PairQWORDS, 0b01);
//      printf("%lf %lf\n", STCK[0], STCK[1]);
//      exit(0);
// }
// /*
// __m128d _mm_permute_pd (__m128d a, int imm8)
// #include <immintrin.h>
// Instruction: vpermilpd xmm, xmm, imm8
// CPUID Flags: AVX
// Description
// Shuffle double-precision (64-bit) floating-point elements in a using the control in imm8, and store the results in dst.
// Operation
// IF (imm8[0] == 0) dst[63:0] := a[63:0]; FI
// IF (imm8[0] == 1) dst[63:0] := a[127:64]; FI
// IF (imm8[1] == 0) dst[127:64] := a[63:0]; FI
// IF (imm8[1] == 1) dst[127:64] := a[127:64]; FI
// dst[MAX:128] := 0
// Performance
// Architecture Latency Throughput (CPI)
// Icelake      1       -
// Skylake      1       1
// Broadwell    1       1
// Haswell      1       1
// Ivy Bridge   1       1
// */
// /*
// __m128d _mm_loadu_pd (double const* mem_addr)
// #include <emmintrin.h>
// Instruction: movupd xmm, m128
// CPUID Flags: SSE2
// Description
// Load 128-bits (composed of 2 packed double-precision (64-bit) floating-point elements) from memory into dst. mem_addr does not need to be aligned on any particular boundary.
// Operation
// dst[127:0] := MEM[mem_addr+127:mem_addr]
// Performance
// Architecture Latency Throughput (CPI)
// Skylake      6       0.5
// Broadwell    1       0.5
// Haswell      1       0.5
// Ivy Bridge   1       1
// */
// /*
// void _mm_storeu_pd (double* mem_addr, __m128d a)
// #include <emmintrin.h>
// Instruction: movupd m128, xmm
// CPUID Flags: SSE2
// Description
// Store 128-bits (composed of 2 packed double-precision (64-bit) floating-point elements) from a into memory. mem_addr does not need to be aligned on any particular boundary.
// Operation
// MEM[mem_addr+127:mem_addr] := a[127:0]
// Performance
// Architecture Latency Throughput (CPI)
// Skylake      5       1
// Broadwell    1       0.5
// Haswell      1       0.5
// Ivy Bridge   1       1
// */
// test_avx_swap.c ]
// By berenger.bramas@mpcdf.mpg.de 2017. [
// Gcc : -mavx512f -mavx512cd -mavx512vl -mavx512bw -mavx512dq -fopenmp
// Intel : -xCOMMON-AVX512 -xCORE-AVX512 -qopenmp
/*
inline __m512d CoreSmallSort(__m512d input){
    {
        __m512i idxNoNeigh = _mm512_set_epi64(6, 7, 4, 5, 2, 3, 0, 1);
        __m512d permNeigh = _mm512_permutexvar_pd(idxNoNeigh, input);
        __m512d permNeighMin = _mm512_min_pd(permNeigh, input);
        __m512d permNeighMax = _mm512_max_pd(permNeigh, input);
        input = _mm512_mask_mov_pd(permNeighMin, 0xAA, permNeighMax);
    }
    {
        __m512i idxNoNeigh = _mm512_set_epi64(4, 5, 6, 7, 0, 1, 2, 3);
        __m512d permNeigh = _mm512_permutexvar_pd(idxNoNeigh, input);
        __m512d permNeighMin = _mm512_min_pd(permNeigh, input);
        __m512d permNeighMax = _mm512_max_pd(permNeigh, input);
        input = _mm512_mask_mov_pd(permNeighMin, 0xCC, permNeighMax);
    }
    {
        __m512i idxNoNeigh = _mm512_set_epi64(6, 7, 4, 5, 2, 3, 0, 1);
        __m512d permNeigh = _mm512_permutexvar_pd(idxNoNeigh, input);
        __m512d permNeighMin = _mm512_min_pd(permNeigh, input);
        __m512d permNeighMax = _mm512_max_pd(permNeigh, input);
        input = _mm512_mask_mov_pd(permNeighMin, 0xAA, permNeighMax);
    }
    {
        __m512i idxNoNeigh = _mm512_set_epi64(0, 1, 2, 3, 4, 5, 6, 7);
        __m512d permNeigh = _mm512_permutexvar_pd(idxNoNeigh, input);
        __m512d permNeighMin = _mm512_min_pd(permNeigh, input);
        __m512d permNeighMax = _mm512_max_pd(permNeigh, input);
        input = _mm512_mask_mov_pd(permNeighMin, 0xF0, permNeighMax);
    }
    {
        __m512i idxNoNeigh = _mm512_set_epi64(5, 4, 7, 6, 1, 0, 3, 2);
        __m512d permNeigh = _mm512_permutexvar_pd(idxNoNeigh, input);
        __m512d permNeighMin = _mm512_min_pd(permNeigh, input);
        __m512d permNeighMax = _mm512_max_pd(permNeigh, input);
        input = _mm512_mask_mov_pd(permNeighMin, 0xCC, permNeighMax);
    }
    {
        __m512i idxNoNeigh = _mm512_set_epi64(6, 7, 4, 5, 2, 3, 0, 1);
        __m512d permNeigh = _mm512_permutexvar_pd(idxNoNeigh, input);
        __m512d permNeighMin = _mm512_min_pd(permNeigh, input);
        __m512d permNeighMax = _mm512_max_pd(permNeigh, input);
        input = _mm512_mask_mov_pd(permNeighMin, 0xAA, permNeighMax);
    }
    return input;
}
inline void CoreSmallSort(double* __restrict__ ptr1){ _mm512_storeu_pd(ptr1, CoreSmallSort(_mm512_loadu_pd(ptr1))); }
*/
// By berenger.bramas@mpcdf.mpg.de 2017. ]

// (unstressed U)=X 
// (short I)=Y (YA)/(YU)/(YO)
// (TS)=C
// (TCH)=Q
// (SCH)=W

//  __      __                  __                                   
// /  \    /  \ _____    ____  |  | __  ____ _______   ____    ____  
// \   \/\/   //     \ _/ __ \ |  |/ /_/ __ \\_  __ \ /  _ \  /  _ \
//  \        /|  Y Y  \\  ___/ |    < \  ___/ |  | \/(  <_> )(  <_> )
//   \__/\  / |__|_|  / \___  >|__|_ \ \___  >|__|    \____/  \____/
//        \/        \/      \/      \/     \/

//   _________        .__                       __                           
//  /   _____/  ____  |  |__    _____    ____  |  | __  ____ _______   ____    ____  
//  \_____  \ _/ ___\ |  |  \  /     \ _/ __ \ |  |/ /_/ __ \\_  __ \ /  _ \  /  _ \
//  /        \\  \___ |   Y  \|  Y Y  \\  ___/ |    < \  ___/ |  | \/(  <_> )(  <_> )
// /_______  / \___  >|___|  /|__|_|  / \___  >|__|_ \ \___  >|__|    \____/  \____/
//         \/      \/      \/       \/      \/      \/     \/

//   ________          _____   _____                               
//  /  _____/ _____  _/ ____\_/ ____\ ____ _______   ____    ____  
// /   \  ___ \__  \ \   __\ \   __\_/ __ \\_  __ \ /  _ \  /  _ \
// \    \_\  \ / __ \_|  |    |  |  \  ___/ |  | \/(  <_> )(  <_> )
//  \______  /(____  /|__|    |__|   \___  >|__|    \____/  \____/
//         \/      \/                    \/

//   ________         .__    _____               .__             .___        
//  /  _____/ _____   |  | _/ ____\____    ____  |__|_____     __| _/_____   
// /   \  ___ \__  \  |  | \   __\/  _ \  /    \ |  |\__  \   / __ | \__  \
// \    \_\  \ / __ \_|  |__|  | (  <_> )|   |  \|  | / __ \_/ /_/ |  / __ \_
//  \______  /(____  /|____/|__|  \____/ |___|  /|__|(____  /\____ | (____  /
//         \/      \/                         \/          \/      \/      \/

// ___________        .__     .___                __   .__                 
// \__    ___/_______ |__|  __| _/ ____    ____ _/  |_ |__|  ____  _____   
//   |    |   \_  __ \|  | / __ |_/ __ \  /    \\   __\|  |_/ ___\ \__  \
//   |    |    |  | \/|  |/ /_/ |\  ___/ |   |  \|  |  |  |\  \___  / __ \_
//   |____|    |__|   |__|\____ | \___  >|___|  /|__|  |__| \___  >(____  /
//                             \/     \/      \/                \/      \/



#define CRorLF 10 // 13 or 10 or 0
int strcmpKAZE10 (const char * src, const char * dst) {
        int ret = 0 ;
        while( ! (ret = *(unsigned char *)src - *(unsigned char *)dst) && (*dst!=CRorLF) ) {
		++src;
		++dst;
	}
        return( ret );
}



inline int32_t memcmpKAZE_QWORD (const void * buf1, const void * buf2, size_t count) {
        if (!count) return(0);
        for (; count>8 && (*(uint64_t *)buf1 == *(uint64_t *)buf2) ; count=count-8) {buf1 = (char *)buf1 + 8; buf2 = (char *)buf2 + 8;} 
        while ( --count && *(char *)buf1 == *(char *)buf2 ) {buf1 = (char *)buf1 + 1; buf2 = (char *)buf2 + 1;} 
        return( *((unsigned char *)buf1) - *((unsigned char *)buf2) );
}
int CompareOrder (uint64_t Left, uint64_t Right, size_t Order) { return memcmp((char *)Left, (char *)Right, Order); }
//#include <tmmintrin.h> // for _mm_shuffle_pi8
//#include <endian.h> // for htobe64

void encode_bigend_u64(uint64_t value, void* dest) {
  value =
      ((value & 0xFF00000000000000u) >> 56u) |
      ((value & 0x00FF000000000000u) >> 40u) |
      ((value & 0x0000FF0000000000u) >> 24u) |
      ((value & 0x000000FF00000000u) >>  8u) |
      ((value & 0x00000000FF000000u) <<  8u) |      
      ((value & 0x0000000000FF0000u) << 24u) |
      ((value & 0x000000000000FF00u) << 40u) |
      ((value & 0x00000000000000FFu) << 56u);
  memcpy(dest, &value, sizeof(uint64_t));
}
// clang_14.0.1 -O3 -mavx2 -march=haswell -S -fverbose-asm
/*
encode_bigend_u64:                      # @encode_bigend_u64
# %bb.0:
	movbeq	%rcx, (%rdx)
	retq
*/
uint64_t be64_to_host(unsigned char* data) {
    return
      ((uint64_t)data[7]<<0)  | ((uint64_t)data[6]<<8 ) |
      ((uint64_t)data[5]<<16) | ((uint64_t)data[4]<<24) |
      ((uint64_t)data[3]<<32) | ((uint64_t)data[2]<<40) |
      ((uint64_t)data[1]<<48) | ((uint64_t)data[0]<<56);
}
// clang_14.0.1 -O3 -mavx2 -march=haswell -S -fverbose-asm
/*
be64_to_host:                           # @be64_to_host
# %bb.0:
	movbeq	(%rcx), %rax
	retq
*/

// Note: If count is 0 then compare [CR]LF postfixed "strings" i.e. lines.
inline int32_t memcmpKAZE_QWORD_reverse (const void * buf1, const void * buf2, size_t count) {
	uint64_t buf1rev;
	uint64_t buf2rev;
	unsigned char * buf1ICL=(unsigned char *)buf1;
	unsigned char * buf2ICL=(unsigned char *)buf2;
	//int Remainder=count%8;
        //if (!count) return(0);
	if (count>=8) {
        for (; count>8 && (*(uint64_t *)buf1 == *(uint64_t *)buf2) ; count=count-8) {buf1 = (char *)buf1 + 8; buf2 = (char *)buf2 + 8;} 
	//doing only QWORD compares, e.g. for count=9 shifting by 1 to handle the remainder
	if (count>8) count=8;                   	//]----+
	//Remainder = 0; // if (count>=8)               //]    |
	//Remainder = (8-Remainder); // if (count<8)	//]    |
	//Remainder = (8-Remainder)*(count<8);          //]<---+ even slower by 10s
	//Remainder = (8-Remainder)&(-(count<8));       //]<---+ slower
	buf1 = (char *)buf1 - 8 + count; //-Remainder; //- 8 + count;
	buf2 = (char *)buf2 - 8 + count; //-Remainder; //- 8 + count;

buf1rev = 
      ((*(uint64_t *)buf1 & 0xFF00000000000000u) >> 56u) |
      ((*(uint64_t *)buf1 & 0x00FF000000000000u) >> 40u) |
      ((*(uint64_t *)buf1 & 0x0000FF0000000000u) >> 24u) |
      ((*(uint64_t *)buf1 & 0x000000FF00000000u) >>  8u) |
      ((*(uint64_t *)buf1 & 0x00000000FF000000u) <<  8u) |      
      ((*(uint64_t *)buf1 & 0x0000000000FF0000u) << 24u) |
      ((*(uint64_t *)buf1 & 0x000000000000FF00u) << 40u) |
      ((*(uint64_t *)buf1 & 0x00000000000000FFu) << 56u);

buf2rev = 
      ((*(uint64_t *)buf2 & 0xFF00000000000000u) >> 56u) |
      ((*(uint64_t *)buf2 & 0x00FF000000000000u) >> 40u) |
      ((*(uint64_t *)buf2 & 0x0000FF0000000000u) >> 24u) |
      ((*(uint64_t *)buf2 & 0x000000FF00000000u) >>  8u) |
      ((*(uint64_t *)buf2 & 0x00000000FF000000u) <<  8u) |      
      ((*(uint64_t *)buf2 & 0x0000000000FF0000u) << 24u) |
      ((*(uint64_t *)buf2 & 0x000000000000FF00u) << 40u) |
      ((*(uint64_t *)buf2 & 0x00000000000000FFu) << 56u);

	//buf1rev = be64_to_host(*(uint64_t *)buf1);
	//buf2rev = be64_to_host(*(uint64_t *)buf2);
//	buf1rev = _mm_shuffle_pi8 (*(__m64 *)buf1, (__m64)0x0001020304050607);
//	buf2rev = _mm_shuffle_pi8 (*(__m64 *)buf2, (__m64)0x0001020304050607);
	//buf1rev = htobe64(*(uint64_t *)buf1);
	//buf2rev = htobe64(*(uint64_t *)buf2);
	return (buf1rev > buf2rev) - (buf1rev < buf2rev);
	} else {
		if (count) {
		        while ( --count && *buf1ICL == *buf2ICL ) {++buf1ICL; ++buf2ICL;} 
       		} else {
                         //if ( (*(unsigned char *)buf1 == 10) && (*(unsigned char *)buf2 != 10) ) {return -1;}
                         //if ( (*(unsigned char *)buf1 != 10) && (*(unsigned char *)buf2 == 10) ) {return 1;}
//printf("[");
		        while( (*buf1ICL == *buf2ICL) && (*buf2ICL != 10) ) {++buf1ICL; ++buf2ICL;}
//printf("]\n");
		}
	        return( *(buf1ICL) - *(buf2ICL) );
		//return memcmp((char *)buf1, (char *)buf2, count);
	}
}

inline int32_t memcmpKAZE_QWORD_reversePTR (uint64_t *buf1, uint64_t *buf2, size_t count, size_t NumberOfLFs) {
	unsigned char * buf1ICL=(unsigned char *)*buf1;
	unsigned char * buf2ICL=(unsigned char *)*buf2;
        int SgndR;
	uint64_t buf1rev;
	uint64_t buf2rev;
	//int Remainder=count%8;
        //if (!count) return(0);
	if (count>=8) {
                for (; count>8 && (*(uint64_t *)buf1ICL == *(uint64_t *)buf2ICL) ; count=count-8) {buf1ICL = buf1ICL + 8; buf2ICL = buf2ICL + 8;} 
	        //doing only QWORD compares, e.g. for count=9 shifting by 1 to handle the remainder
	        if (count>8) count=8;                   	//]----+
	        //Remainder = 0; // if (count>=8)               //]    |
	        //Remainder = (8-Remainder); // if (count<8)	//]    |
	        //Remainder = (8-Remainder)*(count<8);          //]<---+ even slower by 10s
	        //Remainder = (8-Remainder)&(-(count<8));       //]<---+ slower
	        buf1ICL = buf1ICL - 8 + count; //-Remainder; //- 8 + count;
	        buf2ICL = buf2ICL - 8 + count; //-Remainder; //- 8 + count;

              buf1rev = 
              ((*(uint64_t *)buf1ICL & 0xFF00000000000000u) >> 56u) |
              ((*(uint64_t *)buf1ICL & 0x00FF000000000000u) >> 40u) |
              ((*(uint64_t *)buf1ICL & 0x0000FF0000000000u) >> 24u) |
              ((*(uint64_t *)buf1ICL & 0x000000FF00000000u) >>  8u) |
              ((*(uint64_t *)buf1ICL & 0x00000000FF000000u) <<  8u) |      
              ((*(uint64_t *)buf1ICL & 0x0000000000FF0000u) << 24u) |
              ((*(uint64_t *)buf1ICL & 0x000000000000FF00u) << 40u) |
              ((*(uint64_t *)buf1ICL & 0x00000000000000FFu) << 56u);

              buf2rev = 
              ((*(uint64_t *)buf2ICL & 0xFF00000000000000u) >> 56u) |
              ((*(uint64_t *)buf2ICL & 0x00FF000000000000u) >> 40u) |
              ((*(uint64_t *)buf2ICL & 0x0000FF0000000000u) >> 24u) |
              ((*(uint64_t *)buf2ICL & 0x000000FF00000000u) >>  8u) |
              ((*(uint64_t *)buf2ICL & 0x00000000FF000000u) <<  8u) |      
              ((*(uint64_t *)buf2ICL & 0x0000000000FF0000u) << 24u) |
              ((*(uint64_t *)buf2ICL & 0x000000000000FF00u) << 40u) |
              ((*(uint64_t *)buf2ICL & 0x00000000000000FFu) << 56u);

	        //buf1rev = be64_to_host(*(uint64_t *)buf1);
	        //buf2rev = be64_to_host(*(uint64_t *)buf2);
        //	buf1rev = _mm_shuffle_pi8 (*(__m64 *)buf1, (__m64)0x0001020304050607);
        //	buf2rev = _mm_shuffle_pi8 (*(__m64 *)buf2, (__m64)0x0001020304050607);
	        //buf1rev = htobe64(*(uint64_t *)buf1);
	        //buf2rev = htobe64(*(uint64_t *)buf2);
	        return (buf1rev > buf2rev) - (buf1rev < buf2rev);
	} else {
		if (count) { //1..7
		        while ( --count && *buf1ICL == *buf2ICL ) {++buf1ICL; ++buf2ICL;} 
        	        return( *(buf1ICL) - *(buf2ICL) );
       		} else {
                        if (*(buf1+NumberOfLFs) * *(buf2+NumberOfLFs)) { // Neither is zero
                                //SgndR = memcmp( (char *)*buf1, (char *)*buf2, MINKaze(*(buf1+NumberOfLFs),*(buf2+NumberOfLFs)) );
				//[ Avoid memcmp

	count=MINKaze(*(buf1+NumberOfLFs),*(buf2+NumberOfLFs));
	if (count>=8) {
                for (; count>8 && (*(uint64_t *)buf1ICL == *(uint64_t *)buf2ICL) ; count=count-8) {buf1ICL = buf1ICL + 8; buf2ICL = buf2ICL + 8;} 
	        //doing only QWORD compares, e.g. for count=9 shifting by 1 to handle the remainder
	        if (count>8) count=8;                   	//]----+
	        //Remainder = 0; // if (count>=8)               //]    |
	        //Remainder = (8-Remainder); // if (count<8)	//]    |
	        //Remainder = (8-Remainder)*(count<8);          //]<---+ even slower by 10s
	        //Remainder = (8-Remainder)&(-(count<8));       //]<---+ slower
	        buf1ICL = buf1ICL - 8 + count; //-Remainder; //- 8 + count;
	        buf2ICL = buf2ICL - 8 + count; //-Remainder; //- 8 + count;

              buf1rev = 
              ((*(uint64_t *)buf1ICL & 0xFF00000000000000u) >> 56u) |
              ((*(uint64_t *)buf1ICL & 0x00FF000000000000u) >> 40u) |
              ((*(uint64_t *)buf1ICL & 0x0000FF0000000000u) >> 24u) |
              ((*(uint64_t *)buf1ICL & 0x000000FF00000000u) >>  8u) |
              ((*(uint64_t *)buf1ICL & 0x00000000FF000000u) <<  8u) |      
              ((*(uint64_t *)buf1ICL & 0x0000000000FF0000u) << 24u) |
              ((*(uint64_t *)buf1ICL & 0x000000000000FF00u) << 40u) |
              ((*(uint64_t *)buf1ICL & 0x00000000000000FFu) << 56u);

              buf2rev = 
              ((*(uint64_t *)buf2ICL & 0xFF00000000000000u) >> 56u) |
              ((*(uint64_t *)buf2ICL & 0x00FF000000000000u) >> 40u) |
              ((*(uint64_t *)buf2ICL & 0x0000FF0000000000u) >> 24u) |
              ((*(uint64_t *)buf2ICL & 0x000000FF00000000u) >>  8u) |
              ((*(uint64_t *)buf2ICL & 0x00000000FF000000u) <<  8u) |      
              ((*(uint64_t *)buf2ICL & 0x0000000000FF0000u) << 24u) |
              ((*(uint64_t *)buf2ICL & 0x000000000000FF00u) << 40u) |
              ((*(uint64_t *)buf2ICL & 0x00000000000000FFu) << 56u);

	        //buf1rev = be64_to_host(*(uint64_t *)buf1);
	        //buf2rev = be64_to_host(*(uint64_t *)buf2);
        //	buf1rev = _mm_shuffle_pi8 (*(__m64 *)buf1, (__m64)0x0001020304050607);
        //	buf2rev = _mm_shuffle_pi8 (*(__m64 *)buf2, (__m64)0x0001020304050607);
	        //buf1rev = htobe64(*(uint64_t *)buf1);
	        //buf2rev = htobe64(*(uint64_t *)buf2);
	        SgndR = (buf1rev > buf2rev) - (buf1rev < buf2rev);
	} else { // count inhere is non-zero
		        while ( --count && *buf1ICL == *buf2ICL ) {++buf1ICL; ++buf2ICL;} 
        	        SgndR = ( *(buf1ICL) - *(buf2ICL) );
	}

				//] Avoid memcmp
                                if (SgndR !=0) return SgndR;
                                // Inhere SgndR == 0
                                //if ( !(*(buf1+NumberOfLFs) - *(buf2+NumberOfLFs)) ) return SgndR; // If they are of equal length  - return 0 which is their delta
                        }
                        return (*(buf1+NumberOfLFs) - *(buf2+NumberOfLFs));
		}
	}
}

inline int32_t memcmpKAZE_QWORD_reversePTR_countISzero (uint64_t *buf1, uint64_t *buf2, size_t NumberOfLFs) {
	unsigned char * buf1ICL=(unsigned char *)*buf1;
	unsigned char * buf2ICL=(unsigned char *)*buf2;
        int SgndR;
	uint64_t buf1rev;
	uint64_t buf2rev;
	size_t count;
	//int Remainder=count%8;
        //if (!count) return(0);
                        if (*(buf1+NumberOfLFs) * *(buf2+NumberOfLFs)) { // Neither is zero
                                //SgndR = memcmp( (char *)*buf1, (char *)*buf2, MINKaze(*(buf1+NumberOfLFs),*(buf2+NumberOfLFs)) );
				//[ Avoid memcmp

	count=MINKaze(*(buf1+NumberOfLFs),*(buf2+NumberOfLFs));
	if (count>=8) {
                for (; count>8 && (*(uint64_t *)buf1ICL == *(uint64_t *)buf2ICL) ; count=count-8) {buf1ICL = buf1ICL + 8; buf2ICL = buf2ICL + 8;} 
	        //doing only QWORD compares, e.g. for count=9 shifting by 1 to handle the remainder
	        if (count>8) count=8;                   	//]----+
	        //Remainder = 0; // if (count>=8)               //]    |
	        //Remainder = (8-Remainder); // if (count<8)	//]    |
	        //Remainder = (8-Remainder)*(count<8);          //]<---+ even slower by 10s
	        //Remainder = (8-Remainder)&(-(count<8));       //]<---+ slower
	        buf1ICL = buf1ICL - 8 + count; //-Remainder; //- 8 + count;
	        buf2ICL = buf2ICL - 8 + count; //-Remainder; //- 8 + count;

              buf1rev = 
              ((*(uint64_t *)buf1ICL & 0xFF00000000000000u) >> 56u) |
              ((*(uint64_t *)buf1ICL & 0x00FF000000000000u) >> 40u) |
              ((*(uint64_t *)buf1ICL & 0x0000FF0000000000u) >> 24u) |
              ((*(uint64_t *)buf1ICL & 0x000000FF00000000u) >>  8u) |
              ((*(uint64_t *)buf1ICL & 0x00000000FF000000u) <<  8u) |      
              ((*(uint64_t *)buf1ICL & 0x0000000000FF0000u) << 24u) |
              ((*(uint64_t *)buf1ICL & 0x000000000000FF00u) << 40u) |
              ((*(uint64_t *)buf1ICL & 0x00000000000000FFu) << 56u);

              buf2rev = 
              ((*(uint64_t *)buf2ICL & 0xFF00000000000000u) >> 56u) |
              ((*(uint64_t *)buf2ICL & 0x00FF000000000000u) >> 40u) |
              ((*(uint64_t *)buf2ICL & 0x0000FF0000000000u) >> 24u) |
              ((*(uint64_t *)buf2ICL & 0x000000FF00000000u) >>  8u) |
              ((*(uint64_t *)buf2ICL & 0x00000000FF000000u) <<  8u) |      
              ((*(uint64_t *)buf2ICL & 0x0000000000FF0000u) << 24u) |
              ((*(uint64_t *)buf2ICL & 0x000000000000FF00u) << 40u) |
              ((*(uint64_t *)buf2ICL & 0x00000000000000FFu) << 56u);

	        //buf1rev = be64_to_host(*(uint64_t *)buf1);
	        //buf2rev = be64_to_host(*(uint64_t *)buf2);
        //	buf1rev = _mm_shuffle_pi8 (*(__m64 *)buf1, (__m64)0x0001020304050607);
        //	buf2rev = _mm_shuffle_pi8 (*(__m64 *)buf2, (__m64)0x0001020304050607);
	        //buf1rev = htobe64(*(uint64_t *)buf1);
	        //buf2rev = htobe64(*(uint64_t *)buf2);
	        SgndR = (buf1rev > buf2rev) - (buf1rev < buf2rev);
	} else { // count inhere is non-zero
		        while ( --count && *buf1ICL == *buf2ICL ) {++buf1ICL; ++buf2ICL;} 
        	        SgndR = ( *(buf1ICL) - *(buf2ICL) );
	}

				//] Avoid memcmp
                                if (SgndR !=0) return SgndR;
                                // Inhere SgndR == 0
                                //if ( !(*(buf1+NumberOfLFs) - *(buf2+NumberOfLFs)) ) return SgndR; // If they are of equal length  - return 0 which is their delta
                        }
                        return (*(buf1+NumberOfLFs) - *(buf2+NumberOfLFs));
}

void Quicksort_Magnetica_v18_Balxchonka_indirect (uint64_t* Left, uint64_t* Right, size_t Order) {
        uint64_t* Stack[M18_StackEntries];
        uint64_t *Indx, *Jndx, *PL, *PR;
        uint64_t StackPtr = 0;
        uint64_t Pivot;
        register uint64_t x0,x1,x2,x3,x4,x5,x6,x7,x8;
        int o0,o1,o2,o3,o4,o5,o6,o7,o8;
        int DontRelyOnCompiler;
        StackPtr++; Stack[StackPtr] = Left; // M18_StackEntries minimum is 3 i.e. Stack[0]=unused,Stack[1],Stack[2] i.e. one entry/pair
        StackPtr++; Stack[StackPtr] = Right;

        do { //while ( (StackPtr != 0) );
                Right = Stack[StackPtr];
                Left = Stack[StackPtr - 1];
                StackPtr = StackPtr - 2;
                for(;(M18_InsertionsortTHRESHOLD < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
                                        Jndx = Right;
// if ((1LL<<17) < Right-Left) {
//                                         M18_swapUnconditional (Left + (1*(Right-Left)>>3), Left + (2*(Right-Left)>>2)-3);
//                                         M18_swapUnconditional (Left + (2*(Right-Left)>>3), Left + (2*(Right-Left)>>2)-2);
//                                         M18_swapUnconditional (Left + (3*(Right-Left)>>3), Left + (2*(Right-Left)>>2)-1);
//                                         //M18_swapUnconditional (Left + (4*(Right-Left)>>3), Left + (2*(Right-Left)>>2)-0);
//                                         M18_swapUnconditional (Left + (5*(Right-Left)>>3), Left + (2*(Right-Left)>>2)+1);
//                                         M18_swapUnconditional (Left + (6*(Right-Left)>>3), Left + (2*(Right-Left)>>2)+2);
//                                         M18_swapUnconditional (Left + (7*(Right-Left)>>3), Left + (2*(Right-Left)>>2)+3);
// 
//                                                 // sorting 7 elements [
//                                                 /*
//                                                 x0 = *(Left+0);
//                                                 x1 = *(Left+1);
//                                                 x2 = *(Left+2);
//                                                 x3 = *(Left+3);
//                                                 x4 = *(Left+4);
//                                                 x5 = *(Left+5);
//                                                 x6 = *(Left+6);
//                                                 o0 = (x0>x1)+(x0>x2)+(x0>x3)+(x0>x4)+(x0>x5)+(x0>x6);
//                                                 o1 = (x1>=x0)+(x1>x2)+(x1>x3)+(x1>x4)+(x1>x5)+(x1>x6);
//                                                 o2 = (x2>=x0)+(x2>=x1)+(x2>x3)+(x2>x4)+(x2>x5)+(x2>x6);
//                                                 o3 = (x3>=x0)+(x3>=x1)+(x3>=x2)+(x3>x4)+(x3>x5)+(x3>x6);
//                                                 o4 = (x4>=x0)+(x4>=x1)+(x4>=x2)+(x4>=x3)+(x4>x5)+(x4>x6);
//                                                 o5 = (x5>=x0)+(x5>=x1)+(x5>=x2)+(x5>=x3)+(x5>=x4)+(x5>x6);
//                                                 o6 = (0+1+2+3+4+5+6)-(o0+o1+o2+o3+o4+o5);
//                                                 *(Left+o0)=x0;
//                                                 *(Left+o1)=x1;
//                                                 *(Left+o2)=x2;
//                                                 *(Left+o3)=x3;
//                                                 *(Left+o4)=x4;
//                                                 *(Left+o5)=x5;
//                                                 *(Left+o6)=x6;
//                                                 */
//                                                 // sorting 7 elements ]
//                                                 x0 = *(Left + (2*(Right-Left)>>2)-3+0);
//                                                 x1 = *(Left + (2*(Right-Left)>>2)-3+1);
//                                                 x2 = *(Left + (2*(Right-Left)>>2)-3+2);
//                                                 x3 = *(Left + (2*(Right-Left)>>2)-3+3);
//                                                 x4 = *(Left + (2*(Right-Left)>>2)-3+4);
//                                                 x5 = *(Left + (2*(Right-Left)>>2)-3+5);
//                                                 x6 = *(Left + (2*(Right-Left)>>2)-3+6);
// 
//                                                 //o0 = (x0>x1)+(x0>x2)+(x0>x3)+(x0>x4)+(x0>x5)+(x0>x6);
//                                                 o0 = (memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x1, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x2, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x3, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x4, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x5, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x6, Order)>0);
// 
//                                                 //o1 = (x1>=x0)+(x1>x2)+(x1>x3)+(x1>x4)+(x1>x5)+(x1>x6);
//                                                 o1 = (memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x0, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x2, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x3, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x4, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x5, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x6, Order)>0);
// 
//                                                 //o2 = (x2>=x0)+(x2>=x1)+(x2>x3)+(x2>x4)+(x2>x5)+(x2>x6);
//                                                 o2 = (memcmpKAZE_QWORD_reverse((const void *)x2, (const void *)x0, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x2, (const void *)x1, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x2, (const void *)x3, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x2, (const void *)x4, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x2, (const void *)x5, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x2, (const void *)x6, Order)>0);
// 
//                                                 //o3 = (x3>=x0)+(x3>=x1)+(x3>=x2)+(x3>x4)+(x3>x5)+(x3>x6);
//                                                 o3 = (memcmpKAZE_QWORD_reverse((const void *)x3, (const void *)x0, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x3, (const void *)x1, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x3, (const void *)x2, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x3, (const void *)x4, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x3, (const void *)x5, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x3, (const void *)x6, Order)>0);
// 
//                                                 //o4 = (x4>=x0)+(x4>=x1)+(x4>=x2)+(x4>=x3)+(x4>x5)+(x4>x6);
//                                                 o4 = (memcmpKAZE_QWORD_reverse((const void *)x4, (const void *)x0, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x4, (const void *)x1, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x4, (const void *)x2, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x4, (const void *)x3, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x4, (const void *)x5, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x4, (const void *)x6, Order)>0);
// 
//                                                 //o5 = (x5>=x0)+(x5>=x1)+(x5>=x2)+(x5>=x3)+(x5>=x4)+(x5>x6);
//                                                 o5 = (memcmpKAZE_QWORD_reverse((const void *)x5, (const void *)x0, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x5, (const void *)x1, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x5, (const void *)x2, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x5, (const void *)x3, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x5, (const void *)x4, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x5, (const void *)x6, Order)>0);
// 
//                                                 o6 = (0+1+2+3+4+5+6)-(o0+o1+o2+o3+o4+o5);
//                                                 *(Left + (2*(Right-Left)>>2)-3+o0)=x0;
//                                                 *(Left + (2*(Right-Left)>>2)-3+o1)=x1;
//                                                 *(Left + (2*(Right-Left)>>2)-3+o2)=x2;
//                                                 *(Left + (2*(Right-Left)>>2)-3+o3)=x3;
//                                                 *(Left + (2*(Right-Left)>>2)-3+o4)=x4;
//                                                 *(Left + (2*(Right-Left)>>2)-3+o5)=x5;
//                                                 *(Left + (2*(Right-Left)>>2)-3+o6)=x6;
// } else if ((1LL<<9) < Right-Left) {
/*
if ((1LL<<9) < Right-Left) {
                                        M18_swapUnconditional (Left + (1*(Right-Left)>>2), Left + (2*(Right-Left)>>2)-1);
                                        M18_swapUnconditional (Left + (3*(Right-Left)>>2), Left + (2*(Right-Left)>>2)+1);
                                        x0 = *(Left + (2*(Right-Left)>>2)-1+0);
                                        x1 = *(Left + (2*(Right-Left)>>2)-1+1);
                                        x2 = *(Left + (2*(Right-Left)>>2)-1+2);
                                        o0 = ( memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x1, Order) > 0 )+( memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x2, Order) > 0 ); //(x0>x1)+(x0>x2);
                                        o1 = ( memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x0, Order) >= 0 )+( memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x2, Order) > 0 ); //(x1>=x0)+(x1>x2);
                                        o2 = (0+1+2)-(o0+o1);
                                        *(Left + (2*(Right-Left)>>2)-1+o0)=x0;
                                        *(Left + (2*(Right-Left)>>2)-1+o1)=x1;
                                        *(Left + (2*(Right-Left)>>2)-1+o2)=x2;
}
*/
                                        Pivot = *(Left + (2*(Right-Left)>>2)); //Pivot = *(Left + ((Right-Left)>>1));
                                        PL = Left;                                            
                                        //for (;*PL < Pivot; PL++) {                            
                                        for (;memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)Pivot, Order) < 0; PL++) {
//                                      for (;CompareOrder(*PL, Pivot, Order) < 0; PL++) { //== -1; PL++) {                            
                                        }                                                     
                                        PR = PL;                                              
                                        M18_swapUnconditional (Left + ((Right-Left)>>1), PL); 
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP [
                                        for (;PR < Jndx;) {
                                                PR = PR + 1;
                                                //if (Pivot > *PR) { // *PL == Pivot
                                                //if (*PL > *PR) { // *PL == Pivot
                                                DontRelyOnCompiler = memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)*PR, Order);
//                                                DontRelyOnCompiler = CompareOrder(*PL, *PR, Order);
                                                if (DontRelyOnCompiler > 0) {
//                                              if (CompareOrder(*PL, *PR, Order) > 0) {//== 1) {== 1) { // *PL == Pivot // Remember already, memcmp doesn't return -1|1 but <0|>0
                                                        M18_swapUnconditional (PL, PR);
                                                        //*PL=*PR; *PR=Pivot;
                                                        PL = PL + 1;
                                                //} else if (Pivot < *PR) {
                                                } else if (DontRelyOnCompiler < 0) {
//                                              } else if (CompareOrder(*PL, *PR, Order) < 0) {//== -1) {
                                                        //for (;Pivot < *Jndx;) {
                                                    for (;memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)*Jndx, Order) < 0;) {
//                                                    for (;CompareOrder(*PL, *Jndx, Order) < 0;) {//== -1;) {
                                                                Jndx = Jndx - 1;
                                                        }
                                                        M18_swapUnconditional (PR, Jndx);
                                                        Jndx = Jndx - 1;                 
                                                        PR = PR - 1;                     
                                                }
                                        }
                                        M18_SwapConditional_ifXbY_BUGGY((uint64_t)Jndx, (uint64_t)PR, PR+1, Jndx+1);
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP ]
                                        StackPtr = StackPtr + 2;
                                        Stack[StackPtr - 1] = PR + 1;
                                        Stack[StackPtr] = Right;
                                        Right = PL - 1;
                } //for(;(M18_InsertionsortTHRESHOLD < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
        } while ( (StackPtr != 0) );
}

#define Mv18_MedianOfTri
void Quicksort_Magnetica_v18_BalxchonkaForte_indirect (uint64_t* Left, uint64_t* Right, size_t Order, size_t NumberOfLFs) {
        uint64_t* Stack[M18_StackEntries];
        uint64_t *Indx, *Jndx, *PL, *PR;
        uint64_t StackPtr = 0;
        uint64_t Pivot;
        uint64_t* LeftBackup = Left;
        uint64_t* RightBackup = Right;
	//uint64_t NumberOfLFs=(uint64_t)(Right-Left+1); //*(Left+NumberOfLFs-1)==*Right
        register uint64_t x0,x1,x2,x3,x4,x5,x6,x7,x8;
        int64_t ABsgnd;
        int o0,o1,o2,o3,o4,o5,o6,o7,o8;
        int DontRelyOnCompiler;
        int M19_InsertionsortTHRESHOLD = 13;
        StackPtr++; Stack[StackPtr] = Left; // M18_StackEntries minimum is 3 i.e. Stack[0]=unused,Stack[1],Stack[2] i.e. one entry/pair
        StackPtr++; Stack[StackPtr] = Right;

if (Order !=0 ) {
        do { //while ( (StackPtr != 0) );
                Right = Stack[StackPtr];
                Left = Stack[StackPtr - 1];
                StackPtr = StackPtr - 2;
                for(;(M18_InsertionsortTHRESHOLD < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
					#ifdef Mv18_MedianOfTri
                                        if ( (Right-Left) > (1LL<<9) ) { // 15 is slow, 9 is better, didn't play enough
	                                        M18_swapUnconditionalPAIR ( (Left + (2*((Right-Left)>>2)-1) +0), (Left + (1*((Right-Left)>>2)-1) +1), NumberOfLFs );
	                                        M18_swapUnconditionalPAIR ( (Left + (2*((Right-Left)>>2)-1) +2), (Left + (3*((Right-Left)>>2)-1) +1), NumberOfLFs );
                                                x0 = *(Left + (2*((Right-Left)>>2)-1) +0); x3 = *(Left + (2*((Right-Left)>>2)-1) +0 +NumberOfLFs);
                                                x1 = *(Left + (2*((Right-Left)>>2)-1) +1); x4 = *(Left + (2*((Right-Left)>>2)-1) +1 +NumberOfLFs);
                                                x2 = *(Left + (2*((Right-Left)>>2)-1) +2); x5 = *(Left + (2*((Right-Left)>>2)-1) +2 +NumberOfLFs);
                                                o0 = (memcmpKAZE_QWORD_reversePTR((Left + (2*((Right-Left)>>2)-1) +0), (Left + (2*((Right-Left)>>2)-1) +1), Order, NumberOfLFs)>0)+(memcmpKAZE_QWORD_reversePTR((Left + (2*((Right-Left)>>2)-1) +0), (Left + (2*((Right-Left)>>2)-1) +2), Order, NumberOfLFs)>0); //o0 = (memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x1, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x2, Order)>0);
                                                o1 = (memcmpKAZE_QWORD_reversePTR((Left + (2*((Right-Left)>>2)-1) +1), (Left + (2*((Right-Left)>>2)-1) +0), Order, NumberOfLFs)>=0)+(memcmpKAZE_QWORD_reversePTR((Left + (2*((Right-Left)>>2)-1) +1), (Left + (2*((Right-Left)>>2)-1) +2), Order, NumberOfLFs)>0); //o1 = (memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x0, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x2, Order)>0);
                                                o2 = (0+1+2)-(o0+o1);
                                                *((Left+ (2*((Right-Left)>>2)-1) +o0)+NumberOfLFs) = x3;
                                                *((Left+ (2*((Right-Left)>>2)-1) +o1)+NumberOfLFs) = x4;
                                                *((Left+ (2*((Right-Left)>>2)-1) +o2)+NumberOfLFs) = x5;
                                                *(Left+ (2*((Right-Left)>>2)-1) +o0)=x0;
                                                *(Left+ (2*((Right-Left)>>2)-1) +o1)=x1;
                                                *(Left+ (2*((Right-Left)>>2)-1) +o2)=x2;
                                        /*
                                                // sorting 3 elements [
                                                x0 = *(Left + (2*((Right-Left)>>2)-1) +0);
                                                x1 = *(Left + (2*((Right-Left)>>2)-1) +1);
                                                x2 = *(Left + (2*((Right-Left)>>2)-1) +2);
                                                o0 = (x0>x1)+(x0>x2);
                                                o1 = (x1>=x0)+(x1>x2);
                                                o2 = (0+1+2)-(o0+o1);
                                                *(Left+ (2*((Right-Left)>>2)-1) +o0)=x0;
                                                *(Left+ (2*((Right-Left)>>2)-1) +o1)=x1;
                                                *(Left+ (2*((Right-Left)>>2)-1) +o2)=x2;
                                                // sorting 3 elements ]
                                        */
                                                // 23 instructions!
                                                /*
                                                ..1.200_0.TAG.02.0.200::
                                                .B60.35::                       
                                                  00e09 48 8b 3a         mov rdi, QWORD PTR [rdx]               
                                                  00e0c 33 db            xor ebx, ebx                           
                                                  00e0e 4c 8b 42 08      mov r8, QWORD PTR [8+rdx]              
                                                  00e12 49 3b f8         cmp rdi, r8                            
                                                  00e15 4c 8b 4a 10      mov r9, QWORD PTR [16+rdx]             
                                                  00e19 0f 97 c3         seta bl                                
                                                  00e1c 33 c0            xor eax, eax                           
                                                  00e1e 49 3b f9         cmp rdi, r9                            
                                                  00e21 0f 97 c0         seta al                                
                                                  00e24 33 f6            xor esi, esi                           
                                                  00e26 33 ed            xor ebp, ebp                           
                                                  00e28 4c 3b c7         cmp r8, rdi                            
                                                  00e2b 40 0f 93 c6      setae sil                              
                                                  00e2f 4d 3b c1         cmp r8, r9                             
                                                  00e32 40 0f 97 c5      seta bpl                               
                                                  00e36 03 d8            add ebx, eax                           
                                                  00e38 03 f5            add esi, ebp                           
                                                  00e3a 48 89 3c da      mov QWORD PTR [rdx+rbx*8], rdi         
                                                  00e3e 48 03 de         add rbx, rsi                           
                                                  00e41 48 f7 db         neg rbx                                
                                                  00e44 4c 89 04 f2      mov QWORD PTR [rdx+rsi*8], r8          
                                                  00e48 4c 89 4c da 18   mov QWORD PTR [24+rdx+rbx*8], r9       
                                                  00e4d e9 33 f3 ff ff   jmp .B60.19 
                                                */
                                        }
					#endif
                                        Jndx = Right;
                                        Pivot = *(Left + (2*(Right-Left)>>2)); //Pivot = *(Left + ((Right-Left)>>1));
                                        PL = Left;                                            
                                        //for (;*PL < Pivot; PL++) {                            
                                        for (;memcmpKAZE_QWORD_reversePTR(PL, (Left + (2*(Right-Left)>>2)), Order, NumberOfLFs) < 0; PL++) { // for (;memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)Pivot, Order) < 0; PL++) {
//                                      for (;CompareOrder(*PL, Pivot, Order) < 0; PL++) { //== -1; PL++) {                            
                                        }                                                     
                                        PR = PL;                                              
                                        M18_swapUnconditionalPAIR (Left + ((Right-Left)>>1), PL, NumberOfLFs);//M18_swapUnconditional (Left + ((Right-Left)>>1), PL); 
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP [
                                        for (;PR < Jndx;) {
                                                PR = PR + 1;
                                                //if (Pivot > *PR) { // *PL == Pivot
                                                //if (*PL > *PR) { // *PL == Pivot
                                                DontRelyOnCompiler = memcmpKAZE_QWORD_reversePTR(PL, PR, Order, NumberOfLFs); // DontRelyOnCompiler = memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)*PR, Order);
//                                                DontRelyOnCompiler = CompareOrder(*PL, *PR, Order);
                                                if (DontRelyOnCompiler > 0) {
//                                              if (CompareOrder(*PL, *PR, Order) > 0) {//== 1) {== 1) { // *PL == Pivot // Remember already, memcmp doesn't return -1|1 but <0|>0
                                                        M18_swapUnconditionalPAIR (PL, PR, NumberOfLFs);//M18_swapUnconditional (PL, PR);
                                                        //*PL=*PR; *PR=Pivot;
                                                        PL = PL + 1;
                                                //} else if (Pivot < *PR) {
                                                } else if (DontRelyOnCompiler < 0) {
//                                              } else if (CompareOrder(*PL, *PR, Order) < 0) {//== -1) {
                                                        //for (;Pivot < *Jndx;) {
                                                    for (;memcmpKAZE_QWORD_reversePTR(PL, Jndx, Order, NumberOfLFs) < 0;) { // for (;memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)*Jndx, Order) < 0;) {
//                                                    for (;CompareOrder(*PL, *Jndx, Order) < 0;) {//== -1;) {
                                                                Jndx = Jndx - 1;
                                                        }
                                                        M18_swapUnconditionalPAIR (PR, Jndx, NumberOfLFs);//M18_swapUnconditional (PR, Jndx);
                                                        Jndx = Jndx - 1;                 
                                                        PR = PR - 1;                     
                                                }
                                        }
                                        //2022-Oct-18: [
                                        M18_SwapConditional_ifXbY_BUGGYPAIR((uint64_t)Jndx, (uint64_t)PR, PR+1, Jndx+1, NumberOfLFs); // if ((uint64_t)Jndx < (uint64_t)PR) M18_swapUnconditionalPAIR (PR+1, Jndx+1, NumberOfLFs);//M18_SwapConditional_ifXbY_BUGGY((uint64_t)Jndx, (uint64_t)PR, PR+1, Jndx+1);
                                        //2022-Oct-18: ]
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP ]
                                        StackPtr = StackPtr + 2;
                                        ABsgnd=(int64_t)(Right-(PR + 1)) - (int64_t)((PL - 1)-Left);                                    //]---+
                                        ABsgnd=(ABsgnd >> 63);                                                                          //]   |
                                        Stack[StackPtr - 1] = (uint64_t*)( (ABsgnd&(int64_t)Left) + ((~ABsgnd)&(int64_t)(PR + 1)) );    //]   |
                                        Stack[StackPtr] = (uint64_t*)( (ABsgnd&(int64_t)(PL - 1)) + ((~ABsgnd)&(int64_t)(Right)) );     //]   |
                                        Left = (uint64_t*)( (ABsgnd&(int64_t)(PR + 1)) + ((~ABsgnd)&(int64_t)(Left)) );                 //]   |
                                        Right = (uint64_t*)( (ABsgnd&(int64_t)(Right)) + ((~ABsgnd)&(int64_t)(PL - 1)) );               //]   |
                                                                                                                                        //    |
                                        //if ( Right-(PR + 1) > (PL - 1)-Left ) {                                                       //]<--+
                                        //        Stack[StackPtr - 1] = PR + 1;                                                         //]
                                        //        Stack[StackPtr] = Right;                                                              //]
                                        //        Right = PL - 1;                                                                       //]
                                        //} else {                                                                                      //]
                                        //        Stack[StackPtr - 1] = Left;                                                           //]
                                        //        Stack[StackPtr] = PL - 1;                                                             //]
                                        //        Left = PR + 1;                                                                        //]
                                        //}                                                                                             //]
                } //for(;(M18_InsertionsortTHRESHOLD < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
        } while ( (StackPtr != 0) );
	// Insertionsort [
        for (Indx=LeftBackup+1; Indx <= MINKaze(M19_InsertionsortTHRESHOLD + LeftBackup,RightBackup); Indx++) { // Ensuring (with this sort) the first (M18_InsertionsortTHRESHOLDcoffin + 1) keys are sorted.
                Jndx = Indx;
                for (;Jndx >= LeftBackup+1;) {
                        //if (*(Jndx-1) > *Jndx) M18_swapUnconditional (Jndx-1, Jndx); else break;
                        if ( memcmpKAZE_QWORD_reversePTR((Jndx-1), Jndx, Order, NumberOfLFs) > 0 ) M18_swapUnconditionalPAIR (Jndx-1, Jndx, NumberOfLFs); else break;
                        Jndx = Jndx - 1;
                }
        }
        for (Indx=LeftBackup+1; Indx <= RightBackup; Indx++) { // Ensuring (with this sort) the first (M18_InsertionsortTHRESHOLDcoffin + 1) keys are sorted.
                Jndx = Indx;
                for (;;) {
                        //if (*(Jndx-1) > *Jndx) M18_swapUnconditional (Jndx-1, Jndx); else break;
                        if ( memcmpKAZE_QWORD_reversePTR((Jndx-1), Jndx, Order, NumberOfLFs) > 0 ) M18_swapUnconditionalPAIR (Jndx-1, Jndx, NumberOfLFs); else break;
                        Jndx = Jndx - 1;
                }
        }
	// Insertionsort ]

} else { //if (Order !=0 ) {
//...
} //if (Order !=0 ) {
}

void Quicksort_Magnetica_v19_BalxchonkaForte_indirect_ZERO (uint64_t* Left, uint64_t* Right, size_t Order, size_t NumberOfLFs) {
        uint64_t* Stack[M18_StackEntries];
        uint64_t *Indx, *Jndx, *PL, *PR;
        uint64_t StackPtr = 0;
        uint64_t Pivot;
        uint64_t* LeftBackup = Left;
        uint64_t* RightBackup = Right;
	//uint64_t NumberOfLFs=(uint64_t)(Right-Left+1); //*(Left+NumberOfLFs-1)==*Right
        register uint64_t x0,x1,x2,x3,x4,x5,x6,x7,x8;
        int64_t ABsgnd;
        int o0,o1,o2,o3,o4,o5,o6,o7,o8;
        int DontRelyOnCompiler;
        int M19_InsertionsortTHRESHOLD = 13;
        StackPtr++; Stack[StackPtr] = Left; // M18_StackEntries minimum is 3 i.e. Stack[0]=unused,Stack[1],Stack[2] i.e. one entry/pair
        StackPtr++; Stack[StackPtr] = Right;

                Right = Stack[StackPtr];
                Left = Stack[StackPtr - 1];
                StackPtr = StackPtr - 2;
        FuseWhileAndFor:
        //do { //while ( (StackPtr != 0) );
                //Right = Stack[StackPtr];
                //Left = Stack[StackPtr - 1];
                //StackPtr = StackPtr - 2;
                for(;(M19_InsertionsortTHRESHOLD < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
					#ifdef Mv18_MedianOfTri
                                        if ( (Right-Left) > (1LL<<9) ) { // 15 is slow, 9 is better, didn't play enough
	                                        M18_swapUnconditionalPAIR ( (Left + (2*((Right-Left)>>2)-1) +0), (Left + (1*((Right-Left)>>2)-1) +1), NumberOfLFs );
	                                        M18_swapUnconditionalPAIR ( (Left + (2*((Right-Left)>>2)-1) +2), (Left + (3*((Right-Left)>>2)-1) +1), NumberOfLFs );
                                                x0 = *(Left + (2*((Right-Left)>>2)-1) +0); x3 = *(Left + (2*((Right-Left)>>2)-1) +0 +NumberOfLFs);
                                                x1 = *(Left + (2*((Right-Left)>>2)-1) +1); x4 = *(Left + (2*((Right-Left)>>2)-1) +1 +NumberOfLFs);
                                                x2 = *(Left + (2*((Right-Left)>>2)-1) +2); x5 = *(Left + (2*((Right-Left)>>2)-1) +2 +NumberOfLFs);
                                                o0 = (memcmpKAZE_QWORD_reversePTR_countISzero((Left + (2*((Right-Left)>>2)-1) +0), (Left + (2*((Right-Left)>>2)-1) +1), NumberOfLFs)>0)+(memcmpKAZE_QWORD_reversePTR_countISzero((Left + (2*((Right-Left)>>2)-1) +0), (Left + (2*((Right-Left)>>2)-1) +2), NumberOfLFs)>0); //o0 = (memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x1, Order)>0)+(memcmpKAZE_QWORD_reverse((const void *)x0, (const void *)x2, Order)>0);
                                                o1 = (memcmpKAZE_QWORD_reversePTR_countISzero((Left + (2*((Right-Left)>>2)-1) +1), (Left + (2*((Right-Left)>>2)-1) +0), NumberOfLFs)>=0)+(memcmpKAZE_QWORD_reversePTR_countISzero((Left + (2*((Right-Left)>>2)-1) +1), (Left + (2*((Right-Left)>>2)-1) +2), NumberOfLFs)>0); //o1 = (memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x0, Order)>=0)+(memcmpKAZE_QWORD_reverse((const void *)x1, (const void *)x2, Order)>0);
                                                o2 = (0+1+2)-(o0+o1);
                                                *((Left+ (2*((Right-Left)>>2)-1) +o0)+NumberOfLFs) = x3;
                                                *((Left+ (2*((Right-Left)>>2)-1) +o1)+NumberOfLFs) = x4;
                                                *((Left+ (2*((Right-Left)>>2)-1) +o2)+NumberOfLFs) = x5;
                                                *(Left+ (2*((Right-Left)>>2)-1) +o0)=x0;
                                                *(Left+ (2*((Right-Left)>>2)-1) +o1)=x1;
                                                *(Left+ (2*((Right-Left)>>2)-1) +o2)=x2;
                                        }
					#endif
                                        Jndx = Right;
                                        Pivot = *(Left + (2*(Right-Left)>>2)); //Pivot = *(Left + ((Right-Left)>>1));
                                        PL = Left;                                            
                                        //for (;*PL < Pivot; PL++) {                            
                                        for (;memcmpKAZE_QWORD_reversePTR_countISzero(PL, (Left + (2*(Right-Left)>>2)), NumberOfLFs) < 0; PL++) { // for (;memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)Pivot, Order) < 0; PL++) {
//                                      for (;CompareOrder(*PL, Pivot, Order) < 0; PL++) { //== -1; PL++) {                            
                                        }                                                     
                                        PR = PL;                                              
                                        M18_swapUnconditionalPAIR (Left + ((Right-Left)>>1), PL, NumberOfLFs);//M18_swapUnconditional (Left + ((Right-Left)>>1), PL); 
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP [
                                        for (;PR < Jndx;) {
                                                PR = PR + 1;
                                                //if (Pivot > *PR) { // *PL == Pivot
                                                //if (*PL > *PR) { // *PL == Pivot
                                                DontRelyOnCompiler = memcmpKAZE_QWORD_reversePTR_countISzero(PL, PR, NumberOfLFs); // DontRelyOnCompiler = memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)*PR, Order);
//                                                DontRelyOnCompiler = CompareOrder(*PL, *PR, Order);
                                                if (DontRelyOnCompiler > 0) {
//                                              if (CompareOrder(*PL, *PR, Order) > 0) {//== 1) {== 1) { // *PL == Pivot // Remember already, memcmp doesn't return -1|1 but <0|>0
                                                        M18_swapUnconditionalPAIR (PL, PR, NumberOfLFs);//M18_swapUnconditional (PL, PR);
                                                        //*PL=*PR; *PR=Pivot;
                                                        PL = PL + 1;
                                                //} else if (Pivot < *PR) {
                                                } else if (DontRelyOnCompiler < 0) {
//                                              } else if (CompareOrder(*PL, *PR, Order) < 0) {//== -1) {
                                                        //for (;Pivot < *Jndx;) {
                                                    for (;memcmpKAZE_QWORD_reversePTR_countISzero(PL, Jndx, NumberOfLFs) < 0;) { // for (;memcmpKAZE_QWORD_reverse((const void *)*PL, (const void *)*Jndx, Order) < 0;) {
//                                                    for (;CompareOrder(*PL, *Jndx, Order) < 0;) {//== -1;) {
                                                                Jndx = Jndx - 1;
                                                        }
                                                        M18_swapUnconditionalPAIR (PR, Jndx, NumberOfLFs);//M18_swapUnconditional (PR, Jndx);
                                                        Jndx = Jndx - 1;                 
                                                        PR = PR - 1;                     
                                                }
                                        }
                                        //2022-Oct-18: [
                                        M18_SwapConditional_ifXbY_BUGGYPAIR((uint64_t)Jndx, (uint64_t)PR, PR+1, Jndx+1, NumberOfLFs); // if ((uint64_t)Jndx < (uint64_t)PR) M18_swapUnconditionalPAIR (PR+1, Jndx+1, NumberOfLFs);//M18_SwapConditional_ifXbY_BUGGY((uint64_t)Jndx, (uint64_t)PR, PR+1, Jndx+1);
                                        //2022-Oct-18: ]
                                        // 'Magnetica' partitioning, mainloop rev.5a2p_BYPASSSWAP ]
                                        StackPtr = StackPtr + 2;
                                        ABsgnd=(int64_t)(Right-(PR + 1)) - (int64_t)((PL - 1)-Left);                                    //]---+
                                        ABsgnd=(ABsgnd >> 63);                                                                          //]   |
                                        Stack[StackPtr - 1] = (uint64_t*)( (ABsgnd&(int64_t)Left) + ((~ABsgnd)&(int64_t)(PR + 1)) );    //]   |
                                        Stack[StackPtr] = (uint64_t*)( (ABsgnd&(int64_t)(PL - 1)) + ((~ABsgnd)&(int64_t)(Right)) );     //]   |

// No need to push to stack (UNPUSHING) if they are EQUAL [
                                        //StackPtr = StackPtr - 2*( (uint64_t*)( (ABsgnd&(int64_t)Left) + ((~ABsgnd)&(int64_t)(PR + 1)) ) == (uint64_t*)( (ABsgnd&(int64_t)(PL - 1)) + ((~ABsgnd)&(int64_t)(Right)) ) );
                                        //StackPtr = StackPtr - 2*( (Stack[StackPtr]-Stack[StackPtr - 1]) <= (1LL<<4) );
// No need to push to stack (UNPUSHING) if they are EQUAL ]

                                        Left = (uint64_t*)( (ABsgnd&(int64_t)(PR + 1)) + ((~ABsgnd)&(int64_t)(Left)) );                 //]   |
                                        Right = (uint64_t*)( (ABsgnd&(int64_t)(Right)) + ((~ABsgnd)&(int64_t)(PL - 1)) );               //]   |
                                                                                                                                        //    |
                                        //if ( Right-(PR + 1) > (PL - 1)-Left ) {                                                       //]<--+
                                        //        Stack[StackPtr - 1] = PR + 1;                                                         //]
                                        //        Stack[StackPtr] = Right;                                                              //]
                                        //        Right = PL - 1;                                                                       //]
                                        //} else {                                                                                      //]
                                        //        Stack[StackPtr - 1] = Left;                                                           //]
                                        //        Stack[StackPtr] = PL - 1;                                                             //]
                                        //        Left = PR + 1;                                                                        //]
                                        //}                                                                                             //]
                //if ( (Right-Left) > (1LL<<4) ) goto FuseWhileAndFor;
                } //for(;(M18_InsertionsortTHRESHOLD < Right-Left);) { // if not 1<Right-Left then Right=Left (i.e. 0), or adjacent (i.e. 1) ... or Left>Right
        //} while ( (StackPtr != 0) );
        if ( (StackPtr != 0) ) { // Inhere, (M18_InsertionsortTHRESHOLD < Right-Left) should be TRUE - it means all PAIRs pushed to stack should be checked first!
                Right = Stack[StackPtr];
                Left = Stack[StackPtr - 1];
                StackPtr = StackPtr - 2;
                goto FuseWhileAndFor;
        }

	// Insertionsort [
        for (Indx=LeftBackup+1; Indx <= MINKaze(M19_InsertionsortTHRESHOLD + LeftBackup,RightBackup); Indx++) { // Ensuring (with this sort) the first (M18_InsertionsortTHRESHOLDcoffin + 1) keys are sorted.
                Jndx = Indx;
                for (;Jndx >= LeftBackup+1;) {
                        //if (*(Jndx-1) > *Jndx) M18_swapUnconditional (Jndx-1, Jndx); else break;
                        if ( memcmpKAZE_QWORD_reversePTR_countISzero((Jndx-1), Jndx, NumberOfLFs) > 0 ) M18_swapUnconditionalPAIR (Jndx-1, Jndx, NumberOfLFs); else break;
                        Jndx = Jndx - 1;
                }
        }
        for (Indx=LeftBackup+1; Indx <= RightBackup; Indx++) { // Ensuring (with this sort) the first (M18_InsertionsortTHRESHOLDcoffin + 1) keys are sorted.
                Jndx = Indx;
                for (;;) {
                        //if (*(Jndx-1) > *Jndx) M18_swapUnconditional (Jndx-1, Jndx); else break;
                        if ( memcmpKAZE_QWORD_reversePTR_countISzero((Jndx-1), Jndx, NumberOfLFs) > 0 ) M18_swapUnconditionalPAIR (Jndx-1, Jndx, NumberOfLFs); else break;
                        Jndx = Jndx - 1;
                }
        }
	// Insertionsort ]
}

