#ifndef CHARLATANA_V28_H
#define CHARLATANA_V28_H

#include <immintrin.h>
#include <string.h> // memcpy()
#include <stdint.h>
#include <stddef.h>
#include <omp.h>

// Don't spawn OpenMP tasks for tiny chunks. It chokes the thread queue.
#define OMP_TASK_THRESHOLD 100000
#define INSERTION_THRESHOLD 64

__attribute__((aligned(32))) static const int32_t QWORD_PACK_TABLE[16][8] = {
    {0,1,2,3,4,5,6,7}, {0,1,2,3,4,5,6,7}, {2,3,0,1,4,5,6,7}, {0,1,2,3,4,5,6,7},
    {4,5,0,1,2,3,6,7}, {0,1,4,5,2,3,6,7}, {2,3,4,5,0,1,6,7}, {0,1,2,3,4,5,6,7},
    {6,7,0,1,2,3,4,5}, {0,1,6,7,2,3,4,5}, {2,3,6,7,0,1,4,5}, {0,1,2,3,6,7,4,5},
    {4,5,6,7,0,1,2,3}, {0,1,4,5,6,7,2,3}, {2,3,4,5,6,7,0,1}, {0,1,2,3,4,5,6,7}
};

__attribute__((aligned(32))) static const int64_t MASK_STORE_TABLE[5][4] = {
    {0, 0, 0, 0},
    {-1LL, 0, 0, 0},
    {-1LL, -1LL, 0, 0},
    {-1LL, -1LL, -1LL, 0},
    {-1LL, -1LL, -1LL, -1LL}
};

static inline __m256i Charlatana_cmplt_epu64(const __m256i a, const __m256i b) {
    const __m256i hbit = _mm256_set1_epi64x(0x8000000000000000ULL);
    return _mm256_cmpgt_epi64(_mm256_xor_si256(b, hbit), _mm256_xor_si256(a, hbit));
}

/*
static void charlatana_insertion_sort(uint64_t* arr, int64_t low, int64_t high) {
    for (int64_t i = low + 1; i <= high; i++) {
        uint64_t key = arr[i];
        int64_t j = i - 1;
        while (j >= low && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}
*/
static inline void charlatana_insertion_sort(uint64_t* arr, int64_t low, int64_t high) {
    uint64_t* base = arr + low;          /* everything relative to base */
    int64_t   n    = high - low + 1;     /* size (1 when low==high) */

    //if (n <= 1) return;                  /* optional one-liner guard if you prefer */

    /* min to front */
    int64_t min_idx = 0;
    for (int64_t k = 1; k < n; k++) {
        if (base[k] < base[min_idx]) min_idx = k;
    }
    uint64_t tmp = base[0];
    base[0]      = base[min_idx];
    base[min_idx]= tmp;

    /* sentinel insertion */
    for (int64_t i = 1; i < n; i++) {
        uint64_t  key  = base[i];
        uint64_t* jptr = base + i - 1;

        while (*jptr > key) {
            *(jptr + 1) = *jptr;
            jptr--;
        }
        *(jptr + 1) = key;
    }
}

//    if (n > OMP_TASK_THRESHOLD) { should be true on entrance (n = high - low + 1) i.e. for 1..33 n = 32 > 32 is false i.e. for 1..34 n = 33 > 32 is true
static void charlatana_v28_recursive(uint64_t* arr, int64_t low, int64_t high) {
    while (low < high) {
/*
        if (high - low < 48) {
            charlatana_insertion_sort(arr, low, high);
            return;
        }
*/

/*
        int64_t mid = low + (high - low) / 2;
        
        uint64_t v1 = arr[low], v2 = arr[mid], v3 = arr[high];
        uint64_t min1 = (v1 < v2) ? v1 : v2;
        uint64_t max1 = (v1 > v2) ? v1 : v2;
        uint64_t min2 = (max1 < v3) ? max1 : v3;
        uint64_t max2 = (max1 > v3) ? max1 : v3;
        uint64_t min3 = (min1 < min2) ? min1 : min2;
        uint64_t max3 = (min1 > min2) ? min1 : min2;
        arr[low] = min3;
        arr[mid] = max3;
        arr[high] = max2;
        
        uint64_t pivot = arr[mid];
*/

// Masks [
        // === YOUR 25%/50%/75% SAMPLING + BRANCHLESS MEDIAN (perfect for BELL) ===
        // This is exactly what you proposed — spread probes kill the BELL pattern
        // while staying 100 % branchless and only 3 loads + ~12 cheap ops.
        int64_t delta = high - low;
        uint64_t v1   = arr[low   + delta / 4];
        uint64_t v2   = arr[low   + delta / 2];
        uint64_t v3   = arr[high  - delta / 4];

 // min/max of first pair
 uint64_t mask_min_xy = -(uint64_t)(v1 > v2);
 uint64_t mask_max_xy = -(uint64_t)(v1 < v2);
 uint64_t min_xy = v1 ^ ((v1 ^ v2) & mask_min_xy);
 uint64_t max_xy = v1 ^ ((v1 ^ v2) & mask_max_xy);

 // min of (min_xy, v3)
 uint64_t mask_min = -(uint64_t)(min_xy > v3);
 uint64_t overall_min = min_xy ^ ((min_xy ^ v3) & mask_min);

 // max of (max_xy, v3)
 uint64_t mask_max = -(uint64_t)(max_xy < v3);
 uint64_t overall_max = max_xy ^ ((max_xy ^ v3) & mask_max);

 // median = xor of all three minus min minus max
 uint64_t pivot = v1 ^ v2 ^ v3 ^ overall_min ^ overall_max;
// Masks ]

        __m256i v_pivot = _mm256_set1_epi64x(pivot);
        
        uint64_t* read_ptr_L = arr + low;
        uint64_t* write_ptr_L = arr + low;
        uint64_t* read_ptr_R = arr + high + 1;
        uint64_t* write_ptr_R = arr + high + 1;

        uint64_t buf_L[256];
        uint64_t buf_R[256];
        int count_L = 0;
        int count_R = 0;

        while (read_ptr_R - read_ptr_L >= 4) {
            if (count_L > count_R) {
                __m256i v = _mm256_loadu_si256((__m256i*)read_ptr_L);
                read_ptr_L += 4;
                
                __m256i m_lt = Charlatana_cmplt_epu64(v, v_pivot);
                int mask_lt = _mm256_movemask_pd(_mm256_castsi256_pd(m_lt));
                int k_lt = __builtin_popcount(mask_lt);
                __m256i perm_lt = _mm256_load_si256((__m256i*)QWORD_PACK_TABLE[mask_lt]);
                __m256i packed_lt = _mm256_permutevar8x32_epi32(v, perm_lt);
                __m256i store_mask_lt = _mm256_load_si256((__m256i*)MASK_STORE_TABLE[k_lt]);
                _mm256_maskstore_epi64((long long*)write_ptr_L, store_mask_lt, packed_lt);
                write_ptr_L += k_lt;
                
                __m256i m_gt = Charlatana_cmplt_epu64(v_pivot, v);
                int mask_gt = _mm256_movemask_pd(_mm256_castsi256_pd(m_gt));
                int k_gt = __builtin_popcount(mask_gt);
                __m256i perm_gt = _mm256_load_si256((__m256i*)QWORD_PACK_TABLE[mask_gt]);
                __m256i packed_gt = _mm256_permutevar8x32_epi32(v, perm_gt);
                __m256i store_mask_gt = _mm256_load_si256((__m256i*)MASK_STORE_TABLE[k_gt]);
                _mm256_maskstore_epi64((long long*)(buf_R + count_R), store_mask_gt, packed_gt);
                count_R += k_gt;
                
                // Branchless [
/*
                // --- USER OPTIMIZATION: Bitwise Branchless Flush ---
                int space_L = (int)(read_ptr_L - write_ptr_L);
                int flush_L = count_L & -(space_L >= count_L); // 0 or count_L
                
                for (int k = 0; k < flush_L; k++) write_ptr_L[k] = buf_L[k];
                write_ptr_L += flush_L;
                count_L -= flush_L; // Resets cleanly without a branch
*/
                // Branchless ]
                // Branchful [
                int space_L = read_ptr_L - write_ptr_L;
                if (count_L > 0 && space_L >= count_L) {
                    for (int k = 0; k < count_L; k++) write_ptr_L[k] = buf_L[k];
                    write_ptr_L += count_L;
                    count_L = 0;
                }
                // Branchful ]                
                // Branchless and for-less [
/*
 ptrdiff_t space_L = read_ptr_L - write_ptr_L;
 int flush_L = count_L & -(int)(space_L >= count_L);

 memcpy(write_ptr_L, buf_L, (size_t)flush_L * sizeof(uint64_t));
 write_ptr_L += flush_L;
 count_L -= flush_L;
*/
                // Branchless and for-less ]
            } else {
                read_ptr_R -= 4;
                __m256i v = _mm256_loadu_si256((__m256i*)read_ptr_R);
                
                __m256i m_gt = Charlatana_cmplt_epu64(v_pivot, v);
                int mask_gt = _mm256_movemask_pd(_mm256_castsi256_pd(m_gt));
                int k_gt = __builtin_popcount(mask_gt);
                __m256i perm_gt = _mm256_load_si256((__m256i*)QWORD_PACK_TABLE[mask_gt]);
                __m256i packed_gt = _mm256_permutevar8x32_epi32(v, perm_gt);
                __m256i store_mask_gt = _mm256_load_si256((__m256i*)MASK_STORE_TABLE[k_gt]);
                write_ptr_R -= k_gt;
                _mm256_maskstore_epi64((long long*)write_ptr_R, store_mask_gt, packed_gt);
                
                __m256i m_lt = Charlatana_cmplt_epu64(v, v_pivot);
                int mask_lt = _mm256_movemask_pd(_mm256_castsi256_pd(m_lt));
                int k_lt = __builtin_popcount(mask_lt);
                __m256i perm_lt = _mm256_load_si256((__m256i*)QWORD_PACK_TABLE[mask_lt]);
                __m256i packed_lt = _mm256_permutevar8x32_epi32(v, perm_lt);
                __m256i store_mask_lt = _mm256_load_si256((__m256i*)MASK_STORE_TABLE[k_lt]);
                _mm256_maskstore_epi64((long long*)(buf_L + count_L), store_mask_lt, packed_lt);
                count_L += k_lt;
                
                // Branchless [
/*
                // --- USER OPTIMIZATION: Bitwise Branchless Flush ---
                int space_R = (int)(write_ptr_R - read_ptr_R);
                int flush_R = count_R & -(space_R >= count_R); // 0 or count_R
                
                write_ptr_R -= flush_R; // Shift pointer down before loop
                for (int k = 0; k < flush_R; k++) write_ptr_R[k] = buf_R[k];
                count_R -= flush_R;     // Resets cleanly without a branch
*/
                // Branchless ]
                // Branchful [
                int space_R = write_ptr_R - read_ptr_R;
                if (count_R > 0 && space_R >= count_R) {
                    write_ptr_R -= count_R;
                    for (int k = 0; k < count_R; k++) write_ptr_R[k] = buf_R[k];
                    count_R = 0;
                }
                // Branchful ]
                // Branchless and for-less [
/*
 ptrdiff_t space_R = write_ptr_R - read_ptr_R;
 int flush_R = count_R & -(int)(space_R >= count_R);

 write_ptr_R -= flush_R;
 memcpy(write_ptr_R, buf_R, (size_t)flush_R * sizeof(uint64_t));
 count_R -= flush_R;
*/
                // Branchless and for-less ]
            }
        }

        while (read_ptr_L < read_ptr_R) {
            uint64_t val = *read_ptr_L;
            int is_lt = (val < pivot);
            int is_gt = (val > pivot);
            
            *write_ptr_L = val;
            write_ptr_L += is_lt;
            
            buf_R[count_R] = val;
            count_R += is_gt;
            
            read_ptr_L++;
        }

        for (int k = 0; k < count_L; k++) *write_ptr_L++ = buf_L[k];
        write_ptr_R -= count_R;
        for (int k = 0; k < count_R; k++) write_ptr_R[k] = buf_R[k];

        uint64_t* end_lt = write_ptr_L; 
        uint64_t* start_gt = write_ptr_R;

        while (write_ptr_L < write_ptr_R) {
            *write_ptr_L++ = pivot;
        }

        int64_t p_left = (end_lt - arr) - 1;
        int64_t p_right = (start_gt - arr);

        int64_t len_L = p_left - low + 1;
        int64_t len_R = high - p_right + 1;

        if (len_L < len_R) {
            // Right is larger: Task, Recurse, or Sort
            if (len_R > INSERTION_THRESHOLD) {
                //if (len_R > OMP_TASK_THRESHOLD) {
                //    #pragma omp task default(none) firstprivate(arr, p_right, high)
                //    charlatana_v28_recursive(arr, p_right, high);
                //} else {
                    charlatana_v28_recursive(arr, p_right, high);
                //}
            } else {
                charlatana_insertion_sort(arr, p_right, high);
            }

            // Left is smaller: Loop back OR Sort and break
            if (len_L > INSERTION_THRESHOLD) {
                high = p_left; // Only loop back if it's large enough!
            } else {
                charlatana_insertion_sort(arr, low, p_left);
                break; // Left is sorted, right is handled. We are DONE.
            }
        } else {
            // Left is larger: Task, Recurse, or Sort
            if (len_L > INSERTION_THRESHOLD) {
                //if (len_L > OMP_TASK_THRESHOLD) {
                //    #pragma omp task default(none) firstprivate(arr, low, p_left)
                //    charlatana_v28_recursive(arr, low, p_left);
                //} else {
                    charlatana_v28_recursive(arr, low, p_left);
                //}
            } else {
                charlatana_insertion_sort(arr, low, p_left);
            }

            // Right is smaller: Loop back OR Sort and break
            if (len_R > INSERTION_THRESHOLD) {
                low = p_right; // Only loop back if it's large enough!
            } else {
                charlatana_insertion_sort(arr, p_right, high);
                break; // Right is sorted, left is handled. We are DONE.
            }
        }
    }
}

/*
static inline void Charlatana_Sort(uint64_t* arr, size_t n) {
    if (n < 2) return;
    #pragma omp parallel
    {
        #pragma omp single
        {
            charlatana_V28_recursive(arr, 0, (int64_t)(n - 1));
        }
    }
}
*/

static inline void Charlatana_Sort(uint64_t* arr, size_t n) {
    //if (n < 2) return;
    
    if (n <= INSERTION_THRESHOLD) {
        charlatana_insertion_sort(arr, 0, (int64_t)(n - 1));
        return;
    }
    
    #pragma omp parallel
    {
        #pragma omp single
        {
            charlatana_v28_recursive(arr, 0, (int64_t)(n - 1));
        }
    }
}

#endif // CHARLATANA_V28_H

/*
Here is the visual breakdown of the branchless AVX2 partitioning pipeline. 

Let's walk through an example where we load 4 elements, but only **Element A** and **Element C** are valid (e.g., they are smaller than the pivot), giving us a 4-bit mask of `0101` (decimal 5).

### Step 1: The Input & Comparison
We start with four 64-bit integers loaded into a single 256-bit AVX2 register. The CPU compares them against the pivot simultaneously.

```text
               256-bit AVX2 Register (Four 64-bit QWORDs)
+---------------+---------------+---------------+---------------+
|  QWORD 3 (D)  |  QWORD 2 (C)  |  QWORD 1 (B)  |  QWORD 0 (A)  |
+---------------+---------------+---------------+---------------+
        |               |               |               |
        v               v               v               v
     [ > Pivot ]     [ < Pivot ]     [ > Pivot ]     [ < Pivot ]
        |               |               |               |
        v               v               v               v
Mask:   0               1               0               1      --> Binary: 0101 (Dec: 5)
     (Discard)       (Keep)          (Discard)       (Keep)
```

### Step 2: The "Squasher" (Permutation)
We use the mask `5` to look up Row 5 in the `QWORD_PACK_TABLE`. 
This table feeds a permutation instruction that shuffles the 32-bit chunks. It grabs the valid 64-bit QWORDs (A and C) and packs them tightly to the right (the "left" side of the array logically, but right-side in little-endian register views).

```text
 QWORD_PACK_TABLE[5] = {0,1,  4,5,  2,3,  6,7}  <-- 32-bit chunk indices
                          |     |     |     |
      +-------------------+     |     |     +-------------------+
      |                         |     +---------+               |
      |       +-----------------+               |               |
      |       |                                 |               |
      v       v                                 v               v
+---------------+---------------+---------------+---------------+
|  QWORD 3 (D)  |  QWORD 1 (B)  |  QWORD 2 (C)  |  QWORD 0 (A)  |
+---------------+---------------+---------------+---------------+
|====== GARBAGE (Ignored) ======|====== VALID (Squashed) =======|
```
*Notice how Element C jumped over Element B so that A and C are now contiguous.*

### Step 3: The "Filter" (Masked Store)
Now we need to write the squashed register to main memory. We do a popcount on our `0101` mask, which equals **2** (two valid elements). 

We look up Row 2 in the `MASK_STORE_TABLE`, which gives us `{-1LL, -1LL, 0, 0}`. The `maskstore` instruction uses this to act as a physical stencil over the register.

```text
               Squashed AVX2 Register
+---------------+---------------+---------------+---------------+
|    Garbage    |    Garbage    |  QWORD 2 (C)  |  QWORD 0 (A)  |
+---------------+---------------+---------------+---------------+
        |               |               |               |
        v               v               v               v
 MASK_STORE_TABLE[2] (The Stencil)
+---------------+---------------+---------------+---------------+
|       0       |       0       |     -1LL      |     -1LL      |
+---------------+---------------+---------------+---------------+
        |               |               |               |
   [ BLOCKED ]     [ BLOCKED ]   [ PASS THRU ]   [ PASS THRU ]
        |               |               |               |
        v               v               v               v
                 Main Memory (Destination Array)
=================================================================
... | Unchanged |   Unchanged   |  Wrote C here |  Wrote A here | ...
=================================================================
                                                ^
                                                |
                                          Array Pointer
```

### The Result
In just a few clock cycles, with **zero branch instructions** (no `if/else`), the CPU successfully identified the valid elements, compacted them, and cleanly wrote exactly two 64-bit chunks to memory. The array pointer is then advanced by 2, and the pipeline immediately processes the next 256 bits of data.
*/

/*
This is one of the most beautiful and brutal hacks in AVX2 programming. 

What you are looking at is the manual, software-emulated version of AVX-512's `compressstore` instruction. Because AVX2 does ~~not~~ have a native way to take a sparse vector (where only some elements match your condition) and pack them tightly to the left side of the register before writing them to memory, we have to force the CPU to do it using these two lookup tables.

Here is exactly how this branchless pipeline works.

### 1. `QWORD_PACK_TABLE` (The "Squasher")
In the AVX2 version of Charlatana, we load ~~four 64-bit integers (QWORDs)~~ into a single 256-bit register. When we compare them to the pivot, we get a 4-bit mask (values from `0000` to `1111` in binary, or `0` to `15` in decimal). 

This 4-bit mask tells us exactly which elements matched. For example, if the mask is `0101` (decimal 5), it means the 0th and 2nd elements matched, but the 1st and 3rd did not. We need to squash the 0th and 2nd elements to the front of the register.

To move data around in AVX2, we use `_mm256_permutevar8x32_epi32`. Notice the `32`? This instruction shuffles ~~32-bit chunks~~, not 64-bit chunks! A 256-bit register has eight 32-bit chunks. Since our 64-bit QWORDs are made of two 32-bit DWORDs each, we must move them in pairs:
~ ~~QWORD 0~~ is DWORDs `{0, 1}`
~ ~~QWORD 1~~ is DWORDs `{2, 3}`
~ ~~QWORD 2~~ is DWORDs `{4, 5}`
~ ~~QWORD 3~~ is DWORDs `{6, 7}`

The table has 16 rows (one for every possible 4-bit mask) and 8 columns (the instructions on where to put each 32-bit chunk).

~~Let's look at Row 5 (Mask `0101`):~~
```c
{0,1, 4,5, 2,3, 6,7}
```
~ The first two slots are `0,1`. This takes QWORD 0 and puts it in the 1st position.
~ The next two slots are `4,5`. This takes QWORD 2 and squashes it directly behind QWORD 0 into the 2nd position!
~ The rest (`2,3, 6,7`) is just garbage data pushed to the back. We don't care about it because it won't be written to memory anyway.

By looking up the row matching our 4-bit mask, we execute a single hardware shuffle that perfectly squashes all the valid data to the left side of the register in 1 clock cycle.

### 2. `MASK_STORE_TABLE` (The "Filter")
Now that all the valid data is packed cleanly to the left side of the 256-bit register, we need to write it to memory. But we ~only~ want to write the valid elements, not the garbage we pushed to the right. 

To do this, we use `_mm256_maskstore_epi64`. This instruction looks at a control vector. If the most significant bit of a 64-bit lane in the control vector is `1` (which is represented in two's complement as `-1LL`, or `0xFFFFFFFFFFFFFFFF`), it writes that lane to RAM. If it's `0`, it safely ignores it.

The table has 5 rows because if you compare 4 elements, there are exactly 5 possible outcomes for the total number of matches (0, 1, 2, 3, or 4 matches). We find the row by doing a `__builtin_popcount(mask)` which simply counts how many `1`s are in our 4-bit mask.

~ ~~Row 0 (0 matches):~~ `{0, 0, 0, 0}` -> Writes nothing to memory.
~ ~~Row 1 (1 match):~~ `{-1LL, 0, 0, 0}` -> Writes exactly 1 QWORD to memory.
~ ~~Row 2 (2 matches):~~ `{-1LL, -1LL, 0, 0}` -> Writes exactly 2 QWORDs to memory.
~ ~~Row 3 (3 matches):~~ `{-1LL, -1LL, -1LL, 0}` -> Writes exactly 3 QWORDs to memory.
~ ~~Row 4 (4 matches):~~ `{-1LL, -1LL, -1LL, -1LL}` -> Writes all 4 QWORDs to memory.

### The Summary of the Pipeline
When the CPU executes this code, the sequence is:
1.  ~~Compare:~~ Yields a mask like `0101` (5).
2.  ~~Popcount:~~ Counts two `1`s in the mask, so $k = 2$.
3.  ~~Shuffle:~~ Loads Row 5 of `QWORD_PACK_TABLE`. Squashes the valid elements to the left.
4.  ~~Mask Load:~~ Loads Row 2 of `MASK_STORE_TABLE` (because $k = 2$).
5.  ~~Store:~~ Safely writes exactly the two valid 64-bit integers into the array.

This elegant combination of tables turns a branching, unpredictable `if-else` nightmare into a perfectly flat, uninterrupted SIMD mathematics pipeline. It is the secret to AVX2 sorting speeds!
*/

// ]$ gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28.asm benchmark28.c -S
// gcc version 15.2.1 20250808 (Red Hat 15.2.1-1) (GCC) 
/*

*/

