clang -v 2>clangvq
write_speed=$(cat clangvq | grep "clang version" | awk '{print $(NF-2)}')
echo $write_speed
rm clangvq

clang -o Quicksort_UQWORDS_clang_"$write_speed".elf -O3 -mavx2 -fopenmp -std=gnu11 benchmark28.c
clang -o Quicksort_UQWORDS_clang_"$write_speed".elf.asm -O3 -mavx2 -fopenmp -std=gnu11 benchmark28.c -S

gcc -v 2>gccvq
write_speed=$(cat gccvq | grep "gcc version" | awk '{print $(NF-5)}')
echo $write_speed
rm gccvq

gcc -o Quicksort_UQWORDS_gcc_"$write_speed".elf -O3 -mavx2 -fopenmp -std=gnu11 benchmark28.c
gcc -o Quicksort_UQWORDS_gcc_"$write_speed".elf.asm -O3 -mavx2 -fopenmp -std=gnu11 benchmark28.c -S

echo Charlatana_v28:
gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_\(FB2-1012\).tar 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_\(FB2-1012\).tar 1

/bin/time -v ./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_\(FB2-1012\).tar 1

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 1

/bin/time -v ./benchmark28 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 1

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1

/bin/time -v ./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Nobara-43-GNOME-2026-01-26.iso 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Nobara-43-GNOME-2026-01-26.iso 1

/bin/time -v ./benchmark28 Nobara-43-GNOME-2026-01-26.iso 1

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1

/bin/time -v ./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Brawl_in_cell_block_99_\(2017\)_UHD_BDRip_720p.mkv 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Brawl_in_cell_block_99_\(2017\)_UHD_BDRip_720p.mkv 1

/bin/time -v ./benchmark28 Brawl_in_cell_block_99_\(2017\)_UHD_BDRip_720p.mkv 1

echo
echo qsort:
gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_\(FB2-1012\).tar 2
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_\(FB2-1012\).tar 2

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 2
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 2

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 2
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 2

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Nobara-43-GNOME-2026-01-26.iso 2
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Nobara-43-GNOME-2026-01-26.iso 2

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 2
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 2

