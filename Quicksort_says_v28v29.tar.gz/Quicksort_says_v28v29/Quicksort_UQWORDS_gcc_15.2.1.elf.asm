	.file	"benchmark28.c"
	.text
	.p2align 4
	.globl	compare_uint64
	.type	compare_uint64, @function
compare_uint64:
.LFB7299:
	.cfi_startproc
	movq	(%rdi), %rdx
	movq	(%rsi), %rcx
	movl	$-1, %eax
	cmpq	%rcx, %rdx
	jb	.L1
	xorl	%eax, %eax
	cmpq	%rdx, %rcx
	setb	%al
.L1:
	ret
	.cfi_endproc
.LFE7299:
	.size	compare_uint64, .-compare_uint64
	.p2align 4
	.type	charlatana_v28_recursive, @function
charlatana_v28_recursive:
.LFB7297:
	.cfi_startproc
	leaq	8(%rsp), %r10
	.cfi_def_cfa 10, 0
	andq	$-32, %rsp
	pushq	-8(%r10)
	pushq	%rbp
	movq	%rsp, %rbp
	.cfi_escape 0x10,0x6,0x2,0x76,0
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%r10
	.cfi_escape 0xf,0x3,0x76,0x58,0x6
	.cfi_escape 0x10,0xf,0x2,0x76,0x78
	.cfi_escape 0x10,0xe,0x2,0x76,0x70
	.cfi_escape 0x10,0xd,0x2,0x76,0x68
	.cfi_escape 0x10,0xc,0x2,0x76,0x60
	pushq	%rbx
	subq	$4256, %rsp
	.cfi_escape 0x10,0x3,0x2,0x76,0x50
	movq	%rdx, -4184(%rbp)
	cmpq	%rdx, %rsi
	jge	.L114
	movabsq	$-9223372036854775808, %rax
	movq	%rdi, %r14
	movq	%rsi, %r13
	vmovq	%rax, %xmm4
	.p2align 4
	.p2align 3
.L6:
	movq	-4184(%rbp), %rdi
	leaq	(%r14,%r13,8), %rbx
	movq	%rbx, -4288(%rbp)
	movq	%rdi, %rdx
	subq	%r13, %rdx
	movq	%rdx, %rsi
	sarq	%rdx
	sarq	$2, %rsi
	addq	%r13, %rdx
	leaq	(%rsi,%r13), %rax
	movq	(%r14,%rdx,8), %rcx
	movq	%rdi, %rdx
	movq	(%r14,%rax,8), %rax
	subq	%rsi, %rdx
	movq	(%r14,%rdx,8), %rdx
	movq	%rcx, %rsi
	movq	%rax, %r9
	xorq	%rcx, %r9
	xorq	%rdx, %r9
	cmpq	%rcx, %rax
	cmovbe	%rax, %rsi
	cmpq	%rdx, %rsi
	cmova	%rdx, %rsi
	xorq	%rsi, %r9
	cmpq	%rcx, %rax
	cmovb	%rcx, %rax
	cmpq	%rdx, %rax
	cmovb	%rdx, %rax
	xorq	%rax, %r9
	leaq	1(%rdi), %rax
	leaq	(%r14,%rax,8), %r12
	subq	%r13, %rax
	salq	$3, %rax
	cmpq	$24, %rax
	jle	.L8
	vmovq	%r9, %xmm6
	movq	%rbx, %r15
	vpbroadcastq	%xmm4, %ymm0
	movq	%rbx, %r11
	vpbroadcastq	%xmm6, %ymm2
	movq	%r13, -4208(%rbp)
	xorl	%ebx, %ebx
	movq	%r12, %r13
	movq	%r14, -4280(%rbp)
	vpxor	%ymm0, %ymm2, %ymm2
	movq	%r12, %r14
	movq	%r15, %r12
	movq	%r9, -4200(%rbp)
	xorl	%r15d, %r15d
	jmp	.L11
	.p2align 4,,10
	.p2align 3
.L117:
	vmovdqu	(%r11), %ymm1
	vpbroadcastq	%xmm4, %ymm0
	addq	$32, %r11
	movslq	%ebx, %rsi
	vpxor	%ymm0, %ymm1, %ymm0
	vpcmpgtq	%ymm0, %ymm2, %ymm3
	vpcmpgtq	%ymm2, %ymm0, %ymm0
	vmovmskpd	%ymm3, %rdx
	movq	%rdx, %rax
	salq	$5, %rdx
	vmovdqa	QWORD_PACK_TABLE(%rdx), %ymm3
	popcntl	%eax, %eax
	movq	%rax, %rdx
	salq	$5, %rdx
	vmovdqa	MASK_STORE_TABLE(%rdx), %ymm5
	vpermd	%ymm1, %ymm3, %ymm3
	xorl	%edx, %edx
	vpmaskmovq	%ymm3, %ymm5, (%r12)
	leaq	(%r12,%rax,8), %r12
	vmovmskpd	%ymm0, %rax
	popcntl	%eax, %edx
	salq	$5, %rax
	addl	%edx, %ebx
	vmovdqa	QWORD_PACK_TABLE(%rax), %ymm0
	movslq	%edx, %rax
	salq	$5, %rax
	vpermd	%ymm1, %ymm0, %ymm1
	vmovdqa	MASK_STORE_TABLE(%rax), %ymm0
	movq	%r11, %rax
	subq	%r12, %rax
	vpmaskmovq	%ymm1, %ymm0, -2096(%rbp,%rsi,8)
	sarq	$3, %rax
	cmpl	%eax, %r15d
	jg	.L10
	testl	%r15d, %r15d
	jle	.L10
	movq	%r11, -4272(%rbp)
	movl	%r15d, %edx
	movq	%r12, %rdi
	leaq	-4144(%rbp), %rsi
	vmovdqa	%ymm2, -4240(%rbp)
	salq	$3, %rdx
	movslq	%r15d, %r15
	leaq	(%r12,%r15,8), %r12
	vzeroupper
	call	memcpy
	vmovdqa	-4240(%rbp), %ymm2
	xorl	%r15d, %r15d
	movabsq	$-9223372036854775808, %rax
	movq	-4272(%rbp), %r11
	vmovq	%rax, %xmm4
.L10:
	movq	%r14, %rax
	subq	%r11, %rax
	cmpq	$24, %rax
	jle	.L116
.L11:
	cmpl	%ebx, %r15d
	jg	.L117
	vmovdqu	-32(%r14), %ymm1
	vpbroadcastq	%xmm4, %ymm0
	leaq	-32(%r14), %r8
	movslq	%r15d, %rsi
	vpxor	%ymm0, %ymm1, %ymm0
	vpcmpgtq	%ymm2, %ymm0, %ymm3
	vpcmpgtq	%ymm0, %ymm2, %ymm0
	vmovmskpd	%ymm3, %rdx
	movq	%rdx, %rax
	salq	$5, %rdx
	vmovdqa	QWORD_PACK_TABLE(%rdx), %ymm3
	popcntl	%eax, %eax
	leaq	0(,%rax,8), %rdx
	salq	$5, %rax
	vmovdqa	MASK_STORE_TABLE(%rax), %ymm5
	subq	%rdx, %r13
	vmovmskpd	%ymm0, %rax
	xorl	%edx, %edx
	popcntl	%eax, %edx
	vpermd	%ymm1, %ymm3, %ymm3
	salq	$5, %rax
	addl	%edx, %r15d
	vpmaskmovq	%ymm3, %ymm5, 0(%r13)
	vmovdqa	QWORD_PACK_TABLE(%rax), %ymm0
	movslq	%edx, %rax
	salq	$5, %rax
	vpermd	%ymm1, %ymm0, %ymm1
	vmovdqa	MASK_STORE_TABLE(%rax), %ymm0
	movq	%r13, %rax
	subq	%r8, %rax
	vpmaskmovq	%ymm1, %ymm0, -4144(%rbp,%rsi,8)
	sarq	$3, %rax
	cmpl	%eax, %ebx
	jg	.L60
	testl	%ebx, %ebx
	jg	.L118
.L60:
	movq	%r8, %r14
	movq	%r14, %rax
	subq	%r11, %rax
	cmpq	$24, %rax
	jg	.L11
.L116:
	movl	%r15d, %r8d
	movq	%r12, %r15
	movq	%r14, %r12
	movq	%r13, %r10
	movq	-4200(%rbp), %r9
	movq	-4208(%rbp), %r13
	movq	-4280(%rbp), %r14
	cmpq	%r12, %r11
	jnb	.L15
	.p2align 6
	.p2align 4
	.p2align 3
.L16:
	movq	(%r11), %rax
	xorl	%edx, %edx
	cmpq	%r9, %rax
	movq	%rax, (%r15)
	setb	%dl
	cmpq	%rax, %r9
	leaq	(%r15,%rdx,8), %r15
	movslq	%ebx, %rdx
	adcl	$0, %ebx
	addq	$8, %r11
	movq	%rax, -2096(%rbp,%rdx,8)
	cmpq	%r12, %r11
	jb	.L16
.L15:
	testl	%r8d, %r8d
	jle	.L17
	movq	%r9, -4272(%rbp)
	movq	%r15, %rdi
	leaq	-4144(%rbp), %rsi
	leaq	0(,%r8,8), %rdx
	movq	%r10, -4240(%rbp)
	leaq	(%r15,%r8,8), %r15
	vzeroupper
	call	memcpy
	movq	-4272(%rbp), %r9
	movabsq	$-9223372036854775808, %rax
	movq	-4240(%rbp), %r10
	vmovq	%rax, %xmm4
.L17:
	movslq	%ebx, %rax
	salq	$3, %rax
	subq	%rax, %r10
	movq	%r10, %r12
	testl	%ebx, %ebx
	jle	.L18
	movq	%r9, -4240(%rbp)
	movl	%ebx, %edx
	leaq	-2096(%rbp), %rsi
	movq	%r10, %rdi
	salq	$3, %rdx
	vzeroupper
	call	memcpy
	movq	-4240(%rbp), %r9
	movabsq	$-9223372036854775808, %rax
	vmovq	%rax, %xmm4
.L18:
	cmpq	%r12, %r15
	jnb	.L14
	leaq	-1(%r12), %rdx
	movq	%r15, %rax
	subq	%r15, %rdx
	cmpq	$23, %rdx
	jbe	.L22
	shrq	$3, %rdx
	vmovq	%r9, %xmm7
	addq	$1, %rdx
	vpbroadcastq	%xmm7, %ymm0
	movq	%rdx, %rdi
	shrq	$2, %rdi
	salq	$5, %rdi
	leaq	(%rdi,%r15), %rsi
	andl	$32, %edi
	je	.L23
	leaq	32(%r15), %rax
	vmovdqu	%ymm0, (%r15)
	cmpq	%rax, %rsi
	je	.L108
	.p2align 5
	.p2align 4
	.p2align 3
.L23:
	vmovdqu	%ymm0, (%rax)
	addq	$64, %rax
	vmovdqu	%ymm0, -32(%rax)
	cmpq	%rax, %rsi
	jne	.L23
.L108:
	testb	$3, %dl
	je	.L14
	andq	$-4, %rdx
	leaq	(%r15,%rdx,8), %rax
.L22:
	leaq	8(%rax), %rdx
	movq	%r9, (%rax)
	cmpq	%r12, %rdx
	jnb	.L14
	leaq	16(%rax), %rdx
	movq	%r9, 8(%rax)
	cmpq	%r12, %rdx
	jnb	.L14
	movq	%r9, 16(%rax)
.L14:
	movq	%r15, %rcx
	movq	%r12, %rax
	movq	-4184(%rbp), %r10
	subq	%r14, %rcx
	subq	%r14, %rax
	sarq	$3, %rcx
	sarq	$3, %rax
	leaq	-1(%rcx), %r11
	movq	%rax, %r15
	movq	%r11, %rbx
	subq	%r15, %r10
	subq	%r13, %rbx
	leaq	1(%rbx), %rax
	movq	%rax, -4240(%rbp)
	leaq	1(%r10), %rax
	movq	%rax, -4272(%rbp)
	cmpq	%r10, %rbx
	jge	.L119
	cmpq	$64, -4272(%rbp)
	jle	.L120
	cmpq	$100000, -4272(%rbp)
	movq	%r11, -4272(%rbp)
	jg	.L121
	movq	-4184(%rbp), %rdx
	movq	%r15, %rsi
	movq	%r14, %rdi
	vzeroupper
	call	charlatana_v28_recursive
	movq	-4272(%rbp), %r11
	movabsq	$-9223372036854775808, %rax
	vmovq	%rax, %xmm4
.L29:
	cmpq	$64, -4240(%rbp)
	jle	.L122
.L65:
	movq	%r11, -4184(%rbp)
.L37:
	cmpq	-4184(%rbp), %r13
	jl	.L6
.L113:
	vzeroupper
.L114:
	leaq	-48(%rbp), %rsp
	popq	%rbx
	popq	%r10
	.cfi_remember_state
	.cfi_def_cfa 10, 0
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	leaq	-8(%r10), %rsp
	.cfi_def_cfa 7, 8
	ret
	.p2align 4,,10
	.p2align 3
.L118:
	.cfi_restore_state
	movslq	%ebx, %rax
	movq	%r11, -4192(%rbp)
	movl	%ebx, %edx
	leaq	-2096(%rbp), %rsi
	salq	$3, %rax
	movq	%r8, -4240(%rbp)
	salq	$3, %rdx
	subq	%rax, %r13
	vmovdqa	%ymm2, -4272(%rbp)
	movq	%r13, %rdi
	vzeroupper
	call	memcpy
	xorl	%ebx, %ebx
	movabsq	$-9223372036854775808, %rax
	movq	-4240(%rbp), %r14
	vmovdqa	-4272(%rbp), %ymm2
	vmovq	%rax, %xmm4
	movq	-4192(%rbp), %r11
	jmp	.L10
	.p2align 4,,10
	.p2align 3
.L119:
	cmpq	$64, -4240(%rbp)
	jle	.L123
	cmpq	$100000, -4240(%rbp)
	movq	%r10, -4240(%rbp)
	jg	.L124
	movq	%r11, %rdx
	movq	%r13, %rsi
	movq	%r14, %rdi
	vzeroupper
	call	charlatana_v28_recursive
	movq	-4240(%rbp), %r10
	movabsq	$-9223372036854775808, %rax
	vmovq	%rax, %xmm4
.L46:
	cmpq	$64, -4272(%rbp)
	jle	.L125
.L70:
	movq	%r15, %r13
	jmp	.L37
	.p2align 4,,10
	.p2align 3
.L121:
	movq	-4184(%rbp), %rax
	movq	%r15, -4168(%rbp)
	xorl	%edx, %edx
	movl	$24, %ecx
	movq	%r14, -4176(%rbp)
	leaq	-4176(%rbp), %rsi
	movl	$charlatana_v28_recursive._omp_fn.0, %edi
	movl	$1, %r9d
	movq	%rax, -4160(%rbp)
	movl	$8, %r8d
	pushq	$0
	pushq	$0
	pushq	$0
	pushq	$0
	vzeroupper
	call	GOMP_task
	movq	-4272(%rbp), %r11
	addq	$32, %rsp
	movabsq	$-9223372036854775808, %rax
	vmovq	%rax, %xmm4
	cmpq	$64, -4240(%rbp)
	jg	.L65
.L122:
	movq	%rbx, %r11
	cmpq	$1, -4240(%rbp)
	jle	.L113
	movq	-4288(%rbp), %rbx
	xorl	%r9d, %r9d
	movl	$1, %edx
	movq	(%rbx), %r10
	movq	%rbx, %rsi
	leaq	8(%rbx), %rax
	movq	%r10, %rdi
	jmp	.L40
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L127:
	leaq	(%rbx,%r9,8), %r8
	addq	$8, %rax
	cmpq	%rdx, %r11
	jle	.L126
.L67:
	addq	$1, %rdx
.L40:
	movq	(%rax), %rcx
	movq	%rax, %r8
	cmpq	%rdi, %rcx
	jnb	.L127
	movq	%rcx, %rdi
	movq	%rdx, %r9
	addq	$8, %rax
	cmpq	%rdx, %r11
	jg	.L67
.L126:
	movq	-4288(%rbp), %rax
	movq	%rdi, (%rax)
	xorl	%edi, %edi
	movq	%r10, (%r8)
	.p2align 4
	.p2align 3
.L43:
	movq	8(%rsi), %rcx
	movq	(%rsi), %rdx
	movq	%rsi, %rax
	cmpq	%rdx, %rcx
	jnb	.L41
	.p2align 5
	.p2align 4
	.p2align 3
.L42:
	movq	%rdx, 8(%rax)
	movq	-8(%rax), %rdx
	subq	$8, %rax
	cmpq	%rdx, %rcx
	jb	.L42
.L41:
	addq	$1, %rdi
	movq	%rcx, 8(%rax)
	addq	$8, %rsi
	cmpq	%rdi, %r11
	jg	.L43
	jmp	.L113
	.p2align 4,,10
	.p2align 3
.L124:
	movq	%r11, -4160(%rbp)
	xorl	%edx, %edx
	leaq	-4176(%rbp), %rsi
	movl	$24, %ecx
	movq	%r13, -4168(%rbp)
	movl	$1, %r9d
	movl	$charlatana_v28_recursive._omp_fn.1, %edi
	movl	$8, %r8d
	movq	%r14, -4176(%rbp)
	pushq	$0
	pushq	$0
	pushq	$0
	pushq	$0
	vzeroupper
	call	GOMP_task
	movq	-4240(%rbp), %r10
	addq	$32, %rsp
	movabsq	$-9223372036854775808, %rax
	vmovq	%rax, %xmm4
	cmpq	$64, -4272(%rbp)
	jg	.L70
.L125:
	cmpq	$1, -4272(%rbp)
	jle	.L113
	movq	(%r12), %r11
	movq	%r12, %rsi
	leaq	8(%r12), %rax
	xorl	%r9d, %r9d
	movl	$1, %edx
	movq	%r11, %rdi
	jmp	.L55
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L129:
	leaq	(%r12,%r9,8), %r8
	addq	$8, %rax
	cmpq	%rdx, %r10
	jle	.L128
.L72:
	addq	$1, %rdx
.L55:
	movq	(%rax), %rcx
	movq	%rax, %r8
	cmpq	%rdi, %rcx
	jnb	.L129
	movq	%rcx, %rdi
	movq	%rdx, %r9
	addq	$8, %rax
	cmpq	%rdx, %r10
	jg	.L72
.L128:
	movq	%rdi, (%r12)
	xorl	%edi, %edi
	movq	%r11, (%r8)
	.p2align 4
	.p2align 3
.L58:
	movq	8(%rsi), %rcx
	movq	(%rsi), %rdx
	movq	%rsi, %rax
	cmpq	%rdx, %rcx
	jnb	.L56
	.p2align 5
	.p2align 4
	.p2align 3
.L57:
	movq	%rdx, 8(%rax)
	movq	-8(%rax), %rdx
	subq	$8, %rax
	cmpq	%rdx, %rcx
	jb	.L57
.L56:
	addq	$1, %rdi
	movq	%rcx, 8(%rax)
	addq	$8, %rsi
	cmpq	%rdi, %r10
	jg	.L58
	jmp	.L113
	.p2align 4,,10
	.p2align 3
.L123:
	cmpq	$1, -4240(%rbp)
	jle	.L46
	movq	-4288(%rbp), %r13
	xorl	%r11d, %r11d
	movl	$1, %esi
	movq	0(%r13), %rax
	movq	%r13, %rdx
	leaq	8(%r13), %rcx
	movq	%rax, %r8
	jmp	.L49
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L131:
	leaq	0(%r13,%r11,8), %r9
	addq	$8, %rcx
	cmpq	%rsi, %rbx
	je	.L130
.L69:
	addq	$1, %rsi
.L49:
	movq	(%rcx), %rdi
	movq	%rcx, %r9
	cmpq	%r8, %rdi
	jnb	.L131
	movq	%rdi, %r8
	movq	%rsi, %r11
	addq	$8, %rcx
	cmpq	%rsi, %rbx
	jne	.L69
.L130:
	movq	-4288(%rbp), %rdi
	movq	%r8, (%rdi)
	leaq	(%rdi,%rbx,8), %r8
	movq	%rax, (%r9)
	.p2align 4
	.p2align 3
.L52:
	movq	8(%rdx), %rsi
	movq	(%rdx), %rcx
	movq	%rdx, %rax
	cmpq	%rcx, %rsi
	jnb	.L50
	.p2align 5
	.p2align 4
	.p2align 3
.L51:
	movq	%rcx, 8(%rax)
	movq	-8(%rax), %rcx
	subq	$8, %rax
	cmpq	%rcx, %rsi
	jb	.L51
.L50:
	addq	$8, %rdx
	movq	%rsi, 8(%rax)
	cmpq	%r8, %rdx
	jne	.L52
	jmp	.L46
	.p2align 4,,10
	.p2align 3
.L120:
	cmpq	$1, -4272(%rbp)
	jle	.L29
	movq	(%r12), %r15
	movq	%r12, %rax
	leaq	8(%r12), %rdx
	xorl	%r9d, %r9d
	movl	$1, %ecx
	movq	%r15, %rdi
	jmp	.L32
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L133:
	leaq	(%r12,%r9,8), %r8
	addq	$8, %rdx
	cmpq	%rcx, %r10
	je	.L132
.L64:
	addq	$1, %rcx
.L32:
	movq	(%rdx), %rsi
	movq	%rdx, %r8
	cmpq	%rdi, %rsi
	jnb	.L133
	movq	%rsi, %rdi
	movq	%rcx, %r9
	addq	$8, %rdx
	cmpq	%rcx, %r10
	jne	.L64
.L132:
	movq	%rdi, (%r12)
	leaq	(%r12,%r10,8), %rdi
	movq	%r15, (%r8)
	.p2align 4
	.p2align 3
.L35:
	movq	8(%rax), %rsi
	movq	(%rax), %rcx
	movq	%rax, %rdx
	cmpq	%rcx, %rsi
	jnb	.L33
	.p2align 5
	.p2align 4
	.p2align 3
.L34:
	movq	%rcx, 8(%rdx)
	movq	-8(%rdx), %rcx
	subq	$8, %rdx
	cmpq	%rcx, %rsi
	jb	.L34
.L33:
	addq	$8, %rax
	movq	%rsi, 8(%rdx)
	cmpq	%rdi, %rax
	jne	.L35
	jmp	.L29
	.p2align 4,,10
	.p2align 3
.L8:
	movq	%rbx, %r15
	cmpq	%r12, -4288(%rbp)
	jnb	.L14
	movq	%rbx, %r11
	movq	%r12, %r10
	xorl	%ebx, %ebx
	xorl	%r8d, %r8d
	jmp	.L16
	.cfi_endproc
.LFE7297:
	.size	charlatana_v28_recursive, .-charlatana_v28_recursive
	.p2align 4
	.type	Charlatana_Sort._omp_fn.0, @function
Charlatana_Sort._omp_fn.0:
.LFB7302:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	movq	8(%rdi), %rbx
	movq	(%rdi), %rbp
	call	GOMP_single_start
	testb	%al, %al
	jne	.L139
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L139:
	.cfi_restore_state
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	leaq	-1(%rbx), %rdx
	movq	%rbp, %rdi
	xorl	%esi, %esi
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	charlatana_v28_recursive
	.cfi_endproc
.LFE7302:
	.size	Charlatana_Sort._omp_fn.0, .-Charlatana_Sort._omp_fn.0
	.p2align 4
	.type	charlatana_v28_recursive._omp_fn.0, @function
charlatana_v28_recursive._omp_fn.0:
.LFB7303:
	.cfi_startproc
	movq	16(%rdi), %rdx
	movq	8(%rdi), %rsi
	movq	(%rdi), %rdi
	jmp	charlatana_v28_recursive
	.cfi_endproc
.LFE7303:
	.size	charlatana_v28_recursive._omp_fn.0, .-charlatana_v28_recursive._omp_fn.0
	.p2align 4
	.type	charlatana_v28_recursive._omp_fn.1, @function
charlatana_v28_recursive._omp_fn.1:
.LFB7304:
	.cfi_startproc
	movq	16(%rdi), %rdx
	movq	8(%rdi), %rsi
	movq	(%rdi), %rdi
	jmp	charlatana_v28_recursive
	.cfi_endproc
.LFE7304:
	.size	charlatana_v28_recursive._omp_fn.1, .-charlatana_v28_recursive._omp_fn.1
	.p2align 4
	.globl	is_sorted
	.type	is_sorted, @function
is_sorted:
.LFB7300:
	.cfi_startproc
	cmpq	$1, %rsi
	jbe	.L149
	leaq	-2(%rsi), %rax
	cmpq	$4, %rax
	jbe	.L144
	leaq	8(%rdi), %rax
	orq	%rdi, %rax
	testb	$31, %al
	jne	.L144
	leaq	-1(%rsi), %r8
	movq	%rdi, %rax
	xorl	%edx, %edx
	vmovdqa	.LC1(%rip), %ymm2
	movq	%r8, %rcx
	vmovdqa	.LC0(%rip), %ymm3
	vpbroadcastq	.LC3(%rip), %ymm4
	shrq	$2, %rcx
	jmp	.L147
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L145:
	addq	$1, %rdx
	addq	$32, %rax
	vpaddq	%ymm4, %ymm2, %ymm2
	cmpq	%rdx, %rcx
	je	.L162
.L147:
	vmovdqu	8(%rax), %ymm1
	vmovdqa	(%rax), %ymm0
	vpsubq	%ymm3, %ymm1, %ymm1
	vpsubq	%ymm3, %ymm0, %ymm0
	vpcmpgtq	%ymm1, %ymm0, %ymm0
	vptest	%ymm0, %ymm0
	je	.L145
	vmovq	%xmm2, %rax
.L146:
	movq	(%rdi,%rax,8), %rdx
	cmpq	-8(%rdi,%rax,8), %rdx
	jb	.L155
	leaq	1(%rax), %rcx
	cmpq	%rsi, %rcx
	jnb	.L156
	movq	8(%rdi,%rax,8), %rcx
	cmpq	%rdx, %rcx
	jb	.L155
	leaq	2(%rax), %rdx
	cmpq	%rsi, %rdx
	jnb	.L156
	movq	16(%rdi,%rax,8), %rdx
	cmpq	%rcx, %rdx
	jb	.L155
	leaq	3(%rax), %rcx
	cmpq	%rsi, %rcx
	jnb	.L156
	cmpq	%rdx, 24(%rdi,%rax,8)
	setnb	%al
	vzeroupper
	ret
	.p2align 4,,10
	.p2align 3
.L162:
	movl	$1, %eax
	testb	$3, %r8b
	je	.L161
	andq	$-4, %r8
	leaq	1(%r8), %rax
	jmp	.L146
	.p2align 4,,10
	.p2align 3
.L144:
	movq	(%rdi), %rdx
	movl	$1, %eax
	jmp	.L148
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L163:
	addq	$1, %rax
	cmpq	%rax, %rsi
	je	.L149
.L148:
	movq	%rdx, %rcx
	movq	(%rdi,%rax,8), %rdx
	cmpq	%rcx, %rdx
	jnb	.L163
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L149:
	movl	$1, %eax
	ret
.L161:
	vzeroupper
	ret
.L155:
	xorl	%eax, %eax
	vzeroupper
	ret
.L156:
	movl	$1, %eax
	vzeroupper
	ret
	.cfi_endproc
.LFE7300:
	.size	is_sorted, .-is_sorted
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC4:
	.string	"YES"
.LC5:
	.string	"NO"
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC6:
	.string	"Usage: %s <file_to_sort> <algorithm>\n"
	.align 8
.LC7:
	.string	"Algorithms:\n  1 = Charlatana_v28\n  2 = Standard qsort()\n"
	.section	.rodata.str1.1
.LC8:
	.string	"rb"
.LC9:
	.string	"Error opening file"
.LC10:
	.string	"Error: File is too small.\n"
.LC11:
	.string	"Extracting %zu keys...\n"
.LC12:
	.string	""
.LC13:
	.string	"\n--- Starting Benchmark ---"
	.section	.rodata.str1.8
	.align 8
.LC14:
	.string	"Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)"
	.align 8
.LC15:
	.string	"OpenMP Engine: Utilizing up to %d Hardware Threads\n"
	.align 8
.LC16:
	.string	"Algorithm: Standard C qsort() [Single Threaded]"
	.section	.rodata.str1.1
.LC17:
	.string	"Sort Time: %.4f seconds\n"
	.section	.rodata.str1.8
	.align 8
.LC20:
	.string	"Total Performance: %'llu keys-per-second\n"
	.align 8
.LC21:
	.string	"Total Performance: N/A keys-per-second"
	.section	.rodata.str1.1
.LC22:
	.string	"Unique keys: %'zu\n"
.LC23:
	.string	"\n--- Verification ---"
.LC24:
	.string	"Array properly sorted: %s\n"
	.section	.text.unlikely,"ax",@progbits
.LCOLDB25:
	.section	.text.startup,"ax",@progbits
.LHOTB25:
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB7301:
	.cfi_startproc
	leaq	8(%rsp), %r10
	.cfi_def_cfa 10, 0
	andq	$-32, %rsp
	pushq	-8(%r10)
	pushq	%rbp
	movq	%rsp, %rbp
	.cfi_escape 0x10,0x6,0x2,0x76,0
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%r10
	.cfi_escape 0xf,0x3,0x76,0x60,0x6
	.cfi_escape 0x10,0xe,0x2,0x76,0x78
	.cfi_escape 0x10,0xd,0x2,0x76,0x70
	.cfi_escape 0x10,0xc,0x2,0x76,0x68
	pushq	%rbx
	subq	$40, %rsp
	.cfi_escape 0x10,0x3,0x2,0x76,0x58
	cmpl	$3, %edi
	je	.L165
	movq	(%rsi), %rdx
	movq	stderr(%rip), %rdi
	movl	$.LC6, %esi
	xorl	%eax, %eax
	call	fprintf
	movl	$56, %edx
	movl	$1, %esi
	movq	stderr(%rip), %rcx
	movl	$.LC7, %edi
	call	fwrite
.L166:
	movl	$1, %eax
.L164:
	addq	$40, %rsp
	popq	%rbx
	popq	%r10
	.cfi_remember_state
	.cfi_def_cfa 10, 0
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	leaq	-8(%r10), %rsp
	.cfi_def_cfa 7, 8
	ret
.L165:
	.cfi_restore_state
	movq	8(%rsi), %rbx
	movq	16(%rsi), %rdi
	movl	$10, %edx
	xorl	%esi, %esi
	call	strtol
	movq	%rbx, %rdi
	movl	$.LC8, %esi
	movq	%rax, %r14
	call	fopen
	movq	%rax, %rbx
	testq	%rax, %rax
	je	.L228
	xorl	%esi, %esi
	movl	$2, %edx
	movq	%rax, %rdi
	call	fseek
	movq	%rbx, %rdi
	call	ftell
	xorl	%edx, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movq	%rax, %r12
	call	fseek
	cmpq	$7, %r12
	jle	.L238
	movq	%r12, %rdi
	leaq	-7(%r12), %r13
	call	malloc
	movq	%rbx, %rcx
	movq	%r12, %rdx
	movl	$1, %esi
	movq	%rax, %rdi
	movq	%rax, -72(%rbp)
	call	fread
	movq	%rbx, %rdi
	call	fclose
	movq	%r13, %rsi
	movl	$.LC11, %edi
	xorl	%eax, %eax
	call	printf
	leaq	0(,%r13,8), %rdi
	call	malloc
	movq	-72(%rbp), %r8
	movq	%rax, %rbx
	xorl	%eax, %eax
	.p2align 5
	.p2align 4
	.p2align 3
.L170:
	movq	(%r8,%rax), %rdx
	movq	%rdx, (%rbx,%rax,8)
	addq	$1, %rax
	cmpq	%r13, %rax
	jne	.L170
	movq	%r8, %rdi
	call	free
	movl	$.LC12, %esi
	movl	$1, %edi
	call	setlocale
	movl	$.LC13, %edi
	call	puts
	call	omp_get_wtime
	vmovsd	%xmm0, -72(%rbp)
	cmpl	$1, %r14d
	je	.L239
	cmpl	$2, %r14d
	je	.L240
.L180:
	call	omp_get_wtime
	vsubsd	-72(%rbp), %xmm0, %xmm2
	movl	$.LC17, %edi
	movl	$1, %eax
	vmovapd	%xmm2, %xmm0
	vmovsd	%xmm2, -72(%rbp)
	call	printf
	vmovsd	-72(%rbp), %xmm2
	vxorpd	%xmm0, %xmm0, %xmm0
	vcomisd	%xmm0, %xmm2
	jbe	.L230
	vxorps	%xmm1, %xmm1, %xmm1
	vcvtsi2sdq	%r13, %xmm1, %xmm1
	vdivsd	%xmm2, %xmm1, %xmm0
	vmovsd	.LC19(%rip), %xmm1
	vcomisd	%xmm1, %xmm0
	jnb	.L184
	vcvttsd2siq	%xmm0, %rsi
.L185:
	movl	$.LC20, %edi
	xorl	%eax, %eax
	call	printf
.L186:
	cmpq	$1, %r13
	je	.L187
	leaq	-9(%r12), %r8
	leaq	-8(%r12), %rcx
	cmpq	$2, %r8
	jbe	.L207
	movq	%r12, %rdx
	vpxor	%xmm1, %xmm1, %xmm1
	movq	%rbx, %rax
	shrq	$2, %rdx
	vmovdqa	%ymm1, %ymm2
	subq	$2, %rdx
	movq	%rdx, %rsi
	salq	$5, %rsi
	addq	%rbx, %rsi
	.p2align 5
	.p2align 4
	.p2align 3
.L189:
	vmovdqu	8(%rax), %ymm0
	addq	$32, %rax
	vpcmpeqq	-32(%rax), %ymm0, %ymm0
	vpcmpeqq	%ymm2, %ymm0, %ymm0
	vpsubq	%ymm0, %ymm1, %ymm1
	cmpq	%rsi, %rax
	jne	.L189
	vextracti128	$0x1, %ymm1, %xmm0
	leaq	0(,%rdx,4), %rax
	vpaddq	%xmm1, %xmm0, %xmm0
	vpsrldq	$8, %xmm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rsi
	addq	$1, %rsi
	cmpq	%rax, %rcx
	je	.L231
	addq	$1, %rax
	vzeroupper
.L188:
	leaq	1(%rax), %rdx
	cmpq	%rcx, %rdx
	jnb	.L195
	cmpq	%rdx, %r13
	jb	.L195
	movq	(%rbx,%rax,8), %rdx
	leaq	0(,%rax,8), %rdi
	cmpq	%rdx, -8(%rbx,%rax,8)
	je	.L193
	addq	$1, %rsi
.L193:
	cmpq	8(%rbx,%rdi), %rdx
	je	.L197
	addq	$1, %rsi
.L197:
	leaq	3(%rax), %rdx
	addq	$2, %rax
.L195:
	movq	(%rbx,%rax,8), %rdi
	cmpq	%rdi, -8(%rbx,%rax,8)
	je	.L194
	addq	$1, %rsi
.L194:
	movq	%rdx, %rax
	cmpq	%r13, %rdx
	jnb	.L190
	addq	$1, %rdx
	jmp	.L195
.L230:
	movl	$.LC21, %edi
	call	puts
	jmp	.L186
.L231:
	vzeroupper
.L190:
	movl	$.LC22, %edi
	xorl	%eax, %eax
	movq	%r8, -72(%rbp)
	movq	%rcx, -80(%rbp)
	call	printf
	movl	$.LC23, %edi
	call	puts
	cmpq	$4, -72(%rbp)
	jbe	.L209
	leaq	8(%rbx), %rax
	orq	%rbx, %rax
	testb	$31, %al
	jne	.L209
	shrq	$2, %r12
	movq	-80(%rbp), %rcx
	movq	%rbx, %rax
	xorl	%edx, %edx
	vmovdqa	.LC1(%rip), %ymm2
	vmovdqa	.LC0(%rip), %ymm3
	subq	$2, %r12
	vmovdqa	.LC2(%rip), %ymm4
	jmp	.L201
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L199:
	addq	$1, %rdx
	addq	$32, %rax
	vpaddq	%ymm4, %ymm2, %ymm2
	cmpq	%r12, %rdx
	jnb	.L241
.L201:
	vmovdqa	(%rax), %ymm0
	vmovdqa	8(%rax), %ymm1
	vpsubq	%ymm3, %ymm0, %ymm0
	vpsubq	%ymm3, %ymm1, %ymm1
	vpcmpgtq	%ymm1, %ymm0, %ymm0
	vptest	%ymm0, %ymm0
	je	.L199
	vmovq	%xmm2, %rax
.L200:
	movq	(%rbx,%rax,8), %rdx
	cmpq	-8(%rbx,%rax,8), %rdx
	jb	.L213
	leaq	1(%rax), %rcx
	cmpq	%r13, %rcx
	jnb	.L236
	movq	8(%rbx,%rax,8), %rcx
	cmpq	%rdx, %rcx
	jb	.L213
	leaq	2(%rax), %rdx
	cmpq	%r13, %rdx
	jnb	.L236
	movq	16(%rbx,%rax,8), %rdx
	cmpq	%rcx, %rdx
	jb	.L213
	leaq	3(%rax), %rcx
	cmpq	%r13, %rcx
	jnb	.L236
	cmpq	%rdx, 24(%rbx,%rax,8)
	jb	.L213
.L236:
	vzeroupper
.L202:
	movl	$.LC4, %esi
.L203:
	movl	$.LC24, %edi
	xorl	%eax, %eax
	call	printf
	movq	%rbx, %rdi
	call	free
	xorl	%eax, %eax
	jmp	.L164
.L238:
	movl	$26, %edx
	movl	$1, %esi
	movl	$.LC10, %edi
	movq	stderr(%rip), %rcx
	call	fwrite
	movq	%rbx, %rdi
	call	fclose
	jmp	.L166
.L241:
	salq	$2, %r12
	cmpq	%rcx, %r12
	je	.L236
	leaq	1(%r12), %rax
	jmp	.L200
.L184:
	vsubsd	%xmm1, %xmm0, %xmm0
	vcvttsd2siq	%xmm0, %rsi
	btcq	$63, %rsi
	jmp	.L185
.L239:
	call	omp_get_max_threads
	movl	$.LC14, %edi
	movl	%eax, %r14d
	call	puts
	xorl	%eax, %eax
	movl	%r14d, %esi
	movl	$.LC15, %edi
	call	printf
	cmpq	$64, %r13
	jle	.L242
	leaq	-64(%rbp), %rsi
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	movl	$Charlatana_Sort._omp_fn.0, %edi
	movq	%r13, -56(%rbp)
	movq	%rbx, -64(%rbp)
	call	GOMP_parallel
	jmp	.L180
.L209:
	movl	$1, %eax
	jmp	.L204
	.p2align 5
.L243:
	addq	$1, %rax
	cmpq	%r13, %rax
	jnb	.L202
.L204:
	movq	-8(%rbx,%rax,8), %rcx
	cmpq	%rcx, (%rbx,%rax,8)
	jnb	.L243
	movl	$.LC5, %esi
	jmp	.L203
.L240:
	movl	$.LC16, %edi
	call	puts
	movl	$compare_uint64, %ecx
	movq	%r13, %rsi
	movq	%rbx, %rdi
	movl	$8, %edx
	call	qsort
	jmp	.L180
.L242:
	movl	$1, %eax
	xorl	%esi, %esi
	jmp	.L172
	.p2align 5
.L175:
	cmpq	%rcx, (%rbx,%rax,8)
	jnb	.L174
	leaq	0(,%rax,8), %rsi
.L174:
	addq	$1, %rax
.L172:
	movq	(%rbx,%rsi), %rcx
	cmpq	%rax, %r13
	jg	.L175
	movq	(%rbx), %rax
	movl	$1, %edi
	movq	%rcx, (%rbx)
	movq	%rax, (%rbx,%rsi)
	movq	%rbx, %rsi
.L176:
	cmpq	%rdi, %r13
	jle	.L180
	movq	8(%rsi), %rcx
	movq	(%rsi), %rdx
	movq	%rsi, %rax
	cmpq	%rdx, %rcx
	jnb	.L177
	.p2align 5
	.p2align 4
	.p2align 3
.L178:
	movq	%rdx, 8(%rax)
	movq	-8(%rax), %rdx
	subq	$8, %rax
	cmpq	%rdx, %rcx
	jb	.L178
.L177:
	movq	%rcx, 8(%rax)
	addq	$1, %rdi
	addq	$8, %rsi
	jmp	.L176
.L213:
	movl	$.LC5, %esi
	vzeroupper
	jmp	.L203
.L207:
	movl	$1, %eax
	movl	$1, %esi
	jmp	.L188
.L187:
	movl	$1, %esi
	movl	$.LC22, %edi
	xorl	%eax, %eax
	call	printf
	movl	$.LC23, %edi
	call	puts
	jmp	.L202
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	main.cold, @function
main.cold:
.LFSB7301:
.L228:
	.cfi_escape 0xf,0x3,0x76,0x60,0x6
	.cfi_escape 0x10,0x3,0x2,0x76,0x58
	.cfi_escape 0x10,0x6,0x2,0x76,0
	.cfi_escape 0x10,0xc,0x2,0x76,0x68
	.cfi_escape 0x10,0xd,0x2,0x76,0x70
	.cfi_escape 0x10,0xe,0x2,0x76,0x78
	movl	$.LC9, %edi
	call	perror
	jmp	.L166
	.cfi_endproc
.LFE7301:
	.section	.text.startup
	.size	main, .-main
	.section	.text.unlikely
	.size	main.cold, .-main.cold
.LCOLDE25:
	.section	.text.startup
.LHOTE25:
	.section	.rodata
	.align 32
	.type	MASK_STORE_TABLE, @object
	.size	MASK_STORE_TABLE, 160
MASK_STORE_TABLE:
	.quad	0
	.quad	0
	.quad	0
	.quad	0
	.quad	-1
	.quad	0
	.quad	0
	.quad	0
	.quad	-1
	.quad	-1
	.quad	0
	.quad	0
	.quad	-1
	.quad	-1
	.quad	-1
	.quad	0
	.quad	-1
	.quad	-1
	.quad	-1
	.quad	-1
	.align 32
	.type	QWORD_PACK_TABLE, @object
	.size	QWORD_PACK_TABLE, 512
QWORD_PACK_TABLE:
	.long	0
	.long	1
	.long	2
	.long	3
	.long	4
	.long	5
	.long	6
	.long	7
	.long	0
	.long	1
	.long	2
	.long	3
	.long	4
	.long	5
	.long	6
	.long	7
	.long	2
	.long	3
	.long	0
	.long	1
	.long	4
	.long	5
	.long	6
	.long	7
	.long	0
	.long	1
	.long	2
	.long	3
	.long	4
	.long	5
	.long	6
	.long	7
	.long	4
	.long	5
	.long	0
	.long	1
	.long	2
	.long	3
	.long	6
	.long	7
	.long	0
	.long	1
	.long	4
	.long	5
	.long	2
	.long	3
	.long	6
	.long	7
	.long	2
	.long	3
	.long	4
	.long	5
	.long	0
	.long	1
	.long	6
	.long	7
	.long	0
	.long	1
	.long	2
	.long	3
	.long	4
	.long	5
	.long	6
	.long	7
	.long	6
	.long	7
	.long	0
	.long	1
	.long	2
	.long	3
	.long	4
	.long	5
	.long	0
	.long	1
	.long	6
	.long	7
	.long	2
	.long	3
	.long	4
	.long	5
	.long	2
	.long	3
	.long	6
	.long	7
	.long	0
	.long	1
	.long	4
	.long	5
	.long	0
	.long	1
	.long	2
	.long	3
	.long	6
	.long	7
	.long	4
	.long	5
	.long	4
	.long	5
	.long	6
	.long	7
	.long	0
	.long	1
	.long	2
	.long	3
	.long	0
	.long	1
	.long	4
	.long	5
	.long	6
	.long	7
	.long	2
	.long	3
	.long	2
	.long	3
	.long	4
	.long	5
	.long	6
	.long	7
	.long	0
	.long	1
	.long	0
	.long	1
	.long	2
	.long	3
	.long	4
	.long	5
	.long	6
	.long	7
	.section	.rodata.cst32,"aM",@progbits,32
	.align 32
.LC0:
	.quad	-9223372036854775808
	.quad	-9223372036854775808
	.quad	-9223372036854775808
	.quad	-9223372036854775808
	.align 32
.LC1:
	.quad	1
	.quad	2
	.quad	3
	.quad	4
	.align 32
.LC2:
	.quad	4
	.quad	4
	.quad	4
	.quad	4
	.set	.LC3,.LC1+24
	.section	.rodata.cst8,"aM",@progbits,8
	.align 8
.LC19:
	.long	0
	.long	1138753536
	.ident	"GCC: (GNU) 15.2.1 20250808 (Red Hat 15.2.1-1)"
	.section	.note.GNU-stack,"",@progbits
