/*
COMPILE WITH OPENMP:
gcc -O3 -mavx512f -fopenmp -std=gnu11 -o benchmark29 benchmark29.c

Usage: 
  ./benchmark <file_to_sort> <algorithm_choice>
  
Algorithms:
  1 = Charlatana_v29 (Branchless OpenMP + AVX2 In-Place)
  2 = Standard C qsort()
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <omp.h>
#include <locale.h>          // NEW: for comma-formatted thousands

#include "Charlatana_v29_AVX512_8bytes.h"

int compare_uint64(const void* a, const void* b) {
    uint64_t val_a = *(const uint64_t*)a;
    uint64_t val_b = *(const uint64_t*)b;
    if (val_a < val_b) return -1;
    if (val_a > val_b) return 1;
    return 0;
}

bool is_sorted(uint64_t* arr, size_t n) {
    for (size_t i = 1; i < n; i++) {
        if (arr[i - 1] > arr[i]) return false;
    }
    return true;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <file_to_sort> <algorithm>\n", argv[0]);
        fprintf(stderr, "Algorithms:\n  1 = Charlatana_v29\n  2 = Standard qsort()\n");
        return EXIT_FAILURE;
    }

    const char* filename = argv[1];
    int algo_choice = atoi(argv[2]);

    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Error opening file");
        return EXIT_FAILURE;
    }

    fseek(file, 0, SEEK_END);
    long filesize = ftell(file);
    fseek(file, 0, SEEK_SET);

    if (filesize < 8) {
        fprintf(stderr, "Error: File is too small.\n");
        fclose(file);
        return EXIT_FAILURE;
    }

    uint8_t *file_buffer = (uint8_t*)malloc(filesize);
    fread(file_buffer, 1, filesize, file);
    fclose(file);

    size_t num_keys = filesize - 8 + 1;
    printf("Extracting %zu keys...\n", num_keys);

    uint64_t *keys = (uint64_t*)malloc(num_keys * sizeof(uint64_t));
    for (size_t i = 0; i < num_keys; i++) {
        memcpy(&keys[i], &file_buffer[i], sizeof(uint64_t));
    }
    free(file_buffer);

    /* === NEW: enable comma formatting for performance numbers === */
    setlocale(LC_NUMERIC, "");

    printf("\n--- Starting Benchmark ---\n");
    double start_time = omp_get_wtime();
    
    if (algo_choice == 1) {
        int threads = omp_get_max_threads();
        printf("Algorithm: Charlatana_v29\n");
        printf("OpenMP Engine: Utilizing up to %d Hardware Threads\n", threads);
        Charlatana_Sort(keys, num_keys);
    } 
    else if (algo_choice == 2) {
        printf("Algorithm: Standard C qsort() [Single Threaded]\n");
        qsort(keys, num_keys, sizeof(uint64_t), compare_uint64);
    } 
    
    double end_time = omp_get_wtime();
    double elapsed = end_time - start_time;

    printf("Sort Time: %.4f seconds\n", elapsed);

    /* === NEW: Total Performance report (Total_keys / OpenMPtime) === */
    if (elapsed > 0.0) {
        uint64_t keys_per_sec = (uint64_t)(num_keys / elapsed);
        printf("Total Performance: %'llu keys-per-second\n", (unsigned long long)keys_per_sec);
    } else {
        printf("Total Performance: N/A keys-per-second\n");
    }

    /* === UNIQUE KEYS COUNT (after sorting) === */
    size_t unique_keys = 0;
    if (num_keys > 0) {
        unique_keys = 1;
        for (size_t i = 1; i < num_keys; i++) {
            if (keys[i] != keys[i - 1]) {
                unique_keys++;
            }
        }
    }
    printf("Unique keys: %'zu\n", unique_keys);

    printf("\n--- Verification ---\n");
    bool is_properly_sorted = is_sorted(keys, num_keys);
    printf("Array properly sorted: %s\n", is_properly_sorted ? "YES" : "NO");

    free(keys);
    return EXIT_SUCCESS;
}

// Core i7-11850H (Tiger Lake-H). 128GB DDR4 3200MHz

/*
[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update_2026-Mar-16]$ sh bench.sh 
Charlatana_v29:
Extracting 998340601 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 8.1793 seconds
Total Performance: 122,057,189 keys-per-second
Unique keys: 209,106,265

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 SUPRAPIG_SPETSNAZ-in-Russian_(FB2-1012).tar 1':

        104,035.79 msec task-clock:u                     #    9.168 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         1,950,470      page-faults:u                    #   18.748 K/sec                     
   158,066,061,913      instructions:u                   #    0.48  insn per cycle              (90.91%)
   329,346,708,349      cycles:u                         #    3.166 GHz                         (90.90%)
    26,232,366,608      branches:u                       #  252.148 M/sec                       (90.92%)
     1,196,176,484      branch-misses:u                  #    4.56% of all branches             (81.82%)
                        TopdownL1                 #     14.4 %  tma_backend_bound      
                                                  #     83.1 %  tma_bad_speculation    
                                                  #      0.1 %  tma_frontend_bound     
                                                  #      2.5 %  tma_retiring             (90.91%)
    23,266,115,628      L1-dcache-loads:u                #  223.636 M/sec                       (90.91%)
     3,129,549,893      L1-dcache-load-misses:u          #   13.45% of all L1-dcache accesses   (90.91%)
       137,656,877      LLC-loads:u                      #    1.323 M/sec                       (90.91%)
       132,445,452      LLC-load-misses:u                #   96.21% of all LL-cache accesses    (81.83%)

      11.347493545 seconds time elapsed

      98.815642000 seconds user
       1.926434000 seconds sys


Extracting 998340601 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 9.0549 seconds
Total Performance: 110,253,707 keys-per-second
Unique keys: 209,106,265

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 SUPRAPIG_SPETSNAZ-in-Russian_(FB2-1012).tar 1':

        137,948.15 msec task-clock:u                     #   10.796 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         1,950,688      page-faults:u                    #   14.141 K/sec                     
   253,648,619,986      instructions:u                   #    0.62  insn per cycle              (90.90%)
   407,013,345,422      cycles:u                         #    2.950 GHz                         (90.91%)
    48,609,537,576      branches:u                       #  352.375 M/sec                       (90.92%)
     2,261,311,379      branch-misses:u                  #    4.65% of all branches             (81.82%)
                        TopdownL1                 #     12.4 %  tma_backend_bound      
                                                  #     83.3 %  tma_bad_speculation    
                                                  #      0.7 %  tma_frontend_bound     
                                                  #      3.6 %  tma_retiring             (90.91%)
    39,144,951,929      L1-dcache-loads:u                #  283.766 M/sec                       (90.91%)
     3,579,920,601      L1-dcache-load-misses:u          #    9.15% of all L1-dcache accesses   (90.90%)
       346,437,797      LLC-loads:u                      #    2.511 M/sec                       (90.90%)
       106,933,624      LLC-load-misses:u                #   30.87% of all LL-cache accesses    (81.81%)

      12.778072037 seconds time elapsed

     131.226827000 seconds user
       2.488949000 seconds sys


Extracting 998340601 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 8.8093 seconds
Total Performance: 113,327,952 keys-per-second
Unique keys: 209,106,265

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark29 SUPRAPIG_SPETSNAZ-in-Russian_(FB2-1012).tar 1"
	User time (seconds): 130.95
	System time (seconds): 2.41
	Percent of CPU this job got: 1069%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 0:12.46
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 8776364
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 2194433
	Voluntary context switches: 94
	Involuntary context switches: 2540
	Swaps: 0
	File system inputs: 0
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0
Extracting 5694801913 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 52.9232 seconds
Total Performance: 107,605,024 keys-per-second
Unique keys: 82,181,812

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1':

        691,429.30 msec task-clock:u                     #    9.715 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        11,123,271      page-faults:u                    #   16.087 K/sec                     
   764,312,966,008      instructions:u                   #    0.33  insn per cycle              (90.91%)
 2,312,567,947,491      cycles:u                         #    3.345 GHz                         (90.91%)
   124,521,258,882      branches:u                       #  180.093 M/sec                       (90.91%)
     4,994,400,669      branch-misses:u                  #    4.01% of all branches             (81.82%)
                        TopdownL1                 #     10.6 %  tma_backend_bound      
                                                  #     88.4 %  tma_bad_speculation    
                                                  #     -0.1 %  tma_frontend_bound     
                                                  #      1.2 %  tma_retiring             (90.91%)
   110,295,011,002      L1-dcache-loads:u                #  159.517 M/sec                       (90.91%)
    19,187,644,936      L1-dcache-load-misses:u          #   17.40% of all L1-dcache accesses   (90.91%)
       842,614,892      LLC-loads:u                      #    1.219 M/sec                       (90.91%)
       818,199,967      LLC-load-misses:u                #   97.10% of all LL-cache accesses    (81.82%)

      71.167756297 seconds time elapsed

     659.336609000 seconds user
      11.060270000 seconds sys


Extracting 5694801913 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 56.3271 seconds
Total Performance: 101,102,364 keys-per-second
Unique keys: 82,181,812

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1':

        830,433.79 msec task-clock:u                     #   10.756 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        11,123,458      page-faults:u                    #   13.395 K/sec                     
 1,211,346,573,333      instructions:u                   #    0.46  insn per cycle              (90.91%)
 2,649,240,244,185      cycles:u                         #    3.190 GHz                         (90.91%)
   226,884,753,648      branches:u                       #  273.212 M/sec                       (90.91%)
    10,502,701,821      branch-misses:u                  #    4.63% of all branches             (81.82%)
                        TopdownL1                 #      6.6 %  tma_backend_bound      
                                                  #     92.2 %  tma_bad_speculation    
                                                  #     -0.1 %  tma_frontend_bound     
                                                  #      1.3 %  tma_retiring             (90.91%)
   173,293,882,752      L1-dcache-loads:u                #  208.679 M/sec                       (90.91%)
    21,389,589,983      L1-dcache-load-misses:u          #   12.34% of all L1-dcache accesses   (90.91%)
     1,860,601,872      LLC-loads:u                      #    2.241 M/sec                       (90.91%)
       649,535,104      LLC-load-misses:u                #   34.91% of all LL-cache accesses    (81.82%)

      77.209552105 seconds time elapsed

     793.760548000 seconds user
      12.863132000 seconds sys


Extracting 5694801913 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 55.6772 seconds
Total Performance: 102,282,434 keys-per-second
Unique keys: 82,181,812

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark29 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1"
	User time (seconds): 801.93
	System time (seconds): 12.73
	Percent of CPU this job got: 1070%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 1:16.09
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 50053720
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 12513815
	Voluntary context switches: 96
	Involuntary context switches: 11918
	Swaps: 0
	File system inputs: 0
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0
Extracting 6126911481 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 65.4168 seconds
Total Performance: 93,659,591 keys-per-second
Unique keys: 5,726,784,672

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 Nobara-43-GNOME-2026-01-26.iso 1':

        877,041.85 msec task-clock:u                     #   10.316 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        11,967,477      page-faults:u                    #   13.645 K/sec                     
 1,690,560,918,631      instructions:u                   #    0.66  insn per cycle              (90.91%)
 2,544,445,922,132      cycles:u                         #    2.901 GHz                         (90.91%)
   284,185,742,403      branches:u                       #  324.028 M/sec                       (90.91%)
    15,547,043,601      branch-misses:u                  #    5.47% of all branches             (81.82%)
                        TopdownL1                 #      2.7 %  tma_backend_bound      
                                                  #     96.6 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      1.0 %  tma_retiring             (90.91%)
   253,651,097,946      L1-dcache-loads:u                #  289.212 M/sec                       (90.91%)
    22,141,193,320      L1-dcache-load-misses:u          #    8.73% of all L1-dcache accesses   (90.91%)
       905,919,858      LLC-loads:u                      #    1.033 M/sec                       (90.91%)
       863,131,165      LLC-load-misses:u                #   95.28% of all LL-cache accesses    (81.82%)

      85.016364406 seconds time elapsed

     834.238069000 seconds user
      11.887246000 seconds sys


Extracting 6126911481 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 70.9998 seconds
Total Performance: 86,294,813 keys-per-second
Unique keys: 5,726,784,672

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 Nobara-43-GNOME-2026-01-26.iso 1':

      1,065,683.39 msec task-clock:u                     #   11.375 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        11,967,505      page-faults:u                    #   11.230 K/sec                     
 2,250,640,473,381      instructions:u                   #    0.76  insn per cycle              (90.91%)
 2,977,955,468,591      cycles:u                         #    2.794 GHz                         (90.91%)
   423,811,373,007      branches:u                       #  397.690 M/sec                       (90.91%)
    26,149,756,294      branch-misses:u                  #    6.17% of all branches             (81.82%)
                        TopdownL1                 #      4.8 %  tma_backend_bound      
                                                  #     94.0 %  tma_bad_speculation    
                                                  #     -0.2 %  tma_frontend_bound     
                                                  #      1.4 %  tma_retiring             (90.91%)
   292,711,504,977      L1-dcache-loads:u                #  274.670 M/sec                       (90.91%)
    24,943,763,703      L1-dcache-load-misses:u          #    8.52% of all L1-dcache accesses   (90.91%)
     2,138,435,559      LLC-loads:u                      #    2.007 M/sec                       (90.91%)
       703,107,693      LLC-load-misses:u                #   32.88% of all LL-cache accesses    (81.82%)

      93.689384627 seconds time elapsed

    1016.424224000 seconds user
      14.043938000 seconds sys


Extracting 6126911481 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 68.9735 seconds
Total Performance: 88,829,987 keys-per-second
Unique keys: 5,726,784,672

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark29 Nobara-43-GNOME-2026-01-26.iso 1"
	User time (seconds): 1012.11
	System time (seconds): 13.71
	Percent of CPU this job got: 1126%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 1:31.10
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 53851756
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 13463347
	Voluntary context switches: 83
	Involuntary context switches: 14442
	Swaps: 0
	File system inputs: 0
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0
Extracting 9758687449 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 93.2448 seconds
Total Performance: 104,656,689 keys-per-second
Unique keys: 316,438,651

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1':

      1,174,673.67 msec task-clock:u                     #    9.440 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        19,060,680      page-faults:u                    #   16.226 K/sec                     
 1,446,956,868,729      instructions:u                   #    0.37  insn per cycle              (90.91%)
 3,913,886,396,622      cycles:u                         #    3.332 GHz                         (90.91%)
   235,992,703,521      branches:u                       #  200.901 M/sec                       (90.91%)
    10,338,904,138      branch-misses:u                  #    4.38% of all branches             (81.82%)
                        TopdownL1                 #      3.0 %  tma_backend_bound      
                                                  #     96.6 %  tma_bad_speculation    
                                                  #     -0.2 %  tma_frontend_bound     
                                                  #      0.6 %  tma_retiring             (90.91%)
   209,024,794,244      L1-dcache-loads:u                #  177.943 M/sec                       (90.91%)
    33,644,568,361      L1-dcache-load-misses:u          #   16.10% of all L1-dcache accesses   (90.91%)
     1,465,452,682      LLC-loads:u                      #    1.248 M/sec                       (90.91%)
     1,425,679,089      LLC-load-misses:u                #   97.29% of all LL-cache accesses    (81.82%)

     124.432230989 seconds time elapsed

    1119.999806000 seconds user
      19.051718000 seconds sys


Extracting 9758687449 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 101.6561 seconds
Total Performance: 95,997,093 keys-per-second
Unique keys: 316,438,651

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1':

      1,489,894.63 msec task-clock:u                     #   10.751 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        19,060,764      page-faults:u                    #   12.793 K/sec                     
 2,438,555,649,904      instructions:u                   #    0.53  insn per cycle              (90.91%)
 4,637,757,999,378      cycles:u                         #    3.113 GHz                         (90.91%)
   458,214,932,616      branches:u                       #  307.549 M/sec                       (90.91%)
    21,039,624,834      branch-misses:u                  #    4.59% of all branches             (81.82%)
                        TopdownL1                 #      4.0 %  tma_backend_bound      
                                                  #     95.3 %  tma_bad_speculation    
                                                  #     -0.2 %  tma_frontend_bound     
                                                  #      0.9 %  tma_retiring             (90.91%)
   377,406,774,366      L1-dcache-loads:u                #  253.311 M/sec                       (90.91%)
    38,801,642,105      L1-dcache-load-misses:u          #   10.28% of all L1-dcache accesses   (90.91%)
     3,929,292,817      LLC-loads:u                      #    2.637 M/sec                       (90.91%)
     1,125,115,370      LLC-load-misses:u                #   28.63% of all LL-cache accesses    (81.82%)

     138.586372162 seconds time elapsed

    1423.025775000 seconds user
      23.735265000 seconds sys


Extracting 9758687449 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 100.1579 seconds
Total Performance: 97,433,007 keys-per-second
Unique keys: 316,438,651

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark29 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1"
	User time (seconds): 1433.74
	System time (seconds): 23.02
	Percent of CPU this job got: 1075%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 2:15.40
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 85771688
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 21443271
	Voluntary context switches: 137
	Involuntary context switches: 23695
	Swaps: 0
	File system inputs: 2068744
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0
Extracting 11402523458 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 126.0372 seconds
Total Performance: 90,469,525 keys-per-second
Unique keys: 11,116,109,642

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 Brawl_in_cell_block_99_(2017)_UHD_BDRip_720p.mkv 1':

      1,670,036.72 msec task-clock:u                     #   10.219 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        22,271,484      page-faults:u                    #   13.336 K/sec                     
 3,185,120,974,606      instructions:u                   #    0.65  insn per cycle              (90.91%)
 4,926,339,713,328      cycles:u                         #    2.950 GHz                         (90.91%)
   534,267,198,096      branches:u                       #  319.913 M/sec                       (90.91%)
    29,028,669,808      branch-misses:u                  #    5.43% of all branches             (81.82%)
                        TopdownL1                 #      1.6 %  tma_backend_bound      
                                                  #     98.3 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      0.4 %  tma_retiring             (90.91%)
   475,088,488,621      L1-dcache-loads:u                #  284.478 M/sec                       (90.91%)
    42,554,198,556      L1-dcache-load-misses:u          #    8.96% of all L1-dcache accesses   (90.91%)
     1,763,092,192      LLC-loads:u                      #    1.056 M/sec                       (90.91%)
     1,682,198,448      LLC-load-misses:u                #   95.41% of all LL-cache accesses    (81.82%)

     163.423203518 seconds time elapsed

    1589.658880000 seconds user
      22.603619000 seconds sys


Extracting 11402523458 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 138.3886 seconds
Total Performance: 82,394,970 keys-per-second
Unique keys: 11,116,109,642

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 Brawl_in_cell_block_99_(2017)_UHD_BDRip_720p.mkv 1':

      2,091,631.50 msec task-clock:u                     #   11.525 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        22,271,435      page-faults:u                    #   10.648 K/sec                     
 4,398,523,868,889      instructions:u                   #    0.74  insn per cycle              (90.91%)
 5,922,253,493,011      cycles:u                         #    2.831 GHz                         (90.91%)
   827,761,818,325      branches:u                       #  395.749 M/sec                       (90.91%)
    49,026,244,682      branch-misses:u                  #    5.92% of all branches             (81.82%)
                        TopdownL1                 #      3.9 %  tma_backend_bound      
                                                  #     95.8 %  tma_bad_speculation    
                                                  #     -0.4 %  tma_frontend_bound     
                                                  #      0.7 %  tma_retiring             (90.91%)
   598,378,061,572      L1-dcache-loads:u                #  286.082 M/sec                       (90.91%)
    48,867,623,554      L1-dcache-load-misses:u          #    8.17% of all L1-dcache accesses   (90.91%)
     4,592,190,847      LLC-loads:u                      #    2.196 M/sec                       (90.91%)
     1,314,038,821      LLC-load-misses:u                #   28.61% of all LL-cache accesses    (81.82%)

     181.486636196 seconds time elapsed

    1997.291146000 seconds user
      27.350448000 seconds sys


Extracting 11402523458 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 134.3685 seconds
Total Performance: 84,860,097 keys-per-second
Unique keys: 11,116,109,642

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark29 Brawl_in_cell_block_99_(2017)_UHD_BDRip_720p.mkv 1"
	User time (seconds): 1990.04
	System time (seconds): 26.23
	Percent of CPU this job got: 1145%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 2:56.04
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 100219300
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 25055289
	Voluntary context switches: 2396
	Involuntary context switches: 36897
	Swaps: 0
	File system inputs: 15860320
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0

qsort:
Extracting 998340601 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 109.9040 seconds
Total Performance: 9,083,750 keys-per-second
Unique keys: 209,106,265

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 SUPRAPIG_SPETSNAZ-in-Russian_(FB2-1012).tar 2':

        113,168.19 msec task-clock:u                     #    0.999 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         3,899,848      page-faults:u                    #   34.461 K/sec                     
   763,063,905,866      instructions:u                   #    1.52  insn per cycle              (90.91%)
   502,371,354,890      cycles:u                         #    4.439 GHz                         (90.91%)
   163,100,927,929      branches:u                       #    1.441 G/sec                       (90.91%)
    10,095,342,786      branch-misses:u                  #    6.19% of all branches             (81.82%)
                        TopdownL1                 #      2.3 %  tma_backend_bound      
                                                  #     97.6 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      0.5 %  tma_retiring             (90.91%)
   205,577,364,217      L1-dcache-loads:u                #    1.817 G/sec                       (90.91%)
     8,354,866,675      L1-dcache-load-misses:u          #    4.06% of all L1-dcache accesses   (90.91%)
       198,296,750      LLC-loads:u                      #    1.752 M/sec                       (90.91%)
       144,381,032      LLC-load-misses:u                #   72.81% of all LL-cache accesses    (81.82%)

     113.274881180 seconds time elapsed

     108.578241000 seconds user
       3.751489000 seconds sys


Extracting 998340601 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 118.7475 seconds
Total Performance: 8,407,257 keys-per-second
Unique keys: 209,106,265

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 SUPRAPIG_SPETSNAZ-in-Russian_(FB2-1012).tar 2':

        122,439.16 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         3,899,856      page-faults:u                    #   31.851 K/sec                     
   699,955,172,306      instructions:u                   #    1.30  insn per cycle              (90.91%)
   539,413,977,392      cycles:u                         #    4.406 GHz                         (90.91%)
   133,621,828,899      branches:u                       #    1.091 G/sec                       (90.91%)
    10,660,323,936      branch-misses:u                  #    7.98% of all branches             (81.82%)
                        TopdownL1                 #      2.5 %  tma_backend_bound      
                                                  #     97.7 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      0.1 %  tma_retiring             (90.91%)
   204,694,595,584      L1-dcache-loads:u                #    1.672 G/sec                       (90.91%)
     8,363,737,027      L1-dcache-load-misses:u          #    4.09% of all L1-dcache accesses   (90.91%)
       189,877,447      LLC-loads:u                      #    1.551 M/sec                       (90.91%)
       135,950,657      LLC-load-misses:u                #   71.60% of all LL-cache accesses    (81.82%)

     122.467709151 seconds time elapsed

     117.909679000 seconds user
       3.635959000 seconds sys


Extracting 5694801913 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 583.9533 seconds
Total Performance: 9,752,152 keys-per-second
Unique keys: 82,181,812

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 2':

        602,180.47 msec task-clock:u                     #    0.999 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        22,245,400      page-faults:u                    #   36.941 K/sec                     
 4,757,728,988,876      instructions:u                   #    1.72  insn per cycle              (90.91%)
 2,768,287,142,727      cycles:u                         #    4.597 GHz                         (90.91%)
 1,006,619,950,498      branches:u                       #    1.672 G/sec                       (90.91%)
    48,314,457,606      branch-misses:u                  #    4.80% of all branches             (81.82%)
                        TopdownL1                 #      1.9 %  tma_backend_bound      
                                                  #     98.2 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      0.2 %  tma_retiring             (90.91%)
 1,269,849,832,895      L1-dcache-loads:u                #    2.109 G/sec                       (90.91%)
    53,228,413,392      L1-dcache-load-misses:u          #    4.19% of all L1-dcache accesses   (90.91%)
     1,241,903,141      LLC-loads:u                      #    2.062 M/sec                       (90.91%)
       918,042,053      LLC-load-misses:u                #   73.92% of all LL-cache accesses    (81.82%)

     602.600854715 seconds time elapsed

     577.589861000 seconds user
      20.320902000 seconds sys


Extracting 5694801913 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 625.5660 seconds
Total Performance: 9,103,438 keys-per-second
Unique keys: 82,181,812

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 2':

        646,283.39 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        22,245,409      page-faults:u                    #   34.421 K/sec                     
 4,326,626,870,484      instructions:u                   #    1.48  insn per cycle              (90.91%)
 2,920,078,795,976      cycles:u                         #    4.518 GHz                         (90.91%)
   822,897,969,977      branches:u                       #    1.273 G/sec                       (90.91%)
    49,644,175,796      branch-misses:u                  #    6.03% of all branches             (81.82%)
                        TopdownL1                 #      2.0 %  tma_backend_bound      
                                                  #     98.3 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      0.0 %  tma_retiring             (90.91%)
 1,265,022,183,117      L1-dcache-loads:u                #    1.957 G/sec                       (90.91%)
    53,181,729,141      L1-dcache-load-misses:u          #    4.20% of all L1-dcache accesses   (90.91%)
     1,195,456,950      LLC-loads:u                      #    1.850 M/sec                       (90.91%)
       880,894,677      LLC-load-misses:u                #   73.69% of all LL-cache accesses    (81.82%)

     646.432535393 seconds time elapsed

     621.310524000 seconds user
      20.379258000 seconds sys


Extracting 6126911481 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 891.0324 seconds
Total Performance: 6,876,194 keys-per-second
Unique keys: 5,726,784,672

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 Nobara-43-GNOME-2026-01-26.iso 2':

        910,642.56 msec task-clock:u                     #    0.999 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        23,933,293      page-faults:u                    #   26.282 K/sec                     
 4,983,409,325,761      instructions:u                   #    1.18  insn per cycle              (90.91%)
 4,225,494,550,584      cycles:u                         #    4.640 GHz                         (90.91%)
 1,085,101,574,547      branches:u                       #    1.192 G/sec                       (90.91%)
    98,940,598,881      branch-misses:u                  #    9.12% of all branches             (81.82%)
                        TopdownL1                 #      2.5 %  tma_backend_bound      
                                                  #     97.8 %  tma_bad_speculation    
                                                  #     -0.4 %  tma_frontend_bound     
                                                  #      0.1 %  tma_retiring             (90.91%)
 1,368,815,148,932      L1-dcache-loads:u                #    1.503 G/sec                       (90.91%)
    57,605,676,793      L1-dcache-load-misses:u          #    4.21% of all L1-dcache accesses   (90.91%)
     1,430,571,287      LLC-loads:u                      #    1.571 M/sec                       (90.91%)
     1,070,830,534      LLC-load-misses:u                #   74.85% of all LL-cache accesses    (81.82%)

     911.165483090 seconds time elapsed

     882.445334000 seconds user
      21.823045000 seconds sys


Extracting 6126911481 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 971.6801 seconds
Total Performance: 6,305,482 keys-per-second
Unique keys: 5,726,784,672

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 Nobara-43-GNOME-2026-01-26.iso 2':

        993,921.20 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        23,933,302      page-faults:u                    #   24.080 K/sec                     
 4,663,855,147,751      instructions:u                   #    1.04  insn per cycle              (90.91%)
 4,474,562,885,057      cycles:u                         #    4.502 GHz                         (90.91%)
   887,035,497,851      branches:u                       #  892.461 M/sec                       (90.91%)
   103,518,059,440      branch-misses:u                  #   11.67% of all branches             (81.82%)
                        TopdownL1                 #      2.7 %  tma_backend_bound      
                                                  #     97.7 %  tma_bad_speculation    
                                                  #     -0.4 %  tma_frontend_bound     
                                                  #      0.0 %  tma_retiring             (90.91%)
 1,363,499,132,739      L1-dcache-loads:u                #    1.372 G/sec                       (90.91%)
    57,567,887,609      L1-dcache-load-misses:u          #    4.22% of all L1-dcache accesses   (90.91%)
     1,334,664,810      LLC-loads:u                      #    1.343 M/sec                       (90.91%)
       973,055,133      LLC-load-misses:u                #   72.91% of all LL-cache accesses    (81.82%)

     994.138669140 seconds time elapsed

     964.885699000 seconds user
      21.951980000 seconds sys
*/

