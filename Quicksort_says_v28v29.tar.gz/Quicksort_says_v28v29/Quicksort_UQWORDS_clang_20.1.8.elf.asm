	.file	"benchmark28.c"
	.text
	.globl	compare_uint64                  # -- Begin function compare_uint64
	.p2align	4
	.type	compare_uint64,@function
compare_uint64:                         # @compare_uint64
	.cfi_startproc
# %bb.0:
	movq	(%rdi), %rax
	cmpq	(%rsi), %rax
	seta	%al
	sbbb	$0, %al
	movsbl	%al, %eax
	retq
.Lfunc_end0:
	.size	compare_uint64, .Lfunc_end0-compare_uint64
	.cfi_endproc
                                        # -- End function
	.globl	is_sorted                       # -- Begin function is_sorted
	.p2align	4
	.type	is_sorted,@function
is_sorted:                              # @is_sorted
	.cfi_startproc
# %bb.0:
	movb	$1, %al
	cmpq	$2, %rsi
	jb	.LBB1_4
# %bb.1:
	addq	$-2, %rsi
	xorl	%ecx, %ecx
	.p2align	4
.LBB1_2:                                # =>This Inner Loop Header: Depth=1
	movq	(%rdi,%rcx,8), %rax
	cmpq	8(%rdi,%rcx,8), %rax
	setbe	%al
	ja	.LBB1_4
# %bb.3:                                #   in Loop: Header=BB1_2 Depth=1
	leaq	1(%rcx), %rdx
	cmpq	%rcx, %rsi
	movq	%rdx, %rcx
	jne	.LBB1_2
.LBB1_4:
	retq
.Lfunc_end1:
	.size	is_sorted, .Lfunc_end1-is_sorted
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0                          # -- Begin function main
.LCPI2_0:
	.quad	0x43e0000000000000              # double 9.2233720368547758E+18
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI2_1:
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	0                               # 0x0
	.long	0                               # 0x0
	.section	.rodata,"a",@progbits
.LCPI2_2:
	.byte	1                               # 0x1
	.byte	0                               # 0x0
	.text
	.globl	main
	.p2align	4
	.type	main,@function
main:                                   # @main
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpl	$3, %edi
	jne	.LBB2_1
# %bb.2:
	movq	8(%rsi), %rbx
	movq	16(%rsi), %rdi
	xorl	%esi, %esi
	movl	$10, %edx
	callq	strtol
	movq	%rax, %r12
	movl	$.L.str.2, %esi
	movq	%rbx, %rdi
	callq	fopen
	testq	%rax, %rax
	je	.LBB2_3
# %bb.4:
	movq	%rax, %r14
	movq	%rax, %rdi
	xorl	%esi, %esi
	movl	$2, %edx
	callq	fseek
	movq	%r14, %rdi
	callq	ftell
	movq	%rax, %rbx
	movq	%r14, %rdi
	xorl	%esi, %esi
	xorl	%edx, %edx
	callq	fseek
	cmpq	$7, %rbx
	jle	.LBB2_5
# %bb.6:
	movq	%rbx, %rdi
	callq	malloc
	movq	%rax, %r13
	movl	$1, %esi
	movq	%rax, %rdi
	movq	%rbx, %rdx
	movq	%r14, %rcx
	callq	fread
	movq	%r14, %rdi
	callq	fclose
	leaq	-7(%rbx), %r15
	xorl	%ebp, %ebp
	movl	$.L.str.5, %edi
	movq	%r15, %rsi
	xorl	%eax, %eax
	callq	printf
	leaq	-56(,%rbx,8), %rdi
	callq	malloc
	movq	%rax, %r14
	cmpq	$3, %r15
	jbe	.LBB2_19
# %bb.7:
	cmpq	$16, %r15
	jae	.LBB2_9
# %bb.8:
	xorl	%ebp, %ebp
	jmp	.LBB2_13
.LBB2_9:
	movq	%r15, %rbp
	andq	$-16, %rbp
	xorl	%eax, %eax
	.p2align	4
.LBB2_10:                               # =>This Inner Loop Header: Depth=1
	vmovsd	1(%r13,%rax), %xmm0             # xmm0 = mem[0],zero
	vmovsd	(%r13,%rax), %xmm1              # xmm1 = mem[0],zero
	vunpcklpd	%xmm0, %xmm1, %xmm0     # xmm0 = xmm1[0],xmm0[0]
	vmovq	3(%r13,%rax), %xmm1             # xmm1 = mem[0],zero
	vmovq	2(%r13,%rax), %xmm2             # xmm2 = mem[0],zero
	vpunpcklqdq	%xmm1, %xmm2, %xmm1     # xmm1 = xmm2[0],xmm1[0]
	vmovq	5(%r13,%rax), %xmm2             # xmm2 = mem[0],zero
	vmovq	4(%r13,%rax), %xmm3             # xmm3 = mem[0],zero
	vpunpcklqdq	%xmm2, %xmm3, %xmm2     # xmm2 = xmm3[0],xmm2[0]
	vmovq	7(%r13,%rax), %xmm3             # xmm3 = mem[0],zero
	vmovq	6(%r13,%rax), %xmm4             # xmm4 = mem[0],zero
	vpunpcklqdq	%xmm3, %xmm4, %xmm3     # xmm3 = xmm4[0],xmm3[0]
	vmovq	9(%r13,%rax), %xmm4             # xmm4 = mem[0],zero
	vmovq	8(%r13,%rax), %xmm5             # xmm5 = mem[0],zero
	vpunpcklqdq	%xmm4, %xmm5, %xmm4     # xmm4 = xmm5[0],xmm4[0]
	vmovq	11(%r13,%rax), %xmm5            # xmm5 = mem[0],zero
	vmovq	10(%r13,%rax), %xmm6            # xmm6 = mem[0],zero
	vpunpcklqdq	%xmm5, %xmm6, %xmm5     # xmm5 = xmm6[0],xmm5[0]
	vmovq	13(%r13,%rax), %xmm6            # xmm6 = mem[0],zero
	vmovq	12(%r13,%rax), %xmm7            # xmm7 = mem[0],zero
	vpunpcklqdq	%xmm6, %xmm7, %xmm6     # xmm6 = xmm7[0],xmm6[0]
	vmovq	15(%r13,%rax), %xmm7            # xmm7 = mem[0],zero
	vmovq	14(%r13,%rax), %xmm8            # xmm8 = mem[0],zero
	vpunpcklqdq	%xmm7, %xmm8, %xmm7     # xmm7 = xmm8[0],xmm7[0]
	vmovdqu	%xmm1, 16(%r14,%rax,8)
	vmovupd	%xmm0, (%r14,%rax,8)
	vmovdqu	%xmm3, 48(%r14,%rax,8)
	vmovdqu	%xmm2, 32(%r14,%rax,8)
	vmovdqu	%xmm5, 80(%r14,%rax,8)
	vmovdqu	%xmm4, 64(%r14,%rax,8)
	vmovdqu	%xmm7, 112(%r14,%rax,8)
	vmovdqu	%xmm6, 96(%r14,%rax,8)
	addq	$16, %rax
	cmpq	%rax, %rbp
	jne	.LBB2_10
# %bb.11:
	cmpq	%rbp, %r15
	je	.LBB2_16
# %bb.12:
	testb	$12, %r15b
	je	.LBB2_19
.LBB2_13:
	movq	%rbp, %rax
	movq	%r15, %rbp
	andq	$-4, %rbp
	.p2align	4
.LBB2_14:                               # =>This Inner Loop Header: Depth=1
	vmovsd	1(%r13,%rax), %xmm0             # xmm0 = mem[0],zero
	vmovsd	(%r13,%rax), %xmm1              # xmm1 = mem[0],zero
	vunpcklpd	%xmm0, %xmm1, %xmm0     # xmm0 = xmm1[0],xmm0[0]
	vmovq	3(%r13,%rax), %xmm1             # xmm1 = mem[0],zero
	vmovq	2(%r13,%rax), %xmm2             # xmm2 = mem[0],zero
	vpunpcklqdq	%xmm1, %xmm2, %xmm1     # xmm1 = xmm2[0],xmm1[0]
	vmovdqu	%xmm1, 16(%r14,%rax,8)
	vmovupd	%xmm0, (%r14,%rax,8)
	addq	$4, %rax
	cmpq	%rax, %rbp
	jne	.LBB2_14
	jmp	.LBB2_15
.LBB2_1:
	movq	stderr(%rip), %rdi
	movq	(%rsi), %rdx
	movl	$.L.str, %esi
	xorl	%eax, %eax
	callq	fprintf
	movq	stderr(%rip), %rcx
	movl	$.L.str.1, %edi
	movl	$56, %esi
	movl	$1, %edx
	callq	fwrite@PLT
	movl	$1, %ebp
	jmp	.LBB2_77
.LBB2_3:
	movl	$.L.str.3, %edi
	callq	perror
	movl	$1, %ebp
	jmp	.LBB2_77
.LBB2_5:
	movq	stderr(%rip), %rcx
	movl	$.L.str.4, %edi
	movl	$26, %esi
	movl	$1, %edx
	callq	fwrite@PLT
	movq	%r14, %rdi
	callq	fclose
	movl	$1, %ebp
	jmp	.LBB2_77
.LBB2_15:
	cmpq	%rbp, %r15
	je	.LBB2_16
.LBB2_19:
	movq	(%r13,%rbp), %rax
	movq	%rax, (%r14,%rbp,8)
	incq	%rbp
	jmp	.LBB2_15
.LBB2_16:
	movq	%r13, %rdi
	callq	free
	movl	$.L.str.6, %esi
	movl	$1, %edi
	callq	setlocale
	movl	$.Lstr, %edi
	callq	puts@PLT
	callq	omp_get_wtime
	vmovsd	%xmm0, (%rsp)                   # 8-byte Spill
	cmpl	$1, %r12d
	je	.LBB2_20
# %bb.17:
	cmpl	$2, %r12d
	jne	.LBB2_55
# %bb.18:
	movl	$.Lstr.22, %edi
	callq	puts@PLT
	movl	$8, %edx
	movl	$compare_uint64, %ecx
	movq	%r14, %rdi
	movq	%r15, %rsi
	callq	qsort
	jmp	.LBB2_55
.LBB2_20:
	callq	omp_get_max_threads
	movl	%eax, %ebp
	movl	$.Lstr.23, %edi
	callq	puts@PLT
	movl	$.L.str.9, %edi
	movl	%ebp, %esi
	xorl	%eax, %eax
	callq	printf
	movq	%r14, 16(%rsp)
	movq	%r15, 8(%rsp)
	cmpq	$64, %r15
	ja	.LBB2_78
# %bb.21:
	cmpq	$1, %r15
	je	.LBB2_55
# %bb.22:
	leaq	-8(%rbx), %rax
	leaq	-9(%rbx), %rcx
	movl	%ebx, %edx
	andl	$3, %edx
	cmpq	$3, %rcx
	jae	.LBB2_30
# %bb.23:
	movl	$1, %esi
	xorl	%edi, %edi
.LBB2_24:
	movq	%rdi, %r8
	testq	%rdx, %rdx
	jne	.LBB2_25
.LBB2_28:
	movq	(%r14), %rdx
	movq	(%r14,%r8,8), %rsi
	movq	%rsi, (%r14)
	movq	%rdx, (%r14,%r8,8)
	testq	%rcx, %rcx
	je	.LBB2_29
# %bb.40:
	andq	$-2, %rax
	leaq	8(%r14), %rdx
	leaq	16(%r14), %rsi
	movl	$1, %ecx
	xorl	%edi, %edi
	jmp	.LBB2_41
	.p2align	4
.LBB2_27:                               #   in Loop: Header=BB2_25 Depth=1
	incq	%rsi
	movq	%r8, %rdi
	decq	%rdx
	je	.LBB2_28
.LBB2_25:                               # =>This Inner Loop Header: Depth=1
	movq	(%r14,%rsi,8), %r9
	movq	%rsi, %r8
	cmpq	(%r14,%rdi,8), %r9
	jb	.LBB2_27
# %bb.26:                               #   in Loop: Header=BB2_25 Depth=1
	movq	%rdi, %r8
	jmp	.LBB2_27
	.p2align	4
.LBB2_46:                               #   in Loop: Header=BB2_41 Depth=1
	leaq	(%r14,%rcx,8), %r9
	addq	$8, %r9
.LBB2_49:                               #   in Loop: Header=BB2_41 Depth=1
	movq	%r8, (%r9)
	addq	$2, %rcx
	addq	$2, %rdi
	addq	$16, %rdx
	addq	$16, %rsi
	cmpq	%rax, %rdi
	je	.LBB2_50
.LBB2_41:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB2_44 Depth 2
                                        #     Child Loop BB2_48 Depth 2
	movq	-8(%r14,%rcx,8), %r10
	movq	(%r14,%rcx,8), %r8
	cmpq	%r8, %r10
	jbe	.LBB2_42
# %bb.43:                               #   in Loop: Header=BB2_41 Depth=1
	movq	%rdx, %r9
	.p2align	4
.LBB2_44:                               #   Parent Loop BB2_41 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%r10, (%r9)
	movq	-16(%r9), %r10
	addq	$-8, %r9
	cmpq	%r8, %r10
	ja	.LBB2_44
	jmp	.LBB2_45
	.p2align	4
.LBB2_42:                               #   in Loop: Header=BB2_41 Depth=1
	leaq	(%r14,%rcx,8), %r9
.LBB2_45:                               #   in Loop: Header=BB2_41 Depth=1
	movq	%r8, (%r9)
	movq	(%r14,%rcx,8), %r10
	movq	8(%r14,%rcx,8), %r8
	cmpq	%r8, %r10
	jbe	.LBB2_46
# %bb.47:                               #   in Loop: Header=BB2_41 Depth=1
	movq	%rsi, %r9
	.p2align	4
.LBB2_48:                               #   Parent Loop BB2_41 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%r10, (%r9)
	movq	-16(%r9), %r10
	addq	$-8, %r9
	cmpq	%r8, %r10
	ja	.LBB2_48
	jmp	.LBB2_49
.LBB2_78:
	leaq	16(%rsp), %rcx
	leaq	8(%rsp), %r8
	movl	$.L__unnamed_1, %edi
	movl	$Charlatana_Sort.omp_outlined, %edx
	movl	$2, %esi
	xorl	%eax, %eax
	callq	__kmpc_fork_call@PLT
.LBB2_55:
	callq	omp_get_wtime
	vsubsd	(%rsp), %xmm0, %xmm0            # 8-byte Folded Reload
	vmovsd	%xmm0, (%rsp)                   # 8-byte Spill
	movl	$.L.str.11, %edi
	movb	$1, %al
	callq	printf
	vmovsd	(%rsp), %xmm1                   # 8-byte Reload
                                        # xmm1 = mem[0],zero
	vxorpd	%xmm0, %xmm0, %xmm0
	vucomisd	%xmm0, %xmm1
	jbe	.LBB2_57
# %bb.56:
	vcvtsi2sd	%r15, %xmm9, %xmm0
	vdivsd	%xmm1, %xmm0, %xmm0
	vcvttsd2si	%xmm0, %rax
	movq	%rax, %rcx
	sarq	$63, %rcx
	vsubsd	.LCPI2_0(%rip), %xmm0, %xmm0
	vcvttsd2si	%xmm0, %rsi
	andq	%rcx, %rsi
	orq	%rax, %rsi
	movl	$.L.str.12, %edi
	xorl	%eax, %eax
	callq	printf
	movl	$1, %esi
	cmpq	$2, %r15
	jae	.LBB2_59
	jmp	.LBB2_71
.LBB2_57:
	movl	$.Lstr.24, %edi
	callq	puts@PLT
	movl	$1, %esi
	cmpq	$2, %r15
	jb	.LBB2_71
.LBB2_59:
	leaq	-8(%rbx), %rax
	movl	$1, %edx
	cmpq	$4, %rax
	jb	.LBB2_70
# %bb.60:
	cmpq	$16, %rax
	jae	.LBB2_65
# %bb.61:
	xorl	%ecx, %ecx
	jmp	.LBB2_62
.LBB2_65:
	vpmovsxbq	.LCPI2_2(%rip), %xmm0   # xmm0 = [1,0]
	movq	%rax, %rcx
	andq	$-16, %rcx
	vpxor	%xmm2, %xmm2, %xmm2
	xorl	%edx, %edx
	vpcmpeqd	%ymm1, %ymm1, %ymm1
	vpxor	%xmm3, %xmm3, %xmm3
	vpxor	%xmm4, %xmm4, %xmm4
	.p2align	4
.LBB2_66:                               # =>This Inner Loop Header: Depth=1
	vmovdqu	8(%r14,%rdx,8), %ymm5
	vmovdqu	40(%r14,%rdx,8), %ymm6
	vmovdqu	72(%r14,%rdx,8), %ymm7
	vmovdqu	104(%r14,%rdx,8), %ymm8
	vpcmpeqq	(%r14,%rdx,8), %ymm5, %ymm5
	vpaddq	%ymm5, %ymm0, %ymm0
	vpcmpeqq	32(%r14,%rdx,8), %ymm6, %ymm5
	vpaddq	%ymm5, %ymm2, %ymm2
	vpcmpeqq	64(%r14,%rdx,8), %ymm7, %ymm5
	vpcmpeqq	96(%r14,%rdx,8), %ymm8, %ymm6
	vpaddq	%ymm5, %ymm3, %ymm3
	vpaddq	%ymm6, %ymm4, %ymm4
	vpsubq	%ymm1, %ymm0, %ymm0
	vpsubq	%ymm1, %ymm2, %ymm2
	vpsubq	%ymm1, %ymm3, %ymm3
	vpsubq	%ymm1, %ymm4, %ymm4
	addq	$16, %rdx
	cmpq	%rdx, %rcx
	jne	.LBB2_66
# %bb.67:
	vpaddq	%ymm0, %ymm2, %ymm0
	vpaddq	%ymm3, %ymm4, %ymm1
	vpaddq	%ymm0, %ymm1, %ymm0
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              # xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rsi
	cmpq	%rcx, %rax
	je	.LBB2_71
# %bb.68:
	testb	$12, %al
	je	.LBB2_69
.LBB2_62:
	movq	%rax, %rdi
	andq	$-4, %rdi
	leaq	1(%rdi), %rdx
	vmovq	%rsi, %xmm0
	vpcmpeqd	%ymm1, %ymm1, %ymm1
	.p2align	4
.LBB2_63:                               # =>This Inner Loop Header: Depth=1
	vmovdqu	8(%r14,%rcx,8), %ymm2
	vpcmpeqq	(%r14,%rcx,8), %ymm2, %ymm2
	vpaddq	%ymm2, %ymm0, %ymm0
	vpsubq	%ymm1, %ymm0, %ymm0
	addq	$4, %rcx
	cmpq	%rcx, %rdi
	jne	.LBB2_63
# %bb.64:
	vextracti128	$1, %ymm0, %xmm1
	vpaddq	%xmm1, %xmm0, %xmm0
	vpshufd	$238, %xmm0, %xmm1              # xmm1 = xmm0[2,3,2,3]
	vpaddq	%xmm1, %xmm0, %xmm0
	vmovq	%xmm0, %rsi
	cmpq	%rdi, %rax
	jne	.LBB2_70
	jmp	.LBB2_71
.LBB2_30:
	movq	%rax, %r8
	andq	$-4, %r8
	movl	$1, %esi
	xorl	%edi, %edi
	jmp	.LBB2_31
	.p2align	4
.LBB2_39:                               #   in Loop: Header=BB2_31 Depth=1
	addq	$4, %rsi
	cmpq	%r8, %r10
	je	.LBB2_24
.LBB2_31:                               # =>This Inner Loop Header: Depth=1
	movq	(%r14,%rsi,8), %r10
	movq	%rsi, %r9
	cmpq	(%r14,%rdi,8), %r10
	jae	.LBB2_32
# %bb.33:                               #   in Loop: Header=BB2_31 Depth=1
	movq	8(%r14,%rsi,8), %rdi
	cmpq	(%r14,%r9,8), %rdi
	jb	.LBB2_34
.LBB2_35:                               #   in Loop: Header=BB2_31 Depth=1
	movq	16(%r14,%rsi,8), %rdi
	cmpq	(%r14,%r9,8), %rdi
	jae	.LBB2_37
.LBB2_36:                               #   in Loop: Header=BB2_31 Depth=1
	leaq	2(%rsi), %r9
.LBB2_37:                               #   in Loop: Header=BB2_31 Depth=1
	movq	24(%r14,%rsi,8), %r11
	leaq	3(%rsi), %r10
	movq	%r10, %rdi
	cmpq	(%r14,%r9,8), %r11
	jb	.LBB2_39
# %bb.38:                               #   in Loop: Header=BB2_31 Depth=1
	movq	%r9, %rdi
	jmp	.LBB2_39
	.p2align	4
.LBB2_32:                               #   in Loop: Header=BB2_31 Depth=1
	movq	%rdi, %r9
	movq	8(%r14,%rsi,8), %rdi
	cmpq	(%r14,%r9,8), %rdi
	jae	.LBB2_35
.LBB2_34:                               #   in Loop: Header=BB2_31 Depth=1
	leaq	1(%rsi), %r9
	movq	16(%r14,%rsi,8), %rdi
	cmpq	(%r14,%r9,8), %rdi
	jb	.LBB2_36
	jmp	.LBB2_37
.LBB2_29:
	movl	$1, %ecx
.LBB2_50:
	testb	$1, %bl
	je	.LBB2_55
# %bb.51:
	leaq	(%r14,%rcx,8), %rax
	movq	-8(%r14,%rcx,8), %rdx
	movq	(%r14,%rcx,8), %rcx
	cmpq	%rcx, %rdx
	jbe	.LBB2_54
	.p2align	4
.LBB2_52:                               # =>This Inner Loop Header: Depth=1
	movq	%rdx, (%rax)
	movq	-16(%rax), %rdx
	addq	$-8, %rax
	cmpq	%rcx, %rdx
	ja	.LBB2_52
.LBB2_54:
	movq	%rcx, (%rax)
	jmp	.LBB2_55
.LBB2_69:
	orq	$1, %rcx
	movq	%rcx, %rdx
	.p2align	4
.LBB2_70:                               # =>This Inner Loop Header: Depth=1
	movq	(%r14,%rdx,8), %rax
	xorl	%ecx, %ecx
	cmpq	-8(%r14,%rdx,8), %rax
	setne	%cl
	addq	%rcx, %rsi
	incq	%rdx
	cmpq	%rdx, %r15
	jne	.LBB2_70
.LBB2_71:
	xorl	%ebp, %ebp
	movl	$.L.str.14, %edi
	xorl	%eax, %eax
	vzeroupper
	callq	printf
	movl	$.Lstr.25, %edi
	callq	puts@PLT
	movl	$.L.str.17, %esi
	cmpq	$2, %r15
	jb	.LBB2_76
# %bb.72:
	addq	$-8, %rbx
	xorl	%eax, %eax
	.p2align	4
.LBB2_74:                               # =>This Inner Loop Header: Depth=1
	movq	(%r14,%rax,8), %rcx
	cmpq	8(%r14,%rax,8), %rcx
	ja	.LBB2_75
# %bb.73:                               #   in Loop: Header=BB2_74 Depth=1
	incq	%rax
	cmpq	%rax, %rbx
	jne	.LBB2_74
	jmp	.LBB2_76
.LBB2_75:
	movl	$.L.str.18, %esi
.LBB2_76:
	movl	$.L.str.16, %edi
	xorl	%eax, %eax
	callq	printf
	movq	%r14, %rdi
	callq	free
.LBB2_77:
	movl	%ebp, %eax
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	main, .Lfunc_end2-main
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function Charlatana_Sort.omp_outlined
	.type	Charlatana_Sort.omp_outlined,@function
Charlatana_Sort.omp_outlined:           # @Charlatana_Sort.omp_outlined
	.cfi_startproc
# %bb.0:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rcx, %r14
	movq	%rdx, %r15
	movl	(%rdi), %ebx
	movl	$.L__unnamed_1, %edi
	movl	%ebx, %esi
	callq	__kmpc_single@PLT
	testl	%eax, %eax
	je	.LBB3_2
# %bb.1:
	movq	(%r15), %rdi
	movq	(%r14), %rdx
	decq	%rdx
	xorl	%esi, %esi
	callq	charlatana_v28_recursive
	movl	$.L__unnamed_1, %edi
	movl	%ebx, %esi
	callq	__kmpc_end_single@PLT
.LBB3_2:
	movl	$.L__unnamed_2, %edi
	movl	%ebx, %esi
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	__kmpc_barrier@PLT              # TAILCALL
.Lfunc_end3:
	.size	Charlatana_Sort.omp_outlined, .Lfunc_end3-Charlatana_Sort.omp_outlined
	.cfi_endproc
                                        # -- End function
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0                          # -- Begin function charlatana_v28_recursive
.LCPI4_0:
	.quad	-9223372036854775808            # 0x8000000000000000
	.text
	.p2align	4
	.type	charlatana_v28_recursive,@function
charlatana_v28_recursive:               # @charlatana_v28_recursive
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4200, %rsp                     # imm = 0x1068
	.cfi_def_cfa_offset 4256
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r14
	movq	%rsi, %rbx
	movq	%rdi, %r13
	movl	$.L__unnamed_1, %edi
	callq	__kmpc_global_thread_num@PLT
	movl	%eax, 36(%rsp)                  # 4-byte Spill
	cmpq	%r14, %rbx
	jge	.LBB4_245
# %bb.1:
	movq	%r14, %rdx
	movq	%rbx, %r11
	leaq	8(%r13), %rax
	movq	%rax, 40(%rsp)                  # 8-byte Spill
	leaq	16(%r13), %rax
	movq	%rax, 56(%rsp)                  # 8-byte Spill
	vpbroadcastq	.LCPI4_0(%rip), %ymm6   # ymm6 = [9223372036854775808,9223372036854775808,9223372036854775808,9223372036854775808]
	vmovdqu	%ymm6, 64(%rsp)                 # 32-byte Spill
	movq	%r13, (%rsp)                    # 8-byte Spill
	.p2align	4
.LBB4_6:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB4_12 Depth 2
                                        #       Child Loop BB4_45 Depth 3
                                        #       Child Loop BB4_49 Depth 3
                                        #       Child Loop BB4_53 Depth 3
                                        #       Child Loop BB4_56 Depth 3
                                        #       Child Loop BB4_38 Depth 3
                                        #       Child Loop BB4_42 Depth 3
                                        #       Child Loop BB4_26 Depth 3
                                        #       Child Loop BB4_29 Depth 3
                                        #     Child Loop BB4_58 Depth 2
                                        #     Child Loop BB4_63 Depth 2
                                        #     Child Loop BB4_66 Depth 2
                                        #     Child Loop BB4_68 Depth 2
                                        #     Child Loop BB4_95 Depth 2
                                        #     Child Loop BB4_99 Depth 2
                                        #     Child Loop BB4_76 Depth 2
                                        #     Child Loop BB4_79 Depth 2
                                        #     Child Loop BB4_88 Depth 2
                                        #     Child Loop BB4_92 Depth 2
                                        #     Child Loop BB4_102 Depth 2
                                        #     Child Loop BB4_141 Depth 2
                                        #     Child Loop BB4_123 Depth 2
                                        #     Child Loop BB4_152 Depth 2
                                        #       Child Loop BB4_154 Depth 3
                                        #       Child Loop BB4_158 Depth 3
                                        #     Child Loop BB4_120 Depth 2
                                        #     Child Loop BB4_131 Depth 2
                                        #     Child Loop BB4_162 Depth 2
                                        #     Child Loop BB4_168 Depth 2
                                        #       Child Loop BB4_170 Depth 3
                                        #       Child Loop BB4_174 Depth 3
                                        #     Child Loop BB4_178 Depth 2
	movq	%rdx, %rax
	subq	%r11, %rax
	leaq	3(%rax), %rcx
	testq	%rax, %rax
	cmovnsq	%rax, %rcx
	sarq	$2, %rcx
	leaq	(,%r11,8), %rbp
	addq	%r13, %rbp
	movq	(%rbp,%rcx,8), %r8
	movq	%rax, %rsi
	shrq	$63, %rsi
	addq	%rax, %rsi
	andq	$-2, %rsi
	movq	(%rbp,%rsi,4), %rax
	movq	%rdx, %rsi
	subq	%rcx, %rsi
	cmpq	%rax, %r8
	movq	%rax, %rcx
	cmovbq	%r8, %rcx
	movq	%rax, %rdi
	cmovaq	%r8, %rdi
	movq	(%r13,%rsi,8), %rsi
	cmpq	%rsi, %rcx
	cmovaeq	%rsi, %rcx
	cmpq	%rsi, %rdi
	cmovbeq	%rsi, %rdi
	xorq	%r8, %rcx
	xorq	%rax, %rcx
	xorq	%rdi, %rcx
	xorq	%rsi, %rcx
	vmovq	%rcx, %xmm0
	vpbroadcastq	%xmm0, %ymm0
	movq	%rdx, 16(%rsp)                  # 8-byte Spill
	movq	40(%rsp), %rax                  # 8-byte Reload
	leaq	(%rax,%rdx,8), %rdi
	movq	%rdi, %rax
	subq	%rbp, %rax
	cmpq	$25, %rax
	movq	%r11, 48(%rsp)                  # 8-byte Spill
	jl	.LBB4_8
# %bb.7:                                #   in Loop: Header=BB4_6 Depth=1
	xorl	%r9d, %r9d
	vpxor	%ymm6, %ymm0, %ymm1
	movq	%rbp, %r8
	movq	%rbp, %rsi
	movq	%rdi, %rax
	xorl	%edx, %edx
	jmp	.LBB4_12
	.p2align	4
.LBB4_8:                                #   in Loop: Header=BB4_6 Depth=1
	xorl	%edx, %edx
	xorl	%r9d, %r9d
	movq	%rdi, %rax
	movq	%rbp, %rsi
	movq	%rbp, %r8
	jmp	.LBB4_58
.LBB4_9:                                #   in Loop: Header=BB4_12 Depth=2
	xorl	%edx, %edx
	.p2align	4
.LBB4_10:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%r10, %rax
.LBB4_11:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%rdi, %r10
	subq	%r8, %r10
	cmpq	$24, %r10
	jle	.LBB4_58
.LBB4_12:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB4_45 Depth 3
                                        #       Child Loop BB4_49 Depth 3
                                        #       Child Loop BB4_53 Depth 3
                                        #       Child Loop BB4_56 Depth 3
                                        #       Child Loop BB4_38 Depth 3
                                        #       Child Loop BB4_42 Depth 3
                                        #       Child Loop BB4_26 Depth 3
                                        #       Child Loop BB4_29 Depth 3
	cmpl	%edx, %r9d
	jle	.LBB4_16
# %bb.13:                               #   in Loop: Header=BB4_12 Depth=2
	vmovdqu	(%r8), %ymm2
	vpxor	%ymm6, %ymm2, %ymm3
	vpcmpgtq	%ymm3, %ymm1, %ymm4
	vmovmskpd	%ymm4, %r10d
	popcntl	%r10d, %r11d
	shll	$5, %r10d
	vmovdqa	QWORD_PACK_TABLE(%r10), %ymm4
	vpermd	%ymm2, %ymm4, %ymm4
	movl	%r11d, %r10d
	shll	$5, %r10d
	vmovdqa	MASK_STORE_TABLE(%r10), %ymm5
	vpmaskmovq	%ymm4, %ymm5, (%rsi)
	vpcmpgtq	%ymm1, %ymm3, %ymm3
	vmovmskpd	%ymm3, %r10d
	popcntl	%r10d, %ebx
	shll	$5, %r10d
	vmovdqa	QWORD_PACK_TABLE(%r10), %ymm3
	vpermd	%ymm2, %ymm3, %ymm2
	movl	%ebx, %r10d
	shll	$5, %r10d
	vmovdqa	MASK_STORE_TABLE(%r10), %ymm3
	movslq	%edx, %r10
	vpmaskmovq	%ymm2, %ymm3, 2144(%rsp,%r10,8)
	addl	%ebx, %edx
	addq	$32, %r8
	leaq	(%rsi,%r11,8), %r10
	testl	%r9d, %r9d
	jle	.LBB4_20
# %bb.14:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%r8, %rbx
	subq	%r10, %rbx
	shrq	$3, %rbx
	cmpl	%ebx, %r9d
	jle	.LBB4_21
.LBB4_20:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%r10, %rsi
	jmp	.LBB4_11
	.p2align	4
.LBB4_16:                               #   in Loop: Header=BB4_12 Depth=2
	vmovdqu	-32(%rdi), %ymm2
	vpxor	%ymm6, %ymm2, %ymm3
	vpcmpgtq	%ymm1, %ymm3, %ymm4
	vmovmskpd	%ymm4, %r10d
	popcntl	%r10d, %r11d
	shll	$5, %r10d
	vmovdqa	QWORD_PACK_TABLE(%r10), %ymm4
	vpermd	%ymm2, %ymm4, %ymm4
	movl	%r11d, %r10d
	shll	$5, %r10d
	vmovdqa	MASK_STORE_TABLE(%r10), %ymm5
	leal	(,%r11,8), %ebx
	movq	%rax, %r10
	subq	%rbx, %r10
	vpmaskmovq	%ymm4, %ymm5, (%r10)
	vpcmpgtq	%ymm3, %ymm1, %ymm3
	vmovmskpd	%ymm3, %ebx
	popcntl	%ebx, %r14d
	shll	$5, %ebx
	vmovdqa	QWORD_PACK_TABLE(%rbx), %ymm3
	vpermd	%ymm2, %ymm3, %ymm2
	movl	%r14d, %ebx
	shll	$5, %ebx
	vmovdqa	MASK_STORE_TABLE(%rbx), %ymm3
	movslq	%r9d, %rbx
	vpmaskmovq	%ymm2, %ymm3, 96(%rsp,%rbx,8)
	addl	%r14d, %r9d
	addq	$-32, %rdi
	testl	%edx, %edx
	jle	.LBB4_10
# %bb.17:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%r10, %rbx
	subq	%rdi, %rbx
	shrq	$3, %rbx
	cmpl	%ebx, %edx
	jg	.LBB4_10
# %bb.18:                               #   in Loop: Header=BB4_12 Depth=2
	movl	%edx, %ebx
	leaq	(,%rbx,8), %r15
	subq	%r15, %r10
	cmpl	$4, %edx
	jb	.LBB4_19
# %bb.31:                               #   in Loop: Header=BB4_12 Depth=2
	leaq	(%r11,%rbx), %r14
	leaq	(%rsp,%r14,8), %r14
	addq	$2144, %r14                     # imm = 0x860
	movq	%rax, %r12
	subq	%r14, %r12
	cmpq	$128, %r12
	jae	.LBB4_35
.LBB4_19:                               #   in Loop: Header=BB4_12 Depth=2
	xorl	%r14d, %r14d
.LBB4_51:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%rbx, %rdx
	movq	%r14, %r15
	andq	$3, %rdx
	je	.LBB4_54
# %bb.52:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%r14, %r15
	.p2align	4
.LBB4_53:                               #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_12 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	2144(%rsp,%r15,8), %r12
	movq	%r12, (%r10,%r15,8)
	incq	%r15
	decq	%rdx
	jne	.LBB4_53
.LBB4_54:                               #   in Loop: Header=BB4_12 Depth=2
	subq	%rbx, %r14
	xorl	%edx, %edx
	cmpq	$-4, %r14
	ja	.LBB4_10
# %bb.55:                               #   in Loop: Header=BB4_12 Depth=2
	shll	$3, %r11d
	leaq	(%r11,%rbx,8), %r11
	subq	%r11, %rax
	addq	$24, %rax
	.p2align	4
.LBB4_56:                               #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_12 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	2144(%rsp,%r15,8), %r11
	movq	%r11, -24(%rax,%r15,8)
	movq	2152(%rsp,%r15,8), %r11
	movq	%r11, -16(%rax,%r15,8)
	movq	2160(%rsp,%r15,8), %r11
	movq	%r11, -8(%rax,%r15,8)
	movq	2168(%rsp,%r15,8), %r11
	movq	%r11, (%rax,%r15,8)
	addq	$4, %r15
	cmpq	%r15, %rbx
	jne	.LBB4_56
	jmp	.LBB4_10
.LBB4_21:                               #   in Loop: Header=BB4_12 Depth=2
	movl	%r9d, %ebx
	cmpl	$3, %r9d
	jbe	.LBB4_23
# %bb.22:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%rsi, %r15
	leaq	96(%rsp), %r14
	subq	%r14, %r15
	leal	(,%r11,8), %r14d
	addq	%r14, %r15
	cmpq	$128, %r15
	jae	.LBB4_33
.LBB4_23:                               #   in Loop: Header=BB4_12 Depth=2
	xorl	%r9d, %r9d
.LBB4_24:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%rbx, %r15
	movq	%r9, %r14
	andq	$3, %r15
	je	.LBB4_27
# %bb.25:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%r9, %r14
	.p2align	4
.LBB4_26:                               #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_12 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	96(%rsp,%r14,8), %r12
	movq	%r12, (%r10,%r14,8)
	incq	%r14
	decq	%r15
	jne	.LBB4_26
.LBB4_27:                               #   in Loop: Header=BB4_12 Depth=2
	subq	%rbx, %r9
	cmpq	$-4, %r9
	ja	.LBB4_30
# %bb.28:                               #   in Loop: Header=BB4_12 Depth=2
	leaq	(%rsi,%r11,8), %rsi
	addq	$24, %rsi
	.p2align	4
.LBB4_29:                               #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_12 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	96(%rsp,%r14,8), %r9
	movq	%r9, -24(%rsi,%r14,8)
	movq	104(%rsp,%r14,8), %r9
	movq	%r9, -16(%rsi,%r14,8)
	movq	112(%rsp,%r14,8), %r9
	movq	%r9, -8(%rsi,%r14,8)
	movq	120(%rsp,%r14,8), %r9
	movq	%r9, (%rsi,%r14,8)
	addq	$4, %r14
	cmpq	%r14, %rbx
	jne	.LBB4_29
.LBB4_30:                               #   in Loop: Header=BB4_12 Depth=2
	leaq	(%r10,%rbx,8), %rsi
	xorl	%r9d, %r9d
	jmp	.LBB4_11
.LBB4_35:                               #   in Loop: Header=BB4_12 Depth=2
	cmpl	$16, %edx
	jae	.LBB4_44
# %bb.36:                               #   in Loop: Header=BB4_12 Depth=2
	xorl	%r14d, %r14d
	jmp	.LBB4_48
.LBB4_33:                               #   in Loop: Header=BB4_12 Depth=2
	cmpl	$16, %r9d
	jae	.LBB4_37
# %bb.34:                               #   in Loop: Header=BB4_12 Depth=2
	xorl	%r9d, %r9d
	jmp	.LBB4_41
.LBB4_44:                               #   in Loop: Header=BB4_12 Depth=2
	movl	%ebx, %r14d
	andl	$2147483632, %r14d              # imm = 0x7FFFFFF0
	leaq	(%r15,%r11,8), %r15
	movq	%rax, %rdx
	subq	%r15, %rdx
	addq	$96, %rdx
	xorl	%r15d, %r15d
	.p2align	4
.LBB4_45:                               #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_12 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	vmovdqu	2144(%rsp,%r15,8), %ymm2
	vmovdqu	2176(%rsp,%r15,8), %ymm3
	vmovdqu	2208(%rsp,%r15,8), %ymm4
	vmovdqu	2240(%rsp,%r15,8), %ymm5
	vmovdqu	%ymm2, -96(%rdx,%r15,8)
	vmovdqu	%ymm3, -64(%rdx,%r15,8)
	vmovdqu	%ymm4, -32(%rdx,%r15,8)
	vmovdqu	%ymm5, (%rdx,%r15,8)
	addq	$16, %r15
	cmpq	%r15, %r14
	jne	.LBB4_45
# %bb.46:                               #   in Loop: Header=BB4_12 Depth=2
	cmpl	%ebx, %r14d
	je	.LBB4_9
# %bb.47:                               #   in Loop: Header=BB4_12 Depth=2
	testb	$12, %bl
	je	.LBB4_51
.LBB4_48:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%r14, %rdx
	movl	%ebx, %r14d
	andl	$2147483644, %r14d              # imm = 0x7FFFFFFC
	.p2align	4
.LBB4_49:                               #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_12 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	vmovdqu	2144(%rsp,%rdx,8), %ymm2
	vmovdqu	%ymm2, (%r10,%rdx,8)
	addq	$4, %rdx
	cmpq	%rdx, %r14
	jne	.LBB4_49
# %bb.50:                               #   in Loop: Header=BB4_12 Depth=2
	cmpl	%ebx, %r14d
	je	.LBB4_9
	jmp	.LBB4_51
.LBB4_37:                               #   in Loop: Header=BB4_12 Depth=2
	movl	%ebx, %r9d
	andl	$2147483632, %r9d               # imm = 0x7FFFFFF0
	addq	%rsi, %r14
	addq	$96, %r14
	xorl	%r15d, %r15d
	.p2align	4
.LBB4_38:                               #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_12 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	vmovdqu	96(%rsp,%r15,8), %ymm2
	vmovdqu	128(%rsp,%r15,8), %ymm3
	vmovdqu	160(%rsp,%r15,8), %ymm4
	vmovdqu	192(%rsp,%r15,8), %ymm5
	vmovdqu	%ymm2, -96(%r14,%r15,8)
	vmovdqu	%ymm3, -64(%r14,%r15,8)
	vmovdqu	%ymm4, -32(%r14,%r15,8)
	vmovdqu	%ymm5, (%r14,%r15,8)
	addq	$16, %r15
	cmpq	%r15, %r9
	jne	.LBB4_38
# %bb.39:                               #   in Loop: Header=BB4_12 Depth=2
	cmpl	%ebx, %r9d
	je	.LBB4_30
# %bb.40:                               #   in Loop: Header=BB4_12 Depth=2
	testb	$12, %bl
	je	.LBB4_24
.LBB4_41:                               #   in Loop: Header=BB4_12 Depth=2
	movq	%r9, %r14
	movl	%ebx, %r9d
	andl	$2147483644, %r9d               # imm = 0x7FFFFFFC
	.p2align	4
.LBB4_42:                               #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_12 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	vmovdqu	96(%rsp,%r14,8), %ymm2
	vmovdqu	%ymm2, (%r10,%r14,8)
	addq	$4, %r14
	cmpq	%r14, %r9
	jne	.LBB4_42
# %bb.43:                               #   in Loop: Header=BB4_12 Depth=2
	cmpl	%ebx, %r9d
	jne	.LBB4_24
	jmp	.LBB4_30
	.p2align	4
.LBB4_57:                               #   in Loop: Header=BB4_58 Depth=2
	movq	(%r8), %r10
	xorl	%r11d, %r11d
	xorl	%ebx, %ebx
	cmpq	%rcx, %r10
	seta	%bl
	setb	%r11b
	movq	%r10, (%rsi)
	leaq	(%rsi,%r11,8), %rsi
	movslq	%edx, %rdx
	movq	%r10, 2144(%rsp,%rdx,8)
	addl	%ebx, %edx
	addq	$8, %r8
.LBB4_58:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	cmpq	%rdi, %r8
	jb	.LBB4_57
# %bb.59:                               #   in Loop: Header=BB4_6 Depth=1
	testl	%r9d, %r9d
	jle	.LBB4_69
# %bb.60:                               #   in Loop: Header=BB4_6 Depth=1
	movl	%r9d, %edi
	cmpl	$16, %r9d
	movq	48(%rsp), %r11                  # 8-byte Reload
	jb	.LBB4_84
# %bb.61:                               #   in Loop: Header=BB4_6 Depth=1
	movq	%rsi, %r8
	leaq	96(%rsp), %r9
	subq	%r9, %r8
	cmpq	$128, %r8
	jb	.LBB4_84
# %bb.62:                               #   in Loop: Header=BB4_6 Depth=1
	movl	%edi, %r8d
	andl	$2147483632, %r8d               # imm = 0x7FFFFFF0
	leaq	(%rsi,%r8,8), %rbx
	movl	%edi, %r9d
	shrl	$4, %r9d
	andl	$134217727, %r9d                # imm = 0x7FFFFFF
	shlq	$7, %r9
	xorl	%r10d, %r10d
	.p2align	4
.LBB4_63:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	vmovdqu	96(%rsp,%r10), %ymm1
	vmovdqu	128(%rsp,%r10), %ymm2
	vmovdqu	160(%rsp,%r10), %ymm3
	vmovdqu	192(%rsp,%r10), %ymm4
	vmovdqu	%ymm1, (%rsi,%r10)
	vmovdqu	%ymm2, 32(%rsi,%r10)
	vmovdqu	%ymm3, 64(%rsi,%r10)
	vmovdqu	%ymm4, 96(%rsi,%r10)
	subq	$-128, %r10
	cmpq	%r10, %r9
	jne	.LBB4_63
# %bb.64:                               #   in Loop: Header=BB4_6 Depth=1
	cmpl	%edi, %r8d
	je	.LBB4_70
# %bb.65:                               #   in Loop: Header=BB4_6 Depth=1
	movq	%rdi, %r9
	movq	%r8, %rsi
	andq	$7, %r9
	je	.LBB4_67
	.p2align	4
.LBB4_66:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	96(%rsp,%rsi,8), %r10
	movq	%r10, (%rbx)
	addq	$8, %rbx
	incq	%rsi
	decq	%r9
	jne	.LBB4_66
.LBB4_67:                               #   in Loop: Header=BB4_6 Depth=1
	subq	%rdi, %r8
	cmpq	$-8, %r8
	ja	.LBB4_70
	.p2align	4
.LBB4_68:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	96(%rsp,%rsi,8), %r8
	movq	%r8, (%rbx)
	movq	104(%rsp,%rsi,8), %r8
	movq	%r8, 8(%rbx)
	movq	112(%rsp,%rsi,8), %r8
	movq	%r8, 16(%rbx)
	movq	120(%rsp,%rsi,8), %r8
	movq	%r8, 24(%rbx)
	movq	128(%rsp,%rsi,8), %r8
	movq	%r8, 32(%rbx)
	movq	136(%rsp,%rsi,8), %r8
	movq	%r8, 40(%rbx)
	movq	144(%rsp,%rsi,8), %r8
	movq	%r8, 48(%rbx)
	movq	152(%rsp,%rsi,8), %r8
	movq	%r8, 56(%rbx)
	addq	$64, %rbx
	addq	$8, %rsi
	cmpq	%rsi, %rdi
	jne	.LBB4_68
	jmp	.LBB4_70
	.p2align	4
.LBB4_69:                               #   in Loop: Header=BB4_6 Depth=1
	movq	%rsi, %rbx
	movq	48(%rsp), %r11                  # 8-byte Reload
.LBB4_70:                               #   in Loop: Header=BB4_6 Depth=1
	movslq	%edx, %r8
	leaq	(,%r8,8), %rsi
	movq	%rax, %r15
	subq	%rsi, %r15
	testl	%r8d, %r8d
	jle	.LBB4_80
# %bb.71:                               #   in Loop: Header=BB4_6 Depth=1
	movl	%edx, %edi
	cmpl	$3, %edx
	jbe	.LBB4_73
# %bb.72:                               #   in Loop: Header=BB4_6 Depth=1
	leaq	(%rsp,%r8,8), %r8
	addq	$2144, %r8                      # imm = 0x860
	movq	%rax, %r9
	subq	%r8, %r9
	cmpq	$128, %r9
	jae	.LBB4_85
.LBB4_73:                               #   in Loop: Header=BB4_6 Depth=1
	xorl	%edx, %edx
.LBB4_74:                               #   in Loop: Header=BB4_6 Depth=1
	movq	%rdi, %r9
	movq	%rdx, %r8
	andq	$3, %r9
	je	.LBB4_77
# %bb.75:                               #   in Loop: Header=BB4_6 Depth=1
	movq	%rdx, %r8
	.p2align	4
.LBB4_76:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	2144(%rsp,%r8,8), %r10
	movq	%r10, (%r15,%r8,8)
	incq	%r8
	decq	%r9
	jne	.LBB4_76
.LBB4_77:                               #   in Loop: Header=BB4_6 Depth=1
	subq	%rdi, %rdx
	cmpq	$-4, %rdx
	ja	.LBB4_80
# %bb.78:                               #   in Loop: Header=BB4_6 Depth=1
	leaq	24(%r15), %rdx
	.p2align	4
.LBB4_79:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	2144(%rsp,%r8,8), %r9
	movq	%r9, -24(%rdx,%r8,8)
	movq	2152(%rsp,%r8,8), %r9
	movq	%r9, -16(%rdx,%r8,8)
	movq	2160(%rsp,%r8,8), %r9
	movq	%r9, -8(%rdx,%r8,8)
	movq	2168(%rsp,%r8,8), %r9
	movq	%r9, (%rdx,%r8,8)
	addq	$4, %r8
	cmpq	%r8, %rdi
	jne	.LBB4_79
.LBB4_80:                               #   in Loop: Header=BB4_6 Depth=1
	cmpq	%r15, %rbx
	movq	16(%rsp), %rdx                  # 8-byte Reload
	jae	.LBB4_103
# %bb.81:                               #   in Loop: Header=BB4_6 Depth=1
	leaq	8(%rbx), %r8
	cmpq	%r8, %r15
	cmovaq	%r15, %r8
	movq	%rbx, %rdi
	notq	%rdi
	addq	%r8, %rdi
	movq	%rbx, %r8
	cmpq	$23, %rdi
	jbe	.LBB4_102
# %bb.82:                               #   in Loop: Header=BB4_6 Depth=1
	movq	%rdi, %r10
	shrq	$3, %r10
	incq	%r10
	cmpq	$120, %rdi
	jae	.LBB4_87
# %bb.83:                               #   in Loop: Header=BB4_6 Depth=1
	xorl	%edi, %edi
	jmp	.LBB4_91
	.p2align	4
.LBB4_84:                               #   in Loop: Header=BB4_6 Depth=1
	xorl	%r8d, %r8d
	movq	%rsi, %rbx
	movq	%rdi, %r9
	movq	%r8, %rsi
	andq	$7, %r9
	jne	.LBB4_66
	jmp	.LBB4_67
.LBB4_85:                               #   in Loop: Header=BB4_6 Depth=1
	cmpl	$16, %edx
	jae	.LBB4_94
# %bb.86:                               #   in Loop: Header=BB4_6 Depth=1
	xorl	%edx, %edx
	jmp	.LBB4_98
.LBB4_87:                               #   in Loop: Header=BB4_6 Depth=1
	movq	%r10, %rdi
	movabsq	$4611686018427387888, %r8       # imm = 0x3FFFFFFFFFFFFFF0
	andq	%r8, %rdi
	xorl	%r8d, %r8d
	.p2align	4
.LBB4_88:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	vmovdqu	%ymm0, (%rbx,%r8,8)
	vmovdqu	%ymm0, 32(%rbx,%r8,8)
	vmovdqu	%ymm0, 64(%rbx,%r8,8)
	vmovdqu	%ymm0, 96(%rbx,%r8,8)
	addq	$16, %r8
	cmpq	%r8, %rdi
	jne	.LBB4_88
# %bb.89:                               #   in Loop: Header=BB4_6 Depth=1
	cmpq	%rdi, %r10
	je	.LBB4_103
# %bb.90:                               #   in Loop: Header=BB4_6 Depth=1
	testb	$12, %r10b
	je	.LBB4_101
.LBB4_91:                               #   in Loop: Header=BB4_6 Depth=1
	movabsq	$4611686018427387888, %rdx      # imm = 0x3FFFFFFFFFFFFFF0
	leaq	12(%rdx), %r9
	andq	%r10, %r9
	leaq	(%rbx,%r9,8), %r8
	.p2align	4
.LBB4_92:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	vmovdqu	%ymm0, (%rbx,%rdi,8)
	addq	$4, %rdi
	cmpq	%rdi, %r9
	jne	.LBB4_92
# %bb.93:                               #   in Loop: Header=BB4_6 Depth=1
	cmpq	%r9, %r10
	movq	16(%rsp), %rdx                  # 8-byte Reload
	jne	.LBB4_102
	jmp	.LBB4_103
.LBB4_94:                               #   in Loop: Header=BB4_6 Depth=1
	movl	%edi, %edx
	andl	$2147483632, %edx               # imm = 0x7FFFFFF0
	leaq	96(%r15), %r8
	movl	%edi, %r9d
	shrl	$4, %r9d
	andl	$134217727, %r9d                # imm = 0x7FFFFFF
	shlq	$7, %r9
	xorl	%r10d, %r10d
	.p2align	4
.LBB4_95:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	vmovdqu	2144(%rsp,%r10), %ymm1
	vmovdqu	2176(%rsp,%r10), %ymm2
	vmovdqu	2208(%rsp,%r10), %ymm3
	vmovdqu	2240(%rsp,%r10), %ymm4
	vmovdqu	%ymm1, -96(%r8,%r10)
	vmovdqu	%ymm2, -64(%r8,%r10)
	vmovdqu	%ymm3, -32(%r8,%r10)
	vmovdqu	%ymm4, (%r8,%r10)
	subq	$-128, %r10
	cmpq	%r10, %r9
	jne	.LBB4_95
# %bb.96:                               #   in Loop: Header=BB4_6 Depth=1
	cmpl	%edi, %edx
	je	.LBB4_80
# %bb.97:                               #   in Loop: Header=BB4_6 Depth=1
	testb	$12, %dil
	je	.LBB4_74
.LBB4_98:                               #   in Loop: Header=BB4_6 Depth=1
	movq	%rdx, %r8
	movl	%edi, %edx
	andl	$2147483644, %edx               # imm = 0x7FFFFFFC
	.p2align	4
.LBB4_99:                               #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	vmovdqu	2144(%rsp,%r8,8), %ymm1
	vmovdqu	%ymm1, (%r15,%r8,8)
	addq	$4, %r8
	cmpq	%r8, %rdx
	jne	.LBB4_99
# %bb.100:                              #   in Loop: Header=BB4_6 Depth=1
	cmpl	%edi, %edx
	jne	.LBB4_74
	jmp	.LBB4_80
.LBB4_101:                              #   in Loop: Header=BB4_6 Depth=1
	leaq	(%rbx,%rdi,8), %r8
	.p2align	4
.LBB4_102:                              #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%rcx, (%r8)
	addq	$8, %r8
	cmpq	%r15, %r8
	jb	.LBB4_102
.LBB4_103:                              #   in Loop: Header=BB4_6 Depth=1
	subq	%r13, %rbx
	sarq	$3, %rbx
	leaq	-1(%rbx), %r8
	movq	%r15, %r14
	subq	%r13, %r14
	movq	%r14, %r12
	sarq	$3, %r12
	movq	%r8, %r9
	subq	%r11, %r9
	movq	%rdx, %r13
	subq	%r12, %r13
	cmpq	%r13, %r9
	jge	.LBB4_107
# %bb.104:                              #   in Loop: Header=BB4_6 Depth=1
	cmpq	$64, %r13
	jl	.LBB4_110
# %bb.105:                              #   in Loop: Header=BB4_6 Depth=1
	movq	%r8, 24(%rsp)                   # 8-byte Spill
	movq	%r9, 8(%rsp)                    # 8-byte Spill
	movq	%r11, %r14
	cmpq	$100000, %r13                   # imm = 0x186A0
	jb	.LBB4_125
# %bb.106:                              #   in Loop: Header=BB4_6 Depth=1
	movl	$.L__unnamed_1, %edi
	movl	$64, %ecx
	movq	%rdx, %r13
	movl	$.omp_task_entry., %r9d
	movl	36(%rsp), %r15d                 # 4-byte Reload
	movl	%r15d, %esi
	movl	$1, %edx
	xorl	%r8d, %r8d
	vzeroupper
	callq	__kmpc_omp_task_alloc@PLT
	movq	(%rsp), %rcx                    # 8-byte Reload
	movq	%rcx, 40(%rax)
	movq	%r12, 48(%rax)
	movq	%r13, 56(%rax)
	movl	$.L__unnamed_1, %edi
	movl	%r15d, %esi
	movq	%rax, %rdx
	callq	__kmpc_omp_task@PLT
	jmp	.LBB4_126
	.p2align	4
.LBB4_107:                              #   in Loop: Header=BB4_6 Depth=1
	cmpq	$64, %r9
	jl	.LBB4_113
# %bb.108:                              #   in Loop: Header=BB4_6 Depth=1
	cmpq	$100000, %r9                    # imm = 0x186A0
	jb	.LBB4_2
# %bb.109:                              #   in Loop: Header=BB4_6 Depth=1
	movl	$.L__unnamed_1, %edi
	movl	$64, %ecx
	movl	$.omp_task_entry..21, %r9d
	movl	36(%rsp), %ebp                  # 4-byte Reload
	movl	%ebp, %esi
	movl	$1, %edx
	movq	%r8, 24(%rsp)                   # 8-byte Spill
	xorl	%r8d, %r8d
	movq	%r11, %rbx
	vzeroupper
	callq	__kmpc_omp_task_alloc@PLT
	movq	(%rsp), %rcx                    # 8-byte Reload
	movq	%rcx, 40(%rax)
	movq	%rbx, 48(%rax)
	movq	24(%rsp), %rcx                  # 8-byte Reload
	movq	%rcx, 56(%rax)
	movl	$.L__unnamed_1, %edi
	movl	%ebp, %esi
	movq	%rax, %rdx
	callq	__kmpc_omp_task@PLT
	jmp	.LBB4_3
	.p2align	4
.LBB4_110:                              #   in Loop: Header=BB4_6 Depth=1
	cmpq	%r12, %rdx
	jle	.LBB4_127
# %bb.111:                              #   in Loop: Header=BB4_6 Depth=1
	movq	%r8, 24(%rsp)                   # 8-byte Spill
	addq	(%rsp), %r14                    # 8-byte Folded Reload
	notq	%r12
	addq	%r12, %rdx
	cmpq	$3, %rdx
	movq	%r9, 8(%rsp)                    # 8-byte Spill
	jae	.LBB4_129
# %bb.112:                              #   in Loop: Header=BB4_6 Depth=1
	movl	$1, %ecx
	xorl	%r12d, %r12d
	movl	%r13d, %edi
	andl	$3, %edi
	jne	.LBB4_160
	jmp	.LBB4_164
	.p2align	4
.LBB4_113:                              #   in Loop: Header=BB4_6 Depth=1
	cmpq	%r11, %r8
	jle	.LBB4_4
# %bb.114:                              #   in Loop: Header=BB4_6 Depth=1
	addq	$-2, %rbx
	movq	%rbx, %rax
	subq	%r11, %rax
	cmpq	$3, %rax
	jae	.LBB4_139
# %bb.115:                              #   in Loop: Header=BB4_6 Depth=1
	movl	$1, %eax
	xorl	%ecx, %ecx
.LBB4_116:                              #   in Loop: Header=BB4_6 Depth=1
	movl	%r9d, %edx
	movq	%rcx, %rsi
	andl	$3, %edx
	jne	.LBB4_123
.LBB4_117:                              #   in Loop: Header=BB4_6 Depth=1
	movq	%r9, 8(%rsp)                    # 8-byte Spill
	movq	(%rbp), %rax
	movq	(%rbp,%rsi,8), %rcx
	movq	%rcx, (%rbp)
	movq	%rax, (%rbp,%rsi,8)
	movl	$1, %eax
	cmpq	%r11, %rbx
	jne	.LBB4_149
.LBB4_118:                              #   in Loop: Header=BB4_6 Depth=1
	testb	$1, 8(%rsp)                     # 1-byte Folded Reload
	movq	16(%rsp), %rdx                  # 8-byte Reload
	je	.LBB4_4
# %bb.119:                              #   in Loop: Header=BB4_6 Depth=1
	leaq	(,%rax,8), %rcx
	addq	%rbp, %rcx
	movq	-8(%rbp,%rax,8), %rsi
	movq	(%rbp,%rax,8), %rax
	cmpq	%rax, %rsi
	jbe	.LBB4_121
	.p2align	4
.LBB4_120:                              #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%rsi, (%rcx)
	movq	-16(%rcx), %rsi
	addq	$-8, %rcx
	cmpq	%rax, %rsi
	ja	.LBB4_120
.LBB4_121:                              #   in Loop: Header=BB4_6 Depth=1
	movq	%rax, (%rcx)
	jmp	.LBB4_4
	.p2align	4
.LBB4_122:                              #   in Loop: Header=BB4_123 Depth=2
	incq	%rax
	movq	%rsi, %rcx
	decq	%rdx
	je	.LBB4_117
.LBB4_123:                              #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rbp,%rax,8), %rdi
	movq	%rax, %rsi
	cmpq	(%rbp,%rcx,8), %rdi
	jb	.LBB4_122
# %bb.124:                              #   in Loop: Header=BB4_123 Depth=2
	movq	%rcx, %rsi
	jmp	.LBB4_122
.LBB4_125:                              #   in Loop: Header=BB4_6 Depth=1
	movq	(%rsp), %rdi                    # 8-byte Reload
	movq	%r12, %rsi
	vzeroupper
	callq	charlatana_v28_recursive
.LBB4_126:                              #   in Loop: Header=BB4_6 Depth=1
	movq	%r14, %r11
	vmovdqu	64(%rsp), %ymm6                 # 32-byte Reload
	movq	8(%rsp), %r9                    # 8-byte Reload
	movq	24(%rsp), %r8                   # 8-byte Reload
.LBB4_127:                              #   in Loop: Header=BB4_6 Depth=1
	cmpq	$63, %r9
	jle	.LBB4_188
# %bb.128:                              #   in Loop: Header=BB4_6 Depth=1
	movq	%r8, %rdx
	movq	%r11, %r12
	movq	(%rsp), %r13                    # 8-byte Reload
	cmpq	%rdx, %r12
	jl	.LBB4_6
	jmp	.LBB4_245
.LBB4_2:                                #   in Loop: Header=BB4_6 Depth=1
	movq	(%rsp), %rdi                    # 8-byte Reload
	movq	%r11, %rsi
	movq	%r8, %rdx
	vzeroupper
	callq	charlatana_v28_recursive
.LBB4_3:                                #   in Loop: Header=BB4_6 Depth=1
	movq	16(%rsp), %rdx                  # 8-byte Reload
	vmovdqu	64(%rsp), %ymm6                 # 32-byte Reload
.LBB4_4:                                #   in Loop: Header=BB4_6 Depth=1
	cmpq	$63, %r13
	jle	.LBB4_180
# %bb.5:                                #   in Loop: Header=BB4_6 Depth=1
	movq	%r12, %r11
	movq	(%rsp), %r13                    # 8-byte Reload
	cmpq	%rdx, %r12
	jl	.LBB4_6
	jmp	.LBB4_245
.LBB4_129:                              #   in Loop: Header=BB4_6 Depth=1
	movq	%rdx, 16(%rsp)                  # 8-byte Spill
	movq	%r13, %rdi
	andq	$-4, %rdi
	movl	$1, %ecx
	xorl	%r12d, %r12d
	jmp	.LBB4_131
	.p2align	4
.LBB4_130:                              #   in Loop: Header=BB4_131 Depth=2
	addq	$4, %rcx
	cmpq	%rdi, %r9
	je	.LBB4_159
.LBB4_131:                              #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%r14,%rcx,8), %r9
	movq	%rcx, %r8
	cmpq	(%r14,%r12,8), %r9
	jb	.LBB4_132
# %bb.137:                              #   in Loop: Header=BB4_131 Depth=2
	movq	%r12, %r8
	movq	8(%r14,%rcx,8), %rdx
	cmpq	(%r14,%r8,8), %rdx
	jae	.LBB4_133
.LBB4_138:                              #   in Loop: Header=BB4_131 Depth=2
	leaq	1(%rcx), %r8
	movq	16(%r14,%rcx,8), %rdx
	cmpq	(%r14,%r8,8), %rdx
	jb	.LBB4_134
	jmp	.LBB4_135
	.p2align	4
.LBB4_132:                              #   in Loop: Header=BB4_131 Depth=2
	movq	8(%r14,%rcx,8), %rdx
	cmpq	(%r14,%r8,8), %rdx
	jb	.LBB4_138
.LBB4_133:                              #   in Loop: Header=BB4_131 Depth=2
	movq	16(%r14,%rcx,8), %rdx
	cmpq	(%r14,%r8,8), %rdx
	jae	.LBB4_135
.LBB4_134:                              #   in Loop: Header=BB4_131 Depth=2
	leaq	2(%rcx), %r8
.LBB4_135:                              #   in Loop: Header=BB4_131 Depth=2
	movq	24(%r14,%rcx,8), %r10
	leaq	3(%rcx), %r9
	movq	%r9, %r12
	cmpq	(%r14,%r8,8), %r10
	jb	.LBB4_130
# %bb.136:                              #   in Loop: Header=BB4_131 Depth=2
	movq	%r8, %r12
	jmp	.LBB4_130
.LBB4_139:                              #   in Loop: Header=BB4_6 Depth=1
	movq	%r9, %rdx
	andq	$-4, %rdx
	movl	$1, %eax
	xorl	%ecx, %ecx
	jmp	.LBB4_141
	.p2align	4
.LBB4_140:                              #   in Loop: Header=BB4_141 Depth=2
	addq	$4, %rax
	cmpq	%rdx, %rdi
	je	.LBB4_116
.LBB4_141:                              #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rbp,%rax,8), %rdi
	movq	%rax, %rsi
	cmpq	(%rbp,%rcx,8), %rdi
	jb	.LBB4_142
# %bb.147:                              #   in Loop: Header=BB4_141 Depth=2
	movq	%rcx, %rsi
	movq	8(%rbp,%rax,8), %rcx
	cmpq	(%rbp,%rsi,8), %rcx
	jae	.LBB4_143
.LBB4_148:                              #   in Loop: Header=BB4_141 Depth=2
	leaq	1(%rax), %rsi
	movq	16(%rbp,%rax,8), %rcx
	cmpq	(%rbp,%rsi,8), %rcx
	jb	.LBB4_144
	jmp	.LBB4_145
	.p2align	4
.LBB4_142:                              #   in Loop: Header=BB4_141 Depth=2
	movq	8(%rbp,%rax,8), %rcx
	cmpq	(%rbp,%rsi,8), %rcx
	jb	.LBB4_148
.LBB4_143:                              #   in Loop: Header=BB4_141 Depth=2
	movq	16(%rbp,%rax,8), %rcx
	cmpq	(%rbp,%rsi,8), %rcx
	jae	.LBB4_145
.LBB4_144:                              #   in Loop: Header=BB4_141 Depth=2
	leaq	2(%rax), %rsi
.LBB4_145:                              #   in Loop: Header=BB4_141 Depth=2
	movq	24(%rbp,%rax,8), %r8
	leaq	3(%rax), %rdi
	movq	%rdi, %rcx
	cmpq	(%rbp,%rsi,8), %r8
	jb	.LBB4_140
# %bb.146:                              #   in Loop: Header=BB4_141 Depth=2
	movq	%rsi, %rcx
	jmp	.LBB4_140
.LBB4_149:                              #   in Loop: Header=BB4_6 Depth=1
	movq	8(%rsp), %rcx                   # 8-byte Reload
	andq	$-2, %rcx
	movq	40(%rsp), %rax                  # 8-byte Reload
	leaq	(%rax,%r11,8), %rdx
	movq	56(%rsp), %rax                  # 8-byte Reload
	leaq	(%rax,%r11,8), %rsi
	movl	$1, %eax
	xorl	%edi, %edi
	jmp	.LBB4_152
	.p2align	4
.LBB4_150:                              #   in Loop: Header=BB4_152 Depth=2
	leaq	8(,%rax,8), %r9
	addq	%rbp, %r9
.LBB4_151:                              #   in Loop: Header=BB4_152 Depth=2
	movq	%r8, (%r9)
	addq	$2, %rax
	addq	$2, %rdi
	addq	$16, %rdx
	addq	$16, %rsi
	cmpq	%rcx, %rdi
	je	.LBB4_118
.LBB4_152:                              #   Parent Loop BB4_6 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB4_154 Depth 3
                                        #       Child Loop BB4_158 Depth 3
	movq	-8(%rbp,%rax,8), %r10
	movq	(%rbp,%rax,8), %r8
	cmpq	%r8, %r10
	jbe	.LBB4_155
# %bb.153:                              #   in Loop: Header=BB4_152 Depth=2
	movq	%rdx, %r9
	.p2align	4
.LBB4_154:                              #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_152 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	%r10, (%r9)
	movq	-16(%r9), %r10
	addq	$-8, %r9
	cmpq	%r8, %r10
	ja	.LBB4_154
	jmp	.LBB4_156
	.p2align	4
.LBB4_155:                              #   in Loop: Header=BB4_152 Depth=2
	leaq	(,%rax,8), %r9
	addq	%rbp, %r9
.LBB4_156:                              #   in Loop: Header=BB4_152 Depth=2
	movq	%r8, (%r9)
	movq	(%rbp,%rax,8), %r10
	movq	8(%rbp,%rax,8), %r8
	cmpq	%r8, %r10
	jbe	.LBB4_150
# %bb.157:                              #   in Loop: Header=BB4_152 Depth=2
	movq	%rsi, %r9
	.p2align	4
.LBB4_158:                              #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_152 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	%r10, (%r9)
	movq	-16(%r9), %r10
	addq	$-8, %r9
	cmpq	%r8, %r10
	ja	.LBB4_158
	jmp	.LBB4_151
.LBB4_159:                              #   in Loop: Header=BB4_6 Depth=1
	movq	16(%rsp), %rdx                  # 8-byte Reload
	movl	%r13d, %edi
	andl	$3, %edi
	je	.LBB4_164
.LBB4_160:                              #   in Loop: Header=BB4_6 Depth=1
	leaq	(%rax,%rcx,8), %rax
	subq	%rsi, %rax
	xorl	%esi, %esi
	jmp	.LBB4_162
	.p2align	4
.LBB4_161:                              #   in Loop: Header=BB4_162 Depth=2
	incq	%rsi
	cmpq	%rsi, %rdi
	je	.LBB4_164
.LBB4_162:                              #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	(%rax,%rsi,8), %r8
	cmpq	(%r14,%r12,8), %r8
	jae	.LBB4_161
# %bb.163:                              #   in Loop: Header=BB4_162 Depth=2
	leaq	(%rcx,%rsi), %r12
	jmp	.LBB4_161
.LBB4_164:                              #   in Loop: Header=BB4_6 Depth=1
	movq	(%r14), %rax
	movq	(%r14,%r12,8), %rcx
	movq	%rcx, (%r14)
	movq	%rax, (%r14,%r12,8)
	testq	%rdx, %rdx
	je	.LBB4_175
# %bb.165:                              #   in Loop: Header=BB4_6 Depth=1
	movq	%r13, %rcx
	andq	$-2, %rcx
	movl	$8, %eax
	leaq	(%rax,%r15), %rdx
	movl	$16, %eax
	addq	%rax, %r15
	movl	$1, %eax
	xorl	%esi, %esi
	jmp	.LBB4_168
	.p2align	4
.LBB4_166:                              #   in Loop: Header=BB4_168 Depth=2
	leaq	(%r14,%rax,8), %r8
	addq	$8, %r8
.LBB4_167:                              #   in Loop: Header=BB4_168 Depth=2
	movq	%rdi, (%r8)
	addq	$2, %rax
	addq	$2, %rsi
	addq	$16, %rdx
	addq	$16, %r15
	cmpq	%rcx, %rsi
	je	.LBB4_176
.LBB4_168:                              #   Parent Loop BB4_6 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB4_170 Depth 3
                                        #       Child Loop BB4_174 Depth 3
	movq	-8(%r14,%rax,8), %r9
	movq	(%r14,%rax,8), %rdi
	cmpq	%rdi, %r9
	jbe	.LBB4_171
# %bb.169:                              #   in Loop: Header=BB4_168 Depth=2
	movq	%rdx, %r8
	.p2align	4
.LBB4_170:                              #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_168 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	%r9, (%r8)
	movq	-16(%r8), %r9
	addq	$-8, %r8
	cmpq	%rdi, %r9
	ja	.LBB4_170
	jmp	.LBB4_172
	.p2align	4
.LBB4_171:                              #   in Loop: Header=BB4_168 Depth=2
	leaq	(%r14,%rax,8), %r8
.LBB4_172:                              #   in Loop: Header=BB4_168 Depth=2
	movq	%rdi, (%r8)
	movq	(%r14,%rax,8), %r9
	movq	8(%r14,%rax,8), %rdi
	cmpq	%rdi, %r9
	jbe	.LBB4_166
# %bb.173:                              #   in Loop: Header=BB4_168 Depth=2
	movq	%r15, %r8
	.p2align	4
.LBB4_174:                              #   Parent Loop BB4_6 Depth=1
                                        #     Parent Loop BB4_168 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	movq	%r9, (%r8)
	movq	-16(%r8), %r9
	addq	$-8, %r8
	cmpq	%rdi, %r9
	ja	.LBB4_174
	jmp	.LBB4_167
.LBB4_175:                              #   in Loop: Header=BB4_6 Depth=1
	movl	$1, %eax
.LBB4_176:                              #   in Loop: Header=BB4_6 Depth=1
	testb	$1, %r13b
	movq	8(%rsp), %r9                    # 8-byte Reload
	movq	24(%rsp), %r8                   # 8-byte Reload
	je	.LBB4_127
# %bb.177:                              #   in Loop: Header=BB4_6 Depth=1
	leaq	(%r14,%rax,8), %rcx
	movq	-8(%r14,%rax,8), %rdx
	movq	(%r14,%rax,8), %rax
	cmpq	%rax, %rdx
	jbe	.LBB4_179
	.p2align	4
.LBB4_178:                              #   Parent Loop BB4_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%rdx, (%rcx)
	movq	-16(%rcx), %rdx
	addq	$-8, %rcx
	cmpq	%rax, %rdx
	ja	.LBB4_178
.LBB4_179:                              #   in Loop: Header=BB4_6 Depth=1
	movq	%rax, (%rcx)
	jmp	.LBB4_127
.LBB4_180:
	movq	%rdx, %rax
	subq	%r12, %rax
	movq	(%rsp), %r11                    # 8-byte Reload
	jle	.LBB4_245
# %bb.181:
	addq	%r14, %r11
	notq	%r12
	addq	%r12, %rdx
	movl	%eax, %ecx
	andl	$3, %ecx
	movq	%rdx, %rbx
	cmpq	$3, %rdx
	jae	.LBB4_212
# %bb.182:
	movl	$1, %edx
	xorl	%esi, %esi
.LBB4_183:
	testq	%rcx, %rcx
	je	.LBB4_196
# %bb.184:
	leaq	(%r15,%rdx,8), %rdi
	xorl	%r8d, %r8d
	jmp	.LBB4_186
	.p2align	4
.LBB4_185:                              #   in Loop: Header=BB4_186 Depth=1
	incq	%r8
	cmpq	%r8, %rcx
	je	.LBB4_196
.LBB4_186:                              # =>This Inner Loop Header: Depth=1
	movq	(%rdi,%r8,8), %r9
	cmpq	(%r11,%rsi,8), %r9
	jae	.LBB4_185
# %bb.187:                              #   in Loop: Header=BB4_186 Depth=1
	leaq	(%rdx,%r8), %rsi
	jmp	.LBB4_185
.LBB4_188:
	cmpq	%r11, %r8
	movq	(%rsp), %r14                    # 8-byte Reload
	jle	.LBB4_245
# %bb.189:
	movq	%r11, %rax
	notq	%rax
	addq	%rbx, %rax
	addq	$-2, %rbx
	movq	%rbx, %rdx
	subq	%r11, %rdx
	movl	%eax, %ecx
	andl	$3, %ecx
	cmpq	$3, %rdx
	jae	.LBB4_222
# %bb.190:
	movl	$1, %edx
	xorl	%esi, %esi
.LBB4_191:
	movq	%rsi, %r8
	testq	%rcx, %rcx
	je	.LBB4_207
# %bb.192:
	leaq	(%r14,%r11,8), %rdi
	jmp	.LBB4_194
	.p2align	4
.LBB4_193:                              #   in Loop: Header=BB4_194 Depth=1
	incq	%rdx
	movq	%r8, %rsi
	decq	%rcx
	je	.LBB4_207
.LBB4_194:                              # =>This Inner Loop Header: Depth=1
	movq	(%rdi,%rdx,8), %r9
	movq	%rdx, %r8
	cmpq	(%rbp,%rsi,8), %r9
	jb	.LBB4_193
# %bb.195:                              #   in Loop: Header=BB4_194 Depth=1
	movq	%rsi, %r8
	jmp	.LBB4_193
.LBB4_196:
	movq	(%r11), %rcx
	movq	(%r11,%rsi,8), %rdx
	movq	%rdx, (%r11)
	movq	%rcx, (%r11,%rsi,8)
	testq	%rbx, %rbx
	je	.LBB4_243
# %bb.197:
	movq	%rax, %rdx
	andq	$-2, %rdx
	leaq	8(%r15), %rsi
	addq	$16, %r15
	movl	$1, %ecx
	xorl	%edi, %edi
	jmp	.LBB4_200
	.p2align	4
.LBB4_198:                              #   in Loop: Header=BB4_200 Depth=1
	leaq	(%r11,%rcx,8), %r9
	addq	$8, %r9
.LBB4_199:                              #   in Loop: Header=BB4_200 Depth=1
	movq	%r8, (%r9)
	addq	$2, %rcx
	addq	$2, %rdi
	addq	$16, %rsi
	addq	$16, %r15
	cmpq	%rdx, %rdi
	je	.LBB4_244
.LBB4_200:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB4_202 Depth 2
                                        #     Child Loop BB4_206 Depth 2
	movq	-8(%r11,%rcx,8), %r10
	movq	(%r11,%rcx,8), %r8
	cmpq	%r8, %r10
	jbe	.LBB4_203
# %bb.201:                              #   in Loop: Header=BB4_200 Depth=1
	movq	%rsi, %r9
	.p2align	4
.LBB4_202:                              #   Parent Loop BB4_200 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%r10, (%r9)
	movq	-16(%r9), %r10
	addq	$-8, %r9
	cmpq	%r8, %r10
	ja	.LBB4_202
	jmp	.LBB4_204
	.p2align	4
.LBB4_203:                              #   in Loop: Header=BB4_200 Depth=1
	leaq	(%r11,%rcx,8), %r9
.LBB4_204:                              #   in Loop: Header=BB4_200 Depth=1
	movq	%r8, (%r9)
	movq	(%r11,%rcx,8), %r10
	movq	8(%r11,%rcx,8), %r8
	cmpq	%r8, %r10
	jbe	.LBB4_198
# %bb.205:                              #   in Loop: Header=BB4_200 Depth=1
	movq	%r15, %r9
	.p2align	4
.LBB4_206:                              #   Parent Loop BB4_200 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%r10, (%r9)
	movq	-16(%r9), %r10
	addq	$-8, %r9
	cmpq	%r8, %r10
	ja	.LBB4_206
	jmp	.LBB4_199
.LBB4_207:
	movq	(%rbp), %rcx
	movq	(%rbp,%r8,8), %rdx
	movq	%rdx, (%rbp)
	movq	%rcx, (%rbp,%r8,8)
	movl	$1, %ecx
	cmpq	%r11, %rbx
	jne	.LBB4_233
.LBB4_208:
	testb	$1, %al
	je	.LBB4_245
# %bb.209:
	leaq	(,%rcx,8), %rax
	addq	%rbp, %rax
	movq	-8(%rbp,%rcx,8), %rdx
	movq	(%rbp,%rcx,8), %rcx
	cmpq	%rcx, %rdx
	jbe	.LBB4_211
	.p2align	4
.LBB4_210:                              # =>This Inner Loop Header: Depth=1
	movq	%rdx, (%rax)
	movq	-16(%rax), %rdx
	addq	$-8, %rax
	cmpq	%rcx, %rdx
	ja	.LBB4_210
	jmp	.LBB4_211
.LBB4_212:
	movq	%rax, %rdi
	andq	$-4, %rdi
	movl	$1, %edx
	xorl	%esi, %esi
	jmp	.LBB4_214
	.p2align	4
.LBB4_213:                              #   in Loop: Header=BB4_214 Depth=1
	addq	$4, %rdx
	cmpq	%rdi, %r9
	je	.LBB4_183
.LBB4_214:                              # =>This Inner Loop Header: Depth=1
	movq	(%r11,%rdx,8), %r9
	movq	%rdx, %r8
	cmpq	(%r11,%rsi,8), %r9
	jb	.LBB4_215
# %bb.220:                              #   in Loop: Header=BB4_214 Depth=1
	movq	%rsi, %r8
	movq	8(%r11,%rdx,8), %rsi
	cmpq	(%r11,%r8,8), %rsi
	jae	.LBB4_216
.LBB4_221:                              #   in Loop: Header=BB4_214 Depth=1
	leaq	1(%rdx), %r8
	movq	16(%r11,%rdx,8), %rsi
	cmpq	(%r11,%r8,8), %rsi
	jb	.LBB4_217
	jmp	.LBB4_218
	.p2align	4
.LBB4_215:                              #   in Loop: Header=BB4_214 Depth=1
	movq	8(%r11,%rdx,8), %rsi
	cmpq	(%r11,%r8,8), %rsi
	jb	.LBB4_221
.LBB4_216:                              #   in Loop: Header=BB4_214 Depth=1
	movq	16(%r11,%rdx,8), %rsi
	cmpq	(%r11,%r8,8), %rsi
	jae	.LBB4_218
.LBB4_217:                              #   in Loop: Header=BB4_214 Depth=1
	leaq	2(%rdx), %r8
.LBB4_218:                              #   in Loop: Header=BB4_214 Depth=1
	movq	24(%r11,%rdx,8), %r10
	leaq	3(%rdx), %r9
	movq	%r9, %rsi
	cmpq	(%r11,%r8,8), %r10
	jb	.LBB4_213
# %bb.219:                              #   in Loop: Header=BB4_214 Depth=1
	movq	%r8, %rsi
	jmp	.LBB4_213
.LBB4_222:
	movq	%rax, %rdi
	andq	$-4, %rdi
	leaq	(%r14,%r11,8), %r8
	movl	$1, %edx
	xorl	%esi, %esi
	jmp	.LBB4_224
	.p2align	4
.LBB4_223:                              #   in Loop: Header=BB4_224 Depth=1
	addq	$4, %rdx
	cmpq	%rdi, %r10
	movq	%r15, %r11
	je	.LBB4_191
.LBB4_224:                              # =>This Inner Loop Header: Depth=1
	movq	(%r8,%rdx,8), %r10
	movq	%rdx, %r9
	cmpq	(%rbp,%rsi,8), %r10
	jb	.LBB4_225
# %bb.228:                              #   in Loop: Header=BB4_224 Depth=1
	movq	%rsi, %r9
	movq	8(%r8,%rdx,8), %rsi
	cmpq	(%rbp,%r9,8), %rsi
	jae	.LBB4_226
.LBB4_229:                              #   in Loop: Header=BB4_224 Depth=1
	leaq	1(%rdx), %r9
	movq	16(%r8,%rdx,8), %rsi
	cmpq	(%rbp,%r9,8), %rsi
	jae	.LBB4_227
.LBB4_230:                              #   in Loop: Header=BB4_224 Depth=1
	movq	%r11, %r15
	leaq	2(%rdx), %r9
	jmp	.LBB4_231
	.p2align	4
.LBB4_225:                              #   in Loop: Header=BB4_224 Depth=1
	movq	8(%r8,%rdx,8), %rsi
	cmpq	(%rbp,%r9,8), %rsi
	jb	.LBB4_229
.LBB4_226:                              #   in Loop: Header=BB4_224 Depth=1
	movq	16(%r8,%rdx,8), %rsi
	cmpq	(%rbp,%r9,8), %rsi
	jb	.LBB4_230
.LBB4_227:                              #   in Loop: Header=BB4_224 Depth=1
	movq	%r11, %r15
.LBB4_231:                              #   in Loop: Header=BB4_224 Depth=1
	movq	24(%r8,%rdx,8), %r11
	leaq	3(%rdx), %r10
	movq	%r10, %rsi
	cmpq	(%rbp,%r9,8), %r11
	jb	.LBB4_223
# %bb.232:                              #   in Loop: Header=BB4_224 Depth=1
	movq	%r9, %rsi
	jmp	.LBB4_223
.LBB4_233:
	movq	%rax, %rdx
	andq	$-2, %rdx
	leaq	(%r14,%r11,8), %rsi
	addq	$8, %rsi
	leaq	(%r14,%r11,8), %rdi
	addq	$16, %rdi
	xorl	%r8d, %r8d
	jmp	.LBB4_236
	.p2align	4
.LBB4_234:                              #   in Loop: Header=BB4_236 Depth=1
	leaq	8(,%rcx,8), %r10
	addq	%rbp, %r10
.LBB4_235:                              #   in Loop: Header=BB4_236 Depth=1
	movq	%r9, (%r10)
	addq	$2, %rcx
	addq	$2, %r8
	addq	$16, %rsi
	addq	$16, %rdi
	cmpq	%rdx, %r8
	je	.LBB4_208
.LBB4_236:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB4_238 Depth 2
                                        #     Child Loop BB4_242 Depth 2
	movq	-8(%rbp,%rcx,8), %r11
	movq	(%rbp,%rcx,8), %r9
	cmpq	%r9, %r11
	jbe	.LBB4_239
# %bb.237:                              #   in Loop: Header=BB4_236 Depth=1
	movq	%rsi, %r10
	.p2align	4
.LBB4_238:                              #   Parent Loop BB4_236 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%r11, (%r10)
	movq	-16(%r10), %r11
	addq	$-8, %r10
	cmpq	%r9, %r11
	ja	.LBB4_238
	jmp	.LBB4_240
	.p2align	4
.LBB4_239:                              #   in Loop: Header=BB4_236 Depth=1
	leaq	(,%rcx,8), %r10
	addq	%rbp, %r10
.LBB4_240:                              #   in Loop: Header=BB4_236 Depth=1
	movq	%r9, (%r10)
	movq	(%rbp,%rcx,8), %r11
	movq	8(%rbp,%rcx,8), %r9
	cmpq	%r9, %r11
	jbe	.LBB4_234
# %bb.241:                              #   in Loop: Header=BB4_236 Depth=1
	movq	%rdi, %r10
	.p2align	4
.LBB4_242:                              #   Parent Loop BB4_236 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	movq	%r11, (%r10)
	movq	-16(%r10), %r11
	addq	$-8, %r10
	cmpq	%r9, %r11
	ja	.LBB4_242
	jmp	.LBB4_235
.LBB4_243:
	movl	$1, %ecx
.LBB4_244:
	testb	$1, %al
	je	.LBB4_245
# %bb.246:
	leaq	(%r11,%rcx,8), %rax
	movq	-8(%r11,%rcx,8), %rdx
	movq	(%r11,%rcx,8), %rcx
	cmpq	%rcx, %rdx
	jbe	.LBB4_211
	.p2align	4
.LBB4_247:                              # =>This Inner Loop Header: Depth=1
	movq	%rdx, (%rax)
	movq	-16(%rax), %rdx
	addq	$-8, %rax
	cmpq	%rcx, %rdx
	ja	.LBB4_247
.LBB4_211:
	movq	%rcx, (%rax)
.LBB4_245:
	addq	$4200, %rsp                     # imm = 0x1068
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.Lfunc_end4:
	.size	charlatana_v28_recursive, .Lfunc_end4-charlatana_v28_recursive
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function .omp_task_entry.
	.type	.omp_task_entry.,@function
.omp_task_entry.:                       # @.omp_task_entry.
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	40(%rsi), %rdi
	movq	48(%rsi), %rax
	movq	56(%rsi), %rdx
	movq	%rax, %rsi
	callq	charlatana_v28_recursive
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end5:
	.size	.omp_task_entry., .Lfunc_end5-.omp_task_entry.
	.cfi_endproc
                                        # -- End function
	.p2align	4                               # -- Begin function .omp_task_entry..21
	.type	.omp_task_entry..21,@function
.omp_task_entry..21:                    # @.omp_task_entry..21
	.cfi_startproc
# %bb.0:
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	40(%rsi), %rdi
	movq	48(%rsi), %rax
	movq	56(%rsi), %rdx
	movq	%rax, %rsi
	callq	charlatana_v28_recursive
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end6:
	.size	.omp_task_entry..21, .Lfunc_end6-.omp_task_entry..21
	.cfi_endproc
                                        # -- End function
	.type	.L.str,@object                  # @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"Usage: %s <file_to_sort> <algorithm>\n"
	.size	.L.str, 38

	.type	.L.str.1,@object                # @.str.1
.L.str.1:
	.asciz	"Algorithms:\n  1 = Charlatana_v28\n  2 = Standard qsort()\n"
	.size	.L.str.1, 57

	.type	.L.str.2,@object                # @.str.2
.L.str.2:
	.asciz	"rb"
	.size	.L.str.2, 3

	.type	.L.str.3,@object                # @.str.3
.L.str.3:
	.asciz	"Error opening file"
	.size	.L.str.3, 19

	.type	.L.str.4,@object                # @.str.4
.L.str.4:
	.asciz	"Error: File is too small.\n"
	.size	.L.str.4, 27

	.type	.L.str.5,@object                # @.str.5
.L.str.5:
	.asciz	"Extracting %zu keys...\n"
	.size	.L.str.5, 24

	.type	.L.str.6,@object                # @.str.6
.L.str.6:
	.zero	1
	.size	.L.str.6, 1

	.type	.L.str.9,@object                # @.str.9
.L.str.9:
	.asciz	"OpenMP Engine: Utilizing up to %d Hardware Threads\n"
	.size	.L.str.9, 52

	.type	.L.str.11,@object               # @.str.11
.L.str.11:
	.asciz	"Sort Time: %.4f seconds\n"
	.size	.L.str.11, 25

	.type	.L.str.12,@object               # @.str.12
.L.str.12:
	.asciz	"Total Performance: %'llu keys-per-second\n"
	.size	.L.str.12, 42

	.type	.L.str.14,@object               # @.str.14
.L.str.14:
	.asciz	"Unique keys: %'zu\n"
	.size	.L.str.14, 19

	.type	.L.str.16,@object               # @.str.16
.L.str.16:
	.asciz	"Array properly sorted: %s\n"
	.size	.L.str.16, 27

	.type	.L.str.17,@object               # @.str.17
.L.str.17:
	.asciz	"YES"
	.size	.L.str.17, 4

	.type	.L.str.18,@object               # @.str.18
.L.str.18:
	.asciz	"NO"
	.size	.L.str.18, 3

	.type	.L__unnamed_3,@object           # @0
.L__unnamed_3:
	.asciz	";unknown;unknown;0;0;;"
	.size	.L__unnamed_3, 23

	.type	.L__unnamed_1,@object           # @1
	.section	.rodata,"a",@progbits
	.p2align	3, 0x0
.L__unnamed_1:
	.long	0                               # 0x0
	.long	2                               # 0x2
	.long	0                               # 0x0
	.long	22                              # 0x16
	.quad	.L__unnamed_3
	.size	.L__unnamed_1, 24

	.type	.L__unnamed_2,@object           # @2
	.p2align	3, 0x0
.L__unnamed_2:
	.long	0                               # 0x0
	.long	322                             # 0x142
	.long	0                               # 0x0
	.long	22                              # 0x16
	.quad	.L__unnamed_3
	.size	.L__unnamed_2, 24

	.type	QWORD_PACK_TABLE,@object        # @QWORD_PACK_TABLE
	.p2align	5, 0x0
QWORD_PACK_TABLE:
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	6                               # 0x6
	.long	7                               # 0x7
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	0                               # 0x0
	.long	1                               # 0x1
	.long	2                               # 0x2
	.long	3                               # 0x3
	.long	4                               # 0x4
	.long	5                               # 0x5
	.long	6                               # 0x6
	.long	7                               # 0x7
	.size	QWORD_PACK_TABLE, 512

	.type	MASK_STORE_TABLE,@object        # @MASK_STORE_TABLE
	.p2align	5, 0x0
MASK_STORE_TABLE:
	.zero	32
	.quad	-1                              # 0xffffffffffffffff
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.quad	-1                              # 0xffffffffffffffff
	.quad	-1                              # 0xffffffffffffffff
	.quad	0                               # 0x0
	.quad	0                               # 0x0
	.quad	-1                              # 0xffffffffffffffff
	.quad	-1                              # 0xffffffffffffffff
	.quad	-1                              # 0xffffffffffffffff
	.quad	0                               # 0x0
	.zero	32,255
	.size	MASK_STORE_TABLE, 160

	.type	.Lstr,@object                   # @str
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lstr:
	.asciz	"\n--- Starting Benchmark ---"
	.size	.Lstr, 28

	.type	.Lstr.22,@object                # @str.22
.Lstr.22:
	.asciz	"Algorithm: Standard C qsort() [Single Threaded]"
	.size	.Lstr.22, 48

	.type	.Lstr.23,@object                # @str.23
.Lstr.23:
	.asciz	"Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)"
	.size	.Lstr.23, 62

	.type	.Lstr.24,@object                # @str.24
.Lstr.24:
	.asciz	"Total Performance: N/A keys-per-second"
	.size	.Lstr.24, 39

	.type	.Lstr.25,@object                # @str.25
.Lstr.25:
	.asciz	"\n--- Verification ---"
	.size	.Lstr.25, 22

	.ident	"clang version 20.1.8 (Fedora 20.1.8-4.fc42)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym compare_uint64
	.addrsig_sym Charlatana_Sort.omp_outlined
	.addrsig_sym .omp_task_entry.
	.addrsig_sym .omp_task_entry..21
