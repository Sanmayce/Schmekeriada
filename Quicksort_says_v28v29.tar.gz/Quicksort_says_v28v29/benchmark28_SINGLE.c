/*
COMPILE WITH OPENMP:
$ gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28_SINGLE benchmark28_SINGLE.c

$ x86_64-w64-mingw32-gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28_SINGLE.exe benchmark28_SINGLE.c

Usage: 
  ./benchmark <file_to_sort> <algorithm_choice>
  
Algorithms:
  1 = Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
  2 = Standard C qsort()
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <omp.h>
#include <locale.h>          // NEW: for comma-formatted thousands

//#include "Charlatana_v28.h"
#include "Charlatana_v28_SINGLE.h"

int compare_uint64(const void* a, const void* b) {
    uint64_t val_a = *(const uint64_t*)a;
    uint64_t val_b = *(const uint64_t*)b;
    if (val_a < val_b) return -1;
    if (val_a > val_b) return 1;
    return 0;
}

bool is_sorted(uint64_t* arr, size_t n) {
    for (size_t i = 1; i < n; i++) {
        if (arr[i - 1] > arr[i]) return false;
    }
    return true;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <file_to_sort> <algorithm>\n", argv[0]);
        fprintf(stderr, "Algorithms:\n  1 = Charlatana_v28\n  2 = Standard qsort()\n");
        return EXIT_FAILURE;
    }

    const char* filename = argv[1];
    int algo_choice = atoi(argv[2]);

    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Error opening file");
        return EXIT_FAILURE;
    }

    fseek(file, 0, SEEK_END);
    long filesize = ftell(file);
    fseek(file, 0, SEEK_SET);

    if (filesize < 8) {
        fprintf(stderr, "Error: File is too small.\n");
        fclose(file);
        return EXIT_FAILURE;
    }

    uint8_t *file_buffer = (uint8_t*)malloc(filesize);
    fread(file_buffer, 1, filesize, file);
    fclose(file);

    size_t num_keys = filesize - 8 + 1;
    printf("Extracting %zu keys...\n", num_keys);

    uint64_t *keys = (uint64_t*)malloc(num_keys * sizeof(uint64_t));
    for (size_t i = 0; i < num_keys; i++) {
        memcpy(&keys[i], &file_buffer[i], sizeof(uint64_t));
    }
    free(file_buffer);

    /* === NEW: enable comma formatting for performance numbers === */
    setlocale(LC_NUMERIC, "");

    printf("\n--- Starting Benchmark ---\n");
    double start_time = omp_get_wtime();
    
    if (algo_choice == 1) {
        int threads = omp_get_max_threads();
        printf("Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)\n");
        printf("OpenMP Engine: Utilizing up to %d Hardware Threads\n", threads);
        Charlatana_Sort(keys, num_keys);
    } 
    else if (algo_choice == 2) {
        printf("Algorithm: Standard C qsort() [Single Threaded]\n");
        qsort(keys, num_keys, sizeof(uint64_t), compare_uint64);
    } 
    
    double end_time = omp_get_wtime();
    double elapsed = end_time - start_time;

    printf("Sort Time: %.4f seconds\n", elapsed);

    /* === NEW: Total Performance report (Total_keys / OpenMPtime) === */
    if (elapsed > 0.0) {
        uint64_t keys_per_sec = (uint64_t)(num_keys / elapsed);
        printf("Total Performance: %'llu keys-per-second\n", (unsigned long long)keys_per_sec);
    } else {
        printf("Total Performance: N/A keys-per-second\n");
    }

    /* === UNIQUE KEYS COUNT (after sorting) === */
    size_t unique_keys = 0;
    if (num_keys > 0) {
        unique_keys = 1;
        for (size_t i = 1; i < num_keys; i++) {
            if (keys[i] != keys[i - 1]) {
                unique_keys++;
            }
        }
    }
    printf("Unique keys: %'zu\n", unique_keys);

    printf("\n--- Verification ---\n");
    bool is_properly_sorted = is_sorted(keys, num_keys);
    printf("Array properly sorted: %s\n", is_properly_sorted ? "YES" : "NO");

    free(keys);
    return EXIT_SUCCESS;
}

// Core i7-11850H (Tiger Lake-H). 128GB DDR4 3200MHz

/*
[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update]$ cat bench.sh 
echo Charlatana_v28:
gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_\(FB2-1012\).tar 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_\(FB2-1012\).tar 1

/bin/time -v ./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_\(FB2-1012\).tar 1

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1

/bin/time -v ./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Nobara-43-GNOME-2026-01-26.iso 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Nobara-43-GNOME-2026-01-26.iso 1

/bin/time -v ./benchmark28 Nobara-43-GNOME-2026-01-26.iso 1

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1

/bin/time -v ./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Brawl_in_cell_block_99_\(2017\)_UHD_BDRip_720p.mkv 1
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Brawl_in_cell_block_99_\(2017\)_UHD_BDRip_720p.mkv 1

/bin/time -v ./benchmark28 Brawl_in_cell_block_99_\(2017\)_UHD_BDRip_720p.mkv 1

echo
echo qsort:
gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_\(FB2-1012\).tar 2
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_\(FB2-1012\).tar 2

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 2
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 2

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Nobara-43-GNOME-2026-01-26.iso 2
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 Nobara-43-GNOME-2026-01-26.iso 2

gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 2
clang -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28 benchmark28.c
perf stat -d ./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 2

[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update]$ 
*/

/*
[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update]$ sh bench.sh 
Charlatana_v28:
Extracting 998340601 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 10.3061 seconds
Total Performance: 96,868,533 keys-per-second
Unique keys: 209,106,265

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_(FB2-1012).tar 1':

        122,470.51 msec task-clock:u                     #    9.010 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         1,950,460      page-faults:u                    #   15.926 K/sec                     
   344,165,215,378      instructions:u                   #    1.03  insn per cycle              (90.91%)
   332,538,057,800      cycles:u                         #    2.715 GHz                         (90.91%)
    44,137,185,917      branches:u                       #  360.390 M/sec                       (90.91%)
     2,501,861,517      branch-misses:u                  #    5.67% of all branches             (81.84%)
                        TopdownL1                 #      4.9 %  tma_backend_bound      
                                                  #     91.0 %  tma_bad_speculation    
                                                  #     -0.0 %  tma_frontend_bound     
                                                  #      4.2 %  tma_retiring             (90.92%)
    53,733,152,687      L1-dcache-loads:u                #  438.744 M/sec                       (90.90%)
     3,183,538,531      L1-dcache-load-misses:u          #    5.92% of all L1-dcache accesses   (90.91%)
        61,238,102      LLC-loads:u                      #  500.023 K/sec                       (90.90%)
        58,056,977      LLC-load-misses:u                #   94.81% of all LL-cache accesses    (81.83%)

      13.592276302 seconds time elapsed

     115.820343000 seconds user
       1.995976000 seconds sys


Extracting 998340601 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 11.9045 seconds
Total Performance: 83,862,583 keys-per-second
Unique keys: 209,106,265

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_(FB2-1012).tar 1':

        178,036.30 msec task-clock:u                     #   11.811 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         1,950,704      page-faults:u                    #   10.957 K/sec                     
   457,680,462,264      instructions:u                   #    0.95  insn per cycle              (90.91%)
   481,166,252,393      cycles:u                         #    2.703 GHz                         (90.90%)
    72,842,294,078      branches:u                       #  409.143 M/sec                       (90.90%)
     3,278,125,285      branch-misses:u                  #    4.50% of all branches             (81.82%)
                        TopdownL1                 #      9.6 %  tma_backend_bound      
                                                  #     83.8 %  tma_bad_speculation    
                                                  #      0.6 %  tma_frontend_bound     
                                                  #      6.0 %  tma_retiring             (90.91%)
    82,113,273,218      L1-dcache-loads:u                #  461.216 M/sec                       (90.91%)
     3,970,894,539      L1-dcache-load-misses:u          #    4.84% of all L1-dcache accesses   (90.91%)
       482,400,901      LLC-loads:u                      #    2.710 M/sec                       (90.91%)
        61,336,250      LLC-load-misses:u                #   12.71% of all LL-cache accesses    (81.82%)

      15.074071314 seconds time elapsed

     169.396583000 seconds user
       2.583716000 seconds sys


Extracting 998340601 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 11.3617 seconds
Total Performance: 87,868,644 keys-per-second
Unique keys: 209,106,265

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_(FB2-1012).tar 1"
	User time (seconds): 165.71
	System time (seconds): 2.51
	Percent of CPU this job got: 1164%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 0:14.44
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 8776320
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 2194453
	Voluntary context switches: 81
	Involuntary context switches: 2779
	Swaps: 0
	File system inputs: 0
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0
Extracting 5694801913 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 61.0153 seconds
Total Performance: 93,334,006 keys-per-second
Unique keys: 82,181,812

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1':

        751,688.26 msec task-clock:u                     #    9.378 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        11,123,421      page-faults:u                    #   14.798 K/sec                     
 1,743,432,645,885      instructions:u                   #    0.80  insn per cycle              (90.91%)
 2,180,343,479,303      cycles:u                         #    2.901 GHz                         (90.91%)
   220,792,301,521      branches:u                       #  293.729 M/sec                       (90.91%)
    11,859,068,243      branch-misses:u                  #    5.37% of all branches             (81.82%)
                        TopdownL1                 #      3.1 %  tma_backend_bound      
                                                  #     94.9 %  tma_bad_speculation    
                                                  #     -0.2 %  tma_frontend_bound     
                                                  #      2.1 %  tma_retiring             (90.91%)
   271,728,016,219      L1-dcache-loads:u                #  361.490 M/sec                       (90.91%)
    19,249,010,118      L1-dcache-load-misses:u          #    7.08% of all L1-dcache accesses   (90.91%)
       371,245,722      LLC-loads:u                      #  493.883 K/sec                       (90.91%)
       356,128,215      LLC-load-misses:u                #   95.93% of all LL-cache accesses    (81.82%)

      80.158144755 seconds time elapsed

     711.969378000 seconds user
      11.245417000 seconds sys


Extracting 5694801913 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 67.8278 seconds
Total Performance: 83,959,736 keys-per-second
Unique keys: 82,181,812

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1':

        965,591.91 msec task-clock:u                     #   11.214 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        11,123,475      page-faults:u                    #   11.520 K/sec                     
 2,222,200,273,818      instructions:u                   #    0.78  insn per cycle              (90.91%)
 2,844,712,749,495      cycles:u                         #    2.946 GHz                         (90.91%)
   342,475,044,733      branches:u                       #  354.679 M/sec                       (90.91%)
    16,112,050,045      branch-misses:u                  #    4.70% of all branches             (81.82%)
                        TopdownL1                 #      9.1 %  tma_backend_bound      
                                                  #     89.2 %  tma_bad_speculation    
                                                  #     -0.1 %  tma_frontend_bound     
                                                  #      1.9 %  tma_retiring             (90.91%)
   380,869,945,471      L1-dcache-loads:u                #  394.442 M/sec                       (90.91%)
    22,799,286,293      L1-dcache-load-misses:u          #    5.99% of all L1-dcache accesses   (90.91%)
     2,332,229,875      LLC-loads:u                      #    2.415 M/sec                       (90.91%)
       411,882,245      LLC-load-misses:u                #   17.66% of all LL-cache accesses    (81.82%)

      86.106339017 seconds time elapsed

     920.421033000 seconds user
      13.862213000 seconds sys


Extracting 5694801913 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 65.3394 seconds
Total Performance: 87,157,184 keys-per-second
Unique keys: 82,181,812

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 1"
	User time (seconds): 905.38
	System time (seconds): 13.23
	Percent of CPU this job got: 1100%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 1:23.45
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 50053784
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 12513824
	Voluntary context switches: 90
	Involuntary context switches: 21991
	Swaps: 0
	File system inputs: 0
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0
Extracting 6126911481 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 89.9750 seconds
Total Performance: 68,095,738 keys-per-second
Unique keys: 5,726,784,672

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 Nobara-43-GNOME-2026-01-26.iso 1':

      1,161,700.34 msec task-clock:u                     #   10.535 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        11,967,495      page-faults:u                    #   10.302 K/sec                     
 3,411,691,180,821      instructions:u                   #    1.19  insn per cycle              (90.91%)
 2,865,372,137,569      cycles:u                         #    2.467 GHz                         (90.91%)
   445,501,001,379      branches:u                       #  383.490 M/sec                       (90.91%)
    28,925,507,830      branch-misses:u                  #    6.49% of all branches             (81.82%)
                        TopdownL1                 #      2.6 %  tma_backend_bound      
                                                  #     96.3 %  tma_bad_speculation    
                                                  #     -0.4 %  tma_frontend_bound     
                                                  #      1.5 %  tma_retiring             (90.91%)
   536,515,293,791      L1-dcache-loads:u                #  461.836 M/sec                       (90.91%)
    22,678,327,761      L1-dcache-load-misses:u          #    4.23% of all L1-dcache accesses   (90.91%)
       408,214,933      LLC-loads:u                      #  351.394 K/sec                       (90.91%)
       384,924,870      LLC-load-misses:u                #   94.29% of all LL-cache accesses    (81.82%)

     110.265365940 seconds time elapsed

    1102.491218000 seconds user
      12.428618000 seconds sys


Extracting 6126911481 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 95.6674 seconds
Total Performance: 64,043,895 keys-per-second
Unique keys: 5,726,784,672

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 Nobara-43-GNOME-2026-01-26.iso 1':

      1,413,945.88 msec task-clock:u                     #   12.319 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        11,967,502      page-faults:u                    #    8.464 K/sec                     
 3,904,650,242,139      instructions:u                   #    1.07  insn per cycle              (90.91%)
 3,643,146,084,414      cycles:u                         #    2.577 GHz                         (90.91%)
   602,946,679,679      branches:u                       #  426.428 M/sec                       (90.91%)
    36,568,971,171      branch-misses:u                  #    6.07% of all branches             (81.82%)
                        TopdownL1                 #      5.4 %  tma_backend_bound      
                                                  #     93.1 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      1.8 %  tma_retiring             (90.91%)
   609,845,724,000      L1-dcache-loads:u                #  431.308 M/sec                       (90.91%)
    26,796,900,097      L1-dcache-load-misses:u          #    4.39% of all L1-dcache accesses   (90.91%)
     2,651,730,973      LLC-loads:u                      #    1.875 M/sec                       (90.91%)
       479,740,826      LLC-load-misses:u                #   18.09% of all LL-cache accesses    (81.82%)

     114.780699032 seconds time elapsed

    1348.881731000 seconds user
      14.567139000 seconds sys


Extracting 6126911481 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 92.7155 seconds
Total Performance: 66,082,946 keys-per-second
Unique keys: 5,726,784,672

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark28 Nobara-43-GNOME-2026-01-26.iso 1"
	User time (seconds): 1344.50
	System time (seconds): 13.91
	Percent of CPU this job got: 1220%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 1:51.28
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 53851636
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 13463343
	Voluntary context switches: 85
	Involuntary context switches: 22451
	Swaps: 0
	File system inputs: 0
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0
Extracting 9758687449 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 110.5515 seconds
Total Performance: 88,272,808 keys-per-second
Unique keys: 316,438,651

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1':

      1,312,222.97 msec task-clock:u                     #    9.187 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        19,060,747      page-faults:u                    #   14.526 K/sec                     
 3,281,791,683,039      instructions:u                   #    0.88  insn per cycle              (90.91%)
 3,745,673,554,108      cycles:u                         #    2.854 GHz                         (90.91%)
   415,754,313,177      branches:u                       #  316.832 M/sec                       (90.91%)
    23,635,494,539      branch-misses:u                  #    5.68% of all branches             (81.82%)
                        TopdownL1                 #      2.1 %  tma_backend_bound      
                                                  #     95.8 %  tma_bad_speculation    
                                                  #     -0.2 %  tma_frontend_bound     
                                                  #      2.3 %  tma_retiring             (90.91%)
   510,774,423,374      L1-dcache-loads:u                #  389.244 M/sec                       (90.91%)
    33,570,469,761      L1-dcache-load-misses:u          #    6.57% of all L1-dcache accesses   (90.91%)
       628,060,941      LLC-loads:u                      #  478.624 K/sec                       (90.91%)
       600,159,577      LLC-load-misses:u                #   95.56% of all LL-cache accesses    (81.82%)

     142.827376306 seconds time elapsed

    1242.486656000 seconds user
      19.575721000 seconds sys


Extracting 9758687449 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 122.1156 seconds
Total Performance: 79,913,516 keys-per-second
Unique keys: 316,438,651

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1':

      1,741,460.14 msec task-clock:u                     #   11.380 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        19,060,768      page-faults:u                    #   10.945 K/sec                     
 4,127,886,241,813      instructions:u                   #    0.82  insn per cycle              (90.91%)
 5,013,116,694,929      cycles:u                         #    2.879 GHz                         (90.91%)
   633,697,859,148      branches:u                       #  363.889 M/sec                       (90.91%)
    31,703,244,840      branch-misses:u                  #    5.00% of all branches             (81.82%)
                        TopdownL1                 #      6.5 %  tma_backend_bound      
                                                  #     91.3 %  tma_bad_speculation    
                                                  #     -0.2 %  tma_frontend_bound     
                                                  #      2.4 %  tma_retiring             (90.91%)
   697,655,133,967      L1-dcache-loads:u                #  400.615 M/sec                       (90.91%)
    40,024,348,259      L1-dcache-load-misses:u          #    5.74% of all L1-dcache accesses   (90.91%)
     4,283,577,242      LLC-loads:u                      #    2.460 M/sec                       (90.91%)
       785,704,061      LLC-load-misses:u                #   18.34% of all LL-cache accesses    (81.82%)

     153.022548463 seconds time elapsed

    1660.024199000 seconds user
      23.463559000 seconds sys


Extracting 9758687449 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 119.6554 seconds
Total Performance: 81,556,594 keys-per-second
Unique keys: 316,438,651

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 1"
	User time (seconds): 1666.72
	System time (seconds): 22.68
	Percent of CPU this job got: 1128%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 2:29.67
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 85771508
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 21443271
	Voluntary context switches: 84
	Involuntary context switches: 32954
	Swaps: 0
	File system inputs: 0
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0
Extracting 11402523458 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 177.7942 seconds
Total Performance: 64,133,278 keys-per-second
Unique keys: 11,116,109,642

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 Brawl_in_cell_block_99_(2017)_UHD_BDRip_720p.mkv 1':

      2,244,660.03 msec task-clock:u                     #   10.464 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        22,271,464      page-faults:u                    #    9.922 K/sec                     
 6,480,248,934,235      instructions:u                   #    1.17  insn per cycle              (90.91%)
 5,530,252,990,842      cycles:u                         #    2.464 GHz                         (90.91%)
   840,540,639,954      branches:u                       #  374.462 M/sec                       (90.91%)
    54,769,045,916      branch-misses:u                  #    6.52% of all branches             (81.82%)
                        TopdownL1                 #      2.5 %  tma_backend_bound      
                                                  #     96.3 %  tma_bad_speculation    
                                                  #     -0.4 %  tma_frontend_bound     
                                                  #      1.6 %  tma_retiring             (90.91%)
 1,016,166,795,867      L1-dcache-loads:u                #  452.704 M/sec                       (90.91%)
    43,974,072,136      L1-dcache-load-misses:u          #    4.33% of all L1-dcache accesses   (90.91%)
       777,620,659      LLC-loads:u                      #  346.431 K/sec                       (90.91%)
       733,211,209      LLC-load-misses:u                #   94.29% of all LL-cache accesses    (81.82%)

     214.510679143 seconds time elapsed

    2129.802199000 seconds user
      22.321096000 seconds sys


Extracting 11402523458 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 183.6663 seconds
Total Performance: 62,082,826 keys-per-second
Unique keys: 11,116,109,642

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 Brawl_in_cell_block_99_(2017)_UHD_BDRip_720p.mkv 1':

      2,754,449.11 msec task-clock:u                     #   12.489 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        22,271,448      page-faults:u                    #    8.086 K/sec                     
 7,573,332,742,688      instructions:u                   #    1.05  insn per cycle              (90.91%)
 7,230,074,546,644      cycles:u                         #    2.625 GHz                         (90.91%)
 1,170,435,576,183      branches:u                       #  424.925 M/sec                       (90.91%)
    68,887,829,627      branch-misses:u                  #    5.89% of all branches             (81.82%)
                        TopdownL1                 #      4.7 %  tma_backend_bound      
                                                  #     95.0 %  tma_bad_speculation    
                                                  #     -0.5 %  tma_frontend_bound     
                                                  #      0.8 %  tma_retiring             (90.91%)
 1,206,217,487,617      L1-dcache-loads:u                #  437.916 M/sec                       (90.91%)
    53,180,816,844      L1-dcache-load-misses:u          #    4.41% of all L1-dcache accesses   (90.91%)
     5,810,570,550      LLC-loads:u                      #    2.110 M/sec                       (90.91%)
       923,528,733      LLC-load-misses:u                #   15.89% of all LL-cache accesses    (81.82%)

     220.544431233 seconds time elapsed

    2630.378806000 seconds user
      28.520519000 seconds sys


Extracting 11402523458 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 184.2720 seconds
Total Performance: 61,878,751 keys-per-second
Unique keys: 11,116,109,642

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark28 Brawl_in_cell_block_99_(2017)_UHD_BDRip_720p.mkv 1"
	User time (seconds): 2711.55
	System time (seconds): 27.43
	Percent of CPU this job got: 1247%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 3:39.53
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 100219504
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 25055281
	Voluntary context switches: 456
	Involuntary context switches: 37648
	Swaps: 0
	File system inputs: 3414624
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0
*/

/*
qsort:
Extracting 998340601 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 105.6141 seconds
Total Performance: 9,452,719 keys-per-second

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_(FB2-1012).tar 2':

        108,437.18 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         3,899,848      page-faults:u                    #   35.964 K/sec                     
   762,455,590,544      instructions:u                   #    1.53  insn per cycle              (90.91%)
   499,221,186,903      cycles:u                         #    4.604 GHz                         (90.91%)
   162,943,125,354      branches:u                       #    1.503 G/sec                       (90.91%)
    10,169,192,584      branch-misses:u                  #    6.24% of all branches             (81.82%)
                        TopdownL1                 #      2.3 %  tma_backend_bound      
                                                  #     97.5 %  tma_bad_speculation    
                                                  #     -0.4 %  tma_frontend_bound     
                                                  #      0.6 %  tma_retiring             (90.91%)
   205,306,023,257      L1-dcache-loads:u                #    1.893 G/sec                       (90.91%)
     8,233,276,053      L1-dcache-load-misses:u          #    4.01% of all L1-dcache accesses   (90.91%)
       123,772,717      LLC-loads:u                      #    1.141 M/sec                       (90.91%)
        70,745,842      LLC-load-misses:u                #   57.16% of all LL-cache accesses    (81.82%)

     108.464918100 seconds time elapsed

     104.177880000 seconds user
       3.499134000 seconds sys

Extracting 998340601 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 112.6477 seconds
Total Performance: 8,862,506 keys-per-second

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 SUPRAPIG_SPETSNAZ-in-Russian_(FB2-1012).tar 2':

        115,375.90 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         3,899,860      page-faults:u                    #   33.801 K/sec                     
   701,063,063,000      instructions:u                   #    1.32  insn per cycle              (90.91%)
   532,424,231,820      cycles:u                         #    4.615 GHz                         (90.91%)
   133,608,491,733      branches:u                       #    1.158 G/sec                       (90.91%)
    10,521,957,591      branch-misses:u                  #    7.88% of all branches             (81.82%)
                        TopdownL1                 #      2.2 %  tma_backend_bound      
                                                  #     97.7 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      0.4 %  tma_retiring             (90.91%)
   205,304,135,347      L1-dcache-loads:u                #    1.779 G/sec                       (90.91%)
     8,230,341,680      L1-dcache-load-misses:u          #    4.01% of all L1-dcache accesses   (90.91%)
       122,294,292      LLC-loads:u                      #    1.060 M/sec                       (90.91%)
        69,841,008      LLC-load-misses:u                #   57.11% of all LL-cache accesses    (81.82%)

     115.404180468 seconds time elapsed

     111.157058000 seconds user
       3.433995000 seconds sys

Extracting 5694801913 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 610.9921 seconds
Total Performance: 9,320,582 keys-per-second

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 2':

        627,104.34 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        22,245,402      page-faults:u                    #   35.473 K/sec                     
 4,753,616,681,616      instructions:u                   #    1.71  insn per cycle              (90.91%)
 2,776,162,721,327      cycles:u                         #    4.427 GHz                         (90.91%)
 1,005,835,596,082      branches:u                       #    1.604 G/sec                       (90.91%)
    49,502,790,940      branch-misses:u                  #    4.92% of all branches             (81.82%)
                        TopdownL1                 #      2.0 %  tma_backend_bound      
                                                  #     98.2 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      0.2 %  tma_retiring             (90.91%)
 1,268,440,096,307      L1-dcache-loads:u                #    2.023 G/sec                       (90.91%)
    52,490,702,203      L1-dcache-load-misses:u          #    4.14% of all L1-dcache accesses   (90.91%)
       806,113,458      LLC-loads:u                      #    1.285 M/sec                       (90.91%)
       486,524,415      LLC-load-misses:u                #   60.35% of all LL-cache accesses    (81.82%)

     627.347498426 seconds time elapsed

     602.255726000 seconds user
      20.192128000 seconds sys

Extracting 5694801913 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 628.6752 seconds
Total Performance: 9,058,416 keys-per-second

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 SUPRAPIG_github.com_Sefaria-Project_2024-Jun-01_16833-TXTs.tar 2':

        644,151.70 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        22,245,410      page-faults:u                    #   34.534 K/sec                     
 4,332,397,831,502      instructions:u                   #    1.50  insn per cycle              (90.91%)
 2,897,027,251,670      cycles:u                         #    4.497 GHz                         (90.91%)
   822,905,463,934      branches:u                       #    1.278 G/sec                       (90.91%)
    49,541,239,380      branch-misses:u                  #    6.02% of all branches             (81.82%)
                        TopdownL1                 #      1.9 %  tma_backend_bound      
                                                  #     98.4 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      0.1 %  tma_retiring             (90.91%)
 1,268,500,608,795      L1-dcache-loads:u                #    1.969 G/sec                       (90.91%)
    52,497,326,588      L1-dcache-load-misses:u          #    4.14% of all L1-dcache accesses   (90.91%)
       827,531,392      LLC-loads:u                      #    1.285 M/sec                       (90.91%)
       509,858,962      LLC-load-misses:u                #   61.61% of all LL-cache accesses    (81.82%)

     644.404570882 seconds time elapsed

     619.387145000 seconds user
      20.124794000 seconds sys

Extracting 6126911481 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 860.6229 seconds
Total Performance: 7,119,159 keys-per-second

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 Nobara-43-GNOME-2026-01-26.iso 2':

        878,082.39 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        23,933,294      page-faults:u                    #   27.256 K/sec                     
 4,978,703,121,441      instructions:u                   #    1.22  insn per cycle              (90.91%)
 4,070,655,649,003      cycles:u                         #    4.636 GHz                         (90.91%)
 1,084,343,675,860      branches:u                       #    1.235 G/sec                       (90.91%)
    98,078,766,609      branch-misses:u                  #    9.04% of all branches             (81.82%)
                        TopdownL1                 #      2.5 %  tma_backend_bound      
                                                  #     97.8 %  tma_bad_speculation    
                                                  #     -0.5 %  tma_frontend_bound     
                                                  #      0.1 %  tma_retiring             (90.91%)
 1,367,276,452,972      L1-dcache-loads:u                #    1.557 G/sec                       (90.91%)
    56,801,443,171      L1-dcache-load-misses:u          #    4.15% of all L1-dcache accesses   (90.91%)
       955,293,720      LLC-loads:u                      #    1.088 M/sec                       (90.91%)
       592,192,679      LLC-load-misses:u                #   61.99% of all LL-cache accesses    (81.82%)

     878.294748079 seconds time elapsed

     849.925523000 seconds user
      22.045097000 seconds sys

Extracting 6126911481 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 941.1377 seconds
Total Performance: 6,510,111 keys-per-second

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 Nobara-43-GNOME-2026-01-26.iso 2':

        958,574.18 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        23,933,302      page-faults:u                    #   24.968 K/sec                     
 4,670,662,541,916      instructions:u                   #    1.07  insn per cycle              (90.91%)
 4,374,132,625,721      cycles:u                         #    4.563 GHz                         (90.91%)
   887,024,212,481      branches:u                       #  925.358 M/sec                       (90.91%)
   100,577,546,652      branch-misses:u                  #   11.34% of all branches             (81.82%)
                        TopdownL1                 #      2.4 %  tma_backend_bound      
                                                  #     97.9 %  tma_bad_speculation    
                                                  #     -0.4 %  tma_frontend_bound     
                                                  #      0.1 %  tma_retiring             (90.91%)
 1,367,314,942,871      L1-dcache-loads:u                #    1.426 G/sec                       (90.91%)
    56,832,779,980      L1-dcache-load-misses:u          #    4.16% of all L1-dcache accesses   (90.91%)
       927,515,829      LLC-loads:u                      #  967.599 K/sec                       (90.91%)
       568,188,494      LLC-load-misses:u                #   61.26% of all LL-cache accesses    (81.82%)

     958.796468887 seconds time elapsed

     929.460106000 seconds user
      22.423730000 seconds sys

Extracting 9758687449 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
./benchmark28: Killed

 Performance counter stats for './benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 2':

      1,184,889.54 msec task-clock:u                     #    0.997 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        32,113,221      page-faults:u                    #   27.102 K/sec                     
 8,136,659,203,902      instructions:u                   #    1.54  insn per cycle              (90.91%)
 5,300,587,386,069      cycles:u                         #    4.473 GHz                         (90.91%)
 1,724,568,030,825      branches:u                       #    1.455 G/sec                       (90.91%)
   106,737,552,222      branch-misses:u                  #    6.19% of all branches             (81.82%)
                        TopdownL1                 #      2.2 %  tma_backend_bound      
                                                  #     98.1 %  tma_bad_speculation    
                                                  #     -0.4 %  tma_frontend_bound     
                                                  #      0.1 %  tma_retiring             (90.91%)
 2,176,715,420,518      L1-dcache-loads:u                #    1.837 G/sec                       (90.91%)
    90,078,303,839      L1-dcache-load-misses:u          #    4.14% of all L1-dcache accesses   (90.91%)
     1,358,996,489      LLC-loads:u                      #    1.147 M/sec                       (90.91%)
       843,164,809      LLC-load-misses:u                #   62.04% of all LL-cache accesses    (81.82%)

    1187.971230797 seconds time elapsed

    1148.805797000 seconds user
      30.002362000 seconds sys


Extracting 9758687449 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
./benchmark28: Killed

 Performance counter stats for './benchmark28 SUPRAPIG_news.ycombinator.com-items-201909_21M-news.ycombinator.com.jsonl 2':

      1,233,714.87 msec task-clock:u                     #    0.997 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        32,102,877      page-faults:u                    #   26.021 K/sec                     
 7,445,969,993,807      instructions:u                   #    1.34  insn per cycle              (90.91%)
 5,575,375,744,923      cycles:u                         #    4.519 GHz                         (90.91%)
 1,407,294,126,792      branches:u                       #    1.141 G/sec                       (90.91%)
   108,315,109,847      branch-misses:u                  #    7.70% of all branches             (81.82%)
                        TopdownL1                 #      2.1 %  tma_backend_bound      
                                                  #     98.2 %  tma_bad_speculation    
                                                  #     -0.4 %  tma_frontend_bound     
                                                  #      0.1 %  tma_retiring             (90.91%)
 2,176,787,236,210      L1-dcache-loads:u                #    1.764 G/sec                       (90.91%)
    90,097,189,613      L1-dcache-load-misses:u          #    4.14% of all L1-dcache accesses   (90.91%)
     1,333,719,878      LLC-loads:u                      #    1.081 M/sec                       (90.91%)
       811,196,078      LLC-load-misses:u                #   60.82% of all LL-cache accesses    (81.82%)

    1236.989750378 seconds time elapsed

    1198.151578000 seconds user
      29.279156000 seconds sys

[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update]$ 
*/

// Quicksort 'Charlatana_UQWORD_AVX2' vs qsort():
// Bottomline first: Quicksort 'Charlatana_UQWORD_AVX2' is 100,548,436 KPS / 9,675,092 KPS = 10.39x faster than qsort().
// Testmachine: Laptop Dell Precision 7560, Core i7-11850H (Tiger Lake-H). 128GB DDR4 3200MHz, OS: Fedora Linux 42
// Testcorpus: Human Genome (sorting all 8 bytes long chuncks - BBs - BuildingBlocks)
// +----------------------------------------+------[ SORTED ]-+--------+-------------------------------------------------+
// | Sort Function, (Compiler)              | Keys-Per-Second |   Time |                    Giga-Instructions-Per-Second |
// +----------------------------------------+-----------------+--------+-------------------------------------------------+
// | Charlatana_UQWORD_AVX512, GCC 15.2.1   | 114,867,502 KPS |  28.8s |   415,877,653,143i/ 28.8s = 14,440,196,289 GIPS |
// | Charlatana_UQWORD_AVX2, GCC 15.2.1     | 100,548,436 KPS |  32.9s |   933,123,132,569i/ 32.9s = 28,362,405,245 GIPS |
// | Charlatana_UQWORD_AVX512, CLANG 20.1.8 |  98,404,826 KPS |  33.6s |   945,379,013,838i/ 33.6s = 28,136,280,173 GIPS |
// | Charlatana_UQWORD_AVX2, CLANG 20.1.8   |  87,842,997 KPS |  37.7s | 1,314,843,354,298i/ 37.7s = 34,876,481,546 GIPS |
// | qsort(),GCC 15.2.1                     |   9,675,092 KPS | 342.4s | 2,642,946,084,482i/342.4s =  7,718,884,592 GIPS |
// | qsort(),CLANG 20.1.8                   |   8,881,970 KPS | 373.0s | 2,408,798,523,104i/373.0s =  6,457,904,887 GIPS |
// +----------------------------------------+-----------------+--------+-------------------------------------------------+
// Note1: Memory footprint is 29,120,748 KB, meaning 32GB RAM are needed.
// Note2: The third Performance statistic, GIPS, is not telling well how fast the compiled-function is, the KPS is the "story teller".
// Note3: The CPU utilization is quite qood (FOR VECTOR CODE), "8.960 CPUs utilized", for the TOP (GCC) result.
// Note4: The testfile is highly redundant (971:1), unique UQWORD-wise, "Unique keys: 3,411,451", that is 3,313,061,624 non-Unique : 3,411,451 Unique.
/*
[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update_2026-Mar-18]$ sh bench28.sh 
20.1.8
15.2.1

Extracting 3313061624 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 32.9499 seconds
Total Performance: 100,548,436 keys-per-second
Unique keys: 3,411,451

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 1':

        390,203.02 msec task-clock:u                     #    8.960 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         6,471,342      page-faults:u                    #   16.585 K/sec                     
   933,123,132,569      instructions:u                   #    0.82  insn per cycle              (90.90%)
 1,137,294,040,482      cycles:u                         #    2.915 GHz                         (90.91%)
   117,698,509,837      branches:u                       #  301.634 M/sec                       (90.91%)
     6,089,659,651      branch-misses:u                  #    5.17% of all branches             (81.82%)
                        TopdownL1                 #      3.0 %  tma_backend_bound      
                                                  #     93.2 %  tma_bad_speculation    
                                                  #     -0.1 %  tma_frontend_bound     
                                                  #      3.9 %  tma_retiring             (90.91%)
   144,832,727,838      L1-dcache-loads:u                #  371.173 M/sec                       (90.91%)
    10,634,282,776      L1-dcache-load-misses:u          #    7.34% of all L1-dcache accesses   (90.91%)
       209,767,067      LLC-loads:u                      #  537.584 K/sec                       (90.91%)
       200,605,979      LLC-load-misses:u                #   95.63% of all LL-cache accesses    (81.81%)

      43.548402808 seconds time elapsed

     369.553758000 seconds user
       6.366808000 seconds sys

Extracting 3313061624 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 37.7157 seconds
Total Performance: 87,842,997 keys-per-second
Unique keys: 3,411,451

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 1':

        567,610.13 msec task-clock:u                     #   11.785 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         6,471,567      page-faults:u                    #   11.401 K/sec                     
 1,314,843,354,298      instructions:u                   #    0.80  insn per cycle              (90.91%)
 1,640,261,908,377      cycles:u                         #    2.890 GHz                         (90.91%)
   208,258,520,895      branches:u                       #  366.904 M/sec                       (90.91%)
     8,226,881,845      branch-misses:u                  #    3.95% of all branches             (81.82%)
                        TopdownL1                 #      7.7 %  tma_backend_bound      
                                                  #     89.9 %  tma_bad_speculation    
                                                  #      0.0 %  tma_frontend_bound     
                                                  #      2.4 %  tma_retiring             (90.91%)
   246,429,661,289      L1-dcache-loads:u                #  434.153 M/sec                       (90.91%)
    13,385,049,064      L1-dcache-load-misses:u          #    5.43% of all L1-dcache accesses   (90.91%)
     1,739,365,399      LLC-loads:u                      #    3.064 M/sec                       (90.91%)
       249,325,625      LLC-load-misses:u                #   14.33% of all LL-cache accesses    (81.82%)

      48.165520187 seconds time elapsed

     541.565271000 seconds user
       8.384866000 seconds sys

Extracting 3313061624 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 37.1803 seconds
Total Performance: 89,108,023 keys-per-second
Unique keys: 3,411,451

--- Verification ---
Array properly sorted: YES
	Command being timed: "./benchmark28 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 1"
	User time (seconds): 546.98
	System time (seconds): 8.07
	Percent of CPU this job got: 1174%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 0:47.26
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 29120748
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 0
	Minor (reclaiming a frame) page faults: 7280436
	Voluntary context switches: 78
	Involuntary context switches: 11525
	Swaps: 0
	File system inputs: 0
	File system outputs: 0
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0

Extracting 3313061624 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 342.4320 seconds
Total Performance: 9,675,092 keys-per-second
Unique keys: 3,411,451

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 2':

        352,950.26 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        12,941,726      page-faults:u                    #   36.667 K/sec                     
 2,642,946,084,482      instructions:u                   #    1.63  insn per cycle              (90.91%)
 1,617,911,635,969      cycles:u                         #    4.584 GHz                         (90.91%)
   558,879,975,061      branches:u                       #    1.583 G/sec                       (90.91%)
    30,099,998,784      branch-misses:u                  #    5.39% of all branches             (81.82%)
                        TopdownL1                 #      2.1 %  tma_backend_bound      
                                                  #     98.0 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      0.2 %  tma_retiring             (90.91%)
   705,872,542,626      L1-dcache-loads:u                #    2.000 G/sec                       (90.91%)
    29,669,347,089      L1-dcache-load-misses:u          #    4.20% of all L1-dcache accesses   (90.91%)
       629,263,511      LLC-loads:u                      #    1.783 M/sec                       (90.91%)
       430,778,208      LLC-load-misses:u                #   68.46% of all LL-cache accesses    (81.82%)

     353.036213165 seconds time elapsed

     338.661765000 seconds user
      11.766211000 seconds sys

Extracting 3313061624 keys...

--- Starting Benchmark ---
Algorithm: Standard C qsort() [Single Threaded]
Sort Time: 373.0097 seconds
Total Performance: 8,881,970 keys-per-second
Unique keys: 3,411,451

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark28 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 2':

        383,391.29 msec task-clock:u                     #    1.000 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
        12,941,739      page-faults:u                    #   33.756 K/sec                     
 2,408,798,523,104      instructions:u                   #    1.42  insn per cycle              (90.91%)
 1,699,651,544,982      cycles:u                         #    4.433 GHz                         (90.91%)
   457,151,900,824      branches:u                       #    1.192 G/sec                       (90.91%)
    30,991,379,910      branch-misses:u                  #    6.78% of all branches             (81.82%)
                        TopdownL1                 #      2.0 %  tma_backend_bound      
                                                  #     98.1 %  tma_bad_speculation    
                                                  #     -0.3 %  tma_frontend_bound     
                                                  #      0.2 %  tma_retiring             (90.91%)
   705,816,233,788      L1-dcache-loads:u                #    1.841 G/sec                       (90.91%)
    29,690,516,507      L1-dcache-load-misses:u          #    4.21% of all L1-dcache accesses   (90.91%)
       679,215,631      LLC-loads:u                      #    1.772 M/sec                       (90.91%)
       488,482,310      LLC-load-misses:u                #   71.92% of all LL-cache accesses    (81.82%)

     383.479187688 seconds time elapsed

     368.879978000 seconds user
      11.699436000 seconds sys

[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update_2026-Mar-18]$ fastfetch
             .',;::::;,'.                 sanmayce@djudjeto
         .';:cccccccccccc:;,.             -----------------
      .;cccccccccccccccccccccc;.          OS: Fedora Linux 42 (MATE-Compiz) x86_64
    .:cccccccccccccccccccccccccc:.        Host: Precision 7560
  .;ccccccccccccc;.:dddl:.;ccccccc;.      Kernel: Linux 6.16.4-200.fc42.x86_64
 .:ccccccccccccc;OWMKOOXMWd;ccccccc:.     Uptime: 21 days, 16 hours, 5 mins
.:ccccccccccccc;KMMc;cc;xMMc;ccccccc:.    Packages: 5234 (rpm), 13 (snap)
,cccccccccccccc;MMM.;cc;;WW:;cccccccc,    Shell: bash 5.2.37
:cccccccccccccc;MMM.;cccccccccccccccc:    Display (LGD05F2): 1920x1080 @ 60 Hz in 16" [Built-in]
:ccccccc;oxOOOo;MMM000k.;cccccccccccc:    DE: Mate 1.28.2
cccccc;0MMKxdd:;MMMkddc.;cccccccccccc;    WM: Marco (X11)
ccccc;XMO';cccc;MMM.;cccccccccccccccc'    WM Theme: Spidey-Left
ccccc;MMo;ccccc;MMW.;ccccccccccccccc;     Theme: Adwaita-dark [GTK2/3/4]
ccccc;0MNc.ccc.xMMd;ccccccccccccccc;      Icons: mate [GTK2/3/4]
cccccc;dNMWXXXWM0:;cccccccccccccc:,       Font: MxPlus ToshibaTxL2 8x16 (16pt) [GTK2/3/4]
cccccccc;.:odl:.;cccccccccccccc:,.        Cursor: mate (24px)
ccccccccccccccccccccccccccccc:'.          Terminal: mate-terminal 1.28.1
:ccccccccccccccccccccccc:;,..             Terminal Font: MxPlus ToshibaTxL2 8x16 (16pt)
 ':cccccccccccccccc::;,.                  CPU: 11th Gen Intel(R) Core(TM) i7-11850H (16) @ 4.80 GHz
                                          GPU: Intel UHD Graphics @ 1.45 GHz [Integrated]
                                          Memory: 2.94 GiB / 125.00 GiB (2%)
                                          Swap: Disabled
                                          Disk (/): 213.76 GiB / 1.79 TiB (12%) - ext4
                                          Disk (/run/media/sanmayce/A400-480_Master): 285.03 GiB / 447.13 GiB (64%) - fuseblk
                                          Disk (/run/media/sanmayce/A400-960GB_Movies): 867.97 GiB / 894.25 GiB (97%) - fuseblk
                                          Disk (/run/media/sanmayce/Lexar_4TB): 3.46 TiB / 3.67 TiB (94%) - ext4
                                          Disk (/run/media/sanmayce/Torbalan_MP600): 1.71 TiB / 1.82 TiB (94%) - fuseblk
                                          Disk (/run/media/sanmayce/sx): 318.21 GiB / 477.50 GiB (67%) - fuseblk
                                          Battery (DELL CR72X21): 68% [AC Connected]
                                          Locale: en_US.UTF-8
*/

// The 512 beast:
/*
[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update_2026-Mar-18]$ gcc -O3 -mavx512f -fopenmp -std=gnu11 -o benchmark29 benchmark29.c
[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update_2026-Mar-18]$ perf stat -d ./benchmark29 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 1
Extracting 3313061624 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 28.8425 seconds
Total Performance: 114,867,502 keys-per-second
Unique keys: 3,411,451

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 1':

        317,749.15 msec task-clock:u                     #    8.077 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         6,471,337      page-faults:u                    #   20.366 K/sec                     
   415,877,653,143      instructions:u                   #    0.38  insn per cycle              (90.91%)
 1,084,714,946,647      cycles:u                         #    3.414 GHz                         (90.90%)
    68,292,683,988      branches:u                       #  214.926 M/sec                       (90.91%)
     2,506,529,767      branch-misses:u                  #    3.67% of all branches             (81.82%)
                        TopdownL1                 #     14.3 %  tma_backend_bound      
                                                  #     84.7 %  tma_bad_speculation    
                                                  #     -0.2 %  tma_frontend_bound     
                                                  #      1.1 %  tma_retiring             (90.91%)
    58,696,843,153      L1-dcache-loads:u                #  184.727 M/sec                       (90.91%)
    10,900,937,425      L1-dcache-load-misses:u          #   18.57% of all L1-dcache accesses   (90.91%)
       500,860,752      LLC-loads:u                      #    1.576 M/sec                       (90.91%)
       485,751,397      LLC-load-misses:u                #   96.98% of all LL-cache accesses    (81.82%)

      39.339132921 seconds time elapsed

     302.794319000 seconds user
       6.382763000 seconds sys


[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update_2026-Mar-18]$ clang -O3 -mavx512f -fopenmp -std=gnu11 -o benchmark29 benchmark29.c
[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update_2026-Mar-18]$ perf stat -d ./benchmark29 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 1
Extracting 3313061624 keys...

--- Starting Benchmark ---
Algorithm: Charlatana_v29
OpenMP Engine: Utilizing up to 16 Hardware Threads
Sort Time: 33.6677 seconds
Total Performance: 98,404,826 keys-per-second
Unique keys: 3,411,451

--- Verification ---
Array properly sorted: YES

 Performance counter stats for './benchmark29 www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna 1':

        514,764.86 msec task-clock:u                     #   11.222 CPUs utilized             
                 0      context-switches:u               #    0.000 /sec                      
                 0      cpu-migrations:u                 #    0.000 /sec                      
         6,471,556      page-faults:u                    #   12.572 K/sec                     
   945,379,013,838      instructions:u                   #    0.59  insn per cycle              (90.91%)
 1,592,955,931,194      cycles:u                         #    3.095 GHz                         (90.91%)
   180,069,044,361      branches:u                       #  349.808 M/sec                       (90.91%)
     5,278,231,770      branch-misses:u                  #    2.93% of all branches             (81.82%)
                        TopdownL1                 #      8.1 %  tma_backend_bound      
                                                  #     90.1 %  tma_bad_speculation    
                                                  #      0.1 %  tma_frontend_bound     
                                                  #      1.7 %  tma_retiring             (90.91%)
   191,185,019,866      L1-dcache-loads:u                #  371.403 M/sec                       (90.91%)
    13,942,845,674      L1-dcache-load-misses:u          #    7.29% of all L1-dcache accesses   (90.91%)
     2,030,920,450      LLC-loads:u                      #    3.945 M/sec                       (90.91%)
       368,229,724      LLC-load-misses:u                #   18.13% of all LL-cache accesses    (81.82%)

      45.872662761 seconds time elapsed

     492.585142000 seconds user
       8.900211000 seconds sys


[sanmayce@djudjeto Quicksort_benchmark_2024-Nov-28_update_2026-Mar-18]$ 
*/

