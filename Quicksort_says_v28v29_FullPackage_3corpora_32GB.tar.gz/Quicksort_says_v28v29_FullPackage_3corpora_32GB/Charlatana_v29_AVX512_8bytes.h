// Moving to AVX-512 is actually going to make the code much cleaner and potentially much faster.
// The beauty of AVX-512 is that Intel introduced native unsigned 64-bit compares and, most importantly, the Compress Store instruction (_mm512_mask_compressstoreu_epi64).
// In the AVX2 version (v28), you had to use massive lookup tables (QWORD_PACK_TABLE, MASK_STORE_TABLE) and messy cross-lane shuffles (_mm256_permutevar8x32_epi32) just to pack the elements to the left or right. AVX-512 does this natively in hardware. You hand it a mask of which elements are < pivot, and the CPU condenses and writes them sequentially to memory in one single instruction.
// Here is Charlatana_v29 (AVX-512). It uses the exact same algorithmic structure, thresholds, and buffer logic as your fastest v33 variant, but scales the processing block from 4 elements to 8 elements using pure AVX-512.

// Why this is structurally identical, but superior:
// - The 8-Element Jump: The while loop checks read_ptr_R - read_ptr_L >= 8 instead of 4. The buffers and conditions scale perfectly natively.
// - Native Comparisons: _mm512_cmp_epu64_mask calculates the boolean mask natively using the _MM_CMPINT_LT (Less Than) hardware flag, completely removing the awkward 0x8000000000000000ULL XOR hack from AVX2.
// - The Magic of Compress Store: _mm512_mask_compressstoreu_epi64 takes the 512-bit register and a mask, and dynamically squashes all the "true" elements sequentially into memory. This eliminates all permutation math, saving instructions and cycles.
// To benchmark this, be sure to compile with -mavx512f (or -march=native if running on a Zen 4 / Intel Sapphire Rapids or newer CPU).

#ifndef CHARLATANA_V29_H
#define CHARLATANA_V29_H

#include <immintrin.h>
#include <stdint.h>
#include <stddef.h>
#include <omp.h>

// DECOUPLED THRESHOLDS: 
// Don't spawn OpenMP tasks for tiny chunks. It chokes the thread queue.
#define OMP_TASK_THRESHOLD 100000
#define INSERTION_THRESHOLD 64

// Notice: No permutation or mask tables required! AVX-512 handles this natively.

static void charlatana_insertion_sort(uint64_t* arr, int64_t low, int64_t high) {
    if (high <= low) return;
    
    uint64_t* base = arr + low;
    int64_t   n    = high - low + 1;

    int64_t min_idx = 0;
    for (int64_t k = 1; k < n; k++) {
        if (base[k] < base[min_idx]) min_idx = k;
    }
    uint64_t tmp = base[0];
    base[0]      = base[min_idx];
    base[min_idx]= tmp;

    for (int64_t i = 1; i < n; i++) {
        uint64_t  key  = base[i];
        uint64_t* jptr = base + i - 1;

        while (*jptr > key) {
            *(jptr + 1) = *jptr;
            jptr--;
        }
        *(jptr + 1) = key;
    }
}

static void charlatana_v29_recursive(uint64_t* arr, int64_t low, int64_t high) {
    while (low < high) {
        
        int64_t delta = high - low;
        uint64_t v1   = arr[low   + delta / 4];
        uint64_t v2   = arr[low   + delta / 2];
        uint64_t v3   = arr[high  - delta / 4];

        // Fast Branchless Median-of-3 using XOR tricks
        uint64_t mask_min_xy = -(uint64_t)(v1 > v2);
        uint64_t mask_max_xy = -(uint64_t)(v1 < v2);
        uint64_t min_xy = v1 ^ ((v1 ^ v2) & mask_min_xy);
        uint64_t max_xy = v1 ^ ((v1 ^ v2) & mask_max_xy);

        uint64_t mask_min = -(uint64_t)(min_xy > v3);
        uint64_t overall_min = min_xy ^ ((min_xy ^ v3) & mask_min);

        uint64_t mask_max = -(uint64_t)(max_xy < v3);
        uint64_t overall_max = max_xy ^ ((max_xy ^ v3) & mask_max);

        uint64_t pivot = v1 ^ v2 ^ v3 ^ overall_min ^ overall_max;

        // Broadcast pivot to all 8 lanes of the 512-bit register
        __m512i v_pivot = _mm512_set1_epi64(pivot);
        
        uint64_t* read_ptr_L = arr + low;
        uint64_t* write_ptr_L = arr + low;
        uint64_t* read_ptr_R = arr + high + 1;
        uint64_t* write_ptr_R = arr + high + 1;

        uint64_t buf_L[256];
        uint64_t buf_R[256];
        int count_L = 0;
        int count_R = 0;

        // Process 8 elements (512 bits) per iteration instead of 4
        while (read_ptr_R - read_ptr_L >= 8) {
            if (count_L > count_R) {
                // Read 8 elements from Left
                __m512i v = _mm512_loadu_si512(read_ptr_L);
                read_ptr_L += 8;
                
                // Native AVX-512 Unsigned Compare (Less Than)
                __mmask8 mask_lt = _mm512_cmp_epu64_mask(v, v_pivot, _MM_CMPINT_LT);
                int k_lt = __builtin_popcount(mask_lt);
                // Hardware Compress Store: Packs matched elements into contiguous memory
                _mm512_mask_compressstoreu_epi64(write_ptr_L, mask_lt, v);
                write_ptr_L += k_lt;
                
                // Native AVX-512 Unsigned Compare (Greater Than)
                __mmask8 mask_gt = _mm512_cmp_epu64_mask(v, v_pivot, _MM_CMPINT_GT);
                int k_gt = __builtin_popcount(mask_gt);
                _mm512_mask_compressstoreu_epi64(buf_R + count_R, mask_gt, v);
                count_R += k_gt;
                
                int space_L = read_ptr_L - write_ptr_L;
                if (count_L > 0 && space_L >= count_L) {
                    for (int k = 0; k < count_L; k++) write_ptr_L[k] = buf_L[k];
                    write_ptr_L += count_L;
                    count_L = 0;
                }
            } else {
                // Read 8 elements from Right
                read_ptr_R -= 8;
                __m512i v = _mm512_loadu_si512(read_ptr_R);
                
                // Native AVX-512 Unsigned Compare (Greater Than)
                __mmask8 mask_gt = _mm512_cmp_epu64_mask(v, v_pivot, _MM_CMPINT_GT);
                int k_gt = __builtin_popcount(mask_gt);
                write_ptr_R -= k_gt;
                _mm512_mask_compressstoreu_epi64(write_ptr_R, mask_gt, v);
                
                // Native AVX-512 Unsigned Compare (Less Than)
                __mmask8 mask_lt = _mm512_cmp_epu64_mask(v, v_pivot, _MM_CMPINT_LT);
                int k_lt = __builtin_popcount(mask_lt);
                _mm512_mask_compressstoreu_epi64(buf_L + count_L, mask_lt, v);
                count_L += k_lt;
                
                int space_R = write_ptr_R - read_ptr_R;
                if (count_R > 0 && space_R >= count_R) {
                    write_ptr_R -= count_R;
                    for (int k = 0; k < count_R; k++) write_ptr_R[k] = buf_R[k];
                    count_R = 0;
                }
            }
        }

        // Scalar cleanup for the remaining < 8 elements
        while (read_ptr_L < read_ptr_R) {
            uint64_t val = *read_ptr_L;
            int is_lt = (val < pivot);
            int is_gt = (val > pivot);
            
            *write_ptr_L = val;
            write_ptr_L += is_lt;
            
            buf_R[count_R] = val;
            count_R += is_gt;
            
            read_ptr_L++;
        }

        for (int k = 0; k < count_L; k++) *write_ptr_L++ = buf_L[k];
        write_ptr_R -= count_R;
        for (int k = 0; k < count_R; k++) write_ptr_R[k] = buf_R[k];

        uint64_t* end_lt = write_ptr_L; 
        uint64_t* start_gt = write_ptr_R;

        // Elements strictly equal to the pivot
        while (write_ptr_L < write_ptr_R) {
            *write_ptr_L++ = pivot;
        }

        // --- Streamlined Tail Routing (identical to fastest v33 logic) ---
        int64_t p_left = (end_lt - arr) - 1;
        int64_t p_right = (start_gt - arr);

        int64_t len_L = p_left - low + 1;
        int64_t len_R = high - p_right + 1;

        if (len_L < len_R) {
            if (len_R > INSERTION_THRESHOLD) {
                if (len_R > OMP_TASK_THRESHOLD) {
                    #pragma omp task default(none) firstprivate(arr, p_right, high)
                    charlatana_v29_recursive(arr, p_right, high);
                } else {
                    charlatana_v29_recursive(arr, p_right, high);
                }
            } else {
                charlatana_insertion_sort(arr, p_right, high);
            }

            if (len_L > INSERTION_THRESHOLD) {
                high = p_left; 
            } else {
                charlatana_insertion_sort(arr, low, p_left);
                break; 
            }
        } else {
            if (len_L > INSERTION_THRESHOLD) {
                if (len_L > OMP_TASK_THRESHOLD) {
                    #pragma omp task default(none) firstprivate(arr, low, p_left)
                    charlatana_v29_recursive(arr, low, p_left);
                } else {
                    charlatana_v29_recursive(arr, low, p_left);
                }
            } else {
                charlatana_insertion_sort(arr, low, p_left);
            }

            if (len_R > INSERTION_THRESHOLD) {
                low = p_right; 
            } else {
                charlatana_insertion_sort(arr, p_right, high);
                break; 
            }
        }
    }
}

static inline void Charlatana_Sort(uint64_t* arr, size_t n) {
    if (n <= INSERTION_THRESHOLD) {
        charlatana_insertion_sort(arr, 0, (int64_t)(n - 1));
        return;
    }
    
    #pragma omp parallel
    {
        #pragma omp single
        {
            charlatana_v29_recursive(arr, 0, (int64_t)(n - 1));
        }
    }
}

#endif // CHARLATANA_V29_H

