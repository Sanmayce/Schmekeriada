/*
COMPILE WITH OPENMP:
$ gcc -O3 -mavx2 -fopenmp -std=gnu11 -o benchmark28_13attempts benchmark28_13attempts.c

Usage: 
  ./benchmark28 <file_to_sort> <algorithm_choice>
  
Algorithms:
  1 = Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)
  2 = Standard C qsort()
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <omp.h>
#include <locale.h>
#include <unistd.h> // Required for sleep()


// Copyright 2021 Justine Alexandra Roberts Tunney [
static inline void InsertionSort(uint64_t *A, uint64_t n) {
  uint64_t i, j, t;
  for (i = 1; i < n; i++) {
    t = A[i];
    j = i - 1;
    while (j >= 0 && A[j] > t) {
      A[j + 1] = A[j];
      j = j - 1;
    }
    A[j + 1] = t;
  }
}
static void LongSort(uint64_t *A, uint64_t n) {
  uint64_t t, p, i, j;
  if (n <= 32) {
    InsertionSort(A, n);
  } else {
    for (p = A[n >> 1], i = 0, j = n - 1;; i++, j--) {
      while (A[i] < p)
        i++;
      while (A[j] > p)
        j--;
      if (i >= j)
        break;
      t = A[i];
      A[i] = A[j];
      A[j] = t;
    }
    LongSort(A, i);
    LongSort(A + i, n - i);
  }
}
// Copyright 2021 Justine Alexandra Roberts Tunney ]

#include "Charlatana_v28.h"

int compare_uint64(const void* a, const void* b) {
    uint64_t val_a = *(const uint64_t*)a;
    uint64_t val_b = *(const uint64_t*)b;
    if (val_a < val_b) return -1;
    if (val_a > val_b) return 1;
    return 0;
}

bool is_sorted(uint64_t* arr, size_t n) {
    for (size_t i = 1; i < n; i++) {
        if (arr[i - 1] > arr[i]) return false;
    }
    return true;
}

int main(int argc, char *argv[]) {
    // Enable comma-formatted thousands for performance numbers
    setlocale(LC_NUMERIC, "");

    if (argc != 3) {
        fprintf(stderr, "Usage: %s <file_to_sort> <algorithm>\n", argv[0]);
        fprintf(stderr, "Algorithms:\n  1 = Charlatana_v28\n  2 = Standard qsort()\n");
        return EXIT_FAILURE;
    }

    const char* filename = argv[1];
    int algo_choice = atoi(argv[2]);

    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Error opening file");
        return EXIT_FAILURE;
    }

    fseek(file, 0, SEEK_END);
    long filesize = ftell(file);
    fseek(file, 0, SEEK_SET);

    if (filesize < 8) {
        fprintf(stderr, "Error: File is too small.\n");
        fclose(file);
        return EXIT_FAILURE;
    }

    uint8_t *file_buffer = (uint8_t*)malloc(filesize);
    if (!file_buffer) {
        perror("Memory allocation for file failed");
        return EXIT_FAILURE;
    }
    
    fread(file_buffer, 1, filesize, file);
    fclose(file);

    size_t num_keys = filesize - 8 + 1;
    printf("Extracting %'zu keys...\n", num_keys);

    uint64_t *keys = (uint64_t*)malloc(num_keys * sizeof(uint64_t));
    if (!keys) {
        perror("Memory allocation for keys failed");
        free(file_buffer);
        return EXIT_FAILURE;
    }

    printf("\n--- Starting Benchmark (13 Iterations) ---\n");
    if (algo_choice == 1) {
        printf("Algorithm: Charlatana_v28 (Branchless OpenMP + AVX2 In-Place)\n");
        printf("OpenMP Engine: Utilizing up to %d Hardware Threads\n\n", omp_get_max_threads());
    } else {
        printf("Algorithm: Standard C qsort() [Single Threaded]\n\n");
    }

    uint64_t max_kps = 0;
    double best_elapsed = 0.0;
    int best_run_index = 0;

    // Execute 13 independent runs
    for (int iter = 1; iter <= 13; iter++) {
        
        // 1. Thermal Cool-off (Skip on the very first run)
        if (iter > 1) {
            sleep(9); 
        }

        // 2. Restore the array to its original UNSORTED state from the master buffer
        #pragma omp parallel for
        for (size_t i = 0; i < num_keys; i++) {
            memcpy(&keys[i], &file_buffer[i], sizeof(uint64_t));
        }

        // 3. Execute and Time the Sort
        double start_time = omp_get_wtime();
        
        if (algo_choice == 1) {
            Charlatana_Sort(keys, num_keys);
        } else if (algo_choice == 2) {
            //qsort(keys, num_keys, sizeof(uint64_t), compare_uint64);
            LongSort(keys, num_keys);
        } 
        
        double end_time = omp_get_wtime();
        double elapsed = end_time - start_time;

        // 4. Calculate and log Performance
        uint64_t kps = 0;
        if (elapsed > 0.0) {
            kps = (uint64_t)(num_keys / elapsed);
        }

        printf("Run %2d: %'14llu KPS  (%.4f seconds)\n", iter, (unsigned long long)kps, elapsed);

        // 5. Track the Absolute Best Run
        if (kps > max_kps) {
            max_kps = kps;
            best_elapsed = elapsed;
            best_run_index = iter;
        }
    }

    // Free the unsorted master buffer as we no longer need to restore it
    free(file_buffer);

    printf("--------------------------------------------------\n");
    printf(">>> BEST RUN: Run %d with %'llu KPS (%.4f seconds) <<<\n", 
           best_run_index, (unsigned long long)max_kps, best_elapsed);
    printf("--------------------------------------------------\n");

    /* === UNIQUE KEYS COUNT (Calculated on the final sorted output) === */
    size_t unique_keys = 0;
    if (num_keys > 0) {
        unique_keys = 1;
        for (size_t i = 1; i < num_keys; i++) {
            if (keys[i] != keys[i - 1]) {
                unique_keys++;
            }
        }
    }
    printf("\nUnique keys: %'zu\n", unique_keys);

    /* === VERIFICATION === */
    printf("--- Verification ---\n");
    bool is_properly_sorted = is_sorted(keys, num_keys);
    printf("Array properly sorted: %s\n", is_properly_sorted ? "YES" : "NO");

    free(keys);
    return EXIT_SUCCESS;
}

