# Run first $ su

lscpu
dmidecode --type 1
dmidecode --type 17

clang -v 2>clangvq
clang_version=$(cat clangvq | grep "clang version" | awk '{print $(NF-2)}')
echo $clang_version
rm clangvq

clang -o Quicksort_UQWORDS_clang_"$clang_version".elf -O3 -mavx2 -fopenmp -std=gnu11 benchmark28_13attempts.c -DCommence_OpenMP
clang -o Quicksort_UQWORDS_clang_"$clang_version".elf.asm -O3 -mavx2 -fopenmp -std=gnu11 benchmark28_13attempts.c -S -DCommence_OpenMP

gcc -v 2>gccvq
gcc_version=$(cat gccvq | grep "gcc version" | awk '{print $(NF-5)}')
echo $gcc_version
rm gccvq

gcc -o Quicksort_UQWORDS_gcc_"$gcc_version".elf -O3 -mavx2 -fopenmp -std=gnu11 benchmark28_13attempts.c -DCommence_OpenMP
gcc -o Quicksort_UQWORDS_gcc_"$gcc_version".elf.asm -O3 -mavx2 -fopenmp -std=gnu11 benchmark28_13attempts.c -S -DCommence_OpenMP

# Set CPU to performance mode for all CPUs
echo "Setting CPU to performance mode..."
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance | tee $cpu > /dev/null
done

cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor

echo "Clearing all the buffers..."
sh -c 'echo 3 >/proc/sys/vm/drop_caches'

echo "Running sort benchmark with highest priority..."
echo

sleep 5
echo "Buffering the testdatafile..."
cp "corpora/3gib_fib_lastdigit.bin" /dev/null
nice -n -20 ./Quicksort_UQWORDS_gcc_"$gcc_version".elf "corpora/3gib_fib_lastdigit.bin" 1
nice -n -20 ./Quicksort_UQWORDS_clang_"$clang_version".elf "corpora/3gib_fib_lastdigit.bin" 1

sleep 5
echo "Buffering the testdatafile..."
cp "corpora/www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna" /dev/null
nice -n -20 ./Quicksort_UQWORDS_gcc_"$gcc_version".elf "corpora/www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna" 1
nice -n -20 ./Quicksort_UQWORDS_clang_"$clang_version".elf "corpora/www.ncbi.nlm.nih.gov_genome_guide_human_GRCh38_latest_genomic.fna" 1

sleep 5
echo "Buffering the testdatafile..."
cp "corpora/linuxmint-22.3-mate-64bit.iso" /dev/null
nice -n -20 ./Quicksort_UQWORDS_gcc_"$gcc_version".elf "corpora/linuxmint-22.3-mate-64bit.iso" 1
nice -n -20 ./Quicksort_UQWORDS_clang_"$clang_version".elf "corpora/linuxmint-22.3-mate-64bit.iso" 1

